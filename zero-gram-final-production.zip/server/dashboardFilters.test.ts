import { describe, expect, it } from "vitest";
import { filterDashboardRows } from "../shared/dashboardFilters";

const now = Date.parse("2026-08-25T12:00:00.000Z");
const rows = [
  { id: 1, payloadJson: '{"diagnosis":{"netScore":92},"measurement":{"ip":"10.0.0.1"}}', createdAt: now - 2 * 86400000 },
  { id: 2, payloadJson: '{"diagnosis":{"netScore":64},"measurement":{"mac":"AA:BB"}}', createdAt: now - 20 * 86400000 },
  { id: 3, payloadJson: '{"measurement":{"downloadMbps":12}}', createdAt: now - 3 * 86400000 },
];

describe("Dashboard advanced filters", () => {
  it("searches identifiers and payload details", () => {
    expect(filterDashboardRows(rows, { query: "10.0.0.1", scoreFilter: "all", sourceFilter: "all", timeFilter: "all", now }).map(row => row.id)).toEqual([1]);
  });

  it("filters by score band and source", () => {
    expect(filterDashboardRows(rows, { query: "", scoreFilter: "strong", sourceFilter: "scored", timeFilter: "all", now }).map(row => row.id)).toEqual([1]);
    expect(filterDashboardRows(rows, { query: "", scoreFilter: "all", sourceFilter: "raw", timeFilter: "all", now }).map(row => row.id)).toEqual([3]);
  });

  it("filters by a real time window", () => {
    expect(filterDashboardRows(rows, { query: "", scoreFilter: "all", sourceFilter: "all", timeFilter: "7", now }).map(row => row.id)).toEqual([1, 3]);
  });
});
