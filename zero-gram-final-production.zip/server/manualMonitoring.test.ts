import { describe, expect, it } from "vitest";
import {
  canRunManualMonitoring,
  manualMonitoringLabel,
  manualMonitoringStatusLabel,
} from "../shared/manualMonitoring";

describe("manual monitoring controls", () => {
  it("allows only a positive profile id while idle", () => {
    expect(canRunManualMonitoring(4, "idle")).toBe(true);
    expect(canRunManualMonitoring(0, "idle")).toBe(false);
    expect(canRunManualMonitoring(-2, "idle")).toBe(false);
    expect(canRunManualMonitoring(4, "running")).toBe(false);
    expect(canRunManualMonitoring(4, "success")).toBe(true);
    expect(canRunManualMonitoring(4, "idle", true)).toBe(false);
  });

  it("keeps the action label bilingual and state-aware", () => {
    expect(manualMonitoringLabel("idle", true)).toBe("شغّل الآن");
    expect(manualMonitoringLabel("running", true)).toBe("جارٍ الفحص");
    expect(manualMonitoringLabel("idle", false)).toBe("Run now");
    expect(manualMonitoringLabel("running", false)).toBe("Checking");
  });

  it("provides visible status labels for every state", () => {
    expect(manualMonitoringStatusLabel("idle", true)).toBe("جاهزة للتشغيل");
    expect(manualMonitoringStatusLabel("running", true)).toBe("قيد التشغيل");
    expect(manualMonitoringStatusLabel("success", false)).toBe("Completed");
    expect(manualMonitoringStatusLabel("failure", false)).toBe("Last check failed");
  });
});
