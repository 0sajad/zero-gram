import { describe, expect, it } from "vitest";
import {
  browserValue,
  capabilityStatus,
  compareMetric,
  qualityLabel,
  scoreQuality,
} from "../shared/browserIntelligence";

describe("browser intelligence contracts", () => {
  it("keeps unavailable values explicit instead of coercing them", () => {
    expect(browserValue(null, "Unavailable", "Browser API")).toEqual({
      value: null,
      state: "Unavailable",
      source: "Browser API",
    });
  });
  it("calculates a bounded quality score only from supplied metrics", () => {
    const score = scoreQuality({
      latencyMs: 45,
      jitterMs: 8,
      packetLossPercent: 2,
      downloadConsistency: 70,
    });
    expect(score).toBeGreaterThanOrEqual(0);
    expect(score).toBeLessThanOrEqual(100);
    expect(qualityLabel(score)).toBe("Fair");
  });
  it("compares real current and baseline metrics", () => {
    expect(compareMetric(120, 100)).toBe(20);
    expect(compareMetric(null, 100)).toBeNull();
    expect(compareMetric(10, 0)).toBeNull();
  });
  it("reports capability states without claiming restricted APIs", () => {
    expect(capabilityStatus(true)).toBe("Supported");
    expect(capabilityStatus(false)).toBe("Not Supported");
    expect(capabilityStatus(null)).toBe("Unavailable");
    expect(capabilityStatus(false, true)).toBe("Permission Required");
  });
});
