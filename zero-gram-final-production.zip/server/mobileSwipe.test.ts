import { describe, expect, it } from "vitest";
import { resolveMobileSwipe } from "../shared/mobileSwipe";

describe("mobile navigation swipe", () => {
  it("recognizes next and previous horizontal swipes", () => {
    expect(resolveMobileSwipe(200, 300, 100, 305)).toBe("next");
    expect(resolveMobileSwipe(100, 300, 200, 305)).toBe("previous");
  });
  it("ignores short and mostly vertical movement", () => {
    expect(resolveMobileSwipe(100, 300, 130, 302)).toBeNull();
    expect(resolveMobileSwipe(100, 300, 80, 360)).toBeNull();
  });
});
