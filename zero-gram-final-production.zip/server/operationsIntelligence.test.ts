import { describe, expect, it } from "vitest";
import {
  analyzeCapacity,
  analyzeReliability,
  detectAnomaly,
} from "../shared/operationsIntelligence";

describe("operations intelligence", () => {
  it("derives capacity metrics only from provided sourced points", () => {
    const result = analyzeCapacity(
      [
        { at: new Date("2026-01-01"), value: 20 },
        { at: new Date("2026-01-02"), value: 40 },
      ],
      100
    );
    expect(result).toMatchObject({
      current: 40,
      peak: 40,
      average: 30,
      utilizationPercent: 40,
      sampleCount: 2,
    });
  });
  it("does not produce capacity utilization without a declared capacity", () => {
    expect(
      analyzeCapacity([{ at: new Date(), value: 20 }], null).utilizationPercent
    ).toBeUndefined();
  });
  it("calculates observed check success and recovered outage duration from actual events", () => {
    const result = analyzeReliability([
      {
        state: "success" as const,
        checkedAt: new Date("2026-01-01T00:00:00Z"),
      },
      {
        state: "failure" as const,
        checkedAt: new Date("2026-01-01T00:10:00Z"),
      },
      {
        state: "success" as const,
        checkedAt: new Date("2026-01-01T00:15:00Z"),
      },
    ]);
    expect(result).toMatchObject({
      observedCheckSuccessPercent: 66.66666666666666,
      outageCount: 1,
      totalDowntimeMs: 300000,
      mttrMs: 300000,
    });
  });
  it("requires a sufficient historical baseline before reporting an anomaly", () => {
    expect(
      detectAnomaly(
        [
          { at: new Date("2026-01-01"), value: 20 },
          { at: new Date("2026-01-02"), value: 20 },
          { at: new Date("2026-01-03"), value: 180 },
        ],
        "latency"
      )
    ).toBeNull();
  });
  it("reports a large latest deviation with baseline evidence rather than a root cause", () => {
    const anomaly = detectAnomaly(
      [
        { at: new Date("2026-01-01"), value: 20 },
        { at: new Date("2026-01-02"), value: 22 },
        { at: new Date("2026-01-03"), value: 21 },
        { at: new Date("2026-01-04"), value: 180 },
      ],
      "latency"
    );
    expect(anomaly).toMatchObject({
      metric: "latency",
      latest: 180,
      baselineMedian: 21,
      confidence: "medium",
      evidenceCount: 3,
    });
  });
});
