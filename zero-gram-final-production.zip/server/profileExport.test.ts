import { describe, expect, it } from "vitest";
import { buildProfileExport } from "../shared/profileExport";

const data = {
  exportedAt: "2026-08-25T00:00:00.000Z",
  userName: "ZERO GRAM User",
  userEmail: null,
  status: "online" as const,
  avatarStoredLocally: false,
  storageScope: "current browser only",
  source: "ZERO GRAM Profile",
};

describe("profile export", () => {
  it("creates readable JSON with profile fields", () => {
    const output = buildProfileExport(data, "json");
    expect(JSON.parse(output)).toMatchObject({ userName: data.userName, status: "online" });
  });

  it("creates CSV with a header and escaped values", () => {
    const output = buildProfileExport(data, "csv");
    expect(output.split("\n")[0]).toBe("field,value");
    expect(output).toContain('userName,"ZERO GRAM User"');
    expect(output).toContain('userEmail,""');
  });
});
