import { describe, expect, it } from "vitest";
import {
  diagnosis,
  health,
  personality,
  roast,
  suspects,
  ticketFrom,
} from "../shared/networkFunLab";

describe("network fun lab evidence engine", () => {
  it("returns insufficient evidence when no metrics or symptoms exist", () => {
    expect(diagnosis([], {}).finalVerdict).toBe("Insufficient Evidence");
  });
  it("ranks DNS when its timing is measured high", () => {
    expect(suspects(["dns"], { dnsMs: 240 })[0].name).toBe("DNS");
  });
  it("keeps health unavailable without evidence", () => {
    expect(health({}).score).toBeNull();
    expect(health({}).disaster).toBeNull();
  });
  it("derives personality and roast from supplied measurements only", () => {
    expect(personality({ latencyMs: 150 })).toContain("Latency");
    expect(roast({ downloadMbps: 12, packageMbps: 100 })).toContain(
      "reflection"
    );
  });
  it("creates a bilingual ticket with safe initial checks", () => {
    const ticket = ticketFrom("النت يقطع كل شوي", "ar");
    expect(ticket.title).toBe("Intermittent Internet Connectivity");
    expect(ticket.checks).toContain("DNS");
  });
  it("creates an Iraqi ticket when Iraqi Arabic is selected", () => {
    const ticket = ticketFrom("النت يقطع كل شوي", "iq");
    expect(ticket.description).toContain("واضح النت");
    expect(ticket.checks).toContain("زمن الاستجابة");
  });
});
