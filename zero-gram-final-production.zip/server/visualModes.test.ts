import { describe, expect, it } from "vitest";
import { resolveConsoleVisualMode } from "../shared/visualModes";

describe("console visual modes", () => {
  it("keeps original mode controlled by the dark preference", () => {
    expect(
      resolveConsoleVisualMode({
        visualMode: "original",
        darkMode: false,
        systemTheme: false,
        systemPrefersDark: true,
      }).dark
    ).toBe(false);
  });

  it("forces the requested white, black, and color modes", () => {
    const base = { darkMode: false, systemTheme: false, systemPrefersDark: false };
    expect(resolveConsoleVisualMode({ ...base, visualMode: "white" }).dark).toBe(false);
    expect(resolveConsoleVisualMode({ ...base, visualMode: "black" }).dark).toBe(true);
    expect(resolveConsoleVisualMode({ ...base, visualMode: "color" }).dark).toBe(true);
  });

  it("uses the device preference only for original mode", () => {
    expect(
      resolveConsoleVisualMode({
        visualMode: "original",
        darkMode: false,
        systemTheme: true,
        systemPrefersDark: true,
      }).dark
    ).toBe(true);
    expect(
      resolveConsoleVisualMode({
        visualMode: "white",
        darkMode: false,
        systemTheme: true,
        systemPrefersDark: true,
      }).classes.light
    ).toBe(true);
  });
});
