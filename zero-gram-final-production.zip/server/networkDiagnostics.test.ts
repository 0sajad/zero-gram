import { describe, expect, it } from "vitest";
import {
  analyzeTechnicianInput,
  calculateNetScore,
  calculateSpeedConsistency,
  diagnoseConnection,
} from "../shared/networkDiagnostics";

describe("diagnoseConnection", () => {
  it("marks web jitter evidence as a warning with a safe step", () => {
    const diagnosis = diagnoseConnection({
      webLatencyMs: 180,
      jitterMs: 35,
      packetLossEstimate: 0,
      ttfbMs: 140,
    });
    expect(
      diagnosis.findings.find(finding => finding.id === "high-jitter")
    ).toMatchObject({ level: "warning", confidence: "high" });
    expect(diagnosis.netScore).toBeTypeOf("number");
  });
  it("does not synthesize a score when no metrics are provided", () => {
    const diagnosis = diagnoseConnection({});
    expect(diagnosis.netScore).toBeUndefined();
    expect(diagnosis.findings).toHaveLength(0);
  });
  it("classifies an otherwise healthy sourced session as very good", () => {
    const diagnosis = diagnoseConnection({
      webLatencyMs: 24,
      jitterMs: 2,
      packetLossEstimate: 0,
      ttfbMs: 55,
      downloadConsistencyPercent: 96,
      uploadConsistencyPercent: 94,
    });
    expect(diagnosis.quality).toBe("VERY GOOD");
  });
  it("adds a sourced download instability finding when actual sample consistency is low", () => {
    const diagnosis = diagnoseConnection({ downloadConsistencyPercent: 48 });
    expect(
      diagnosis.findings.find(finding => finding.id === "download-instability")
    ).toMatchObject({ level: "warning", confidence: "medium" });
  });
});

describe("analyzeTechnicianInput", () => {
  it("extracts only a visible PPPoE authentication pattern", () => {
    const result = analyzeTechnicianInput({
      rawLog: "pppoe authentication failed for user",
    });
    expect(result.some(finding => finding.id === "pppoe-auth")).toBe(true);
    expect(result.every(finding => finding.safeNextStep.length > 20)).toBe(
      true
    );
  });
  it("returns no findings without an actual reading or recognized log evidence", () => {
    expect(
      analyzeTechnicianInput({ rawLog: "interface ether1 linked" })
    ).toEqual([]);
  });
  it("keeps optical boundary evidence tied to the submitted value", () => {
    const result = analyzeTechnicianInput({ opticalRxDbm: -30.1 });
    expect(result[0]).toMatchObject({
      id: "low-optical-rx",
      level: "critical",
      source: "حقل ONT RX",
    });
    expect(result[0]?.evidence).toContain("-30.1");
  });
});

describe("metric boundaries", () => {
  it("does not calculate a score from non-finite values", () => {
    expect(
      calculateNetScore({
        webLatencyMs: Number.NaN,
        jitterMs: Number.POSITIVE_INFINITY,
      })
    ).toBeUndefined();
  });
  it("calculates consistency only from at least two actual samples", () => {
    expect(
      calculateSpeedConsistency([{ elapsedMs: 100, mbps: 50 }])
    ).toBeUndefined();
    expect(
      calculateSpeedConsistency([
        { elapsedMs: 100, mbps: 50 },
        { elapsedMs: 200, mbps: 50 },
      ])
    ).toBe(100);
  });
});
