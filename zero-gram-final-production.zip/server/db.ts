import { and, desc, eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { randomUUID } from "crypto";
import {
  attachments,
  auditLogs,
  InsertUser,
  monitoringEvents,
  monitoringProfiles,
  networkDevices,
  networkPops,
  networkSites,
  organizationMembers,
  organizations,
  subscribers,
  testResults,
  tickets,
  users,
} from "../drizzle/schema";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    _db = drizzle(process.env.DATABASE_URL);
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) return;
  const values: InsertUser = {
    openId: user.openId,
    name: user.name ?? null,
    email: user.email ?? null,
    loginMethod: user.loginMethod ?? null,
    lastSignedIn: new Date(),
  };
  await db
    .insert(users)
    .values(values)
    .onDuplicateKeyUpdate({
      set: {
        name: values.name,
        email: values.email,
        loginMethod: values.loginMethod,
        lastSignedIn: values.lastSignedIn,
      },
    });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  return (
    await db.select().from(users).where(eq(users.openId, openId)).limit(1)
  )[0];
}

export async function ensureOrganization(user: {
  id: number;
  name: string | null;
  openId: string;
}) {
  const db = await getDb();
  if (!db) throw new Error("قاعدة البيانات غير متاحة حاليًا.");
  const membership = (
    await db
      .select()
      .from(organizationMembers)
      .where(eq(organizationMembers.userId, user.id))
      .limit(1)
  )[0];
  if (membership) return membership.organizationId;
  const slug = `org-${user.openId.slice(0, 18)}-${randomUUID().slice(0, 8)}`;
  const result = await db
    .insert(organizations)
    .values({ name: user.name?.trim() || "ZERO GRAM Workspace", slug });
  const organizationId = Number(
    (result as unknown as [{ insertId: number }])[0].insertId
  );
  await db
    .insert(organizationMembers)
    .values({ organizationId, userId: user.id, role: "owner" });
  return organizationId;
}

export async function addAudit(
  organizationId: number,
  actorUserId: number,
  action: string,
  entityType: string,
  entityId?: string,
  detail?: unknown
) {
  const db = await getDb();
  if (!db) return;
  await db.insert(auditLogs).values({
    organizationId,
    actorUserId,
    action,
    entityType,
    entityId: entityId ?? null,
    detailJson: detail ? JSON.stringify(detail) : null,
  });
}

export async function listTestResults(organizationId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(testResults)
    .where(eq(testResults.organizationId, organizationId))
    .orderBy(desc(testResults.createdAt))
    .limit(40);
}

export async function listMonitorProfiles(organizationId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(monitoringProfiles)
    .where(eq(monitoringProfiles.organizationId, organizationId))
    .orderBy(desc(monitoringProfiles.updatedAt));
}

export async function listMonitorEvents(
  profileId: number,
  organizationId: number
) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(monitoringEvents)
    .where(
      and(
        eq(monitoringEvents.profileId, profileId),
        eq(monitoringEvents.organizationId, organizationId)
      )
    )
    .orderBy(desc(monitoringEvents.checkedAt))
    .limit(120);
}

export async function listOperations(organizationId: number) {
  const db = await getDb();
  if (!db)
    return {
      subscribers: [],
      sites: [],
      pops: [],
      devices: [],
      tickets: [],
      audit: [],
    };
  const [subscriberRows, siteRows, popRows, deviceRows, ticketRows, auditRows] =
    await Promise.all([
      db
        .select()
        .from(subscribers)
        .where(eq(subscribers.organizationId, organizationId))
        .orderBy(desc(subscribers.createdAt))
        .limit(60),
      db
        .select()
        .from(networkSites)
        .where(eq(networkSites.organizationId, organizationId))
        .orderBy(desc(networkSites.createdAt))
        .limit(60),
      db
        .select()
        .from(networkPops)
        .where(eq(networkPops.organizationId, organizationId))
        .orderBy(desc(networkPops.createdAt))
        .limit(60),
      db
        .select()
        .from(networkDevices)
        .where(eq(networkDevices.organizationId, organizationId))
        .orderBy(desc(networkDevices.createdAt))
        .limit(60),
      db
        .select()
        .from(tickets)
        .where(eq(tickets.organizationId, organizationId))
        .orderBy(desc(tickets.updatedAt))
        .limit(60),
      db
        .select()
        .from(auditLogs)
        .where(eq(auditLogs.organizationId, organizationId))
        .orderBy(desc(auditLogs.createdAt))
        .limit(60),
    ]);
  return {
    subscribers: subscriberRows,
    sites: siteRows,
    pops: popRows,
    devices: deviceRows,
    tickets: ticketRows,
    audit: auditRows,
  };
}

export {
  attachments,
  monitoringEvents,
  monitoringProfiles,
  networkDevices,
  networkPops,
  networkSites,
  subscribers,
  testResults,
  tickets,
};
