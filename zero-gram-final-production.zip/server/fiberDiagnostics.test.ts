import { describe, expect, it } from "vitest";
import {
  calculateHealth,
  detectOpticalTrend,
  detectServiceStabilityTrend,
  diagnoseFiberSignals,
  type FiberSignal,
} from "../shared/fiberDiagnostics";

const at = (daysAgo: number) => new Date(Date.now() - daysAgo * 86_400_000);

describe("Fiber/GPON diagnostic rules", () => {
  it("reports low optical RX as evidence, not a final physical diagnosis", () => {
    const findings = diagnoseFiberSignals([
      {
        metric: "optical_rx_dbm",
        value: -28.6,
        measuredAt: at(0),
        sourceLabel: "ONT export",
      },
    ]);
    expect(findings).toEqual(
      expect.arrayContaining([
        expect.objectContaining({
          id: "optical-rx-low",
          domain: "optical",
          level: "critical",
          confidence: "medium",
        }),
      ])
    );
    expect(findings[0]?.limitation).toMatch(/threshold/i);
  });

  it("preserves LOS and authentication as distinct evidence domains", () => {
    const findings = diagnoseFiberSignals([], {
      losState: "detected",
      authenticationStatus: "failed",
    });
    expect(findings.map(finding => finding.id)).toEqual(
      expect.arrayContaining(["los-detected", "auth-failed"])
    );
  });

  it("calculates health from available source-backed inputs without inventing Wi-Fi data", () => {
    const health = calculateHealth(
      [
        {
          metric: "packet_loss_percent",
          value: 5,
          measuredAt: at(0),
          sourceLabel: "HTTP session",
        },
      ],
      {},
      [{ negotiatedSpeedMbps: 100, crcErrors: 2 }],
      []
    );
    expect(health.overallScore).toBeLessThan(100);
    expect(health.wifiScore).toBeNull();
  });

  it("reports Ethernet errors and low negotiated speed as separate evidence", () => {
    const findings = diagnoseFiberSignals([], {}, [
      {
        label: "GE0/0/1",
        negotiatedSpeedMbps: 100,
        crcErrors: 4,
        interfaceErrors: 1,
        sourceLabel: "switch counter export",
      },
    ]);
    expect(findings.map(finding => finding.domain)).toEqual(
      expect.arrayContaining(["ethernet"])
    );
    expect(findings.map(finding => finding.id)).toEqual(
      expect.arrayContaining([
        "ethernet-errors-GE0/0/1",
        "ethernet-speed-GE0/0/1",
      ])
    );
    expect(
      findings.find(finding => finding.id === "ethernet-errors-GE0/0/1")
        ?.limitation
    ).toMatch(/cumulative/i);
  });

  it("reports stored Wi-Fi interference and failed service state without asserting a transmitter or final cause", () => {
    const findings = diagnoseFiberSignals(
      [],
      { serviceStatus: "failed" },
      [],
      [
        {
          ssid: "OPS-5G",
          signalDbm: -76,
          interferenceLevel: "high",
          sourceLabel: "controller export",
        },
      ]
    );
    expect(findings.map(finding => finding.id)).toEqual(
      expect.arrayContaining([
        "service-session-failed",
        "wifi-signal-OPS-5G",
        "wifi-interference-OPS-5G",
      ])
    );
    expect(
      findings.find(finding => finding.id === "wifi-interference-OPS-5G")
        ?.limitation
    ).toMatch(/does not identify/i);
  });

  it("reports sourced jitter, DNS, power, duplex and Wi-Fi density conditions as bounded evidence", () => {
    const findings = diagnoseFiberSignals(
      [
        {
          metric: "jitter_ms",
          value: 44,
          measuredAt: at(0),
          sourceLabel: "probe export",
        },
        {
          metric: "wifi_channel_utilization_percent",
          value: 88,
          measuredAt: at(0),
          sourceLabel: "controller export",
        },
        {
          metric: "wifi_client_count",
          value: 47,
          measuredAt: at(0),
          sourceLabel: "controller export",
        },
      ],
      { dnsStatus: "failed", powerState: "power_loss" },
      [{ label: "GE0/0/2", duplex: "half", sourceLabel: "switch export" }]
    );
    expect(findings.map(finding => finding.id)).toEqual(
      expect.arrayContaining([
        "jitter-high",
        "dns-state-failed",
        "power-state-failed",
        "ethernet-duplex-GE0/0/2",
        "wifi-channel-utilization",
        "wifi-client-density",
      ])
    );
    expect(
      findings.find(finding => finding.id === "jitter-high")?.limitation
    ).toMatch(/does not prove/i);
  });

  it("derives service stability from available operational domains without fabricating absent data", () => {
    const health = calculateHealth(
      [
        {
          metric: "optical_rx_dbm",
          value: -22,
          measuredAt: at(0),
          sourceLabel: "OLT export",
        },
      ],
      { authenticationStatus: "failed" }
    );
    expect(health.serviceStabilityScore).not.toBeNull();
    expect(health.serviceStabilityScore).toBeLessThan(100);
  });

  it("requires repeated stored events before emitting a service-stability prediction", () => {
    const events = [0, 1, 2].map(daysAgo => ({
      eventType: "link_flap",
      severity: "high",
      occurredAt: at(daysAgo),
      sourceLabel: "switch export",
    }));
    expect(detectServiceStabilityTrend(events)).toEqual(
      expect.arrayContaining([
        expect.objectContaining({ id: "service-stability-link_flap" }),
      ])
    );
    expect(detectServiceStabilityTrend(events.slice(0, 2))).toEqual([]);
  });

  it("requires three stored optical samples before an early-degradation warning", () => {
    const samples: FiberSignal[] = [
      {
        metric: "optical_rx_dbm",
        value: -22.1,
        measuredAt: at(5),
        sourceLabel: "OLT export",
      },
      {
        metric: "optical_rx_dbm",
        value: -22.4,
        measuredAt: at(3),
        sourceLabel: "OLT export",
      },
      {
        metric: "optical_rx_dbm",
        value: -22.9,
        measuredAt: at(0),
        sourceLabel: "OLT export",
      },
    ];
    expect(detectOpticalTrend(samples)).toEqual(
      expect.arrayContaining([
        expect.objectContaining({ id: "optical-degradation-trend" }),
      ])
    );
    expect(detectOpticalTrend(samples.slice(0, 2))).toEqual([]);
  });

  it("treats connector, splitter, splice and attenuation records as bounded optical evidence", () => {
    const findings = diagnoseFiberSignals([
      {
        metric: "connector_state",
        value: null,
        valueText: "sc_apc_mismatch",
        measuredAt: at(0),
        sourceLabel: "field record",
      },
      {
        metric: "splitter_state",
        value: null,
        valueText: "attention",
        measuredAt: at(0),
        sourceLabel: "ODN record",
      },
      {
        metric: "splice_loss_db",
        value: 0.42,
        measuredAt: at(0),
        sourceLabel: "OTDR record",
      },
      {
        metric: "fiber_attenuation_db_per_km",
        value: 0.47,
        measuredAt: at(0),
        sourceLabel: "OTDR record",
      },
    ]);
    expect(findings.map(finding => finding.id)).toEqual(
      expect.arrayContaining([
        "connector-state-attention",
        "splitter-state-attention",
        "splice-loss-attention",
        "fiber-attenuation-attention",
      ])
    );
    expect(
      findings.find(finding => finding.id === "connector-state-attention")
        ?.limitation
    ).toMatch(/does not prove/i);
  });
});
