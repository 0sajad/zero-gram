import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

function createContext(): TrpcContext {
  return {
    user: {
      id: 91,
      openId: "validation-user",
      name: "Validation User",
      email: "validation@example.com",
      loginMethod: "manus",
      role: "user",
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
    },
    req: { headers: {} } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

describe("tRPC input validation", () => {
  it("rejects a packet-loss value outside the physically valid percentage range", async () => {
    const caller = appRouter.createCaller(createContext());
    await expect(
      caller.network.saveResult({
        measurement: { packetLossEstimate: 101 },
        sources: [],
        limitations: [],
      })
    ).rejects.toMatchObject({ code: "BAD_REQUEST" });
  });

  it("rejects oversized measurement source text before persistence", async () => {
    const caller = appRouter.createCaller(createContext());
    await expect(
      caller.network.saveResult({
        measurement: {},
        sources: ["x".repeat(241)],
        limitations: [],
      })
    ).rejects.toMatchObject({ code: "BAD_REQUEST" });
  });

  it("rejects an invalid monitoring target before any network request is performed", async () => {
    const caller = appRouter.createCaller(createContext());
    await expect(
      caller.monitoring.create({
        label: "x",
        targetUrl: "not-a-url",
        intervalCron: "invalid",
        failureThreshold: 0,
        slaTargetPercent: 40,
      })
    ).rejects.toMatchObject({ code: "BAD_REQUEST" });
  });

  it("rejects malformed six-field monitoring schedules", async () => {
    const caller = appRouter.createCaller(createContext());
    await expect(
      caller.monitoring.create({
        label: "Valid label",
        targetUrl: "https://example.com",
        intervalCron: "0 * * * *",
        failureThreshold: 3,
        slaTargetPercent: 99,
      })
    ).rejects.toMatchObject({ code: "BAD_REQUEST" });
  });

  it("rejects non-positive team member identifiers before authorization logic", async () => {
    const caller = appRouter.createCaller(createContext());
    await expect(
      caller.team.updateRole({ memberId: 0, role: "operator" })
    ).rejects.toMatchObject({ code: "BAD_REQUEST" });
  });

  it("rejects an invite code shorter than the trusted minimum", async () => {
    const caller = appRouter.createCaller(createContext());
    await expect(
      caller.team.acceptInvite({ inviteCode: "too-short" })
    ).rejects.toMatchObject({ code: "BAD_REQUEST" });
  });

  it("rejects malformed Fiber import devices before any persistence is attempted", async () => {
    const caller = appRouter.createCaller(createContext());
    await expect(
      caller.fiber.importDeviceTelemetry({
        sourceName: "valid-source.csv",
        sourceType: "csv",
        devices: [{ label: "x", deviceType: "ont" }],
        telemetry: [],
      })
    ).rejects.toMatchObject({ code: "BAD_REQUEST" });
  });

  it("rejects a one-character global infrastructure search query", async () => {
    const caller = appRouter.createCaller(createContext());
    await expect(
      caller.fiber.globalSearch({ query: "x" })
    ).rejects.toMatchObject({ code: "BAD_REQUEST" });
  });

  it("rejects a GPON path that reuses a stage node", async () => {
    const caller = appRouter.createCaller(createContext());
    await expect(
      caller.fiber.addGponPath({
        oltNodeId: 1,
        ponNodeId: 1,
        splitterNodeId: 2,
        fiberNodeId: 3,
        ontNodeId: 4,
        clientNodeId: 5,
        sourceLabel: "network design export",
      })
    ).rejects.toMatchObject({ code: "BAD_REQUEST" });
  });

  it("rejects a MAC table record without a valid source-length address", async () => {
    const caller = appRouter.createCaller(createContext());
    await expect(
      caller.fiber.addMacTableEntry({
        deviceId: 1,
        macAddress: "x",
        sourceLabel: "switch export",
      })
    ).rejects.toMatchObject({ code: "BAD_REQUEST" });
  });

  it("rejects a monitoring policy without a traceable source reference", async () => {
    const caller = appRouter.createCaller(createContext());
    await expect(
      caller.fiber.saveMonitoringPolicy({
        opticalRxWarningDbm: -25,
        sourceLabel: "",
      })
    ).rejects.toMatchObject({ code: "BAD_REQUEST" });
  });

  it("rejects a company profile without a traceable sourced record", async () => {
    const caller = appRouter.createCaller(createContext());
    await expect(
      caller.networkContext.saveProfile({
        companyName: "Valid company",
        sourceLabel: "",
      })
    ).rejects.toMatchObject({ code: "BAD_REQUEST" });
  });

  it("rejects a package whose expected download ceiling is below its floor", async () => {
    const caller = appRouter.createCaller(createContext());
    await expect(
      caller.networkContext.addPackage({
        label: "100 Mbps",
        expectedDownloadMinMbps: 90,
        expectedDownloadMaxMbps: 80,
        sourceLabel: "service contract",
      })
    ).rejects.toMatchObject({ code: "BAD_REQUEST" });
  });

  it("rejects an empty capacity snapshot before persistence", async () => {
    const caller = appRouter.createCaller(createContext());
    await expect(
      caller.networkContext.addCapacitySnapshot({
        sourceLabel: "NOC capacity export",
        measuredAt: new Date(),
      })
    ).rejects.toMatchObject({ code: "BAD_REQUEST" });
  });
});
