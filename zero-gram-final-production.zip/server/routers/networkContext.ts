import { TRPCError } from "@trpc/server";
import { desc, eq } from "drizzle-orm";
import { z } from "zod";
import {
  capacitySnapshots,
  networkDevices,
  networkIdentities,
  networkPackages,
  networkSites,
  ontUnits,
  organizationProfiles,
  subscribers,
} from "../../drizzle/schema";
import { addAudit, ensureOrganization, getDb } from "../db";
import { protectedProcedure, router } from "../_core/trpc";

const source = z.string().trim().min(2).max(160);
const observedAt = z.coerce.date().optional();
const nullable = <T>(value: T | undefined) => value ?? null;
const requireDb = async () => {
  const db = await getDb();
  if (!db)
    throw new TRPCError({
      code: "INTERNAL_SERVER_ERROR",
      message: "قاعدة البيانات غير متاحة حاليًا.",
    });
  return db;
};
const insertId = (result: unknown) =>
  Number((result as unknown as [{ insertId: number }])[0].insertId);

const profileInput = z.object({
  companyName: z.string().trim().min(2).max(180),
  logoUrl: z.string().trim().url().max(2048).optional(),
  description: z.string().trim().max(10_000).optional(),
  networkType: z.string().trim().max(120).optional(),
  declaredUserCount: z.number().int().nonnegative().max(100_000_000).optional(),
  declaredBranchCount: z.number().int().nonnegative().max(100_000).optional(),
  totalBandwidthMbps: z.number().positive().max(100_000_000).optional(),
  capacityWarningPercent: z.number().int().min(1).max(100).optional(),
  nocInformation: z.string().trim().max(10_000).optional(),
  technicalSupportInformation: z.string().trim().max(10_000).optional(),
  contactInformation: z.string().trim().max(10_000).optional(),
  maintenanceInformation: z.string().trim().max(10_000).optional(),
  sourceLabel: source,
  sourceObservedAt: observedAt,
});
const identityInput = z.object({
  siteId: z.number().int().positive().optional(),
  label: z.string().trim().min(2).max(180),
  isPrimary: z.boolean().optional(),
  ispName: z.string().trim().max(180).optional(),
  asn: z.string().trim().max(80).optional(),
  asName: z.string().trim().max(255).optional(),
  organizationName: z.string().trim().max(255).optional(),
  publicIp: z.string().trim().max(128).optional(),
  ipv4Status: z.string().trim().max(60).optional(),
  ipv6Status: z.string().trim().max(60).optional(),
  ispDomain: z.string().trim().max(255).optional(),
  networkPrefix: z.string().trim().max(128).optional(),
  country: z.string().trim().max(120).optional(),
  region: z.string().trim().max(160).optional(),
  city: z.string().trim().max(160).optional(),
  hostname: z.string().trim().max(255).optional(),
  reverseDns: z.string().trim().max(255).optional(),
  connectionType: z.string().trim().max(120).optional(),
  detectedNetwork: z.string().trim().max(255).optional(),
  networkProvider: z.string().trim().max(255).optional(),
  sourceLabel: source,
  observedAt,
});
const packageInput = z
  .object({
    label: z.string().trim().min(2).max(180),
    downloadMbps: z.number().positive().max(100_000_000).optional(),
    uploadMbps: z.number().positive().max(100_000_000).optional(),
    expectedDownloadMinMbps: z
      .number()
      .nonnegative()
      .max(100_000_000)
      .optional(),
    expectedDownloadMaxMbps: z
      .number()
      .nonnegative()
      .max(100_000_000)
      .optional(),
    expectedUploadMinMbps: z.number().nonnegative().max(100_000_000).optional(),
    expectedUploadMaxMbps: z.number().nonnegative().max(100_000_000).optional(),
    sourceLabel: source,
    observedAt,
  })
  .superRefine((input, context) => {
    if (
      input.expectedDownloadMinMbps !== undefined &&
      input.expectedDownloadMaxMbps !== undefined &&
      input.expectedDownloadMinMbps > input.expectedDownloadMaxMbps
    )
      context.addIssue({
        code: "custom",
        path: ["expectedDownloadMaxMbps"],
        message:
          "الحد الأعلى للتنزيل يجب أن يكون أكبر من أو يساوي الحد الأدنى.",
      });
    if (
      input.expectedUploadMinMbps !== undefined &&
      input.expectedUploadMaxMbps !== undefined &&
      input.expectedUploadMinMbps > input.expectedUploadMaxMbps
    )
      context.addIssue({
        code: "custom",
        path: ["expectedUploadMaxMbps"],
        message: "الحد الأعلى للرفع يجب أن يكون أكبر من أو يساوي الحد الأدنى.",
      });
  });
const capacityInput = z
  .object({
    currentUsageMbps: z.number().nonnegative().max(100_000_000).optional(),
    peakUsageMbps: z.number().nonnegative().max(100_000_000).optional(),
    averageUsageMbps: z.number().nonnegative().max(100_000_000).optional(),
    peakWindow: z.string().trim().max(160).optional(),
    sourceLabel: source,
    measuredAt: z.coerce.date(),
  })
  .refine(
    input =>
      input.currentUsageMbps !== undefined ||
      input.peakUsageMbps !== undefined ||
      input.averageUsageMbps !== undefined,
    { message: "يلزم إدخال استخدام حالي أو ذروة أو متوسط واحد على الأقل." }
  );

export const networkContextRouter = router({
  overview: protectedProcedure.query(async ({ ctx }) => {
    const organizationId = await ensureOrganization(ctx.user);
    const db = await requireDb();
    const [
      profileRows,
      identities,
      packages,
      snapshots,
      devices,
      onts,
      users,
      sites,
    ] = await Promise.all([
      db
        .select()
        .from(organizationProfiles)
        .where(eq(organizationProfiles.organizationId, organizationId))
        .limit(1),
      db
        .select()
        .from(networkIdentities)
        .where(eq(networkIdentities.organizationId, organizationId))
        .orderBy(
          desc(networkIdentities.isPrimary),
          desc(networkIdentities.observedAt)
        )
        .limit(50),
      db
        .select()
        .from(networkPackages)
        .where(eq(networkPackages.organizationId, organizationId))
        .orderBy(desc(networkPackages.observedAt))
        .limit(100),
      db
        .select()
        .from(capacitySnapshots)
        .where(eq(capacitySnapshots.organizationId, organizationId))
        .orderBy(desc(capacitySnapshots.measuredAt))
        .limit(180),
      db
        .select({
          id: networkDevices.id,
          deviceType: networkDevices.deviceType,
        })
        .from(networkDevices)
        .where(eq(networkDevices.organizationId, organizationId))
        .limit(10_000),
      db
        .select({ id: ontUnits.id })
        .from(ontUnits)
        .where(eq(ontUnits.organizationId, organizationId))
        .limit(100_000),
      db
        .select({ id: subscribers.id })
        .from(subscribers)
        .where(eq(subscribers.organizationId, organizationId))
        .limit(100_000),
      db
        .select({ id: networkSites.id })
        .from(networkSites)
        .where(eq(networkSites.organizationId, organizationId))
        .limit(100_000),
    ]);
    const profile = profileRows[0] ?? null;
    const latestCapacity = snapshots[0] ?? null;
    const totalBandwidthMbps = profile?.totalBandwidthMbps ?? null;
    const currentUsageMbps = latestCapacity?.currentUsageMbps ?? null;
    const utilizationPercent =
      totalBandwidthMbps && currentUsageMbps !== null
        ? (currentUsageMbps / totalBandwidthMbps) * 100
        : null;
    const oltCount = devices.filter(
      device => device.deviceType.toLowerCase() === "olt"
    ).length;
    return {
      profile,
      identities,
      packages,
      capacitySnapshots: snapshots,
      actualCounts: {
        devices: devices.length,
        olts: oltCount,
        onts: onts.length,
        subscribers: users.length,
        sites: sites.length,
      },
      capacity: {
        totalBandwidthMbps,
        currentUsageMbps,
        utilizationPercent,
        warningPercent: profile?.capacityWarningPercent ?? null,
        latestMeasuredAt: latestCapacity?.measuredAt ?? null,
      },
    };
  }),
  saveProfile: protectedProcedure
    .input(profileInput)
    .mutation(async ({ ctx, input }) => {
      const organizationId = await ensureOrganization(ctx.user);
      const db = await requireDb();
      const values = {
        organizationId,
        ...input,
        logoUrl: nullable(input.logoUrl),
        description: nullable(input.description),
        networkType: nullable(input.networkType),
        declaredUserCount: nullable(input.declaredUserCount),
        declaredBranchCount: nullable(input.declaredBranchCount),
        totalBandwidthMbps: nullable(input.totalBandwidthMbps),
        capacityWarningPercent: nullable(input.capacityWarningPercent),
        nocInformation: nullable(input.nocInformation),
        technicalSupportInformation: nullable(
          input.technicalSupportInformation
        ),
        contactInformation: nullable(input.contactInformation),
        maintenanceInformation: nullable(input.maintenanceInformation),
        sourceObservedAt: input.sourceObservedAt ?? new Date(),
      };
      await db
        .insert(organizationProfiles)
        .values(values)
        .onDuplicateKeyUpdate({
          set: { ...values, organizationId: undefined },
        });
      await addAudit(
        organizationId,
        ctx.user.id,
        "network_context.profile.saved",
        "organization_profile",
        String(organizationId),
        { source: input.sourceLabel }
      );
      return { success: true };
    }),
  addIdentity: protectedProcedure
    .input(identityInput)
    .mutation(async ({ ctx, input }) => {
      const organizationId = await ensureOrganization(ctx.user);
      const db = await requireDb();
      if (input.isPrimary)
        await db
          .update(networkIdentities)
          .set({ isPrimary: false })
          .where(eq(networkIdentities.organizationId, organizationId));
      const result = await db.insert(networkIdentities).values({
        organizationId,
        ...input,
        siteId: nullable(input.siteId),
        isPrimary: input.isPrimary ?? false,
        ispName: nullable(input.ispName),
        asn: nullable(input.asn),
        asName: nullable(input.asName),
        organizationName: nullable(input.organizationName),
        publicIp: nullable(input.publicIp),
        ipv4Status: nullable(input.ipv4Status),
        ipv6Status: nullable(input.ipv6Status),
        ispDomain: nullable(input.ispDomain),
        networkPrefix: nullable(input.networkPrefix),
        country: nullable(input.country),
        region: nullable(input.region),
        city: nullable(input.city),
        hostname: nullable(input.hostname),
        reverseDns: nullable(input.reverseDns),
        connectionType: nullable(input.connectionType),
        detectedNetwork: nullable(input.detectedNetwork),
        networkProvider: nullable(input.networkProvider),
        observedAt: input.observedAt ?? new Date(),
      });
      const identityId = insertId(result);
      await addAudit(
        organizationId,
        ctx.user.id,
        "network_context.identity.created",
        "network_identity",
        String(identityId),
        { source: input.sourceLabel }
      );
      return { identityId };
    }),
  addPackage: protectedProcedure
    .input(packageInput)
    .mutation(async ({ ctx, input }) => {
      const organizationId = await ensureOrganization(ctx.user);
      const db = await requireDb();
      const result = await db.insert(networkPackages).values({
        organizationId,
        ...input,
        downloadMbps: nullable(input.downloadMbps),
        uploadMbps: nullable(input.uploadMbps),
        expectedDownloadMinMbps: nullable(input.expectedDownloadMinMbps),
        expectedDownloadMaxMbps: nullable(input.expectedDownloadMaxMbps),
        expectedUploadMinMbps: nullable(input.expectedUploadMinMbps),
        expectedUploadMaxMbps: nullable(input.expectedUploadMaxMbps),
        observedAt: input.observedAt ?? new Date(),
      });
      const packageId = insertId(result);
      await addAudit(
        organizationId,
        ctx.user.id,
        "network_context.package.created",
        "network_package",
        String(packageId),
        { source: input.sourceLabel }
      );
      return { packageId };
    }),
  addCapacitySnapshot: protectedProcedure
    .input(capacityInput)
    .mutation(async ({ ctx, input }) => {
      const organizationId = await ensureOrganization(ctx.user);
      const db = await requireDb();
      const result = await db.insert(capacitySnapshots).values({
        organizationId,
        ...input,
        currentUsageMbps: nullable(input.currentUsageMbps),
        peakUsageMbps: nullable(input.peakUsageMbps),
        averageUsageMbps: nullable(input.averageUsageMbps),
        peakWindow: nullable(input.peakWindow),
      });
      const capacitySnapshotId = insertId(result);
      await addAudit(
        organizationId,
        ctx.user.id,
        "network_context.capacity.recorded",
        "capacity_snapshot",
        String(capacitySnapshotId),
        { source: input.sourceLabel }
      );
      return { capacitySnapshotId };
    }),
});
