import { TRPCError } from "@trpc/server";
import { and, eq } from "drizzle-orm";
import { randomUUID } from "crypto";
import { z } from "zod";
import {
  organizationInvitations,
  organizationMembers,
  users,
} from "../../drizzle/schema";
import { addAudit, ensureOrganization, getDb } from "../db";
import { protectedProcedure, router } from "../_core/trpc";

async function requireOwner(user: {
  id: number;
  name: string | null;
  openId: string;
}) {
  const organizationId = await ensureOrganization(user);
  const db = await getDb();
  if (!db)
    throw new TRPCError({
      code: "INTERNAL_SERVER_ERROR",
      message: "قاعدة البيانات غير متاحة.",
    });
  const membership = (
    await db
      .select()
      .from(organizationMembers)
      .where(
        and(
          eq(organizationMembers.organizationId, organizationId),
          eq(organizationMembers.userId, user.id)
        )
      )
      .limit(1)
  )[0];
  if (!membership || !["owner", "admin"].includes(membership.role))
    throw new TRPCError({
      code: "FORBIDDEN",
      message: "لا تملك صلاحية إدارة أعضاء المؤسسة.",
    });
  return { db, organizationId };
}

export const teamRouter = router({
  overview: protectedProcedure.query(async ({ ctx }) => {
    const organizationId = await ensureOrganization(ctx.user);
    const db = await getDb();
    if (!db) return { members: [], invitations: [] };
    const members = await db
      .select({
        id: organizationMembers.id,
        role: organizationMembers.role,
        createdAt: organizationMembers.createdAt,
        name: users.name,
        email: users.email,
      })
      .from(organizationMembers)
      .innerJoin(users, eq(organizationMembers.userId, users.id))
      .where(eq(organizationMembers.organizationId, organizationId));
    const invitations = await db
      .select()
      .from(organizationInvitations)
      .where(eq(organizationInvitations.organizationId, organizationId));
    return { members, invitations };
  }),
  createInvite: protectedProcedure
    .input(
      z.object({
        email: z.string().email().max(320),
        role: z.enum(["admin", "operator", "viewer"]),
        origin: z.string().url(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const { db, organizationId } = await requireOwner(ctx.user);
      const inviteCode = randomUUID().replaceAll("-", "");
      const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);
      const result = await db.insert(organizationInvitations).values({
        organizationId,
        email: input.email.trim().toLowerCase(),
        role: input.role,
        inviteCode,
        invitedByUserId: ctx.user.id,
        expiresAt,
      });
      const id = Number(
        (result as unknown as [{ insertId: number }])[0].insertId
      );
      await addAudit(
        organizationId,
        ctx.user.id,
        "team.invite_created",
        "invitation",
        String(id),
        { email: input.email, role: input.role }
      );
      return {
        id,
        inviteUrl: `${new URL(input.origin).origin}/invite/${inviteCode}`,
        expiresAt,
      };
    }),
  updateRole: protectedProcedure
    .input(
      z.object({
        memberId: z.number().int().positive(),
        role: z.enum(["admin", "operator", "viewer"]),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const { db, organizationId } = await requireOwner(ctx.user);
      const member = (
        await db
          .select()
          .from(organizationMembers)
          .where(
            and(
              eq(organizationMembers.id, input.memberId),
              eq(organizationMembers.organizationId, organizationId)
            )
          )
          .limit(1)
      )[0];
      if (!member)
        throw new TRPCError({ code: "NOT_FOUND", message: "العضو غير موجود." });
      if (member.role === "owner")
        throw new TRPCError({
          code: "FORBIDDEN",
          message: "لا يمكن تغيير دور مالك المؤسسة من هذه الواجهة.",
        });
      await db
        .update(organizationMembers)
        .set({ role: input.role })
        .where(eq(organizationMembers.id, input.memberId));
      await addAudit(
        organizationId,
        ctx.user.id,
        "team.role_updated",
        "member",
        String(member.id),
        { previousRole: member.role, role: input.role }
      );
      return { ok: true };
    }),
  acceptInvite: protectedProcedure
    .input(z.object({ inviteCode: z.string().min(16).max(96) }))
    .mutation(async ({ ctx, input }) => {
      if (!ctx.user.email)
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: "يتطلب قبول الدعوة حسابًا ذا بريد إلكتروني موثق.",
        });
      const db = await getDb();
      if (!db)
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "قاعدة البيانات غير متاحة.",
        });
      const invitation = (
        await db
          .select()
          .from(organizationInvitations)
          .where(eq(organizationInvitations.inviteCode, input.inviteCode))
          .limit(1)
      )[0];
      if (
        !invitation ||
        invitation.status !== "pending" ||
        invitation.expiresAt.getTime() < Date.now()
      )
        throw new TRPCError({
          code: "NOT_FOUND",
          message: "الدعوة غير صالحة أو انتهت صلاحيتها.",
        });
      if (invitation.email.toLowerCase() !== ctx.user.email.toLowerCase())
        throw new TRPCError({
          code: "FORBIDDEN",
          message: "يجب تسجيل الدخول بالبريد الذي استلم الدعوة.",
        });
      const existing = (
        await db
          .select()
          .from(organizationMembers)
          .where(
            and(
              eq(organizationMembers.organizationId, invitation.organizationId),
              eq(organizationMembers.userId, ctx.user.id)
            )
          )
          .limit(1)
      )[0];
      if (!existing)
        await db.insert(organizationMembers).values({
          organizationId: invitation.organizationId,
          userId: ctx.user.id,
          role: invitation.role,
        });
      await db
        .update(organizationInvitations)
        .set({ status: "accepted", acceptedAt: new Date() })
        .where(eq(organizationInvitations.id, invitation.id));
      await addAudit(
        invitation.organizationId,
        ctx.user.id,
        "team.invite_accepted",
        "invitation",
        String(invitation.id)
      );
      return { organizationId: invitation.organizationId };
    }),
});
