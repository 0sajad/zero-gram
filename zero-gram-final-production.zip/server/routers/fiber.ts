import { TRPCError } from "@trpc/server";
import { and, desc, eq, gte, inArray, like, lte, or } from "drizzle-orm";
import { z } from "zod";
import { addAudit, ensureOrganization, getDb } from "../db";
import {
  alerts,
  deviceIpAddresses,
  ethernetPorts,
  fiberMonitoringPolicies,
  healthSnapshots,
  importBatches,
  macTableEntries,
  networkDevices,
  ontUnits,
  operationalEvents,
  ponPorts,
  serviceSessions,
  subscribers,
  telemetrySamples,
  topologyEdges,
  topologyNodes,
  wifiClients,
  wifiNetworks,
} from "../../drizzle/schema";
import {
  calculateHealth,
  detectOpticalTrend,
  detectServiceStabilityTrend,
  diagnoseFiberSignals,
  type FiberSignal,
} from "../../shared/fiberDiagnostics";
import { protectedProcedure, router } from "../_core/trpc";

const source = z.string().trim().min(2).max(160);
const id = z.number().int().positive();
const nowOrDate = z.coerce.date().optional();
const deviceInput = z.object({
  label: z.string().trim().min(2).max(160),
  deviceType: z.string().trim().min(2).max(80),
  siteId: id.optional(),
  managementReference: z.string().trim().max(255).optional(),
  vendor: z.string().trim().max(120).optional(),
  model: z.string().trim().max(160).optional(),
  serialNumber: z.string().trim().max(160).optional(),
  macAddress: z.string().trim().max(32).optional(),
  hostname: z.string().trim().max(255).optional(),
  managementIpv4: z.string().trim().max(64).optional(),
  managementIpv6: z.string().trim().max(128).optional(),
  firmwareVersion: z.string().trim().max(160).optional(),
  uptimeSeconds: z.number().int().nonnegative().optional(),
  linkStatus: z.string().trim().max(40).optional(),
  connectionStatus: z.string().trim().max(40).optional(),
  sourceLabel: source.optional(),
  sourceObservedAt: nowOrDate,
});

const nullable = <T>(value: T | undefined) => value ?? null;
const requireDb = async () => {
  const db = await getDb();
  if (!db)
    throw new TRPCError({
      code: "INTERNAL_SERVER_ERROR",
      message: "قاعدة البيانات غير متاحة حاليًا.",
    });
  return db;
};
const insertId = (result: unknown) =>
  Number((result as unknown as [{ insertId: number }])[0].insertId);

export const fiberRouter = router({
  overview: protectedProcedure.query(async ({ ctx }) => {
    const organizationId = await ensureOrganization(ctx.user);
    const db = await requireDb();
    const [devices, ports, onts, openAlerts, events, nodes, edges] =
      await Promise.all([
        db
          .select()
          .from(networkDevices)
          .where(eq(networkDevices.organizationId, organizationId))
          .orderBy(desc(networkDevices.createdAt))
          .limit(200),
        db
          .select()
          .from(ponPorts)
          .where(eq(ponPorts.organizationId, organizationId))
          .limit(250),
        db
          .select()
          .from(ontUnits)
          .where(eq(ontUnits.organizationId, organizationId))
          .limit(500),
        db
          .select()
          .from(alerts)
          .where(
            and(
              eq(alerts.organizationId, organizationId),
              eq(alerts.status, "open")
            )
          )
          .orderBy(desc(alerts.openedAt))
          .limit(100),
        db
          .select()
          .from(operationalEvents)
          .where(eq(operationalEvents.organizationId, organizationId))
          .orderBy(desc(operationalEvents.occurredAt))
          .limit(150),
        db
          .select()
          .from(topologyNodes)
          .where(eq(topologyNodes.organizationId, organizationId))
          .limit(300),
        db
          .select()
          .from(topologyEdges)
          .where(eq(topologyEdges.organizationId, organizationId))
          .limit(400),
      ]);
    return { devices, ports, onts, openAlerts, events, nodes, edges };
  }),
  reportData: protectedProcedure
    .input(z.object({ days: z.number().int().min(1).max(365).default(30) }))
    .query(async ({ ctx, input }) => {
      const organizationId = await ensureOrganization(ctx.user);
      const db = await requireDb();
      const from = new Date(Date.now() - input.days * 86_400_000);
      const [devices, telemetry, snapshots, events, alertRows, nodes, edges] =
        await Promise.all([
          db
            .select()
            .from(networkDevices)
            .where(eq(networkDevices.organizationId, organizationId))
            .limit(1000),
          db
            .select()
            .from(telemetrySamples)
            .where(
              and(
                eq(telemetrySamples.organizationId, organizationId),
                gte(telemetrySamples.measuredAt, from)
              )
            )
            .orderBy(desc(telemetrySamples.measuredAt))
            .limit(20000),
          db
            .select()
            .from(healthSnapshots)
            .where(
              and(
                eq(healthSnapshots.organizationId, organizationId),
                gte(healthSnapshots.calculatedAt, from)
              )
            )
            .orderBy(desc(healthSnapshots.calculatedAt))
            .limit(5000),
          db
            .select()
            .from(operationalEvents)
            .where(
              and(
                eq(operationalEvents.organizationId, organizationId),
                gte(operationalEvents.occurredAt, from)
              )
            )
            .orderBy(desc(operationalEvents.occurredAt))
            .limit(10000),
          db
            .select()
            .from(alerts)
            .where(
              and(
                eq(alerts.organizationId, organizationId),
                gte(alerts.openedAt, from)
              )
            )
            .orderBy(desc(alerts.openedAt))
            .limit(10000),
          db
            .select()
            .from(topologyNodes)
            .where(eq(topologyNodes.organizationId, organizationId))
            .limit(2000),
          db
            .select()
            .from(topologyEdges)
            .where(eq(topologyEdges.organizationId, organizationId))
            .limit(4000),
        ]);
      return {
        from,
        devices,
        telemetry,
        snapshots,
        events,
        alerts: alertRows,
        nodes,
        edges,
      };
    }),
  createDevice: protectedProcedure
    .input(deviceInput)
    .mutation(async ({ ctx, input }) => {
      const organizationId = await ensureOrganization(ctx.user);
      const db = await requireDb();
      const result = await db.insert(networkDevices).values({
        organizationId,
        ...input,
        siteId: nullable(input.siteId),
        managementReference: nullable(input.managementReference),
        vendor: nullable(input.vendor),
        model: nullable(input.model),
        serialNumber: nullable(input.serialNumber),
        macAddress: nullable(input.macAddress),
        hostname: nullable(input.hostname),
        managementIpv4: nullable(input.managementIpv4),
        managementIpv6: nullable(input.managementIpv6),
        firmwareVersion: nullable(input.firmwareVersion),
        uptimeSeconds: nullable(input.uptimeSeconds),
        linkStatus: nullable(input.linkStatus),
        connectionStatus: nullable(input.connectionStatus),
        sourceLabel: nullable(input.sourceLabel),
        sourceObservedAt: nullable(input.sourceObservedAt),
      });
      const deviceId = insertId(result);
      await addAudit(
        organizationId,
        ctx.user.id,
        "fiber.device.created",
        "device",
        String(deviceId),
        { source: input.sourceLabel ?? "manual" }
      );
      return { deviceId };
    }),
  updateDevice: protectedProcedure
    .input(z.object({ deviceId: id, patch: deviceInput.partial() }))
    .mutation(async ({ ctx, input }) => {
      const organizationId = await ensureOrganization(ctx.user);
      const db = await requireDb();
      const found = (
        await db
          .select({ id: networkDevices.id })
          .from(networkDevices)
          .where(
            and(
              eq(networkDevices.id, input.deviceId),
              eq(networkDevices.organizationId, organizationId)
            )
          )
          .limit(1)
      )[0];
      if (!found) throw new TRPCError({ code: "NOT_FOUND" });
      await db
        .update(networkDevices)
        .set(input.patch)
        .where(eq(networkDevices.id, input.deviceId));
      await addAudit(
        organizationId,
        ctx.user.id,
        "fiber.device.updated",
        "device",
        String(input.deviceId),
        { fields: Object.keys(input.patch) }
      );
      return { success: true };
    }),
  addPonPort: protectedProcedure
    .input(
      z.object({
        oltDeviceId: id,
        label: z.string().min(1).max(120),
        ponIndex: z.string().max(80).optional(),
        administrativeStatus: z.string().max(40).optional(),
        operationalStatus: z.string().max(40).optional(),
        maxOnts: z.number().int().positive().max(4096).optional(),
        sourceLabel: source.optional(),
        sourceObservedAt: nowOrDate,
      })
    )
    .mutation(async ({ ctx, input }) => {
      const organizationId = await ensureOrganization(ctx.user);
      const db = await requireDb();
      const result = await db.insert(ponPorts).values({
        organizationId,
        ...input,
        ponIndex: nullable(input.ponIndex),
        administrativeStatus: nullable(input.administrativeStatus),
        operationalStatus: nullable(input.operationalStatus),
        maxOnts: nullable(input.maxOnts),
        sourceLabel: nullable(input.sourceLabel),
        sourceObservedAt: nullable(input.sourceObservedAt),
      });
      const ponPortId = insertId(result);
      await addAudit(
        organizationId,
        ctx.user.id,
        "fiber.pon.created",
        "pon_port",
        String(ponPortId)
      );
      return { ponPortId };
    }),
  addOnt: protectedProcedure
    .input(
      z.object({
        deviceId: id,
        ponPortId: id.optional(),
        subscriberId: id.optional(),
        onuId: z.string().max(160).optional(),
        authenticationStatus: z.string().max(60).optional(),
        ponStatus: z.string().max(60).optional(),
        losState: z.string().max(40).optional(),
        lofState: z.string().max(40).optional(),
        dyingGaspState: z.string().max(40).optional(),
        opticalDistanceKm: z.number().nonnegative().max(1000).optional(),
        pppoeUsername: z.string().max(180).optional(),
        vlanId: z.string().max(80).optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const organizationId = await ensureOrganization(ctx.user);
      const db = await requireDb();
      const result = await db.insert(ontUnits).values({
        organizationId,
        ...input,
        ponPortId: nullable(input.ponPortId),
        subscriberId: nullable(input.subscriberId),
        onuId: nullable(input.onuId),
        authenticationStatus: nullable(input.authenticationStatus),
        ponStatus: nullable(input.ponStatus),
        losState: nullable(input.losState),
        lofState: nullable(input.lofState),
        dyingGaspState: nullable(input.dyingGaspState),
        opticalDistanceKm: nullable(input.opticalDistanceKm),
        pppoeUsername: nullable(input.pppoeUsername),
        vlanId: nullable(input.vlanId),
      });
      const ontUnitId = insertId(result);
      await addAudit(
        organizationId,
        ctx.user.id,
        "fiber.ont.created",
        "ont_unit",
        String(ontUnitId)
      );
      return { ontUnitId };
    }),
  addIpAddress: protectedProcedure
    .input(
      z.object({
        deviceId: id,
        address: z.string().min(2).max(128),
        family: z.enum(["ipv4", "ipv6"]),
        scope: z.enum([
          "public",
          "private",
          "local",
          "gateway",
          "dns",
          "management",
          "client",
        ]),
        hostname: z.string().max(255).optional(),
        sourceLabel: source.optional(),
        observedAt: nowOrDate,
      })
    )
    .mutation(async ({ ctx, input }) => {
      const organizationId = await ensureOrganization(ctx.user);
      const db = await requireDb();
      const result = await db.insert(deviceIpAddresses).values({
        organizationId,
        ...input,
        hostname: nullable(input.hostname),
        sourceLabel: nullable(input.sourceLabel),
        observedAt: input.observedAt ?? new Date(),
      });
      return { ipId: insertId(result) };
    }),
  addMacTableEntry: protectedProcedure
    .input(
      z.object({
        deviceId: id,
        macAddress: z.string().trim().min(2).max(32),
        ipAddress: z.string().trim().max(128).optional(),
        vlanId: z.string().trim().max(80).optional(),
        interfaceLabel: z.string().trim().max(120).optional(),
        hostname: z.string().trim().max(255).optional(),
        sourceLabel: source,
        observedAt: z.coerce.date().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const organizationId = await ensureOrganization(ctx.user);
      const db = await requireDb();
      const result = await db.insert(macTableEntries).values({
        organizationId,
        ...input,
        ipAddress: nullable(input.ipAddress),
        vlanId: nullable(input.vlanId),
        interfaceLabel: nullable(input.interfaceLabel),
        hostname: nullable(input.hostname),
        observedAt: input.observedAt ?? new Date(),
      });
      return { macEntryId: insertId(result) };
    }),
  listMacTableEntries: protectedProcedure
    .input(z.object({ deviceId: id }))
    .query(async ({ ctx, input }) => {
      const organizationId = await ensureOrganization(ctx.user);
      const db = await requireDb();
      return db
        .select()
        .from(macTableEntries)
        .where(
          and(
            eq(macTableEntries.organizationId, organizationId),
            eq(macTableEntries.deviceId, input.deviceId)
          )
        )
        .orderBy(desc(macTableEntries.observedAt))
        .limit(1000);
    }),
  addEthernetPort: protectedProcedure
    .input(
      z.object({
        deviceId: id,
        label: z.string().min(1).max(120),
        linkStatus: z.string().max(40).optional(),
        negotiatedSpeedMbps: z.number().int().positive().max(100000).optional(),
        duplex: z.string().max(40).optional(),
        rxPackets: z.number().nonnegative().optional(),
        txPackets: z.number().nonnegative().optional(),
        crcErrors: z.number().nonnegative().optional(),
        interfaceErrors: z.number().nonnegative().optional(),
        flappingCount: z.number().int().nonnegative().optional(),
        sourceLabel: source.optional(),
        observedAt: nowOrDate,
      })
    )
    .mutation(async ({ ctx, input }) => {
      const organizationId = await ensureOrganization(ctx.user);
      const db = await requireDb();
      const result = await db.insert(ethernetPorts).values({
        organizationId,
        ...input,
        linkStatus: nullable(input.linkStatus),
        negotiatedSpeedMbps: nullable(input.negotiatedSpeedMbps),
        duplex: nullable(input.duplex),
        rxPackets: nullable(input.rxPackets),
        txPackets: nullable(input.txPackets),
        crcErrors: nullable(input.crcErrors),
        interfaceErrors: nullable(input.interfaceErrors),
        flappingCount: nullable(input.flappingCount),
        sourceLabel: nullable(input.sourceLabel),
        observedAt: nullable(input.observedAt),
      });
      return { ethernetPortId: insertId(result) };
    }),
  addWifiNetwork: protectedProcedure
    .input(
      z.object({
        deviceId: id,
        ssid: z.string().min(1).max(160),
        band: z.string().max(30).optional(),
        channel: z.string().max(40).optional(),
        channelWidthMHz: z.number().int().positive().max(320).optional(),
        signalDbm: z.number().min(-130).max(20).optional(),
        noiseDbm: z.number().min(-160).max(20).optional(),
        interferenceLevel: z.string().max(40).optional(),
        authentication: z.string().max(80).optional(),
        sourceLabel: source.optional(),
        observedAt: nowOrDate,
      })
    )
    .mutation(async ({ ctx, input }) => {
      const organizationId = await ensureOrganization(ctx.user);
      const db = await requireDb();
      const result = await db.insert(wifiNetworks).values({
        organizationId,
        ...input,
        band: nullable(input.band),
        channel: nullable(input.channel),
        channelWidthMHz: nullable(input.channelWidthMHz),
        signalDbm: nullable(input.signalDbm),
        noiseDbm: nullable(input.noiseDbm),
        interferenceLevel: nullable(input.interferenceLevel),
        authentication: nullable(input.authentication),
        sourceLabel: nullable(input.sourceLabel),
        observedAt: nullable(input.observedAt),
      });
      return { wifiNetworkId: insertId(result) };
    }),
  addWifiClient: protectedProcedure
    .input(
      z.object({
        wifiNetworkId: id,
        macAddress: z.string().max(32).optional(),
        ipAddress: z.string().max(128).optional(),
        hostname: z.string().max(255).optional(),
        signalDbm: z.number().min(-130).max(20).optional(),
        rxRateMbps: z.number().nonnegative().optional(),
        txRateMbps: z.number().nonnegative().optional(),
        connectedAt: nowOrDate,
        sourceLabel: source.optional(),
        observedAt: nowOrDate,
      })
    )
    .mutation(async ({ ctx, input }) => {
      const organizationId = await ensureOrganization(ctx.user);
      const db = await requireDb();
      const result = await db.insert(wifiClients).values({
        organizationId,
        ...input,
        macAddress: nullable(input.macAddress),
        ipAddress: nullable(input.ipAddress),
        hostname: nullable(input.hostname),
        signalDbm: nullable(input.signalDbm),
        rxRateMbps: nullable(input.rxRateMbps),
        txRateMbps: nullable(input.txRateMbps),
        connectedAt: nullable(input.connectedAt),
        sourceLabel: nullable(input.sourceLabel),
        observedAt: nullable(input.observedAt),
      });
      return { wifiClientId: insertId(result) };
    }),
  addServiceSession: protectedProcedure
    .input(
      z.object({
        deviceId: id.optional(),
        subscriberId: id.optional(),
        sessionType: z.enum(["pppoe", "dhcp", "dns", "vlan", "route", "arp"]),
        username: z.string().max(180).optional(),
        vlanId: z.string().max(80).optional(),
        mtu: z.number().int().positive().max(10000).optional(),
        gatewayAddress: z.string().max(128).optional(),
        dnsServers: z.array(z.string().max(128)).max(16).optional(),
        status: z.string().max(60).optional(),
        startedAt: nowOrDate,
        observedAt: nowOrDate,
        sourceLabel: source.optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const organizationId = await ensureOrganization(ctx.user);
      const db = await requireDb();
      const result = await db.insert(serviceSessions).values({
        organizationId,
        deviceId: nullable(input.deviceId),
        subscriberId: nullable(input.subscriberId),
        sessionType: input.sessionType,
        username: nullable(input.username),
        vlanId: nullable(input.vlanId),
        mtu: nullable(input.mtu),
        gatewayAddress: nullable(input.gatewayAddress),
        dnsServersJson: input.dnsServers
          ? JSON.stringify(input.dnsServers)
          : null,
        status: nullable(input.status),
        startedAt: nullable(input.startedAt),
        observedAt: input.observedAt ?? new Date(),
        sourceLabel: nullable(input.sourceLabel),
      });
      return { sessionId: insertId(result) };
    }),
  recordTelemetry: protectedProcedure
    .input(
      z
        .object({
          deviceId: id.optional(),
          ontUnitId: id.optional(),
          ponPortId: id.optional(),
          metric: z.string().min(2).max(120),
          valueDouble: z.number().finite().optional(),
          valueText: z.string().max(10000).optional(),
          unit: z.string().max(40).optional(),
          state: z.string().max(60).optional(),
          sourceLabel: source,
          measuredAt: z.coerce.date(),
        })
        .refine(input => input.valueDouble !== undefined || input.valueText, {
          message: "يلزم إدخال قيمة رقمية أو نصية.",
        })
    )
    .mutation(async ({ ctx, input }) => {
      const organizationId = await ensureOrganization(ctx.user);
      const db = await requireDb();
      const result = await db.insert(telemetrySamples).values({
        organizationId,
        ...input,
        deviceId: nullable(input.deviceId),
        ontUnitId: nullable(input.ontUnitId),
        ponPortId: nullable(input.ponPortId),
        valueDouble: nullable(input.valueDouble),
        valueText: nullable(input.valueText),
        unit: nullable(input.unit),
        state: nullable(input.state),
      });
      const telemetryId = insertId(result);
      await addAudit(
        organizationId,
        ctx.user.id,
        "fiber.telemetry.recorded",
        "telemetry",
        String(telemetryId),
        { metric: input.metric, source: input.sourceLabel }
      );
      return { telemetryId };
    }),
  addTopologyNode: protectedProcedure
    .input(
      z.object({
        deviceId: id.optional(),
        nodeKind: z.enum([
          "internet",
          "core",
          "olt",
          "pon",
          "splitter",
          "fiber",
          "distribution_box",
          "onu",
          "ont",
          "router",
          "switch",
          "gateway",
          "access_point",
          "client",
          "service",
        ]),
        label: z.string().min(1).max(180),
        reference: z.string().max(160).optional(),
        status: z.string().max(60).optional(),
        sourceLabel: source.optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const organizationId = await ensureOrganization(ctx.user);
      const db = await requireDb();
      const result = await db.insert(topologyNodes).values({
        organizationId,
        ...input,
        deviceId: nullable(input.deviceId),
        reference: nullable(input.reference),
        status: nullable(input.status),
        sourceLabel: nullable(input.sourceLabel),
      });
      return { nodeId: insertId(result) };
    }),
  addTopologyEdge: protectedProcedure
    .input(
      z.object({
        sourceNodeId: id,
        targetNodeId: id,
        relationType: z.string().min(1).max(80),
        fiberLengthKm: z.number().nonnegative().max(10000).optional(),
        baselineLossDb: z.number().nonnegative().max(200).optional(),
        sourceLabel: source.optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const organizationId = await ensureOrganization(ctx.user);
      if (input.sourceNodeId === input.targetNodeId)
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: "لا يمكن وصل العنصر بنفسه.",
        });
      const db = await requireDb();
      const result = await db.insert(topologyEdges).values({
        organizationId,
        ...input,
        fiberLengthKm: nullable(input.fiberLengthKm),
        baselineLossDb: nullable(input.baselineLossDb),
        sourceLabel: nullable(input.sourceLabel),
      });
      return { edgeId: insertId(result) };
    }),
  addGponPath: protectedProcedure
    .input(
      z.object({
        oltNodeId: id,
        ponNodeId: id,
        splitterNodeId: id,
        fiberNodeId: id,
        ontNodeId: id,
        clientNodeId: id,
        fiberLengthKm: z.number().nonnegative().max(10000).optional(),
        baselineLossDb: z.number().nonnegative().max(200).optional(),
        sourceLabel: source,
      })
    )
    .mutation(async ({ ctx, input }) => {
      const organizationId = await ensureOrganization(ctx.user);
      const ids = [
        input.oltNodeId,
        input.ponNodeId,
        input.splitterNodeId,
        input.fiberNodeId,
        input.ontNodeId,
        input.clientNodeId,
      ];
      if (new Set(ids).size !== ids.length)
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: "تتطلب سلسلة GPON عقدًا مستقلة لكل مرحلة.",
        });
      const db = await requireDb();
      const nodes = await db
        .select({ id: topologyNodes.id })
        .from(topologyNodes)
        .where(
          and(
            eq(topologyNodes.organizationId, organizationId),
            inArray(topologyNodes.id, ids)
          )
        );
      if (nodes.length !== ids.length)
        throw new TRPCError({
          code: "NOT_FOUND",
          message: "توجد عقدة غير متاحة ضمن المؤسسة.",
        });
      const edges = [
        [input.oltNodeId, input.ponNodeId, "olt_terminates_on_pon"],
        [input.ponNodeId, input.splitterNodeId, "pon_feeds_splitter"],
        [input.splitterNodeId, input.fiberNodeId, "splitter_feeds_fiber"],
        [input.fiberNodeId, input.ontNodeId, "fiber_terminates_on_ont"],
        [input.ontNodeId, input.clientNodeId, "ont_serves_client"],
      ] as const;
      await db.insert(topologyEdges).values(
        edges.map(([sourceNodeId, targetNodeId, relationType], index) => ({
          organizationId,
          sourceNodeId,
          targetNodeId,
          relationType,
          fiberLengthKm:
            index === 2 || index === 3 ? nullable(input.fiberLengthKm) : null,
          baselineLossDb:
            index === 2 || index === 3 ? nullable(input.baselineLossDb) : null,
          sourceLabel: input.sourceLabel,
        }))
      );
      await addAudit(
        organizationId,
        ctx.user.id,
        "fiber.gpon_path.created",
        "topology_path",
        ids.join(","),
        { source: input.sourceLabel }
      );
      return { edgeCount: edges.length };
    }),
  addEvent: protectedProcedure
    .input(
      z.object({
        deviceId: id.optional(),
        topologyNodeId: id.optional(),
        eventType: z.string().min(2).max(120),
        title: z.string().min(2).max(240),
        severity: z.enum([
          "critical",
          "high",
          "medium",
          "low",
          "informational",
        ]),
        evidence: z.array(z.string().max(500)).max(20).optional(),
        sourceLabel: source,
        occurredAt: z.coerce.date(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const organizationId = await ensureOrganization(ctx.user);
      const db = await requireDb();
      const result = await db.insert(operationalEvents).values({
        organizationId,
        deviceId: nullable(input.deviceId),
        topologyNodeId: nullable(input.topologyNodeId),
        eventType: input.eventType,
        title: input.title,
        severity: input.severity,
        evidenceJson: input.evidence ? JSON.stringify(input.evidence) : null,
        sourceLabel: input.sourceLabel,
        occurredAt: input.occurredAt,
      });
      return { eventId: insertId(result) };
    }),
  addAlert: protectedProcedure
    .input(
      z.object({
        deviceId: id.optional(),
        topologyNodeId: id.optional(),
        severity: z.enum([
          "critical",
          "high",
          "medium",
          "low",
          "informational",
        ]),
        title: z.string().min(2).max(240),
        impact: z.string().max(5000).optional(),
        probableCause: z.string().max(5000).optional(),
        evidence: z.array(z.string().max(500)).max(20).optional(),
        recommendedCheck: z.string().max(5000).optional(),
        sourceLabel: source,
        openedAt: z.coerce.date(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const organizationId = await ensureOrganization(ctx.user);
      const db = await requireDb();
      const result = await db.insert(alerts).values({
        organizationId,
        deviceId: nullable(input.deviceId),
        topologyNodeId: nullable(input.topologyNodeId),
        severity: input.severity,
        title: input.title,
        impact: nullable(input.impact),
        probableCause: nullable(input.probableCause),
        evidenceJson: input.evidence ? JSON.stringify(input.evidence) : null,
        recommendedCheck: nullable(input.recommendedCheck),
        sourceLabel: input.sourceLabel,
        openedAt: input.openedAt,
      });
      return { alertId: insertId(result) };
    }),
  acknowledgeAlert: protectedProcedure
    .input(
      z.object({ alertId: id, status: z.enum(["acknowledged", "resolved"]) })
    )
    .mutation(async ({ ctx, input }) => {
      const organizationId = await ensureOrganization(ctx.user);
      const db = await requireDb();
      const existing = (
        await db
          .select()
          .from(alerts)
          .where(
            and(
              eq(alerts.id, input.alertId),
              eq(alerts.organizationId, organizationId)
            )
          )
          .limit(1)
      )[0];
      if (!existing) throw new TRPCError({ code: "NOT_FOUND" });
      await db
        .update(alerts)
        .set({
          status: input.status,
          acknowledgedAt:
            input.status === "acknowledged"
              ? new Date()
              : existing.acknowledgedAt,
          resolvedAt: input.status === "resolved" ? new Date() : null,
        })
        .where(eq(alerts.id, input.alertId));
      return { success: true };
    }),
  timeline: protectedProcedure
    .input(
      z.object({
        deviceId: id.optional(),
        severity: z
          .enum(["critical", "high", "medium", "low", "informational"])
          .optional(),
        sourceContains: z.string().trim().min(1).max(160).optional(),
        from: z.coerce.date().optional(),
        to: z.coerce.date().optional(),
      })
    )
    .query(async ({ ctx, input }) => {
      const organizationId = await ensureOrganization(ctx.user);
      const db = await requireDb();
      const conditions = [eq(operationalEvents.organizationId, organizationId)];
      if (input.deviceId)
        conditions.push(eq(operationalEvents.deviceId, input.deviceId));
      if (input.severity)
        conditions.push(eq(operationalEvents.severity, input.severity));
      if (input.sourceContains)
        conditions.push(
          like(operationalEvents.sourceLabel, `%${input.sourceContains}%`)
        );
      if (input.from)
        conditions.push(gte(operationalEvents.occurredAt, input.from));
      if (input.to)
        conditions.push(lte(operationalEvents.occurredAt, input.to));
      return db
        .select()
        .from(operationalEvents)
        .where(and(...conditions))
        .orderBy(desc(operationalEvents.occurredAt))
        .limit(1000);
    }),
  monitoringPolicy: protectedProcedure.query(async ({ ctx }) => {
    const organizationId = await ensureOrganization(ctx.user);
    const db = await requireDb();
    return (
      (
        await db
          .select()
          .from(fiberMonitoringPolicies)
          .where(eq(fiberMonitoringPolicies.organizationId, organizationId))
          .limit(1)
      )[0] ?? null
    );
  }),
  saveMonitoringPolicy: protectedProcedure
    .input(
      z.object({
        opticalRxWarningDbm: z.number().min(-60).max(10).optional(),
        opticalLossWarningDb: z.number().min(0).max(100).optional(),
        latencyWarningMs: z.number().int().min(1).max(60000).optional(),
        jitterWarningMs: z.number().int().min(1).max(60000).optional(),
        retentionDays: z.number().int().min(1).max(3650).optional(),
        alertRepeatThreshold: z.number().int().min(1).max(1000).optional(),
        sourceLabel: source,
      })
    )
    .mutation(async ({ ctx, input }) => {
      const organizationId = await ensureOrganization(ctx.user);
      const db = await requireDb();
      await db
        .insert(fiberMonitoringPolicies)
        .values({
          organizationId,
          ...input,
          opticalRxWarningDbm: nullable(input.opticalRxWarningDbm),
          opticalLossWarningDb: nullable(input.opticalLossWarningDb),
          latencyWarningMs: nullable(input.latencyWarningMs),
          jitterWarningMs: nullable(input.jitterWarningMs),
          retentionDays: nullable(input.retentionDays),
          alertRepeatThreshold: nullable(input.alertRepeatThreshold),
        })
        .onDuplicateKeyUpdate({
          set: {
            opticalRxWarningDbm: nullable(input.opticalRxWarningDbm),
            opticalLossWarningDb: nullable(input.opticalLossWarningDb),
            latencyWarningMs: nullable(input.latencyWarningMs),
            jitterWarningMs: nullable(input.jitterWarningMs),
            retentionDays: nullable(input.retentionDays),
            alertRepeatThreshold: nullable(input.alertRepeatThreshold),
            sourceLabel: input.sourceLabel,
          },
        });
      await addAudit(
        organizationId,
        ctx.user.id,
        "fiber.monitoring_policy.saved",
        "monitoring_policy",
        String(organizationId),
        { source: input.sourceLabel }
      );
      return { success: true };
    }),
  deviceDetails: protectedProcedure
    .input(
      z.object({
        deviceId: id,
        telemetryDays: z.number().int().min(1).max(365).default(30),
      })
    )
    .query(async ({ ctx, input }) => {
      const organizationId = await ensureOrganization(ctx.user);
      const db = await requireDb();
      const device = (
        await db
          .select()
          .from(networkDevices)
          .where(
            and(
              eq(networkDevices.id, input.deviceId),
              eq(networkDevices.organizationId, organizationId)
            )
          )
          .limit(1)
      )[0];
      if (!device) throw new TRPCError({ code: "NOT_FOUND" });
      const from = new Date(Date.now() - input.telemetryDays * 86_400_000);
      const [
        units,
        ips,
        ethernet,
        wifi,
        sessions,
        samples,
        events,
        snapshots,
        activeAlerts,
      ] = await Promise.all([
        db
          .select()
          .from(ontUnits)
          .where(
            and(
              eq(ontUnits.deviceId, input.deviceId),
              eq(ontUnits.organizationId, organizationId)
            )
          )
          .limit(1),
        db
          .select()
          .from(deviceIpAddresses)
          .where(
            and(
              eq(deviceIpAddresses.deviceId, input.deviceId),
              eq(deviceIpAddresses.organizationId, organizationId)
            )
          )
          .orderBy(desc(deviceIpAddresses.observedAt)),
        db
          .select()
          .from(ethernetPorts)
          .where(
            and(
              eq(ethernetPorts.deviceId, input.deviceId),
              eq(ethernetPorts.organizationId, organizationId)
            )
          )
          .orderBy(desc(ethernetPorts.observedAt)),
        db
          .select()
          .from(wifiNetworks)
          .where(
            and(
              eq(wifiNetworks.deviceId, input.deviceId),
              eq(wifiNetworks.organizationId, organizationId)
            )
          ),
        db
          .select()
          .from(serviceSessions)
          .where(
            and(
              eq(serviceSessions.deviceId, input.deviceId),
              eq(serviceSessions.organizationId, organizationId)
            )
          )
          .orderBy(desc(serviceSessions.observedAt)),
        db
          .select()
          .from(telemetrySamples)
          .where(
            and(
              eq(telemetrySamples.deviceId, input.deviceId),
              eq(telemetrySamples.organizationId, organizationId),
              gte(telemetrySamples.measuredAt, from)
            )
          )
          .orderBy(desc(telemetrySamples.measuredAt))
          .limit(5000),
        db
          .select()
          .from(operationalEvents)
          .where(
            and(
              eq(operationalEvents.deviceId, input.deviceId),
              eq(operationalEvents.organizationId, organizationId)
            )
          )
          .orderBy(desc(operationalEvents.occurredAt))
          .limit(300),
        db
          .select()
          .from(healthSnapshots)
          .where(
            and(
              eq(healthSnapshots.deviceId, input.deviceId),
              eq(healthSnapshots.organizationId, organizationId)
            )
          )
          .orderBy(desc(healthSnapshots.calculatedAt))
          .limit(50),
        db
          .select()
          .from(alerts)
          .where(
            and(
              eq(alerts.deviceId, input.deviceId),
              eq(alerts.organizationId, organizationId),
              eq(alerts.status, "open")
            )
          )
          .orderBy(desc(alerts.openedAt)),
      ]);
      const unit = units[0] ?? null;
      const signalSamples: FiberSignal[] = samples.map(sample => ({
        metric: sample.metric,
        value: sample.valueDouble,
        valueText: sample.valueText,
        unit: sample.unit,
        measuredAt: sample.measuredAt,
        sourceLabel: sample.sourceLabel,
      }));
      const sessionStatus = sessions.find(session =>
        ["failed", "down", "offline", "rejected"].includes(
          (session.status || "").toLowerCase()
        )
      )?.status;
      const state = {
        losState: unit?.losState,
        ponStatus: unit?.ponStatus,
        authenticationStatus: unit?.authenticationStatus,
        serviceStatus: sessionStatus,
      };
      const health = calculateHealth(signalSamples, state, ethernet, wifi);
      const prediction = [
        ...detectOpticalTrend(signalSamples),
        ...detectServiceStabilityTrend(events),
      ];
      return {
        device,
        unit,
        ips,
        ethernet,
        wifi,
        sessions,
        samples,
        events,
        snapshots,
        alerts: activeAlerts,
        health,
        prediction,
        currentFindings: diagnoseFiberSignals(
          signalSamples,
          state,
          ethernet,
          wifi
        ),
      };
    }),
  saveHealthSnapshot: protectedProcedure
    .input(z.object({ deviceId: id }))
    .mutation(async ({ ctx, input }) => {
      const organizationId = await ensureOrganization(ctx.user);
      const db = await requireDb();
      const [unit, samples, ethernet, wifi] = await Promise.all([
        db
          .select()
          .from(ontUnits)
          .where(
            and(
              eq(ontUnits.deviceId, input.deviceId),
              eq(ontUnits.organizationId, organizationId)
            )
          )
          .limit(1),
        db
          .select()
          .from(telemetrySamples)
          .where(
            and(
              eq(telemetrySamples.deviceId, input.deviceId),
              eq(telemetrySamples.organizationId, organizationId)
            )
          )
          .orderBy(desc(telemetrySamples.measuredAt))
          .limit(5000),
        db
          .select()
          .from(ethernetPorts)
          .where(
            and(
              eq(ethernetPorts.deviceId, input.deviceId),
              eq(ethernetPorts.organizationId, organizationId)
            )
          ),
        db
          .select()
          .from(wifiNetworks)
          .where(
            and(
              eq(wifiNetworks.deviceId, input.deviceId),
              eq(wifiNetworks.organizationId, organizationId)
            )
          ),
      ]);
      const health = calculateHealth(
        samples.map(sample => ({
          metric: sample.metric,
          value: sample.valueDouble,
          valueText: sample.valueText,
          unit: sample.unit,
          measuredAt: sample.measuredAt,
          sourceLabel: sample.sourceLabel,
        })),
        {
          losState: unit[0]?.losState,
          ponStatus: unit[0]?.ponStatus,
          authenticationStatus: unit[0]?.authenticationStatus,
        },
        ethernet,
        wifi
      );
      const result = await db.insert(healthSnapshots).values({
        organizationId,
        deviceId: input.deviceId,
        overallScore: health.overallScore,
        opticalScore: health.opticalScore,
        networkScore: health.networkScore,
        deviceScore: health.deviceScore,
        ethernetScore: health.ethernetScore,
        wifiScore: health.wifiScore,
        authenticationScore: health.authenticationScore,
        serviceStabilityScore: health.serviceStabilityScore,
        explanationJson: JSON.stringify(health.findings),
        sourceLabel: "ZERO GRAM derived from stored telemetry",
        calculatedAt: new Date(),
      });
      return { healthSnapshotId: insertId(result), health };
    }),
  globalSearch: protectedProcedure
    .input(z.object({ query: z.string().trim().min(2).max(160) }))
    .query(async ({ ctx, input }) => {
      const organizationId = await ensureOrganization(ctx.user);
      const db = await requireDb();
      const term = `%${input.query}%`;
      const [devices, ips, onts, ports, clients, sessions, subscriberRows] =
        await Promise.all([
          db
            .select()
            .from(networkDevices)
            .where(
              and(
                eq(networkDevices.organizationId, organizationId),
                or(
                  like(networkDevices.label, term),
                  like(networkDevices.serialNumber, term),
                  like(networkDevices.macAddress, term),
                  like(networkDevices.hostname, term),
                  like(networkDevices.managementIpv4, term),
                  like(networkDevices.managementIpv6, term)
                )
              )
            )
            .limit(80),
          db
            .select()
            .from(deviceIpAddresses)
            .where(
              and(
                eq(deviceIpAddresses.organizationId, organizationId),
                or(
                  like(deviceIpAddresses.address, term),
                  like(deviceIpAddresses.hostname, term)
                )
              )
            )
            .limit(80),
          db
            .select()
            .from(ontUnits)
            .where(
              and(
                eq(ontUnits.organizationId, organizationId),
                or(
                  like(ontUnits.onuId, term),
                  like(ontUnits.pppoeUsername, term)
                )
              )
            )
            .limit(80),
          db
            .select()
            .from(ponPorts)
            .where(
              and(
                eq(ponPorts.organizationId, organizationId),
                or(like(ponPorts.label, term), like(ponPorts.ponIndex, term))
              )
            )
            .limit(80),
          db
            .select()
            .from(wifiClients)
            .where(
              and(
                eq(wifiClients.organizationId, organizationId),
                or(
                  like(wifiClients.macAddress, term),
                  like(wifiClients.ipAddress, term),
                  like(wifiClients.hostname, term)
                )
              )
            )
            .limit(80),
          db
            .select()
            .from(serviceSessions)
            .where(
              and(
                eq(serviceSessions.organizationId, organizationId),
                or(
                  like(serviceSessions.username, term),
                  like(serviceSessions.gatewayAddress, term),
                  like(serviceSessions.vlanId, term)
                )
              )
            )
            .limit(80),
          db
            .select()
            .from(subscribers)
            .where(
              and(
                eq(subscribers.organizationId, organizationId),
                or(
                  like(subscribers.reference, term),
                  like(subscribers.displayName, term)
                )
              )
            )
            .limit(80),
        ]);
      const deviceIds = Array.from(
        new Set([
          ...devices.map(row => row.id),
          ...ips.map(row => row.deviceId),
        ])
      );
      const deviceRows = deviceIds.length
        ? await db
            .select()
            .from(networkDevices)
            .where(
              and(
                eq(networkDevices.organizationId, organizationId),
                inArray(networkDevices.id, deviceIds)
              )
            )
        : [];
      return {
        devices: deviceRows,
        directDevices: devices,
        ips,
        onts,
        ports,
        clients,
        sessions,
        subscribers: subscriberRows,
      };
    }),
  recordImportBatch: protectedProcedure
    .input(
      z.object({
        sourceName: z.string().min(1).max(255),
        sourceType: z.enum(["csv", "json", "api", "manual"]),
        recordCount: z.number().int().nonnegative().max(100000),
        validationSummary: z.object({
          accepted: z.number().int().nonnegative(),
          rejected: z.number().int().nonnegative(),
          fields: z.array(z.string().max(120)).max(100),
        }),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const organizationId = await ensureOrganization(ctx.user);
      const db = await requireDb();
      const result = await db.insert(importBatches).values({
        organizationId,
        userId: ctx.user.id,
        sourceName: input.sourceName,
        sourceType: input.sourceType,
        recordCount: input.recordCount,
        validationSummaryJson: JSON.stringify(input.validationSummary),
      });
      return { importBatchId: insertId(result) };
    }),
  importDeviceTelemetry: protectedProcedure
    .input(
      z.object({
        sourceName: z.string().min(1).max(255),
        sourceType: z.enum(["csv", "json"]),
        devices: z.array(deviceInput).max(1000),
        telemetry: z
          .array(
            z
              .object({
                deviceLabel: z.string().trim().min(2).max(160),
                metric: z.string().trim().min(2).max(120),
                valueDouble: z.number().finite().optional(),
                valueText: z.string().max(10000).optional(),
                unit: z.string().max(40).optional(),
                state: z.string().max(60).optional(),
                sourceLabel: source,
                measuredAt: z.coerce.date(),
              })
              .refine(
                item => item.valueDouble !== undefined || item.valueText,
                { message: "يلزم إدخال قيمة للقياس." }
              )
          )
          .max(10000),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const organizationId = await ensureOrganization(ctx.user);
      const db = await requireDb();
      const deviceMap = new Map<string, number>();
      let accepted = 0;
      let rejected = 0;
      for (const inputDevice of input.devices) {
        const existing = (
          await db
            .select()
            .from(networkDevices)
            .where(
              and(
                eq(networkDevices.organizationId, organizationId),
                eq(networkDevices.label, inputDevice.label)
              )
            )
            .orderBy(desc(networkDevices.createdAt))
            .limit(1)
        )[0];
        let deviceId = existing?.id;
        if (!deviceId) {
          const result = await db.insert(networkDevices).values({
            organizationId,
            ...inputDevice,
            siteId: nullable(inputDevice.siteId),
            managementReference: nullable(inputDevice.managementReference),
            vendor: nullable(inputDevice.vendor),
            model: nullable(inputDevice.model),
            serialNumber: nullable(inputDevice.serialNumber),
            macAddress: nullable(inputDevice.macAddress),
            hostname: nullable(inputDevice.hostname),
            managementIpv4: nullable(inputDevice.managementIpv4),
            managementIpv6: nullable(inputDevice.managementIpv6),
            firmwareVersion: nullable(inputDevice.firmwareVersion),
            uptimeSeconds: nullable(inputDevice.uptimeSeconds),
            linkStatus: nullable(inputDevice.linkStatus),
            connectionStatus: nullable(inputDevice.connectionStatus),
            sourceLabel: nullable(inputDevice.sourceLabel),
            sourceObservedAt: nullable(inputDevice.sourceObservedAt),
          });
          deviceId = insertId(result);
        }
        deviceMap.set(inputDevice.label.toLowerCase(), deviceId);
        accepted++;
      }
      for (const sample of input.telemetry) {
        const deviceId =
          deviceMap.get(sample.deviceLabel.toLowerCase()) ??
          (
            await db
              .select()
              .from(networkDevices)
              .where(
                and(
                  eq(networkDevices.organizationId, organizationId),
                  eq(networkDevices.label, sample.deviceLabel)
                )
              )
              .limit(1)
          )[0]?.id;
        if (!deviceId) {
          rejected++;
          continue;
        }
        await db.insert(telemetrySamples).values({
          organizationId,
          deviceId,
          metric: sample.metric,
          valueDouble: nullable(sample.valueDouble),
          valueText: nullable(sample.valueText),
          unit: nullable(sample.unit),
          state: nullable(sample.state),
          sourceLabel: sample.sourceLabel,
          measuredAt: sample.measuredAt,
        });
        accepted++;
      }
      const result = await db.insert(importBatches).values({
        organizationId,
        userId: ctx.user.id,
        sourceName: input.sourceName,
        sourceType: input.sourceType,
        recordCount: input.devices.length + input.telemetry.length,
        validationSummaryJson: JSON.stringify({
          accepted,
          rejected,
          fields: ["devices", "telemetry"],
        }),
      });
      await addAudit(
        organizationId,
        ctx.user.id,
        "fiber.import.completed",
        "import_batch",
        String(insertId(result)),
        { accepted, rejected, sourceName: input.sourceName }
      );
      return { accepted, rejected };
    }),
});
