import { TRPCError } from "@trpc/server";
import { and, desc, eq, like, or } from "drizzle-orm";
import { z } from "zod";
import {
  capacitySnapshots,
  changeRecords,
  incidents,
  monitoringEvents,
  networkDevices,
  operationalEvents,
  organizationProfiles,
  testResults,
} from "../../drizzle/schema";
import {
  analyzeCapacity,
  analyzeReliability,
  detectAnomaly,
  type NumericPoint,
} from "../../shared/operationsIntelligence";
import { addAudit, ensureOrganization, getDb } from "../db";
import { protectedProcedure, router } from "../_core/trpc";

const source = z.string().trim().min(2).max(160);
const id = z.number().int().positive();
const requireDb = async () => {
  const db = await getDb();
  if (!db)
    throw new TRPCError({
      code: "INTERNAL_SERVER_ERROR",
      message: "قاعدة البيانات غير متاحة حاليًا.",
    });
  return db;
};
const insertId = (result: unknown) =>
  Number((result as unknown as [{ insertId: number }])[0].insertId);
const nullable = <T>(value: T | undefined) => value ?? null;
const parseMeasurement = (value: string): Record<string, unknown> | null => {
  try {
    const parsed = JSON.parse(value) as {
      measurement?: Record<string, unknown>;
    };
    return parsed.measurement ?? null;
  } catch {
    return null;
  }
};

const incidentInput = z.object({
  reference: z.string().trim().min(3).max(120).optional(),
  title: z.string().trim().min(2).max(240),
  severity: z.enum(["critical", "high", "medium", "low"]),
  state: z.enum(["open", "investigating", "resolved"]).default("open"),
  startedAt: z.coerce.date(),
  endedAt: z.coerce.date().optional(),
  affectedServiceCount: z
    .number()
    .int()
    .nonnegative()
    .max(100_000_000)
    .optional(),
  affectedDeviceIds: z.array(id).max(500).optional(),
  relatedEventIds: z.array(id).max(500).optional(),
  rootCause: z.string().trim().max(10_000).optional(),
  rootCauseConfidence: z.number().int().min(0).max(100).optional(),
  resolution: z.string().trim().max(10_000).optional(),
  engineerNotes: z.string().trim().max(10_000).optional(),
  sourceLabel: source,
});
const changeInput = z
  .object({
    deviceId: id.optional(),
    changeType: z.string().trim().min(2).max(120),
    title: z.string().trim().min(2).max(240),
    before: z.record(z.string(), z.unknown()).optional(),
    after: z.record(z.string(), z.unknown()).optional(),
    sourceLabel: source,
    changedAt: z.coerce.date(),
  })
  .refine(input => input.before || input.after, {
    message: "يلزم إدخال قيمة قبل أو بعد واحدة على الأقل.",
  });

export const intelligenceRouter = router({
  overview: protectedProcedure.query(async ({ ctx }) => {
    const organizationId = await ensureOrganization(ctx.user);
    const db = await requireDb();
    const [
      profiles,
      capacities,
      monitorRows,
      incidentRows,
      changes,
      results,
      criticalEvents,
      devices,
    ] = await Promise.all([
      db
        .select()
        .from(organizationProfiles)
        .where(eq(organizationProfiles.organizationId, organizationId))
        .limit(1),
      db
        .select()
        .from(capacitySnapshots)
        .where(eq(capacitySnapshots.organizationId, organizationId))
        .orderBy(desc(capacitySnapshots.measuredAt))
        .limit(500),
      db
        .select()
        .from(monitoringEvents)
        .where(eq(monitoringEvents.organizationId, organizationId))
        .orderBy(desc(monitoringEvents.checkedAt))
        .limit(1000),
      db
        .select()
        .from(incidents)
        .where(eq(incidents.organizationId, organizationId))
        .orderBy(desc(incidents.startedAt))
        .limit(200),
      db
        .select()
        .from(changeRecords)
        .where(eq(changeRecords.organizationId, organizationId))
        .orderBy(desc(changeRecords.changedAt))
        .limit(200),
      db
        .select()
        .from(testResults)
        .where(eq(testResults.organizationId, organizationId))
        .orderBy(desc(testResults.createdAt))
        .limit(200),
      db
        .select()
        .from(operationalEvents)
        .where(eq(operationalEvents.organizationId, organizationId))
        .orderBy(desc(operationalEvents.occurredAt))
        .limit(80),
      db
        .select({ id: networkDevices.id, label: networkDevices.label })
        .from(networkDevices)
        .where(eq(networkDevices.organizationId, organizationId))
        .limit(1000),
    ]);
    const capacityPoints: NumericPoint[] = capacities.flatMap(row =>
      row.currentUsageMbps === null
        ? []
        : [
            {
              at: row.measuredAt,
              value: row.currentUsageMbps,
              label: row.sourceLabel,
            },
          ]
    );
    const testPoints = (metric: string): NumericPoint[] =>
      results.flatMap(row => {
        const measurement = parseMeasurement(row.payloadJson);
        const value = measurement?.[metric];
        return typeof value === "number" && Number.isFinite(value)
          ? [{ at: row.createdAt, value }]
          : [];
      });
    const profile = profiles[0] ?? null;
    const capacity = analyzeCapacity(
      capacityPoints,
      profile?.totalBandwidthMbps
    );
    const reliability = analyzeReliability(monitorRows);
    const anomalies = [
      detectAnomaly(testPoints("webLatencyMs"), "web_latency_ms"),
      detectAnomaly(testPoints("downloadMbps"), "download_mbps"),
      detectAnomaly(capacityPoints, "capacity_usage_mbps"),
    ].flatMap(item => (item ? [item] : []));
    const highEvents = criticalEvents.filter(
      event => event.severity === "critical" || event.severity === "high"
    );
    const activeIncidents = incidentRows.filter(
      incident => incident.state !== "resolved"
    );
    return {
      profile,
      capacity,
      capacitySnapshots: capacities,
      reliability,
      anomalies,
      incidents: incidentRows,
      changes,
      devices,
      suggestedIncidents: highEvents.slice(0, 12).map(event => ({
        eventId: event.id,
        title: event.title,
        severity: event.severity,
        occurredAt: event.occurredAt,
        sourceLabel: event.sourceLabel,
        evidence: event.evidenceJson,
      })),
      activeIncidentCount: activeIncidents.length,
      testSampleCount: results.length,
    };
  }),
  search: protectedProcedure
    .input(z.object({ query: z.string().trim().min(2).max(160) }))
    .query(async ({ ctx, input }) => {
      const organizationId = await ensureOrganization(ctx.user);
      const db = await requireDb();
      const pattern = `%${input.query}%`;
      const [incidentRows, changes, profiles] = await Promise.all([
        db
          .select()
          .from(incidents)
          .where(
            and(
              eq(incidents.organizationId, organizationId),
              or(
                like(incidents.reference, pattern),
                like(incidents.title, pattern),
                like(incidents.sourceLabel, pattern),
                like(incidents.rootCause, pattern)
              )
            )
          )
          .orderBy(desc(incidents.startedAt))
          .limit(40),
        db
          .select()
          .from(changeRecords)
          .where(
            and(
              eq(changeRecords.organizationId, organizationId),
              or(
                like(changeRecords.changeType, pattern),
                like(changeRecords.title, pattern),
                like(changeRecords.sourceLabel, pattern),
                like(changeRecords.beforeJson, pattern),
                like(changeRecords.afterJson, pattern)
              )
            )
          )
          .orderBy(desc(changeRecords.changedAt))
          .limit(40),
        db
          .select()
          .from(organizationProfiles)
          .where(
            and(
              eq(organizationProfiles.organizationId, organizationId),
              or(
                like(organizationProfiles.companyName, pattern),
                like(organizationProfiles.networkType, pattern),
                like(organizationProfiles.sourceLabel, pattern),
                like(organizationProfiles.nocInformation, pattern),
                like(organizationProfiles.technicalSupportInformation, pattern)
              )
            )
          )
          .limit(5),
      ]);
      return { incidents: incidentRows, changes, profiles };
    }),
  createIncident: protectedProcedure
    .input(incidentInput)
    .mutation(async ({ ctx, input }) => {
      const organizationId = await ensureOrganization(ctx.user);
      const db = await requireDb();
      const reference =
        input.reference ??
        `INC-${new Date().getUTCFullYear()}-${String(Date.now()).slice(-6)}`;
      const result = await db.insert(incidents).values({
        organizationId,
        reference,
        title: input.title,
        severity: input.severity,
        state: input.state,
        startedAt: input.startedAt,
        endedAt: nullable(input.endedAt),
        affectedServiceCount: nullable(input.affectedServiceCount),
        affectedDeviceIdsJson: input.affectedDeviceIds
          ? JSON.stringify(input.affectedDeviceIds)
          : null,
        relatedEventIdsJson: input.relatedEventIds
          ? JSON.stringify(input.relatedEventIds)
          : null,
        rootCause: nullable(input.rootCause),
        rootCauseConfidence: nullable(input.rootCauseConfidence),
        resolution: nullable(input.resolution),
        engineerNotes: nullable(input.engineerNotes),
        sourceLabel: input.sourceLabel,
      });
      const incidentId = insertId(result);
      await addAudit(
        organizationId,
        ctx.user.id,
        "intelligence.incident.created",
        "incident",
        String(incidentId),
        { reference, source: input.sourceLabel }
      );
      return { incidentId, reference };
    }),
  updateIncident: protectedProcedure
    .input(
      z.object({
        incidentId: id,
        state: z.enum(["open", "investigating", "resolved"]).optional(),
        endedAt: z.coerce.date().optional(),
        rootCause: z.string().trim().max(10_000).optional(),
        rootCauseConfidence: z.number().int().min(0).max(100).optional(),
        resolution: z.string().trim().max(10_000).optional(),
        engineerNotes: z.string().trim().max(10_000).optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const organizationId = await ensureOrganization(ctx.user);
      const db = await requireDb();
      const existing = (
        await db
          .select()
          .from(incidents)
          .where(eq(incidents.id, input.incidentId))
          .limit(1)
      )[0];
      if (!existing || existing.organizationId !== organizationId)
        throw new TRPCError({ code: "NOT_FOUND" });
      const patch = {
        state: input.state,
        endedAt:
          input.endedAt ??
          (input.state === "resolved" ? new Date() : undefined),
        rootCause: input.rootCause,
        rootCauseConfidence: input.rootCauseConfidence,
        resolution: input.resolution,
        engineerNotes: input.engineerNotes,
      };
      await db
        .update(incidents)
        .set(patch)
        .where(eq(incidents.id, input.incidentId));
      await addAudit(
        organizationId,
        ctx.user.id,
        "intelligence.incident.updated",
        "incident",
        String(input.incidentId),
        {
          fields: Object.keys(patch).filter(
            key => patch[key as keyof typeof patch] !== undefined
          ),
        }
      );
      return { success: true };
    }),
  recordChange: protectedProcedure
    .input(changeInput)
    .mutation(async ({ ctx, input }) => {
      const organizationId = await ensureOrganization(ctx.user);
      const db = await requireDb();
      if (input.deviceId) {
        const found = await db
          .select({ id: networkDevices.id })
          .from(networkDevices)
          .where(eq(networkDevices.id, input.deviceId))
          .limit(1);
        if (!found[0]) throw new TRPCError({ code: "NOT_FOUND" });
      }
      const result = await db.insert(changeRecords).values({
        organizationId,
        deviceId: nullable(input.deviceId),
        changeType: input.changeType,
        title: input.title,
        beforeJson: input.before ? JSON.stringify(input.before) : null,
        afterJson: input.after ? JSON.stringify(input.after) : null,
        sourceLabel: input.sourceLabel,
        changedAt: input.changedAt,
      });
      const changeId = insertId(result);
      await addAudit(
        organizationId,
        ctx.user.id,
        "intelligence.change.recorded",
        "change_record",
        String(changeId),
        { source: input.sourceLabel, type: input.changeType }
      );
      return { changeId };
    }),
});
