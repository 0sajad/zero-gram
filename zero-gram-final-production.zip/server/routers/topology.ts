import { and, desc, eq, inArray } from "drizzle-orm";
import {
  alerts,
  deviceIpAddresses,
  networkDevices,
  operationalEvents,
  telemetrySamples,
  topologyEdges,
  topologyNodes,
} from "../../drizzle/schema";
import { ensureOrganization, getDb } from "../db";
import { protectedProcedure, router } from "../_core/trpc";

export const topologyRouter = router({
  context: protectedProcedure.query(async ({ ctx }) => {
    const organizationId = await ensureOrganization(ctx.user);
    const db = await getDb();
    if (!db) throw new Error("Database unavailable");
    const [nodes, edges, devices, ips, samples, openAlerts, events] =
      await Promise.all([
        db
          .select()
          .from(topologyNodes)
          .where(eq(topologyNodes.organizationId, organizationId))
          .limit(500),
        db
          .select()
          .from(topologyEdges)
          .where(eq(topologyEdges.organizationId, organizationId))
          .limit(800),
        db
          .select()
          .from(networkDevices)
          .where(eq(networkDevices.organizationId, organizationId))
          .limit(500),
        db
          .select()
          .from(deviceIpAddresses)
          .where(eq(deviceIpAddresses.organizationId, organizationId))
          .orderBy(desc(deviceIpAddresses.observedAt))
          .limit(2000),
        db
          .select()
          .from(telemetrySamples)
          .where(eq(telemetrySamples.organizationId, organizationId))
          .orderBy(desc(telemetrySamples.measuredAt))
          .limit(5000),
        db
          .select()
          .from(alerts)
          .where(
            and(
              eq(alerts.organizationId, organizationId),
              eq(alerts.status, "open")
            )
          )
          .orderBy(desc(alerts.openedAt))
          .limit(500),
        db
          .select()
          .from(operationalEvents)
          .where(eq(operationalEvents.organizationId, organizationId))
          .orderBy(desc(operationalEvents.occurredAt))
          .limit(1000),
      ]);
    const deviceIds = nodes.flatMap(node =>
      node.deviceId ? [node.deviceId] : []
    );
    const scopedDevices = deviceIds.length
      ? devices.filter(device => deviceIds.includes(device.id))
      : [];
    return {
      nodes,
      edges,
      devices: scopedDevices,
      ips,
      samples,
      openAlerts,
      events,
    };
  }),
});
