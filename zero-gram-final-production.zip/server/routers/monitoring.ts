import { TRPCError } from "@trpc/server";
import { parse as parseCookie } from "cookie";
import { and, desc, eq } from "drizzle-orm";
import { lookup } from "dns/promises";
import { z } from "zod";
import {
  addAudit,
  ensureOrganization,
  getDb,
  listMonitorEvents,
  listMonitorProfiles,
  monitoringEvents,
  monitoringProfiles,
} from "../db";
import { COOKIE_NAME } from "../../shared/const";
import {
  createHeartbeatJob,
  deleteHeartbeatJob,
  updateHeartbeatJob,
} from "../_core/heartbeat";
import { protectedProcedure, router } from "../_core/trpc";

function isPrivateAddress(address: string) {
  if (
    address === "::1" ||
    address.startsWith("fc") ||
    address.startsWith("fd") ||
    address.startsWith("fe80")
  )
    return true;
  const parts = address.split(".").map(Number);
  if (parts.length !== 4 || parts.some(Number.isNaN)) return false;
  const [a, b] = parts;
  return (
    a === 10 ||
    a === 127 ||
    a === 0 ||
    (a === 169 && b === 254) ||
    (a === 172 && b >= 16 && b <= 31) ||
    (a === 192 && b === 168)
  );
}

async function validateMonitoringTarget(raw: string) {
  let url: URL;
  try {
    url = new URL(raw);
  } catch {
    throw new TRPCError({
      code: "BAD_REQUEST",
      message: "أدخل رابط HTTP/HTTPS صالحًا.",
    });
  }
  if (
    !/^https?:$/.test(url.protocol) ||
    url.username ||
    url.password ||
    url.hostname === "localhost"
  )
    throw new TRPCError({
      code: "BAD_REQUEST",
      message: "لا يسمح الهدف بعناوين محلية أو بروتوكولات غير HTTP/HTTPS.",
    });
  const hosts = await lookup(url.hostname, { all: true, verbatim: true }).catch(
    () => []
  );
  if (!hosts.length || hosts.some(host => isPrivateAddress(host.address)))
    throw new TRPCError({
      code: "BAD_REQUEST",
      message: "تعذر التحقق من أن الهدف عام وآمن للمراقبة.",
    });
  return url.toString();
}

export async function runMonitorCheck(profile: {
  id: number;
  organizationId: number;
  targetUrl: string;
}) {
  const startedAt = Date.now();
  let state: "success" | "failure" = "failure";
  let statusCode: number | null = null;
  let errorMessage: string | null = null;
  try {
    await validateMonitoringTarget(profile.targetUrl);
    const response = await fetch(profile.targetUrl, {
      method: "GET",
      redirect: "manual",
      signal: AbortSignal.timeout(12_000),
      headers: { "User-Agent": "ZERO-GRAM-Monitor/1.0" },
    });
    statusCode = response.status;
    state = response.ok ? "success" : "failure";
    if (!response.ok) errorMessage = `HTTP ${response.status}`;
  } catch (error) {
    errorMessage =
      error instanceof Error ? error.message.slice(0, 700) : "فشل تحقق الاتصال";
  }
  const db = await getDb();
  if (!db) throw new Error("قاعدة البيانات غير متاحة.");
  const result = await db.insert(monitoringEvents).values({
    profileId: profile.id,
    organizationId: profile.organizationId,
    state,
    statusCode,
    responseTimeMs: Date.now() - startedAt,
    errorMessage,
  });
  return {
    id: Number((result as unknown as [{ insertId: number }])[0].insertId),
    state,
    statusCode,
    responseTimeMs: Date.now() - startedAt,
    errorMessage,
  };
}

export const monitoringRouter = router({
  list: protectedProcedure.query(async ({ ctx }) =>
    listMonitorProfiles(await ensureOrganization(ctx.user))
  ),
  create: protectedProcedure
    .input(
      z.object({
        label: z.string().min(2).max(160),
        targetUrl: z.string().url().max(2048),
        intervalCron: z
          .string()
          .regex(
            /^[\d*/,-]+\s+[\d*/,-]+\s+[\d*/,-]+\s+[\d*/,-]+\s+[\d*/,-]+\s+[\d*/,-]+$/,
            "استخدم صيغة كرون من ستة حقول."
          )
          .max(64),
        failureThreshold: z.number().int().min(1).max(10),
        slaTargetPercent: z.number().int().min(80).max(100),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const organizationId = await ensureOrganization(ctx.user);
      const db = await getDb();
      if (!db)
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "قاعدة البيانات غير متاحة.",
        });
      const targetUrl = await validateMonitoringTarget(input.targetUrl);
      const result = await db.insert(monitoringProfiles).values({
        organizationId,
        userId: ctx.user.id,
        label: input.label,
        targetUrl,
        intervalCron: input.intervalCron,
        failureThreshold: input.failureThreshold,
        slaTargetPercent: input.slaTargetPercent,
      });
      const id = Number(
        (result as unknown as [{ insertId: number }])[0].insertId
      );
      await addAudit(
        organizationId,
        ctx.user.id,
        "monitor.created",
        "monitor",
        String(id),
        { targetUrl }
      );
      return { id };
    }),
  activateSchedule: protectedProcedure
    .input(z.object({ profileId: z.number().int().positive() }))
    .mutation(async ({ ctx, input }) => {
      const organizationId = await ensureOrganization(ctx.user);
      const db = await getDb();
      if (!db)
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "قاعدة البيانات غير متاحة.",
        });
      const profile = (
        await db
          .select()
          .from(monitoringProfiles)
          .where(
            and(
              eq(monitoringProfiles.id, input.profileId),
              eq(monitoringProfiles.organizationId, organizationId)
            )
          )
          .limit(1)
      )[0];
      if (!profile)
        throw new TRPCError({
          code: "NOT_FOUND",
          message: "ملف المراقبة غير موجود.",
        });
      const sessionToken =
        parseCookie(ctx.req.headers.cookie ?? "")[COOKIE_NAME] ?? "";
      let nextExecutionAt: string | null = null;
      if (profile.scheduleCronTaskUid) {
        const updated = await updateHeartbeatJob(
          profile.scheduleCronTaskUid,
          {
            cron: profile.intervalCron,
            path: "/api/scheduled/monitor-check",
            method: "POST",
            payload: { profileId: profile.id },
            enable: true,
            description: `ZERO GRAM monitor: ${profile.label}`,
          },
          sessionToken
        );
        nextExecutionAt = updated.nextExecutionAt ?? null;
      } else {
        const created = await createHeartbeatJob(
          {
            name: `zero-gram-monitor-${profile.id}`,
            cron: profile.intervalCron,
            path: "/api/scheduled/monitor-check",
            method: "POST",
            payload: { profileId: profile.id },
            description: `ZERO GRAM monitor: ${profile.label}`,
          },
          sessionToken
        );
        nextExecutionAt = created.nextExecutionAt ?? null;
        await db
          .update(monitoringProfiles)
          .set({ scheduleCronTaskUid: created.taskUid, isActive: true })
          .where(eq(monitoringProfiles.id, profile.id));
      }
      await addAudit(
        organizationId,
        ctx.user.id,
        "monitor.schedule_activated",
        "monitor",
        String(profile.id)
      );
      return { ok: true, nextExecutionAt };
    }),
  pauseSchedule: protectedProcedure
    .input(z.object({ profileId: z.number().int().positive() }))
    .mutation(async ({ ctx, input }) => {
      const organizationId = await ensureOrganization(ctx.user);
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      const profile = (
        await db
          .select()
          .from(monitoringProfiles)
          .where(
            and(
              eq(monitoringProfiles.id, input.profileId),
              eq(monitoringProfiles.organizationId, organizationId)
            )
          )
          .limit(1)
      )[0];
      if (!profile) throw new TRPCError({ code: "NOT_FOUND" });
      if (!profile.scheduleCronTaskUid)
        return { ok: true, skipped: "not-scheduled" };
      const sessionToken =
        parseCookie(ctx.req.headers.cookie ?? "")[COOKIE_NAME] ?? "";
      await updateHeartbeatJob(
        profile.scheduleCronTaskUid,
        { enable: false },
        sessionToken
      );
      await db
        .update(monitoringProfiles)
        .set({ isActive: false })
        .where(eq(monitoringProfiles.id, profile.id));
      await addAudit(
        organizationId,
        ctx.user.id,
        "monitor.schedule_paused",
        "monitor",
        String(profile.id)
      );
      return { ok: true };
    }),
  delete: protectedProcedure
    .input(z.object({ profileId: z.number().int().positive() }))
    .mutation(async ({ ctx, input }) => {
      const organizationId = await ensureOrganization(ctx.user);
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      const profile = (
        await db
          .select()
          .from(monitoringProfiles)
          .where(
            and(
              eq(monitoringProfiles.id, input.profileId),
              eq(monitoringProfiles.organizationId, organizationId)
            )
          )
          .limit(1)
      )[0];
      if (!profile) throw new TRPCError({ code: "NOT_FOUND" });
      if (profile.scheduleCronTaskUid) {
        const sessionToken =
          parseCookie(ctx.req.headers.cookie ?? "")[COOKIE_NAME] ?? "";
        await deleteHeartbeatJob(profile.scheduleCronTaskUid, sessionToken);
      }
      await db
        .delete(monitoringProfiles)
        .where(eq(monitoringProfiles.id, profile.id));
      await addAudit(
        organizationId,
        ctx.user.id,
        "monitor.deleted",
        "monitor",
        String(profile.id)
      );
      return { ok: true };
    }),
  runNow: protectedProcedure
    .input(z.object({ profileId: z.number().int().positive() }))
    .mutation(async ({ ctx, input }) => {
      const organizationId = await ensureOrganization(ctx.user);
      const db = await getDb();
      if (!db)
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "قاعدة البيانات غير متاحة.",
        });
      const profile = (
        await db
          .select()
          .from(monitoringProfiles)
          .where(
            and(
              eq(monitoringProfiles.id, input.profileId),
              eq(monitoringProfiles.organizationId, organizationId)
            )
          )
          .limit(1)
      )[0];
      if (!profile)
        throw new TRPCError({
          code: "NOT_FOUND",
          message: "ملف المراقبة غير موجود.",
        });
      const event = await runMonitorCheck(profile);
      await addAudit(
        organizationId,
        ctx.user.id,
        "monitor.checked",
        "monitor",
        String(profile.id),
        { state: event.state }
      );
      return event;
    }),
  events: protectedProcedure
    .input(z.object({ profileId: z.number().int().positive() }))
    .query(async ({ ctx, input }) =>
      listMonitorEvents(input.profileId, await ensureOrganization(ctx.user))
    ),
  status: protectedProcedure.query(async ({ ctx }) => {
    const organizationId = await ensureOrganization(ctx.user);
    const db = await getDb();
    if (!db) return { profiles: [], events: [] };
    const profiles = await listMonitorProfiles(organizationId);
    const events = await db
      .select()
      .from(monitoringEvents)
      .where(eq(monitoringEvents.organizationId, organizationId))
      .orderBy(desc(monitoringEvents.checkedAt))
      .limit(80);
    return { profiles, events };
  }),
});
