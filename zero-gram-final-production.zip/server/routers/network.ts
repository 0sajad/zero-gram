import { TRPCError } from "@trpc/server";
import { and, desc, eq } from "drizzle-orm";
import { randomUUID } from "crypto";
import { z } from "zod";
import { diagnoseConnection } from "../../shared/networkDiagnostics";
import {
  addAudit,
  attachments,
  ensureOrganization,
  getDb,
  listTestResults,
  testResults,
} from "../db";
import { resultShareLinks, resultShareViews } from "../../drizzle/schema";
import { storagePut } from "../storage";
import { protectedProcedure, publicProcedure, router } from "../_core/trpc";

const speedTraceSchema = z.object({
  elapsedMs: z.number().finite().nonnegative().max(600_000),
  mbps: z.number().finite().nonnegative().max(100_000_000),
});
const measurementSchema = z.object({
  downloadMbps: z.number().finite().optional(),
  uploadMbps: z.number().finite().optional(),
  webLatencyMs: z.number().finite().optional(),
  jitterMs: z.number().finite().optional(),
  ttfbMs: z.number().finite().optional(),
  dnsMs: z.number().finite().optional(),
  packetLossEstimate: z.number().min(0).max(100).optional(),
  networkType: z.string().max(80).optional(),
  effectiveType: z.string().max(80).optional(),
  saveData: z.boolean().optional(),
  ipv4: z.boolean().optional(),
  ipv6: z.boolean().optional(),
  webrtc: z.boolean().optional(),
  downloadTrace: z.array(speedTraceSchema).max(30).optional(),
  uploadTrace: z.array(speedTraceSchema).max(30).optional(),
  downloadConsistencyPercent: z.number().min(0).max(100).optional(),
  uploadConsistencyPercent: z.number().min(0).max(100).optional(),
  testDurationMs: z.number().finite().nonnegative().max(600_000).optional(),
});

export const networkRouter = router({
  saveResult: protectedProcedure
    .input(
      z.object({
        measurement: measurementSchema,
        sources: z.array(z.string().max(240)).max(30),
        limitations: z.array(z.string().max(400)).max(30),
        metricTrace: z
          .record(
            z.string(),
            z.object({
              source: z.string().max(240),
              precision: z.string().max(120),
              limitation: z.string().max(400),
            })
          )
          .optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const organizationId = await ensureOrganization(ctx.user);
      const db = await getDb();
      if (!db)
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "قاعدة البيانات غير متاحة.",
        });
      const diagnosis = diagnoseConnection(input.measurement);
      const result = await db.insert(testResults).values({
        organizationId,
        userId: ctx.user.id,
        payloadJson: JSON.stringify({
          measurement: input.measurement,
          diagnosis,
          metricTrace: input.metricTrace ?? {},
        }),
        sourceJson: JSON.stringify(input.sources),
        limitationsJson: JSON.stringify(input.limitations),
      });
      const id = Number(
        (result as unknown as [{ insertId: number }])[0].insertId
      );
      await addAudit(
        organizationId,
        ctx.user.id,
        "test_result.saved",
        "test_result",
        String(id)
      );
      return { id, diagnosis };
    }),
  history: protectedProcedure.query(async ({ ctx }) =>
    listTestResults(await ensureOrganization(ctx.user))
  ),
  createShare: protectedProcedure
    .input(
      z.object({
        resultId: z.number().int().positive(),
        origin: z.string().url(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const organizationId = await ensureOrganization(ctx.user);
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      const result = (
        await db
          .select()
          .from(testResults)
          .where(
            and(
              eq(testResults.id, input.resultId),
              eq(testResults.organizationId, organizationId)
            )
          )
          .limit(1)
      )[0];
      if (!result)
        throw new TRPCError({
          code: "NOT_FOUND",
          message: "نتيجة الفحص غير موجودة.",
        });
      const existing = (
        await db
          .select()
          .from(resultShareLinks)
          .where(
            and(
              eq(resultShareLinks.resultId, input.resultId),
              eq(resultShareLinks.isActive, true)
            )
          )
          .limit(1)
      )[0];
      const link =
        existing ??
        (await (async () => {
          const token = randomUUID().replaceAll("-", "");
          const inserted = await db.insert(resultShareLinks).values({
            organizationId,
            resultId: input.resultId,
            createdByUserId: ctx.user.id,
            shareToken: token,
          });
          const id = Number(
            (inserted as unknown as [{ insertId: number }])[0].insertId
          );
          await addAudit(
            organizationId,
            ctx.user.id,
            "test_result.shared",
            "share_link",
            String(id),
            { resultId: input.resultId }
          );
          return { id, shareToken: token };
        })());
      return {
        shareUrl: `${new URL(input.origin).origin}/share/${link.shareToken}`,
      };
    }),
  sharedResult: publicProcedure
    .input(z.object({ shareToken: z.string().min(16).max(96) }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      const link = (
        await db
          .select()
          .from(resultShareLinks)
          .where(
            and(
              eq(resultShareLinks.shareToken, input.shareToken),
              eq(resultShareLinks.isActive, true)
            )
          )
          .limit(1)
      )[0];
      if (!link || (link.expiresAt && link.expiresAt.getTime() < Date.now()))
        throw new TRPCError({
          code: "NOT_FOUND",
          message: "رابط المشاركة غير صالح أو انتهت صلاحيته.",
        });
      const result = (
        await db
          .select()
          .from(testResults)
          .where(eq(testResults.id, link.resultId))
          .limit(1)
      )[0];
      if (!result) throw new TRPCError({ code: "NOT_FOUND" });
      await db.insert(resultShareViews).values({ shareLinkId: link.id });
      const viewCount = (
        await db
          .select()
          .from(resultShareViews)
          .where(eq(resultShareViews.shareLinkId, link.id))
      ).length;
      return { result, viewCount, expiresAt: link.expiresAt };
    }),
  uploadAttachment: protectedProcedure
    .input(
      z.object({
        ticketId: z.number().int().positive().optional(),
        filename: z.string().min(1).max(180),
        contentType: z.string().min(1).max(120),
        base64: z.string().min(1).max(7_000_000),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const organizationId = await ensureOrganization(ctx.user);
      const allowed = [
        "application/pdf",
        "text/plain",
        "image/png",
        "image/jpeg",
        "image/webp",
      ];
      if (!allowed.includes(input.contentType))
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: "نوع الملف غير مسموح.",
        });
      const bytes = Buffer.from(input.base64, "base64");
      if (!bytes.length || bytes.length > 5 * 1024 * 1024)
        throw new TRPCError({
          code: "PAYLOAD_TOO_LARGE",
          message: "حجم المرفق يجب أن يكون أقل من 5MB.",
        });
      const cleanName = input.filename.replace(/[^\w.\-\u0600-\u06FF]/g, "_");
      const stored = await storagePut(
        `zero-gram/${organizationId}/attachments/${Date.now()}-${cleanName}`,
        bytes,
        input.contentType
      );
      const db = await getDb();
      if (!db)
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "قاعدة البيانات غير متاحة.",
        });
      const result = await db.insert(attachments).values({
        organizationId,
        ticketId: input.ticketId ?? null,
        storageKey: stored.key,
        filename: cleanName,
        mimeType: input.contentType,
        sizeBytes: bytes.length,
        createdByUserId: ctx.user.id,
      });
      const id = Number(
        (result as unknown as [{ insertId: number }])[0].insertId
      );
      await addAudit(
        organizationId,
        ctx.user.id,
        "attachment.uploaded",
        "attachment",
        String(id),
        { filename: cleanName, sizeBytes: bytes.length }
      );
      return {
        id,
        url: stored.url,
        filename: cleanName,
        sizeBytes: bytes.length,
      };
    }),
  attachments: protectedProcedure
    .input(z.object({ ticketId: z.number().int().positive().optional() }))
    .query(async ({ ctx, input }) => {
      const organizationId = await ensureOrganization(ctx.user);
      const db = await getDb();
      if (!db) return [];
      return db
        .select()
        .from(attachments)
        .where(
          input.ticketId
            ? and(
                eq(attachments.organizationId, organizationId),
                eq(attachments.ticketId, input.ticketId)
              )
            : eq(attachments.organizationId, organizationId)
        )
        .orderBy(desc(attachments.createdAt));
    }),
});
