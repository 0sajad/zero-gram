import { TRPCError } from "@trpc/server";
import { z } from "zod";
import {
  addAudit,
  ensureOrganization,
  getDb,
  listOperations,
  networkDevices,
  networkPops,
  networkSites,
  subscribers,
  tickets,
} from "../db";
import { protectedProcedure, router } from "../_core/trpc";

export const operationsRouter = router({
  overview: protectedProcedure.query(async ({ ctx }) =>
    listOperations(await ensureOrganization(ctx.user))
  ),
  addSubscriber: protectedProcedure
    .input(
      z.object({
        reference: z.string().min(1).max(120),
        displayName: z.string().min(1).max(180),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const organizationId = await ensureOrganization(ctx.user);
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      const result = await db
        .insert(subscribers)
        .values({ organizationId, ...input });
      const id = Number(
        (result as unknown as [{ insertId: number }])[0].insertId
      );
      await addAudit(
        organizationId,
        ctx.user.id,
        "subscriber.created",
        "subscriber",
        String(id)
      );
      return { id };
    }),
  addSite: protectedProcedure
    .input(
      z.object({
        name: z.string().min(1).max(180),
        siteType: z.string().min(1).max(80),
        reference: z.string().max(120).optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const organizationId = await ensureOrganization(ctx.user);
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      const result = await db.insert(networkSites).values({
        organizationId,
        ...input,
        reference: input.reference ?? null,
      });
      const id = Number(
        (result as unknown as [{ insertId: number }])[0].insertId
      );
      await addAudit(
        organizationId,
        ctx.user.id,
        "site.created",
        "site",
        String(id)
      );
      return { id };
    }),
  addPop: protectedProcedure
    .input(
      z.object({
        label: z.string().min(1).max(160),
        code: z.string().min(1).max(80),
        locationReference: z.string().max(180).optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const organizationId = await ensureOrganization(ctx.user);
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      const result = await db.insert(networkPops).values({
        organizationId,
        ...input,
        locationReference: input.locationReference ?? null,
      });
      const id = Number(
        (result as unknown as [{ insertId: number }])[0].insertId
      );
      await addAudit(
        organizationId,
        ctx.user.id,
        "pop.created",
        "pop",
        String(id)
      );
      return { id };
    }),
  addDevice: protectedProcedure
    .input(
      z.object({
        label: z.string().min(1).max(160),
        deviceType: z.string().min(1).max(80),
        managementReference: z.string().max(255).optional(),
        siteId: z.number().int().positive().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const organizationId = await ensureOrganization(ctx.user);
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      const result = await db.insert(networkDevices).values({
        organizationId,
        ...input,
        managementReference: input.managementReference ?? null,
        siteId: input.siteId ?? null,
      });
      const id = Number(
        (result as unknown as [{ insertId: number }])[0].insertId
      );
      await addAudit(
        organizationId,
        ctx.user.id,
        "device.created",
        "device",
        String(id)
      );
      return { id };
    }),
  addTicket: protectedProcedure
    .input(
      z.object({
        title: z.string().min(3).max(240),
        severity: z.enum(["low", "medium", "high", "critical"]),
        subscriberId: z.number().int().positive().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const organizationId = await ensureOrganization(ctx.user);
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      const result = await db.insert(tickets).values({
        organizationId,
        title: input.title,
        severity: input.severity,
        subscriberId: input.subscriberId ?? null,
      });
      const id = Number(
        (result as unknown as [{ insertId: number }])[0].insertId
      );
      await addAudit(
        organizationId,
        ctx.user.id,
        "ticket.created",
        "ticket",
        String(id)
      );
      return { id };
    }),
});
