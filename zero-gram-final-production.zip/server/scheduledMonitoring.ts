import type { Request, Response } from "express";
import { and, desc, eq } from "drizzle-orm";
import { getDb, monitoringEvents, monitoringProfiles } from "./db";
import { notifyOwner } from "./_core/notification";
import { runMonitorCheck } from "./routers/monitoring";

export async function runScheduledMonitor(req: Request, res: Response) {
  try {
    const configuredSecret = process.env.ZERO_GRAM_CRON_SECRET?.trim();
    const providedSecret = req.header("x-zero-gram-cron-secret")?.trim();
    if (configuredSecret && providedSecret !== configuredSecret)
      return res.status(403).json({ error: "cron-only" });
    const taskUid = String(req.body?.taskUid || req.query.taskUid || "").trim();
    if (!taskUid) return res.status(400).json({ error: "taskUid-required" });
    const db = await getDb();
    if (!db) throw new Error("قاعدة البيانات غير متاحة.");
    const profile = (
      await db
        .select()
        .from(monitoringProfiles)
        .where(eq(monitoringProfiles.scheduleCronTaskUid, taskUid))
        .limit(1)
    )[0];
    if (!profile || !profile.isActive)
      return res.json({ ok: true, skipped: "orphan-or-paused" });
    const event = await runMonitorCheck(profile);
    const latest = await db
      .select()
      .from(monitoringEvents)
      .where(
        and(
          eq(monitoringEvents.profileId, profile.id),
          eq(monitoringEvents.organizationId, profile.organizationId)
        )
      )
      .orderBy(desc(monitoringEvents.checkedAt))
      .limit(100);
    const repeatedFailures =
      latest.slice(0, profile.failureThreshold).length ===
        profile.failureThreshold &&
      latest
        .slice(0, profile.failureThreshold)
        .every(item => item.state === "failure");
    const uptimePercent = latest.length
      ? (latest.filter(item => item.state === "success").length /
          latest.length) *
        100
      : undefined;
    const slaBreached =
      uptimePercent !== undefined &&
      latest.length >= 5 &&
      uptimePercent < profile.slaTargetPercent;
    if (repeatedFailures || slaBreached) {
      const reason = repeatedFailures
        ? `${profile.failureThreshold} إخفاقات متتالية`
        : `SLA المحسوب ${uptimePercent?.toFixed(1)}% أقل من الهدف ${profile.slaTargetPercent}%`;
      await notifyOwner({
        title: `ZERO GRAM: تنبيه مراقبة — ${profile.label}`,
        content: `الوجهة: ${profile.targetUrl}\nالسبب: ${reason}\nآخر نتيجة: ${event.state}${event.statusCode ? ` (HTTP ${event.statusCode})` : ""}.`,
      });
    }
    return res.json({
      ok: true,
      profileId: profile.id,
      event,
      uptimePercent,
      alertSent: repeatedFailures || slaBreached,
    });
  } catch (error) {
    const message = error instanceof Error ? error.message : "خطأ غير معروف";
    return res.status(500).json({
      error: message,
      context: { path: req.path },
      timestamp: new Date().toISOString(),
    });
  }
}
