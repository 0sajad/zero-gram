import type { CreateExpressContextOptions } from "@trpc/server/adapters/express";
import { describe, expect, it } from "vitest";
import { createContext } from "./_core/context";

describe("local guest context", () => {
  it("provides a stable local identity without an external session", async () => {
    const opts = {
      req: {} as CreateExpressContextOptions["req"],
      res: {} as CreateExpressContextOptions["res"],
      info: {} as CreateExpressContextOptions["info"],
    } as CreateExpressContextOptions;

    const context = await createContext(opts);

    expect(context.user).toMatchObject({
      id: 0,
      openId: "local-guest",
      loginMethod: "local",
      role: "user",
    });
  });
});
