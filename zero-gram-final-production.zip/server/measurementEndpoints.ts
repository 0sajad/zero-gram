import type { Request, Response } from "express";

const MAX_DOWNLOAD_BYTES = 4 * 1024 * 1024;

export function measureBytes(req: Request, res: Response) {
  const requested = Number(req.query.bytes);
  const total = Number.isInteger(requested)
    ? Math.min(Math.max(requested, 1024), MAX_DOWNLOAD_BYTES)
    : 1024 * 1024;
  res.setHeader("Content-Type", "application/octet-stream");
  res.setHeader("Content-Length", String(total));
  res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
  const chunk = Buffer.alloc(Math.min(64 * 1024, total), 0x5a);
  let remaining = total;
  while (remaining > 0) {
    const next =
      remaining >= chunk.length ? chunk : chunk.subarray(0, remaining);
    res.write(next);
    remaining -= next.length;
  }
  res.end();
}

export function measureUpload(req: Request, res: Response) {
  const bytes = Buffer.isBuffer(req.body) ? req.body.length : 0;
  res.setHeader("Cache-Control", "no-store");
  res.json({ receivedBytes: bytes });
}
