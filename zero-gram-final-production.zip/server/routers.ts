import { systemRouter } from "./_core/systemRouter";
import { router } from "./_core/trpc";
import { monitoringRouter } from "./routers/monitoring";
import { networkRouter } from "./routers/network";
import { operationsRouter } from "./routers/operations";
import { teamRouter } from "./routers/team";
import { fiberRouter } from "./routers/fiber";
import { topologyRouter } from "./routers/topology";
import { networkContextRouter } from "./routers/networkContext";
import { intelligenceRouter } from "./routers/intelligence";

export const appRouter = router({
  system: systemRouter,
  network: networkRouter,
  monitoring: monitoringRouter,
  operations: operationsRouter,
  team: teamRouter,
  fiber: fiberRouter,
  topology: topologyRouter,
  networkContext: networkContextRouter,
  intelligence: intelligenceRouter,
});
export type AppRouter = typeof appRouter;
