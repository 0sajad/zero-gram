import { BrandMark } from "@/components/ZeroGramShell";
import { trpc } from "@/lib/trpc";
import { Activity, Eye, ShieldCheck } from "lucide-react";

export default function SharePage({ params }: { params: { token: string } }) {
  const share = trpc.network.sharedResult.useQuery({
    shareToken: params.token,
  });
  if (share.isLoading)
    return (
      <main className="invite-page">
        <BrandMark />
        <div className="panel-loading">Loading verified result…</div>
      </main>
    );
  if (!share.data)
    return (
      <main className="invite-page">
        <BrandMark />
        <section className="invite-card">
          <ShieldCheck />
          <h1>Link unavailable</h1>
          <span>This shared result may have expired or been withdrawn.</span>
        </section>
      </main>
    );
  const payload = JSON.parse(share.data.result.payloadJson) as {
    measurement?: Record<string, number>;
    diagnosis?: {
      netScore?: number;
      findings?: Array<{ title: string; evidence: string; level: string }>;
    };
  };
  return (
    <main className="share-page">
      <header>
        <BrandMark />
        <span>
          <Eye size={14} />
          {share.data.viewCount} views
        </span>
      </header>
      <section className="share-card">
        <p>ZERO GRAM / SHARED MEASUREMENT</p>
        <h1>Traceable connection result</h1>
        <div className="share-score">
          <b>{payload.diagnosis?.netScore ?? "—"}</b>
          <span>NetScore / 100</span>
        </div>
        <div className="share-metrics">
          {Object.entries(payload.measurement || {})
            .filter(([, value]) => typeof value === "number")
            .slice(0, 6)
            .map(([key, value]) => (
              <div key={key}>
                <span>{key}</span>
                <b>{Number(value).toFixed(2)}</b>
              </div>
            ))}
        </div>
        <div className="share-findings">
          {payload.diagnosis?.findings?.map(finding => (
            <article key={finding.title}>
              <i>{finding.level}</i>
              <div>
                <b>{finding.title}</b>
                <p>{finding.evidence}</p>
              </div>
            </article>
          ))}
        </div>
        <small>
          <Activity size={13} />
          This page contains a stored result only; it does not claim live
          network status.
        </small>
      </section>
    </main>
  );
}
