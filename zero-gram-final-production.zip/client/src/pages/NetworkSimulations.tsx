import { SectionHeading, ZeroGramShell } from "@/components/ZeroGramShell";
import { useI18n } from "@/lib/i18n";
import { panicFrames } from "../../../shared/networkFunLab";
import {
  AlertTriangle,
  FileWarning,
  Play,
  RotateCcw,
  Siren,
} from "lucide-react";
import { useEffect, useState } from "react";

export default function NetworkSimulations() {
  const { isArabic } = useI18n();
  const [step, setStep] = useState(-1);
  const [service, setService] = useState("");
  const [cause, setCause] = useState("Timeout");
  const active = step >= 0 && step < panicFrames.length - 1;
  useEffect(() => {
    if (!active) return;
    const timer = window.setTimeout(
      () => setStep(value => Math.min(value + 1, panicFrames.length - 1)),
      1050
    );
    return () => window.clearTimeout(timer);
  }, [active, step]);
  const reset = () => setStep(-1);
  return (
    <ZeroGramShell title="ZERO GRAM" eyebrow="ZERO GRAM / SIMULATION MODE">
      <div className="page-content simulation-page">
        <SectionHeading
          index="F/02"
          title={isArabic ? "محاكاة الشبكة" : "Network simulations"}
          description={
            isArabic
              ? "الصفحة مخصصة للمحاكاة الساخرة فقط. لا تقيس شبكة حقيقية، ولا تحفظ حادثة أو تنبيهًا أو نتيجة في سجلات ZERO GRAM."
              : "This page is for labelled humorous simulations only. It does not measure a real network or write incidents, alerts, or results to ZERO GRAM records."
          }
        />
        <div className="simulation-banner">
          <Siren size={16} />
          <b>SIMULATION MODE</b>
          <span>
            {isArabic
              ? "بيانات هذا القسم ليست تشغيلية."
              : "Data in this section is not operational."}
          </span>
        </div>
        <section className="data-panel panic-console">
          <header>
            <AlertTriangle size={18} />
            <div>
              <h3>NETWORK PANIC</h3>
              <small>
                {isArabic
                  ? "تسلسل NOC تمثيلي مع سبب مضحك معلن."
                  : "A fictional NOC sequence with an explicit humorous cause."}
              </small>
            </div>
          </header>
          <div className={`panic-screen ${active ? "active" : ""}`}>
            {step < 0 ? (
              <p>{isArabic ? "لم يبدأ أي سيناريو." : "No scenario running."}</p>
            ) : (
              <>
                <small>SIMULATION · NOT A LIVE NOC</small>
                <strong>{panicFrames[step]}</strong>
                {step >= panicFrames.length - 1 && (
                  <p>
                    {isArabic
                      ? "بعد تحقيق مطول: الكابل مفصول. لا علاقة لهذا بأي جهاز أو حدث حقيقي."
                      : "After extensive investigation, the cable was unplugged. This has no relation to any real device or event."}
                  </p>
                )}
              </>
            )}
          </div>
          <div className="simulation-actions">
            <button
              className="action-button primary"
              onClick={() => setStep(0)}
              disabled={active}
            >
              <Play size={15} />{" "}
              {isArabic ? "تشغيل المحاكاة" : "Run simulation"}
            </button>
            <button className="action-button" onClick={reset}>
              <RotateCcw size={15} /> {isArabic ? "إعادة ضبط" : "Reset"}
            </button>
          </div>
        </section>
        <section className="data-panel funeral-console">
          <header>
            <FileWarning size={18} />
            <div>
              <h3>INTERNET FUNERAL</h3>
              <small>
                {isArabic
                  ? "ينشئ بطاقة Simulation من الاسم والسبب اللذين تكتبهما؛ لا يفحص موقعًا ولا خدمة فعلية."
                  : "Creates a Simulation card from the name and cause you enter; it does not probe a website or live service."}
              </small>
            </div>
          </header>
          <div className="funeral-form">
            <label>
              {isArabic ? "اسم الخدمة أو الموقع" : "Website or service name"}
              <input
                value={service}
                onChange={event => setService(event.target.value)}
                placeholder="Example service"
              />
            </label>
            <label>
              {isArabic ? "السبب التمثيلي" : "Simulation cause"}
              <select
                value={cause}
                onChange={event => setCause(event.target.value)}
              >
                <option>Timeout</option>
                <option>Maintenance</option>
                <option>Lost route</option>
                <option>Cable disconnected</option>
              </select>
            </label>
          </div>
          {service && (
            <article className="funeral-card">
              <small>SIMULATION MODE · NOT A REAL STATUS</small>
              <h3>{service}</h3>
              <b>SERVICE STATUS · OFFLINE</b>
              <span>Last Seen: {new Date().toLocaleTimeString()}</span>
              <span>Cause: {cause}</span>
              <p>
                {isArabic
                  ? "Unfortunately unavailable — في هذه المحاكاة فقط."
                  : "Unfortunately unavailable — in this simulation only."}
              </p>
            </article>
          )}
        </section>
      </div>
    </ZeroGramShell>
  );
}
