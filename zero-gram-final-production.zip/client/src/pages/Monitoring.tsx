import { useConsolePreferences } from "@/components/ConsolePreferences";
import {
  EmptyState,
  SectionHeading,
  ZeroGramShell,
} from "@/components/ZeroGramShell";
import { useI18n } from "@/lib/i18n";
import { trpc } from "@/lib/trpc";
import {
  BellRing,
  CheckCircle2,
  CirclePause,
  CirclePlay,
  Clock3,
  Copy,
  Plus,
  RadioTower,
  RefreshCw,
  SlidersHorizontal,
  Trash2,
  XCircle,
} from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";

export default function Monitoring() {
  const { isArabic, t } = useI18n();
  const { autoRefresh, timeMode, showUnits } = useConsolePreferences();
  const list = trpc.monitoring.list.useQuery();
  const [show, setShow] = useState(false);
  const [selectedId, setSelectedId] = useState<number | null>(null);
  const [eventFilter, setEventFilter] = useState<"all" | "success" | "failure">(
    "all"
  );
  const [profileFilter, setProfileFilter] = useState<"all" | "active">("all");
  const [lastSync, setLastSync] = useState<Date | null>(null);
  const [form, setForm] = useState({
    label: "",
    targetUrl: "",
    intervalCron: "0 */5 * * * *",
    failureThreshold: 3,
    slaTargetPercent: 99,
  });
  const events = trpc.monitoring.events.useQuery(
    { profileId: selectedId ?? 0 },
    { enabled: Boolean(selectedId) }
  );
  const sync = () => {
    list.refetch();
    if (selectedId) events.refetch();
    setLastSync(new Date());
  };
  useEffect(() => {
    if (!autoRefresh) return;
    const timer = window.setInterval(sync, 30_000);
    return () => window.clearInterval(timer);
  }, [autoRefresh, selectedId]);
  const create = trpc.monitoring.create.useMutation({
    onSuccess: () => {
      toast.success(
        isArabic
          ? "أُنشئ ملف المراقبة. فعّل الجدولة بعد نشر المشروع."
          : "Monitoring profile created. Activate scheduling after publishing the project."
      );
      setShow(false);
      sync();
    },
    onError: error => toast.error(error.message),
  });
  const run = trpc.monitoring.runNow.useMutation({
    onSuccess: (event, input) => {
      setSelectedId(input.profileId);
      sync();
      if (event.state === "failure")
        toast.warning(
          isArabic
            ? "اكتمل الفحص بحالة فشل مسجلة."
            : "The check completed with a recorded failure."
        );
      else
        toast.success(
          isArabic ? "اكتمل الفحص اليدوي." : "Manual check completed."
        );
    },
    onError: error => toast.error(error.message),
  });
  const activate = trpc.monitoring.activateSchedule.useMutation({
    onSuccess: () => {
      toast.success(isArabic ? "فُعّلت الجدولة." : "Schedule activated.");
      sync();
    },
    onError: error => toast.error(error.message),
  });
  const pause = trpc.monitoring.pauseSchedule.useMutation({
    onSuccess: sync,
    onError: error => toast.error(error.message),
  });
  const remove = trpc.monitoring.delete.useMutation({
    onSuccess: () => {
      sync();
      setSelectedId(null);
    },
    onError: error => toast.error(error.message),
  });
  const selected = list.data?.find(profile => profile.id === selectedId);
  const visibleProfiles = useMemo(
    () =>
      (list.data || []).filter(
        profile => profileFilter === "all" || profile.isActive
      ),
    [list.data, profileFilter]
  );
  const shownEvents = useMemo(
    () =>
      (events.data || []).filter(
        event => eventFilter === "all" || event.state === eventFilter
      ),
    [events.data, eventFilter]
  );
  const successful = (events.data || []).filter(
    event => event.state === "success"
  ).length;
  const failed = (events.data || []).filter(
    event => event.state === "failure"
  ).length;
  const sla = events.data?.length
    ? (successful / events.data.length) * 100
    : undefined;
  const formatTime = (value: Date) =>
    new Date(value).toLocaleString(
      isArabic ? "ar" : "en",
      timeMode === "utc" ? { timeZone: "UTC" } : undefined
    );
  return (
    <ZeroGramShell title={t("monitoring")} eyebrow="ZERO GRAM / VERIFIED WATCH">
      <div className="page-content">
        <SectionHeading
          index="03"
          title={isArabic ? "مراقبة وجهاتك الفعلية" : "Monitor real endpoints"}
          description={
            isArabic
              ? "تُسجّل الاستجابات والأخطاء عند تشغيل فحص يدوي أو دوري. لا توجد حالات أو SLA قبل وصول أحداث محفوظة."
              : "Responses and errors are recorded after a manual or scheduled check. No status or SLA appears before stored events exist."
          }
          action={
            <div className="quick-actions">
              <button className="action-button" onClick={sync}>
                <RefreshCw size={14} />
                {isArabic ? "مزامنة" : "Sync"}
              </button>
              <button
                className="action-button primary"
                onClick={() => setShow(!show)}
              >
                <Plus size={15} />
                {isArabic ? "إضافة وجهة" : "Add target"}
              </button>
            </div>
          }
        />
        {show && (
          <section className="data-panel monitor-form">
            <div className="panel-header">
              <h3>{isArabic ? "ملف مراقبة جديد" : "New monitoring profile"}</h3>
              <span>HTTP / HTTPS ONLY</span>
            </div>
            <div className="field-grid monitor-fields">
              <label>
                {isArabic ? "الاسم" : "Label"}
                <input
                  value={form.label}
                  onChange={event =>
                    setForm({ ...form, label: event.target.value })
                  }
                  placeholder={isArabic ? "موقع العميل" : "Client site"}
                />
              </label>
              <label>
                {isArabic ? "الرابط" : "URL"}
                <input
                  dir="ltr"
                  value={form.targetUrl}
                  onChange={event =>
                    setForm({ ...form, targetUrl: event.target.value })
                  }
                  placeholder="https://example.com"
                />
              </label>
              <label>
                {isArabic ? "كرون (UTC، 6 حقول)" : "Cron (UTC, 6 fields)"}
                <input
                  dir="ltr"
                  value={form.intervalCron}
                  onChange={event =>
                    setForm({ ...form, intervalCron: event.target.value })
                  }
                />
              </label>
              <label>
                {isArabic ? "حد الإخفاق المتكرر" : "Repeated failure threshold"}
                <input
                  type="number"
                  min="1"
                  max="10"
                  value={form.failureThreshold}
                  onChange={event =>
                    setForm({
                      ...form,
                      failureThreshold: Number(event.target.value),
                    })
                  }
                />
              </label>
              <label>
                SLA target (%)
                <input
                  type="number"
                  min="80"
                  max="100"
                  value={form.slaTargetPercent}
                  onChange={event =>
                    setForm({
                      ...form,
                      slaTargetPercent: Number(event.target.value),
                    })
                  }
                />
              </label>
            </div>
            <div className="info-strip">
              <Clock3 />
              {isArabic
                ? "يتطلب تفعيل الجدولة نشر المشروع أولًا. يتحقق الخادم من أن الهدف عام وليس عنوانًا داخليًا."
                : "Activating scheduling requires publishing first. The server verifies the target is public rather than internal."}
            </div>
            <button
              className="action-button primary"
              disabled={create.isPending}
              onClick={() => create.mutate(form)}
            >
              {create.isPending ? (
                t("loading")
              ) : (
                <>
                  <Plus size={15} />
                  {isArabic ? "حفظ الملف" : "Save profile"}
                </>
              )}
            </button>
          </section>
        )}
        <div className="monitor-controlbar">
          <div>
            <SlidersHorizontal size={14} />
            <select
              value={profileFilter}
              onChange={event =>
                setProfileFilter(event.target.value as typeof profileFilter)
              }
            >
              <option value="all">
                {isArabic ? "كل الوجهات" : "All targets"}
              </option>
              <option value="active">
                {isArabic ? "النشطة فقط" : "Active only"}
              </option>
            </select>
            <span className={`badge ${autoRefresh ? "success" : "info"}`}>
              {autoRefresh
                ? isArabic
                  ? "تحديث تلقائي / 30s"
                  : "Auto refresh / 30s"
                : isArabic
                  ? "تحديث يدوي"
                  : "Manual refresh"}
            </span>
          </div>
          <small>
            {lastSync
              ? `${isArabic ? "آخر مزامنة: " : "Last sync: "}${formatTime(lastSync)}`
              : isArabic
                ? "لم تُطلب مزامنة يدوية بعد."
                : "No manual sync requested yet."}
          </small>
        </div>
        {list.isError ? (
          <div className="info-strip error-strip">
            <XCircle />
            {list.error.message}
            <button className="action-button" onClick={() => list.refetch()}>
              {t("retry")}
            </button>
          </div>
        ) : (
          <section className="monitor-grid">
            {list.isLoading ? (
              <div className="panel-loading">{t("loading")}</div>
            ) : visibleProfiles.length ? (
              visibleProfiles.map(profile => (
                <article className="data-panel monitor-card" key={profile.id}>
                  <div className="monitor-card-top">
                    <div>
                      <span
                        className={`badge ${profile.isActive ? "success" : "warning"}`}
                      >
                        {profile.isActive ? t("active") : t("paused")}
                      </span>
                      <h3>{profile.label}</h3>
                      <p dir="ltr">{profile.targetUrl}</p>
                    </div>
                    <RadioTower />
                  </div>
                  <div className="monitor-facts">
                    <span>
                      CRON <b dir="ltr">{profile.intervalCron}</b>
                    </span>
                    <span>
                      SLA TARGET <b>{profile.slaTargetPercent}%</b>
                    </span>
                    <span>
                      THRESHOLD <b>{profile.failureThreshold}</b>
                    </span>
                  </div>
                  <div className="monitor-actions">
                    <button
                      className="action-button"
                      onClick={() => {
                        setSelectedId(profile.id);
                        run.mutate({ profileId: profile.id });
                      }}
                      disabled={run.isPending}
                    >
                      <RefreshCw size={14} />
                      {t("run")}
                    </button>
                    <button
                      className="action-button"
                      onClick={() => setSelectedId(profile.id)}
                    >
                      {isArabic ? "الأحداث" : "Events"}
                    </button>
                    <button
                      className="icon-button"
                      aria-label="Copy target URL"
                      onClick={() => {
                        navigator.clipboard.writeText(profile.targetUrl);
                        toast.success(
                          isArabic ? "نُسخ رابط الوجهة." : "Target URL copied."
                        );
                      }}
                    >
                      <Copy size={14} />
                    </button>
                    {profile.scheduleCronTaskUid ? (
                      <button
                        className="action-button"
                        onClick={() => pause.mutate({ profileId: profile.id })}
                      >
                        <CirclePause size={14} />
                        {isArabic ? "إيقاف" : "Pause"}
                      </button>
                    ) : (
                      <button
                        className="action-button primary"
                        onClick={() =>
                          activate.mutate({ profileId: profile.id })
                        }
                      >
                        <CirclePlay size={14} />
                        {isArabic ? "تفعيل الجدولة" : "Activate"}
                      </button>
                    )}
                    <button
                      className="action-button danger"
                      onClick={() => remove.mutate({ profileId: profile.id })}
                    >
                      <Trash2 size={14} />
                    </button>
                  </div>
                </article>
              ))
            ) : (
              <EmptyState
                title={t("noData")}
                copy={
                  isArabic
                    ? "لا توجد وجهات تطابق فلتر العرض الحالي."
                    : "No targets match the current display filter."
                }
                action={
                  <button
                    className="action-button primary"
                    onClick={() => {
                      setProfileFilter("all");
                      setShow(true);
                    }}
                  >
                    <RadioTower size={15} />
                    {isArabic ? "أضف وجهة" : "Add target"}
                  </button>
                }
              />
            )}
          </section>
        )}
        {selectedId && (
          <section className="data-panel monitor-events-panel">
            <div className="panel-header">
              <h3>
                {isArabic ? "سجل أحداث المراقبة" : "Monitoring event log"} —{" "}
                {selected?.label || `#${selectedId}`}
              </h3>
              <span>
                {sla !== undefined
                  ? `SLA ${sla.toFixed(1)}%`
                  : isArabic
                    ? "لا أحداث"
                    : "No events"}
              </span>
            </div>
            {events.isError ? (
              <div className="info-strip error-strip">
                <XCircle />
                {events.error.message}
                <button
                  className="action-button"
                  onClick={() => events.refetch()}
                >
                  {t("retry")}
                </button>
              </div>
            ) : events.isLoading ? (
              <div className="panel-loading">{t("loading")}</div>
            ) : (
              <>
                <div className="event-summary">
                  <article className="success">
                    <CheckCircle2 size={16} />
                    <b>{successful}</b>
                    <span>{isArabic ? "نجاح" : "success"}</span>
                  </article>
                  <article className="critical">
                    <XCircle size={16} />
                    <b>{failed}</b>
                    <span>{isArabic ? "فشل" : "failure"}</span>
                  </article>
                  <article className="sla-gauge">
                    <div>
                      <span style={{ width: `${sla ?? 0}%` }} />
                    </div>
                    <b>{sla === undefined ? "—" : `${sla.toFixed(1)}%`}</b>
                    <small>
                      {isArabic
                        ? "SLA من الأحداث المحفوظة"
                        : "SLA from stored events"}
                    </small>
                  </article>
                  <select
                    value={eventFilter}
                    onChange={event =>
                      setEventFilter(event.target.value as typeof eventFilter)
                    }
                  >
                    <option value="all">
                      {isArabic ? "كل الأحداث" : "All events"}
                    </option>
                    <option value="success">
                      {isArabic ? "الناجحة" : "Success"}
                    </option>
                    <option value="failure">
                      {isArabic ? "الفاشلة" : "Failure"}
                    </option>
                  </select>
                </div>
                {shownEvents.length ? (
                  <div className="event-list">
                    {shownEvents.map(event => (
                      <article key={event.id}>
                        <span
                          className={
                            event.state === "success"
                              ? "event-icon success"
                              : "event-icon critical"
                          }
                        >
                          {event.state === "success" ? (
                            <CirclePlay />
                          ) : (
                            <XCircle />
                          )}
                        </span>
                        <div>
                          <b>
                            {event.state === "success"
                              ? isArabic
                                ? "نجاح"
                                : "Success"
                              : isArabic
                                ? "فشل"
                                : "Failure"}
                          </b>
                          <p>
                            {event.statusCode
                              ? `HTTP ${event.statusCode}`
                              : event.errorMessage || "—"}{" "}
                            · {event.responseTimeMs ?? "—"}
                            {showUnits ? " ms" : ""}
                          </p>
                        </div>
                        <small>{formatTime(event.checkedAt)}</small>
                      </article>
                    ))}
                  </div>
                ) : (
                  <EmptyState
                    title={t("noData")}
                    copy={
                      isArabic
                        ? "لا توجد أحداث تطابق فلتر الحالة."
                        : "No events match the status filter."
                    }
                  />
                )}
              </>
            )}
          </section>
        )}
        <div className="info-strip notification-note">
          <BellRing />
          {isArabic
            ? "تصل التنبيهات تلقائيًا إلى مالك المشروع المرتبط بالمؤسسة عند تحقق عدد الإخفاقات المتتالية المحدد أو نزول SLA المحسوب عن الهدف بعد خمس قراءات على الأقل."
            : "Alerts automatically reach the project owner tied to the organization after the configured consecutive failures or when calculated SLA falls below target after at least five readings."}
        </div>
      </div>
    </ZeroGramShell>
  );
}
