import { ZeroGramShell } from "@/components/ZeroGramShell";
import { useI18n } from "@/lib/i18n";
import { buildProfileExport } from "../../../shared/profileExport";
import { useAuth } from "@/_core/hooks/useAuth";
import { Camera, Check, Download, FileJson, ShieldCheck, Trash2, User } from "lucide-react";
import { useEffect, useState } from "react";
import { toast } from "sonner";

type UserStatus = "online" | "away" | "offline";

export default function Profile() {
  const { isArabic } = useI18n();
  const { user } = useAuth();
  const [avatar, setAvatar] = useState<string | null>(null);
  const [status, setStatus] = useState<UserStatus>("online");

  useEffect(() => {
    try {
      const savedAvatar = localStorage.getItem("zero-gram-avatar");
      if (savedAvatar) setAvatar(savedAvatar);
      const savedStatus = localStorage.getItem("zero-gram-status") as UserStatus;
      if (savedStatus) setStatus(savedStatus);
    } catch {
      // ignore local storage errors
    }
  }, []);

  const handleAvatarUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith("image/")) {
      toast.error(isArabic ? "يجب اختيار ملف صورة صالح." : "Must select a valid image file.");
      return;
    }

    if (file.size > 2 * 1024 * 1024) {
      toast.error(isArabic ? "حجم الصورة يجب ألا يتجاوز 2MB." : "Image size must not exceed 2MB.");
      return;
    }

    const reader = new FileReader();
    reader.onload = e => {
      const result = e.target?.result as string;
      setAvatar(result);
      try {
        localStorage.setItem("zero-gram-avatar", result);
        toast.success(isArabic ? "تم تحديث الصورة الرمزية بنجاح." : "Avatar updated successfully.");
      } catch {
        toast.error(isArabic ? "فشل حفظ الصورة محليًا." : "Failed to save avatar locally.");
      }
    };
    reader.onerror = () => {
      toast.error(isArabic ? "حدث خطأ أثناء قراءة الصورة." : "Error reading image file.");
    };
    reader.readAsDataURL(file);
  };

  const handleStatusChange = (newStatus: UserStatus) => {
    setStatus(newStatus);
    try {
      localStorage.setItem("zero-gram-status", newStatus);
      toast.success(isArabic ? "تم تحديث حالة الاتصال." : "Status updated.");
    } catch {
      toast.error(isArabic ? "تعذر حفظ الحالة محليًا." : "Could not save status locally.");
    }
  };

  const clearLocalProfile = () => {
    try {
      localStorage.removeItem("zero-gram-avatar");
      localStorage.removeItem("zero-gram-status");
      setAvatar(null);
      setStatus("online");
      toast.success(isArabic ? "تم مسح بيانات الملف المحلية." : "Local profile data cleared.");
    } catch {
      toast.error(isArabic ? "تعذر مسح البيانات المحلية." : "Could not clear local data.");
    }
  };

  const exportProfile = (format: "csv" | "json") => {
    const activity = {
      exportedAt: new Date().toISOString(),
      userName: user?.name || "ZERO GRAM User",
      userEmail: user?.email || null,
      status,
      avatarStoredLocally: Boolean(avatar),
      storageScope: "current browser only",
      source: "ZERO GRAM Profile",
    };
    try {
      const body = buildProfileExport(activity, format);
      const blob = new Blob([body], { type: format === "json" ? "application/json" : "text/csv;charset=utf-8" });
      const url = URL.createObjectURL(blob);
      const anchor = document.createElement("a");
      anchor.href = url;
      anchor.download = `zero-gram-profile-${new Date().toISOString().slice(0, 10)}.${format}`;
      anchor.click();
      URL.revokeObjectURL(url);
      toast.success(isArabic ? "تم تصدير بيانات الملف الشخصي." : "Profile data exported.");
    } catch {
      toast.error(isArabic ? "تعذر تصدير البيانات." : "Could not export profile data.");
    }
  };

  return (
    <ZeroGramShell title={isArabic ? "الملف الشخصي" : "Profile"} eyebrow="ZERO GRAM / ACCOUNT">
      <div className="page-content">
        <section className="data-panel profile-panel">
          <header className="panel-header">
            <h3>{isArabic ? "إعدادات الحساب" : "Account settings"}</h3>
          </header>
          <div className="profile-grid">
            <div className="avatar-section">
              <div className="avatar-preview">
                {avatar ? (
                  <img
                    src={avatar}
                    alt={isArabic ? "الصورة الرمزية للمستخدم" : "User avatar"}
                  />
                ) : (
                  <User size={40} />
                )}
                <div className={`status-indicator ${status}`} />
              </div>
              <label className="action-button primary">
                <Camera size={14} />
                {isArabic ? "تغيير الصورة" : "Change avatar"}
                <input
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={handleAvatarUpload}
                />
              </label>
              <small>
                {isArabic ? "الحد الأقصى 2MB. تُحفظ محليًا فقط." : "Max 2MB. Saved locally only."}
              </small>
            </div>
            <div className="profile-details">
              <div className="detail-group">
                <label>{isArabic ? "الاسم" : "Name"}</label>
                <div className="detail-value">{user?.name || "ZERO GRAM User"}</div>
              </div>
              <div className="detail-group">
                <label>{isArabic ? "حالة الاتصال" : "Connection status"}</label>
                <div className="status-selector">
                  {(["online", "away", "offline"] as const).map(s => (
                    <button
                      key={s}
                      className={`status-btn ${status === s ? "active" : ""}`}
                      onClick={() => handleStatusChange(s)}
                    >
                      <span className={`status-dot ${s}`} />
                      {s === "online" ? (isArabic ? "متصل" : "Online") :
                       s === "away" ? (isArabic ? "بالخارج" : "Away") :
                       (isArabic ? "غير متصل" : "Offline")}
                      {status === s && <Check size={12} />}
                    </button>
                  ))}
                </div>
              </div>
              <div className="detail-group">
                <label>{isArabic ? "تصدير البيانات" : "Export data"}</label>
                <div className="profile-export">
                  <button className="action-button primary" onClick={() => exportProfile("csv")}>
                    <Download size={14} />
                    {isArabic ? "تصدير CSV" : "Export CSV"}
                  </button>
                  <button className="action-button" onClick={() => exportProfile("json")}>
                    <FileJson size={14} />
                    {isArabic ? "تصدير JSON" : "Export JSON"}
                  </button>
                </div>
                <small className="muted">{isArabic ? "يتضمن الحالة وسجل التصدير والبيانات المحلية المتاحة فقط." : "Includes status, export activity, and available local data only."}</small>
              </div>
              <div className="detail-group">
                <label>{isArabic ? "الخصوصية" : "Privacy"}</label>
                <div className="privacy-note">
                  <ShieldCheck size={14} />
                  {isArabic
                    ? "الصورة والحالة تُحفظان في متصفحك الحالي فقط ولا تُرسلان إلى خوادم خارجية."
                    : "Avatar and status are saved in your current browser only and are not sent to external servers."}
                </div>
              </div>
              <div className="profile-actions">
                <button className="action-button danger" onClick={clearLocalProfile}>
                  <Trash2 size={14} />
                  {isArabic ? "مسح البيانات المحلية" : "Clear local data"}
                </button>
              </div>
            </div>
          </div>
        </section>
      </div>
    </ZeroGramShell>
  );
}
