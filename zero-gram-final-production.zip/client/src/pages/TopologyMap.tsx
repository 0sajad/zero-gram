import {
  EmptyState,
  SectionHeading,
  ZeroGramShell,
} from "@/components/ZeroGramShell";
import { useI18n } from "@/lib/i18n";
import { trpc } from "@/lib/trpc";
import {
  AlertTriangle,
  GitBranch,
  MapPinned,
  Network,
  Route,
  Signal,
} from "lucide-react";
import { useMemo, useState } from "react";

export default function TopologyMap() {
  const { isArabic } = useI18n();
  const topology = trpc.topology.context.useQuery();
  const [focusId, setFocusId] = useState<number | null>(null);
  const data = topology.data;
  const latestFault = useMemo(
    () =>
      (data?.events || []).find(event =>
        ["critical", "high"].includes(event.severity)
      ) || null,
    [data?.events]
  );
  const faultPath = useMemo(() => {
    if (!data || !latestFault)
      return { nodes: new Set<number>(), edges: new Set<number>() };
    const anchor =
      latestFault.topologyNodeId ||
      data.nodes.find(node => node.deviceId === latestFault.deviceId)?.id;
    if (!anchor) return { nodes: new Set<number>(), edges: new Set<number>() };
    const nodes = new Set<number>([anchor]);
    const edges = new Set<number>();
    let cursor: number | undefined = anchor;
    const visited = new Set<number>();
    while (cursor && !visited.has(cursor)) {
      visited.add(cursor);
      const edge = data.edges.find(row => row.targetNodeId === cursor);
      if (!edge) break;
      edges.add(edge.id);
      nodes.add(edge.sourceNodeId);
      cursor = edge.sourceNodeId;
    }
    cursor = anchor;
    visited.clear();
    while (cursor && !visited.has(cursor)) {
      visited.add(cursor);
      const edge = data.edges.find(row => row.sourceNodeId === cursor);
      if (!edge) break;
      edges.add(edge.id);
      nodes.add(edge.targetNodeId);
      cursor = edge.targetNodeId;
    }
    return { nodes, edges };
  }, [data, latestFault]);
  const focused = focusId
    ? data?.nodes.find(node => node.id === focusId)
    : null;
  const relatedEdges = focusId
    ? (data?.edges || []).filter(
        edge => edge.sourceNodeId === focusId || edge.targetNodeId === focusId
      )
    : [];
  const metadata = (nodeId: number) => {
    const node = data?.nodes.find(row => row.id === nodeId);
    const device = data?.devices.find(row => row.id === node?.deviceId);
    const ip =
      (data?.ips || []).find(row => row.deviceId === device?.id)?.address ||
      device?.managementIpv4 ||
      device?.managementIpv6 ||
      "—";
    const signal = (data?.samples || []).find(
      row =>
        row.deviceId === device?.id &&
        /(optical_rx|wifi_signal|signal_dbm)/i.test(row.metric)
    );
    const connection =
      device?.connectionStatus || device?.linkStatus || node?.status || "—";
    const alertCount = (data?.openAlerts || []).filter(
      row =>
        row.topologyNodeId === nodeId || (device && row.deviceId === device.id)
    ).length;
    return {
      ip,
      signal: signal
        ? `${signal.valueDouble ?? signal.valueText ?? "—"} ${signal.unit || ""}`
        : "—",
      connection,
      alertCount,
    };
  };
  return (
    <ZeroGramShell
      title={isArabic ? "طوبولوجيا الشبكة" : "Network topology"}
      eyebrow="ZERO GRAM / TOPOLOGY MAP"
    >
      <div className="page-content topology-page">
        <SectionHeading
          index="F/MAP"
          title={isArabic ? "مسار الألياف والوصول" : "Fiber & access path"}
          description={
            isArabic
              ? "تظهر الحقول من الجرد والقياسات والتنبيهات اليدوية المحفوظة فقط. يميَّز مسار واحد مشتق من أحدث حدث شديد موثق، لا من استنتاج تاريخي عام."
              : "Fields come only from stored manual inventory, telemetry and alerts. One path is highlighted from the latest sourced severe event, not from a general historical inference."
          }
        />
        {topology.isLoading ? (
          <div className="panel-loading">…</div>
        ) : !data?.nodes.length ? (
          <EmptyState
            title={
              isArabic
                ? "لا توجد عقد طوبولوجيا مصدرية"
                : "No sourced topology nodes"
            }
            copy={
              isArabic
                ? "أضف عقدًا وروابط موثقة من مساحة الألياف، ثم استخدم خريطة المسار للتحقق."
                : "Add sourced nodes and edges from the Fiber workspace, then use this map for path verification."
            }
          />
        ) : (
          <>
            <section className="topology-summary">
              <span>
                <Network size={15} />
                {data.nodes.length} {isArabic ? "عقدة" : "nodes"}
              </span>
              <span>
                <GitBranch size={15} />
                {data.edges.length} {isArabic ? "رابط" : "edges"}
              </span>
              <span className={faultPath.nodes.size ? "fault" : ""}>
                <AlertTriangle size={15} />
                {faultPath.nodes.size}{" "}
                {isArabic
                  ? "عقدة في مسار الحدث الأحدث"
                  : "nodes on latest-event path"}
              </span>
            </section>
            {latestFault && (
              <section className="latest-fault">
                <AlertTriangle size={16} />
                <span>
                  {isArabic ? "أحدث دليل شديد:" : "Latest severe evidence:"}
                </span>
                <b>{latestFault.title}</b>
                <small>
                  {new Date(latestFault.occurredAt).toLocaleString()} ·{" "}
                  {latestFault.sourceLabel}
                </small>
              </section>
            )}
            <section className="topology-map-grid">
              {data.nodes.map(node => {
                const meta = metadata(node.id);
                return (
                  <button
                    key={node.id}
                    className={`topology-node ${faultPath.nodes.has(node.id) ? "affected" : ""} ${focusId === node.id ? "selected" : ""}`}
                    onClick={() => setFocusId(node.id)}
                  >
                    <span>{node.nodeKind}</span>
                    <b>{node.label}</b>
                    <small>
                      {node.status || "—"} · {node.reference || "—"}
                    </small>
                    <em>IP {meta.ip}</em>
                    <em>
                      <Signal size={10} />
                      {meta.signal} · {meta.connection}
                    </em>
                    <i className={meta.alertCount ? "has-alert" : ""}>
                      <AlertTriangle size={11} />
                      {meta.alertCount}{" "}
                      {isArabic ? "تنبيه مفتوح" : "open alerts"}
                    </i>
                  </button>
                );
              })}
            </section>
            {focused && (
              <section className="data-panel topology-inspector">
                <header>
                  <MapPinned size={16} />
                  <div>
                    <b>{focused.label}</b>
                    <small>
                      {focused.nodeKind} · {focused.status || "—"} ·{" "}
                      {focused.reference || "—"}
                    </small>
                  </div>
                </header>
                <div className="topology-relations">
                  <h3>
                    <Route size={15} />
                    {isArabic ? "روابط المسار الموثقة" : "Sourced path links"}
                  </h3>
                  {relatedEdges.length ? (
                    relatedEdges.map(edge => {
                      const from =
                        data.nodes.find(node => node.id === edge.sourceNodeId)
                          ?.label || edge.sourceNodeId;
                      const to =
                        data.nodes.find(node => node.id === edge.targetNodeId)
                          ?.label || edge.targetNodeId;
                      const affected = faultPath.edges.has(edge.id);
                      return (
                        <p className={affected ? "affected" : ""} key={edge.id}>
                          <b>{from}</b>
                          <span>→ {edge.relationType} →</span>
                          <b>{to}</b>
                          <small>
                            {edge.fiberLengthKm ?? "—"} km ·{" "}
                            {edge.baselineLossDb ?? "—"} dB ·{" "}
                            {edge.sourceLabel || "—"}
                          </small>
                        </p>
                      );
                    })
                  ) : (
                    <p className="muted">
                      {isArabic
                        ? "لا توجد روابط محفوظة لهذه العقدة."
                        : "No stored edges exist for this node."}
                    </p>
                  )}
                </div>
              </section>
            )}
          </>
        )}
      </div>
    </ZeroGramShell>
  );
}
