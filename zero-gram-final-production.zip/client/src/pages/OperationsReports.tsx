import {
  EmptyState,
  SectionHeading,
  ZeroGramShell,
} from "@/components/ZeroGramShell";
import { useConsolePreferences } from "@/components/ConsolePreferences";
import {
  exportOperationsExcel,
  exportOperationsPdf,
} from "@/lib/reportExports";
import { trpc } from "@/lib/trpc";
import { Download, FileSpreadsheet, FileText, ShieldCheck } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { useI18n } from "@/lib/i18n";

export default function OperationsReports() {
  const { isArabic } = useI18n();
  const { timeMode } = useConsolePreferences();
  const data = trpc.intelligence.overview.useQuery();
  const [exporting, setExporting] = useState<"" | "pdf" | "excel">("");
  const recordCount =
    (data.data?.capacity.sampleCount || 0) +
    (data.data?.reliability.sampleCount || 0) +
    (data.data?.incidents.length || 0) +
    (data.data?.changes.length || 0) +
    (data.data?.anomalies.length || 0);
  const run = (kind: "pdf" | "excel") => {
    if (!data.data) return;
    setExporting(kind);
    window.setTimeout(() => {
      try {
        if (kind === "pdf") exportOperationsPdf(data.data, timeMode);
        else exportOperationsExcel(data.data, timeMode);
        toast.success(
          isArabic
            ? "أُنشئ ملف الدليل من السجلات المتاحة."
            : "Evidence file created from available records."
        );
      } catch {
        toast.error(
          isArabic
            ? "تعذر إنشاء ملف الدليل."
            : "Could not create evidence file."
        );
      } finally {
        setExporting("");
      }
    }, 50);
  };
  return (
    <ZeroGramShell
      title={isArabic ? "تقارير العمليات" : "Operations reports"}
      eyebrow="ZERO GRAM / OPERATIONS EVIDENCE"
    >
      <div className="page-content">
        <SectionHeading
          index="R/07"
          title={isArabic ? "حزمة دليل العمليات" : "Operations evidence pack"}
          description={
            isArabic
              ? "تجمع ملفات PDF وExcel سياق الشركة ولقطات السعة والموثوقية المرصودة والشذوذات والحوادث والتغييرات المحفوظة. لا ينشئ التصدير قياسًا أو نتيجة جديدة."
              : "PDF and Excel collect stored company context, capacity snapshots, observed reliability, anomalies, incidents, and changes. Exporting never creates a measurement or a new result."
          }
        />
        <section className="data-panel operations-report-panel">
          <div className="report-export-dock">
            <div>
              <ShieldCheck size={17} />
              <span>
                {isArabic
                  ? "أدلة السعة والموثوقية والعمليات"
                  : "Capacity, reliability & operations evidence"}
              </span>
              <small>
                {recordCount}{" "}
                {isArabic
                  ? "سجل أو قيمة مشتقة من سجل"
                  : "stored or record-derived values"}
              </small>
            </div>
            <button
              className="action-button"
              disabled={!recordCount || Boolean(exporting)}
              onClick={() => run("pdf")}
            >
              {exporting === "pdf" ? (
                isArabic ? (
                  "جارٍ الإنشاء"
                ) : (
                  "Creating"
                )
              ) : (
                <>
                  <Download size={14} />
                  PDF
                </>
              )}
            </button>
            <button
              className="action-button primary"
              disabled={!recordCount || Boolean(exporting)}
              onClick={() => run("excel")}
            >
              {exporting === "excel" ? (
                isArabic ? (
                  "جارٍ الإنشاء"
                ) : (
                  "Creating"
                )
              ) : (
                <>
                  <FileSpreadsheet size={14} />
                  Excel
                </>
              )}
            </button>
          </div>
          {recordCount ? (
            <div className="operations-report-notes">
              <article>
                <FileText size={16} />
                <div>
                  <b>
                    {isArabic ? "ما يتضمنه الملف" : "What the file contains"}
                  </b>
                  <p>
                    {isArabic
                      ? "السعة والذروة والاتجاه إن وُجدت لقاطات؛ نجاح فحوصات HTTP المرصود وMTBF/MTTR إن وُجد تسلسل مراقبة؛ وحوادث وتغييرات وشذوذات ذات دليل."
                      : "Capacity, peak, and trend when snapshots exist; observed HTTP-check success and MTBF/MTTR when monitoring sequences exist; plus evidence-backed incidents, changes, and anomalies."}
                  </p>
                </div>
              </article>
              <article>
                <ShieldCheck size={16} />
                <div>
                  <b>{isArabic ? "حدود صريحة" : "Explicit limitations"}</b>
                  <p>
                    {isArabic
                      ? "الموثوقية المرصودة ليست ضمان uptime شاملًا، والشذوذ انحراف رقمي لا سبب جذري. القيم غير المتوفرة تبقى غير متوفرة في الملف."
                      : "Observed reliability is not a global uptime guarantee, and an anomaly is numeric deviation—not root cause. Unavailable values remain unavailable in the file."}
                  </p>
                </div>
              </article>
            </div>
          ) : (
            <EmptyState
              title={
                isArabic
                  ? "لا يوجد دليل مصدر قابل للتصدير"
                  : "No sourced evidence to export"
              }
              copy={
                isArabic
                  ? "أدخل سياقًا أو لقطة سعة أو حدث مراقبة أو حادثة أو تغييرًا أولًا؛ لا ينشئ ZERO GRAM سجلات افتراضية للتقرير."
                  : "Add context, a capacity snapshot, a monitoring event, an incident, or a change first; ZERO GRAM never creates default records for a report."
              }
            />
          )}
        </section>
      </div>
    </ZeroGramShell>
  );
}
