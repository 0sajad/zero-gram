import {
  EmptyState,
  SectionHeading,
  ZeroGramShell,
} from "@/components/ZeroGramShell";
import { useConsolePreferences } from "@/components/ConsolePreferences";
import {
  exportDiagnosticsExcel,
  exportDiagnosticsPdf,
  exportFiberExcel,
  exportFiberPdf,
  exportSlaExcel,
  exportSlaPdf,
} from "@/lib/reportExports";
import { useI18n } from "@/lib/i18n";
import { trpc } from "@/lib/trpc";
import {
  Download,
  FileJson,
  FileSpreadsheet,
  FileText,
  Filter,
  Printer,
  Search,
} from "lucide-react";
import { useMemo, useState } from "react";
import { toast } from "sonner";

const download = (name: string, body: string, type: string) => {
  const url = URL.createObjectURL(new Blob([body], { type }));
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = name;
  anchor.click();
  URL.revokeObjectURL(url);
};
export default function Reports() {
  const { isArabic, t } = useI18n();
  const { timeMode } = useConsolePreferences();
  const results = trpc.network.history.useQuery();
  const monitoring = trpc.monitoring.status.useQuery();
  const [range, setRange] = useState<"all" | "day" | "week">("all");
  const [search, setSearch] = useState("");
  const [exporting, setExporting] = useState<
    | ""
    | "diagnostic-pdf"
    | "diagnostic-xlsx"
    | "sla-pdf"
    | "sla-xlsx"
    | "fiber-pdf"
    | "fiber-xlsx"
  >("");
  const fiber = trpc.fiber.reportData.useQuery({
    days: range === "day" ? 1 : range === "week" ? 7 : 365,
  });
  const filtered = useMemo(() => {
    const since =
      range === "day"
        ? Date.now() - 86_400_000
        : range === "week"
          ? Date.now() - 604_800_000
          : 0;
    return (results.data || []).filter(
      row =>
        (!since || row.createdAt.getTime() >= since) &&
        (!search ||
          `${row.id} ${row.payloadJson}`
            .toLowerCase()
            .includes(search.toLowerCase()))
    );
  }, [results.data, range, search]);
  const events = useMemo(
    () =>
      (monitoring.data?.events || []).filter(
        event =>
          range === "all" ||
          event.checkedAt.getTime() >=
            (range === "day"
              ? Date.now() - 86_400_000
              : Date.now() - 604_800_000)
      ),
    [monitoring.data?.events, range]
  );
  const runExport = (kind: typeof exporting, action: () => void) => {
    setExporting(kind);
    window.setTimeout(() => {
      try {
        action();
        toast.success(
          isArabic ? "اكتمل إنشاء ملف التصدير." : "Export file created."
        );
      } catch {
        toast.error(
          isArabic ? "تعذر إنشاء ملف التصدير." : "Export could not be created."
        );
      } finally {
        setExporting("");
      }
    }, 50);
  };
  const fiberRecordCount =
    (fiber.data?.devices.length || 0) +
    (fiber.data?.telemetry.length || 0) +
    (fiber.data?.events.length || 0) +
    (fiber.data?.alerts.length || 0);
  return (
    <ZeroGramShell title={t("reports")} eyebrow="ZERO GRAM / EVIDENCE PACK">
      <div className="page-content">
        <SectionHeading
          index="04"
          title={
            isArabic
              ? "تقارير من السجل الحقيقي"
              : "Reports from the real record"
          }
          description={
            isArabic
              ? "تصدّر ملفات PDF وExcel من النتائج والأحداث المحفوظة فقط، مع المرجع والمصدر والدقة وحدود القياس. لا تتوفر ملفات عند غياب البيانات."
              : "PDF and Excel files export only from stored results and events, including references, sources, precision, and limitations. Files are unavailable when data is absent."
          }
        />
        <section className="data-panel report-panel">
          <div className="report-filter">
            <Filter size={15} />
            <span>{isArabic ? "نطاق السجل" : "Record range"}</span>
            <select
              value={range}
              onChange={event => setRange(event.target.value as typeof range)}
            >
              <option value="all">{isArabic ? "كل الوقت" : "All time"}</option>
              <option value="day">
                {isArabic ? "آخر 24 ساعة" : "Last 24 hours"}
              </option>
              <option value="week">
                {isArabic ? "آخر 7 أيام" : "Last 7 days"}
              </option>
            </select>
            <label className="report-search">
              <Search size={13} />
              <input
                value={search}
                onChange={event => setSearch(event.target.value)}
                placeholder={isArabic ? "ابحث بالمرجع" : "Search reference"}
              />
            </label>
            <b>{filtered.length}</b>
          </div>
          <div className="report-export-dock">
            <div>
              <FileText size={17} />
              <span>
                {isArabic ? "تشخيصات الاتصال" : "Connection diagnostics"}
              </span>
              <small>
                {filtered.length} {isArabic ? "نتيجة محفوظة" : "stored results"}
              </small>
            </div>
            <button
              className="action-button"
              disabled={!filtered.length || Boolean(exporting)}
              onClick={() =>
                runExport("diagnostic-pdf", () =>
                  exportDiagnosticsPdf(filtered, timeMode)
                )
              }
            >
              {exporting === "diagnostic-pdf" ? (
                t("loading")
              ) : (
                <>
                  <Download size={14} />
                  PDF
                </>
              )}
            </button>
            <button
              className="action-button primary"
              disabled={!filtered.length || Boolean(exporting)}
              onClick={() =>
                runExport("diagnostic-xlsx", () =>
                  exportDiagnosticsExcel(filtered, timeMode)
                )
              }
            >
              {exporting === "diagnostic-xlsx" ? (
                t("loading")
              ) : (
                <>
                  <FileSpreadsheet size={14} />
                  Excel
                </>
              )}
            </button>
          </div>
          <div className="report-export-dock">
            <div>
              <FileJson size={17} />
              <span>{isArabic ? "SLA والمراقبة" : "SLA & monitoring"}</span>
              <small>
                {events.length} {isArabic ? "حدث محفوظ" : "stored events"}
              </small>
            </div>
            <button
              className="action-button"
              disabled={!events.length || Boolean(exporting)}
              onClick={() =>
                runExport("sla-pdf", () =>
                  exportSlaPdf(
                    monitoring.data?.profiles || [],
                    events,
                    timeMode
                  )
                )
              }
            >
              {exporting === "sla-pdf" ? (
                t("loading")
              ) : (
                <>
                  <Download size={14} />
                  PDF
                </>
              )}
            </button>
            <button
              className="action-button primary"
              disabled={!events.length || Boolean(exporting)}
              onClick={() =>
                runExport("sla-xlsx", () =>
                  exportSlaExcel(
                    monitoring.data?.profiles || [],
                    events,
                    timeMode
                  )
                )
              }
            >
              {exporting === "sla-xlsx" ? (
                t("loading")
              ) : (
                <>
                  <FileSpreadsheet size={14} />
                  Excel
                </>
              )}
            </button>
          </div>
          <div className="report-export-dock">
            <div>
              <FileSpreadsheet size={17} />
              <span>
                {isArabic
                  ? "Fiber / GPON / الصحة / التنبيهات"
                  : "Fiber / GPON / health / alerts"}
              </span>
              <small>
                {fiberRecordCount} {isArabic ? "سجل مصدر" : "sourced records"}
              </small>
            </div>
            <button
              className="action-button"
              disabled={!fiberRecordCount || Boolean(exporting)}
              onClick={() =>
                runExport("fiber-pdf", () =>
                  exportFiberPdf(fiber.data!, timeMode)
                )
              }
            >
              {exporting === "fiber-pdf" ? (
                t("loading")
              ) : (
                <>
                  <Download size={14} />
                  PDF
                </>
              )}
            </button>
            <button
              className="action-button primary"
              disabled={!fiberRecordCount || Boolean(exporting)}
              onClick={() =>
                runExport("fiber-xlsx", () =>
                  exportFiberExcel(fiber.data!, timeMode)
                )
              }
            >
              {exporting === "fiber-xlsx" ? (
                t("loading")
              ) : (
                <>
                  <FileSpreadsheet size={14} />
                  Excel
                </>
              )}
            </button>
          </div>
          {results.isLoading || monitoring.isLoading || fiber.isLoading ? (
            <div className="panel-loading">{t("loading")}</div>
          ) : filtered.length ? (
            <>
              <div className="report-masthead">
                <span>ZERO GRAM</span>
                <h2>
                  {isArabic
                    ? "ملخص قياسات الاتصال"
                    : "Connection measurement summary"}
                </h2>
                <p>
                  {isArabic
                    ? "الملفات المُصدّرة توثق السجل المحفوظ ضمن النطاق الزمني المختار، ولا تُنشأ قياسات جديدة أثناء التصدير."
                    : "Exported files document stored records within the selected range; exporting never creates new measurements."}
                </p>
              </div>
              <div className="report-list">
                {filtered.map(row => (
                  <article key={row.id}>
                    <span className="metric-value">
                      REF-{String(row.id).padStart(6, "0")}
                    </span>
                    <div>
                      <b>
                        {new Date(row.createdAt).toLocaleString(
                          isArabic ? "ar" : "en",
                          timeMode === "utc" ? { timeZone: "UTC" } : undefined
                        )}
                      </b>
                      <p>
                        {isArabic
                          ? "المصادر والدقة وحدود القياس مضمنة في سجل النتيجة وملف التصدير."
                          : "Sources, precision, and measurement limits are embedded in the result record and export file."}
                      </p>
                    </div>
                  </article>
                ))}
              </div>
              <div className="quick-actions report-print">
                <button
                  className="action-button"
                  onClick={() => window.print()}
                >
                  <Printer size={14} />
                  {t("print")}
                </button>
                <button
                  className="action-button"
                  onClick={() =>
                    download(
                      "zero-gram-results.json",
                      JSON.stringify(filtered, null, 2),
                      "application/json"
                    )
                  }
                >
                  <FileJson size={14} />
                  JSON
                </button>
              </div>
            </>
          ) : (
            <EmptyState
              title={t("noData")}
              copy={
                isArabic
                  ? "لا توجد نتائج محفوظة ضمن النطاق أو البحث الذي اخترته؛ لذلك لا يُنشأ ملف تصدير."
                  : "No results match your selected range or search, so no export file is created."
              }
            />
          )}
        </section>
      </div>
    </ZeroGramShell>
  );
}
