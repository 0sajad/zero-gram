import {
  EmptyState,
  SectionHeading,
  ZeroGramShell,
} from "@/components/ZeroGramShell";
import { useI18n } from "@/lib/i18n";
import { trpc } from "@/lib/trpc";
import {
  Activity,
  AlertTriangle,
  Boxes,
  Cable,
  CheckCircle2,
  Cpu,
  DatabaseZap,
  GitBranch,
  LineChart,
  Loader2,
  Network,
  Plus,
  Radio,
  Router,
  Save,
  Search,
  Server,
  ShieldAlert,
  Signal,
  Timer,
  Wifi,
} from "lucide-react";
import { useMemo, useState } from "react";
import { toast } from "sonner";
import {
  Area,
  AreaChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";

type Tab =
  | "overview"
  | "inventory"
  | "signals"
  | "troubleshoot"
  | "topology"
  | "timeline";
const stringValue = (form: FormData, key: string) =>
  String(form.get(key) || "").trim();
const numericValue = (form: FormData, key: string) => {
  const value = stringValue(form, key);
  return value === "" ? undefined : Number(value);
};

export default function FiberConsole() {
  const { isArabic, t } = useI18n();
  const utils = trpc.useUtils();
  const { data, isLoading, error } = trpc.fiber.overview.useQuery();
  const [tab, setTab] = useState<Tab>("overview");
  const [selectedDeviceId, setSelectedDeviceId] = useState<number | null>(null);
  const [search, setSearch] = useState("");
  const [chartMetric, setChartMetric] = useState("optical_rx_dbm");
  const detail = trpc.fiber.deviceDetails.useQuery(
    { deviceId: selectedDeviceId || 1, telemetryDays: 90 },
    { enabled: Boolean(selectedDeviceId) }
  );
  const searchResult = trpc.fiber.globalSearch.useQuery(
    { query: search || "__" },
    { enabled: search.trim().length >= 2 }
  );
  const refresh = () =>
    Promise.all([
      utils.fiber.overview.invalidate(),
      selectedDeviceId
        ? utils.fiber.deviceDetails.invalidate({
            deviceId: selectedDeviceId,
            telemetryDays: 90,
          })
        : Promise.resolve(),
    ]);
  const createDevice = trpc.fiber.createDevice.useMutation({
    onSuccess: async ({ deviceId }) => {
      await refresh();
      setSelectedDeviceId(deviceId);
      toast.success(
        isArabic ? "تم حفظ الجهاز مع مصدره." : "Device and source were saved."
      );
    },
  });
  const addPon = trpc.fiber.addPonPort.useMutation({ onSuccess: refresh });
  const addOnt = trpc.fiber.addOnt.useMutation({ onSuccess: refresh });
  const addIp = trpc.fiber.addIpAddress.useMutation({ onSuccess: refresh });
  const addEthernet = trpc.fiber.addEthernetPort.useMutation({
    onSuccess: refresh,
  });
  const addWifi = trpc.fiber.addWifiNetwork.useMutation({ onSuccess: refresh });
  const addSession = trpc.fiber.addServiceSession.useMutation({
    onSuccess: refresh,
  });
  const addTelemetry = trpc.fiber.recordTelemetry.useMutation({
    onSuccess: async () => {
      await refresh();
      toast.success(
        isArabic
          ? "حُفظت القراءة بتاريخها ومصدرها."
          : "The source-backed reading was saved."
      );
    },
  });
  const addNode = trpc.fiber.addTopologyNode.useMutation({
    onSuccess: refresh,
  });
  const addEdge = trpc.fiber.addTopologyEdge.useMutation({
    onSuccess: refresh,
  });
  const addEvent = trpc.fiber.addEvent.useMutation({ onSuccess: refresh });
  const addAlert = trpc.fiber.addAlert.useMutation({
    onSuccess: async () => {
      await refresh();
      toast.success(
        isArabic ? "حُفظ التنبيه مع دليله." : "Alert and evidence were saved."
      );
    },
  });
  const saveHealth = trpc.fiber.saveHealthSnapshot.useMutation({
    onSuccess: async () => {
      await refresh();
      toast.success(
        isArabic
          ? "حُفظت لقطة الصحة التفسيرية."
          : "The explainable health snapshot was saved."
      );
    },
  });
  const devices = data?.devices || [];
  const selected = detail.data;
  const metricOptions = useMemo(
    () =>
      Array.from(
        new Set(
          (selected?.samples || [])
            .filter(sample => sample.valueDouble !== null)
            .map(sample => sample.metric)
        )
      ),
    [selected?.samples]
  );
  const chart = useMemo(
    () =>
      (selected?.samples || [])
        .filter(
          sample => sample.valueDouble !== null && sample.metric === chartMetric
        )
        .map(sample => ({
          at: new Date(sample.measuredAt).toLocaleDateString(
            isArabic ? "ar" : "en"
          ),
          value: sample.valueDouble,
          unit: sample.unit || "",
        }))
        .reverse(),
    [selected?.samples, isArabic, chartMetric]
  );
  const submitDevice = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    createDevice.mutate({
      label: stringValue(form, "label"),
      deviceType: stringValue(form, "type"),
      vendor: stringValue(form, "vendor") || undefined,
      model: stringValue(form, "model") || undefined,
      serialNumber: stringValue(form, "serial") || undefined,
      macAddress: stringValue(form, "mac") || undefined,
      managementIpv4: stringValue(form, "ipv4") || undefined,
      managementIpv6: stringValue(form, "ipv6") || undefined,
      hostname: stringValue(form, "hostname") || undefined,
      firmwareVersion: stringValue(form, "firmware") || undefined,
      sourceLabel: stringValue(form, "source") || "Manual inventory",
      sourceObservedAt: new Date(),
    });
  };
  if (isLoading)
    return (
      <ZeroGramShell title={t("fiber")} eyebrow="ZERO GRAM / FIBER OPS">
        <div className="page-content loading-shell">
          <Loader2 className="spin" />
          <p>{t("loading")}</p>
        </div>
      </ZeroGramShell>
    );
  if (error)
    return (
      <ZeroGramShell title={t("fiber")} eyebrow="ZERO GRAM / FIBER OPS">
        <div className="page-content">
          <EmptyState
            title={
              isArabic
                ? "تعذر تحميل بيانات المؤسسة"
                : "Unable to load organization data"
            }
            copy={error.message}
          />
        </div>
      </ZeroGramShell>
    );
  return (
    <ZeroGramShell title={t("fiber")} eyebrow="ZERO GRAM / OPTICAL COMMAND">
      <div className="page-content fiber-console">
        <SectionHeading
          index="F/01"
          title={
            isArabic
              ? "بنية الألياف، GPON، والدليل التشغيلي"
              : "Fiber, GPON & operational evidence"
          }
          description={
            isArabic
              ? "لا تُعرض القراءات أو الطوبولوجيا أو التحليلات إلا من سجلات مؤسستك المحفوظة أو المدخلة يدويًا مع مصدرها."
              : "Readings, topology and diagnosis come only from your stored or manually entered organization records, with their source."
          }
          action={
            <button className="action-button" onClick={() => refresh()}>
              <Activity size={15} />
              {isArabic ? "تحديث السجل" : "Refresh records"}
            </button>
          }
        />
        <div className="fiber-tabs">
          {(
            [
              "overview",
              "inventory",
              "signals",
              "troubleshoot",
              "topology",
              "timeline",
            ] as Tab[]
          ).map(item => (
            <button
              key={item}
              className={tab === item ? "active" : ""}
              onClick={() => setTab(item)}
            >
              {item === "overview"
                ? isArabic
                  ? "النظرة"
                  : "Overview"
                : item === "inventory"
                  ? isArabic
                    ? "الجرد"
                    : "Inventory"
                  : item === "signals"
                    ? isArabic
                      ? "القراءات والصحة"
                      : "Signals & health"
                    : item === "troubleshoot"
                      ? isArabic
                        ? "لماذا متوقفة؟"
                        : "Why down?"
                      : item === "topology"
                        ? "Topology"
                        : isArabic
                          ? "الأحداث والتنبيهات"
                          : "Events & alerts"}
            </button>
          ))}
        </div>
        {tab === "overview" && (
          <Overview
            data={data}
            isArabic={isArabic}
            onSelect={setSelectedDeviceId}
          />
        )}
        {tab === "inventory" && (
          <section className="fiber-layout">
            <div className="data-panel technical-form">
              <div className="panel-header">
                <h3>
                  {isArabic ? "تسجيل جهاز موثق" : "Register sourced device"}
                </h3>
                <span>INVENTORY</span>
              </div>
              <form onSubmit={submitDevice}>
                <div className="field-grid">
                  <label>
                    {isArabic ? "اسم الجهاز" : "Device label"}
                    <input required name="label" />
                  </label>
                  <label>
                    {isArabic ? "النوع" : "Type"}
                    <select name="type" defaultValue="ont">
                      <option value="olt">OLT</option>
                      <option value="ont">ONT / ONU</option>
                      <option value="router">Router</option>
                      <option value="switch">Switch</option>
                      <option value="gateway">Gateway</option>
                      <option value="access_point">Access Point</option>
                      <option value="splitter">Splitter</option>
                      <option value="distribution_box">Distribution Box</option>
                    </select>
                  </label>
                  <label>
                    Vendor
                    <input name="vendor" />
                  </label>
                  <label>
                    Model
                    <input name="model" />
                  </label>
                  <label>
                    Serial
                    <input name="serial" />
                  </label>
                  <label>
                    MAC
                    <input name="mac" />
                  </label>
                  <label>
                    IPv4
                    <input name="ipv4" />
                  </label>
                  <label>
                    IPv6
                    <input name="ipv6" />
                  </label>
                  <label>
                    Hostname
                    <input name="hostname" />
                  </label>
                  <label>
                    Firmware
                    <input name="firmware" />
                  </label>
                </div>
                <label>
                  {isArabic ? "مصدر السجل" : "Record source"}
                  <input
                    required
                    name="source"
                    placeholder={
                      isArabic
                        ? "مثال: تصدير OLT بتاريخ …"
                        : "Example: OLT export dated …"
                    }
                  />
                </label>
                <button
                  className="action-button primary"
                  disabled={createDevice.isPending}
                >
                  <Save size={15} />
                  {isArabic ? "حفظ الجهاز" : "Save device"}
                </button>
              </form>
            </div>
            <InventoryList
              devices={devices}
              isArabic={isArabic}
              onSelect={setSelectedDeviceId}
            />
            <ProvisionPanel
              devices={devices}
              isArabic={isArabic}
              onPon={payload => addPon.mutate(payload)}
              onOnt={payload => addOnt.mutate(payload)}
            />
            <NetworkSourcePanel
              devices={devices}
              isArabic={isArabic}
              onIp={payload => addIp.mutate(payload)}
              onEthernet={payload => addEthernet.mutate(payload)}
              onWifi={payload => addWifi.mutate(payload)}
              onSession={payload => addSession.mutate(payload)}
            />
          </section>
        )}
        {tab === "signals" && (
          <section className="fiber-layout">
            <div className="data-panel technical-form">
              <div className="panel-header">
                <h3>
                  {isArabic ? "تسجيل قراءة موثقة" : "Record sourced telemetry"}
                </h3>
                <span>NO SYNTHETIC DATA</span>
              </div>
              <form
                onSubmit={event => {
                  event.preventDefault();
                  const form = new FormData(event.currentTarget);
                  const deviceId = Number(stringValue(form, "device"));
                  addTelemetry.mutate({
                    deviceId,
                    metric: stringValue(form, "metric"),
                    valueDouble: numericValue(form, "value"),
                    valueText: stringValue(form, "text") || undefined,
                    unit: stringValue(form, "unit") || undefined,
                    state: stringValue(form, "state") || undefined,
                    sourceLabel: stringValue(form, "source"),
                    measuredAt: new Date(stringValue(form, "measuredAt")),
                  });
                }}
              >
                <label>
                  {isArabic ? "الجهاز" : "Device"}
                  <select name="device" required defaultValue="">
                    {" "}
                    <option value="" disabled>
                      {isArabic ? "اختر جهازًا" : "Select device"}
                    </option>
                    {devices.map(device => (
                      <option key={device.id} value={device.id}>
                        {device.label} · {device.deviceType}
                      </option>
                    ))}
                  </select>
                </label>
                <div className="field-grid">
                  <label>
                    Metric
                    <select name="metric" defaultValue="optical_rx_dbm">
                      <option value="optical_rx_dbm">Optical RX</option>
                      <option value="optical_tx_dbm">Optical TX</option>
                      <option value="optical_loss_db">Optical loss</option>
                      <option value="latency_ms">Latency</option>
                      <option value="packet_loss_percent">Packet loss</option>
                      <option value="temperature_c">Temperature</option>
                      <option value="cpu_percent">CPU</option>
                      <option value="memory_percent">Memory</option>
                      <option value="uptime_seconds">Uptime</option>
                    </select>
                  </label>
                  <label>
                    {isArabic ? "قيمة رقمية" : "Numeric value"}
                    <input name="value" type="number" step="any" />
                  </label>
                  <label>
                    {isArabic ? "الوحدة" : "Unit"}
                    <input name="unit" placeholder="dBm / dB / ms / %" />
                  </label>
                  <label>
                    {isArabic ? "الحالة إن وجدت" : "State if supplied"}
                    <input name="state" placeholder="up / down / LOS" />
                  </label>
                </div>
                <label>
                  {isArabic ? "مصدر القراءة" : "Reading source"}
                  <input required name="source" />
                </label>
                <label>
                  {isArabic ? "وقت القياس" : "Measured at"}
                  <input
                    required
                    name="measuredAt"
                    type="datetime-local"
                    defaultValue={new Date().toISOString().slice(0, 16)}
                  />
                </label>
                <button
                  className="action-button primary"
                  disabled={addTelemetry.isPending}
                >
                  <DatabaseZap size={15} />
                  {isArabic ? "حفظ القراءة" : "Save reading"}
                </button>
              </form>
            </div>
            <DeviceDetail
              data={selected}
              devices={devices}
              selectedDeviceId={selectedDeviceId}
              onSelect={setSelectedDeviceId}
              chart={chart}
              chartMetric={chartMetric}
              metricOptions={metricOptions}
              onMetric={setChartMetric}
              isArabic={isArabic}
              onSaveHealth={() =>
                selectedDeviceId &&
                saveHealth.mutate({ deviceId: selectedDeviceId })
              }
            />
          </section>
        )}
        {tab === "troubleshoot" && (
          <WhyDown
            devices={devices}
            selectedDeviceId={selectedDeviceId}
            onSelect={setSelectedDeviceId}
            data={selected}
            isArabic={isArabic}
          />
        )}
        {tab === "topology" && (
          <section className="fiber-layout topology-layout">
            <TopologyCanvas
              nodes={data?.nodes || []}
              edges={data?.edges || []}
              isArabic={isArabic}
            />
            <div className="data-panel technical-form">
              <div className="panel-header">
                <h3>
                  {isArabic ? "ربط المسار الفعلي" : "Map the actual path"}
                </h3>
                <span>GRAPH</span>
              </div>
              <form
                onSubmit={event => {
                  event.preventDefault();
                  const form = new FormData(event.currentTarget);
                  addNode.mutate({
                    nodeKind: stringValue(form, "kind") as "olt",
                    label: stringValue(form, "label"),
                    reference: stringValue(form, "reference") || undefined,
                    status: stringValue(form, "status") || undefined,
                    sourceLabel: stringValue(form, "source") || undefined,
                  });
                }}
              >
                <label>
                  {isArabic ? "العنصر" : "Node kind"}
                  <select name="kind">
                    <option value="internet">Internet</option>
                    <option value="core">Core</option>
                    <option value="olt">OLT</option>
                    <option value="pon">PON</option>
                    <option value="splitter">Splitter</option>
                    <option value="fiber">Fiber</option>
                    <option value="distribution_box">Distribution box</option>
                    <option value="ont">ONT / ONU</option>
                    <option value="router">Router</option>
                    <option value="access_point">Access point</option>
                    <option value="client">Client</option>
                  </select>
                </label>
                <label>
                  {isArabic ? "الاسم" : "Label"}
                  <input required name="label" />
                </label>
                <label>
                  {isArabic ? "المرجع" : "Reference"}
                  <input name="reference" />
                </label>
                <label>
                  {isArabic ? "الحالة" : "Status"}
                  <input name="status" />
                </label>
                <label>
                  {isArabic ? "المصدر" : "Source"}
                  <input name="source" />
                </label>
                <button className="action-button primary">
                  <Plus size={15} />
                  {isArabic ? "إضافة عقدة" : "Add node"}
                </button>
              </form>
              <form
                className="edge-form"
                onSubmit={event => {
                  event.preventDefault();
                  const form = new FormData(event.currentTarget);
                  addEdge.mutate({
                    sourceNodeId: Number(stringValue(form, "from")),
                    targetNodeId: Number(stringValue(form, "to")),
                    relationType: stringValue(form, "relation"),
                    fiberLengthKm: numericValue(form, "length"),
                    baselineLossDb: numericValue(form, "loss"),
                    sourceLabel: stringValue(form, "source") || undefined,
                  });
                }}
              >
                <h4>{isArabic ? "إضافة وصلة" : "Add link"}</h4>
                <label>
                  {isArabic ? "من" : "From"}
                  <select name="from" required defaultValue="">
                    {" "}
                    <option value="" disabled>
                      —
                    </option>
                    {(data?.nodes || []).map(node => (
                      <option key={node.id} value={node.id}>
                        {node.label}
                      </option>
                    ))}
                  </select>
                </label>
                <label>
                  {isArabic ? "إلى" : "To"}
                  <select name="to" required defaultValue="">
                    {" "}
                    <option value="" disabled>
                      —
                    </option>
                    {(data?.nodes || []).map(node => (
                      <option key={node.id} value={node.id}>
                        {node.label}
                      </option>
                    ))}
                  </select>
                </label>
                <label>
                  {isArabic ? "العلاقة" : "Relation"}
                  <input
                    required
                    name="relation"
                    placeholder="feeds / fiber / uplink"
                  />
                </label>
                <label>
                  {isArabic ? "طول الألياف كم" : "Fiber km"}
                  <input name="length" type="number" step="any" />
                </label>
                <label>
                  {isArabic ? "فقد خط الأساس dB" : "Baseline loss dB"}
                  <input name="loss" type="number" step="any" />
                </label>
                <label>
                  {isArabic ? "المصدر" : "Source"}
                  <input name="source" />
                </label>
                <button className="action-button">
                  <GitBranch size={15} />
                  {isArabic ? "ربط العقد" : "Link nodes"}
                </button>
              </form>
            </div>
          </section>
        )}
        {tab === "timeline" && (
          <section className="fiber-layout">
            <div className="data-panel technical-form">
              <div className="panel-header">
                <h3>{isArabic ? "حدث موثق" : "Sourced event"}</h3>
                <span>TIMELINE</span>
              </div>
              <form
                onSubmit={event => {
                  event.preventDefault();
                  const form = new FormData(event.currentTarget);
                  addEvent.mutate({
                    deviceId: Number(stringValue(form, "device")) || undefined,
                    eventType: stringValue(form, "type"),
                    title: stringValue(form, "title"),
                    severity: stringValue(form, "severity") as "critical",
                    evidence: stringValue(form, "evidence")
                      ? stringValue(form, "evidence")
                          .split("\n")
                          .filter(Boolean)
                      : undefined,
                    sourceLabel: stringValue(form, "source"),
                    occurredAt: new Date(stringValue(form, "time")),
                  });
                }}
              >
                <label>
                  {isArabic ? "الجهاز (اختياري)" : "Device (optional)"}
                  <select name="device" defaultValue="">
                    <option value="">—</option>
                    {devices.map(device => (
                      <option key={device.id} value={device.id}>
                        {device.label}
                      </option>
                    ))}
                  </select>
                </label>
                <label>
                  {isArabic ? "نوع الحدث" : "Event type"}
                  <input
                    required
                    name="type"
                    placeholder="LOS / reboot / PPPoE"
                  />
                </label>
                <label>
                  {isArabic ? "العنوان" : "Title"}
                  <input required name="title" />
                </label>
                <label>
                  {isArabic ? "الشدة" : "Severity"}
                  <select name="severity">
                    <option value="critical">Critical</option>
                    <option value="high">High</option>
                    <option value="medium">Medium</option>
                    <option value="low">Low</option>
                    <option value="informational">Informational</option>
                  </select>
                </label>
                <label>
                  {isArabic
                    ? "الدليل (سطر لكل عنصر)"
                    : "Evidence (one per line)"}
                  <textarea name="evidence" />
                </label>
                <label>
                  {isArabic ? "المصدر" : "Source"}
                  <input required name="source" />
                </label>
                <label>
                  {isArabic ? "وقت الحدث" : "Occurred at"}
                  <input
                    required
                    name="time"
                    type="datetime-local"
                    defaultValue={new Date().toISOString().slice(0, 16)}
                  />
                </label>
                <button className="action-button primary">
                  <Plus size={15} />
                  {isArabic ? "حفظ الحدث" : "Save event"}
                </button>
              </form>
            </div>
            <AlertEntry
              devices={devices}
              isArabic={isArabic}
              onAlert={payload => addAlert.mutate(payload)}
            />
            <Timeline
              events={data?.events || []}
              alerts={data?.openAlerts || []}
              isArabic={isArabic}
            />
          </section>
        )}
        <section className="fiber-search data-panel">
          <div>
            <Search size={17} />
            <div>
              <h3>
                {isArabic
                  ? "بحث شامل في البنية"
                  : "Global infrastructure search"}
              </h3>
              <p>
                {isArabic
                  ? "IP، MAC، Serial، ONT/ONU، OLT، PON، اسم الجهاز، PPPoE، VLAN والعملاء."
                  : "IP, MAC, serial, ONT/ONU, OLT, PON, device, PPPoE, VLAN and clients."}
              </p>
            </div>
          </div>
          <input
            value={search}
            onChange={event => setSearch(event.target.value)}
            placeholder={
              isArabic
                ? "ابحث برقم تسلسلي أو IP أو MAC…"
                : "Search serial, IP, MAC…"
            }
          />
          {search.trim().length >= 2 && (
            <div className="search-result-list">
              {searchResult.isLoading ? (
                <Loader2 className="spin" />
              ) : (
                <>
                  <b>{isArabic ? "النتائج المرتبطة" : "Linked results"}</b>
                  <span>
                    {(searchResult.data?.devices.length || 0) +
                      (searchResult.data?.ips.length || 0) +
                      (searchResult.data?.onts.length || 0)}{" "}
                    {isArabic ? "سجلًا" : "records"}
                  </span>
                  {searchResult.data?.devices.map(device => (
                    <button
                      key={device.id}
                      onClick={() => {
                        setSelectedDeviceId(device.id);
                        setTab("signals");
                      }}
                    >
                      {device.label} · {device.deviceType}
                    </button>
                  ))}
                </>
              )}
            </div>
          )}
        </section>
      </div>
    </ZeroGramShell>
  );
}

function Overview({
  data,
  isArabic,
  onSelect,
}: {
  data: any;
  isArabic: boolean;
  onSelect: (id: number) => void;
}) {
  const cards = [
    {
      label: isArabic ? "أجهزة مسجلة" : "Sourced devices",
      value: data?.devices.length || 0,
      icon: Server,
    },
    {
      label: isArabic ? "منافذ PON" : "PON ports",
      value: data?.ports.length || 0,
      icon: Cable,
    },
    {
      label: isArabic ? "ONU / ONT" : "ONU / ONT",
      value: data?.onts.length || 0,
      icon: Router,
    },
    {
      label: isArabic ? "تنبيهات مفتوحة" : "Open alerts",
      value: data?.openAlerts.length || 0,
      icon: ShieldAlert,
    },
  ];
  return (
    <>
      <div className="fiber-stat-grid">
        {cards.map(card => (
          <article key={card.label}>
            <card.icon size={18} />
            <b>{card.value}</b>
            <span>{card.label}</span>
          </article>
        ))}
      </div>
      <section className="fiber-layout">
        <InventoryList
          devices={data?.devices || []}
          isArabic={isArabic}
          onSelect={onSelect}
        />
        <Timeline
          events={data?.events || []}
          alerts={data?.openAlerts || []}
          isArabic={isArabic}
        />
      </section>
    </>
  );
}
function InventoryList({
  devices,
  isArabic,
  onSelect,
}: {
  devices: any[];
  isArabic: boolean;
  onSelect: (id: number) => void;
}) {
  return (
    <section className="data-panel inventory-list">
      <div className="panel-header">
        <h3>{isArabic ? "الأجهزة والسجلات" : "Devices & source records"}</h3>
        <span>{devices.length}</span>
      </div>
      {devices.length ? (
        devices.map(device => (
          <button
            key={device.id}
            className="device-row"
            onClick={() => onSelect(device.id)}
          >
            <span className="device-icon">
              <Server size={16} />
            </span>
            <span>
              <b>{device.label}</b>
              <small>
                {device.deviceType} · {device.vendor || "—"}{" "}
                {device.model || ""}
              </small>
            </span>
            <span
              className={
                device.connectionStatus === "down"
                  ? "state-bad"
                  : "state-neutral"
              }
            >
              {device.connectionStatus ||
                (isArabic ? "غير مؤكد" : "unconfirmed")}
            </span>
          </button>
        ))
      ) : (
        <EmptyState
          title={isArabic ? "لا يوجد جرد فعلي بعد" : "No sourced inventory yet"}
          copy={
            isArabic
              ? "سجّل جهازًا أو استورد بيانات موثقة؛ لن تنشئ المنصة أجهزة أو IPs افتراضية."
              : "Register a device or import sourced data; the platform will not generate devices or IPs."
          }
        />
      )}
    </section>
  );
}
function ProvisionPanel({
  devices,
  isArabic,
  onPon,
  onOnt,
}: {
  devices: any[];
  isArabic: boolean;
  onPon: (input: any) => void;
  onOnt: (input: any) => void;
}) {
  return (
    <section className="data-panel technical-form provision">
      <div className="panel-header">
        <h3>{isArabic ? "ربط OLT / PON / ONT" : "Link OLT / PON / ONT"}</h3>
        <span>GPON</span>
      </div>
      <form
        onSubmit={event => {
          event.preventDefault();
          const form = new FormData(event.currentTarget);
          onPon({
            oltDeviceId: Number(stringValue(form, "olt")),
            label: stringValue(form, "label"),
            ponIndex: stringValue(form, "index") || undefined,
            operationalStatus: stringValue(form, "status") || undefined,
            maxOnts: numericValue(form, "max"),
            sourceLabel: stringValue(form, "source") || undefined,
            sourceObservedAt: new Date(),
          });
        }}
      >
        <h4>{isArabic ? "منفذ PON" : "PON port"}</h4>
        <label>
          OLT
          <select required name="olt" defaultValue="">
            <option value="" disabled>
              —
            </option>
            {devices
              .filter(device => device.deviceType.toLowerCase() === "olt")
              .map(device => (
                <option key={device.id} value={device.id}>
                  {device.label}
                </option>
              ))}
          </select>
        </label>
        <label>
          PON
          <input required name="label" placeholder="PON 1/1/1" />
        </label>
        <label>
          {isArabic ? "الفهرس" : "Index"}
          <input name="index" />
        </label>
        <label>
          {isArabic ? "الحالة" : "Status"}
          <input name="status" />
        </label>
        <label>
          {isArabic ? "الحد" : "Capacity"}
          <input name="max" type="number" />
        </label>
        <label>
          {isArabic ? "المصدر" : "Source"}
          <input name="source" />
        </label>
        <button className="action-button">
          <Plus size={14} />
          {isArabic ? "إضافة PON" : "Add PON"}
        </button>
      </form>
      <form
        onSubmit={event => {
          event.preventDefault();
          const form = new FormData(event.currentTarget);
          onOnt({
            deviceId: Number(stringValue(form, "ontDevice")),
            onuId: stringValue(form, "onu") || undefined,
            ponStatus: stringValue(form, "ponStatus") || undefined,
            authenticationStatus: stringValue(form, "auth") || undefined,
            losState: stringValue(form, "los") || undefined,
            opticalDistanceKm: numericValue(form, "distance"),
            pppoeUsername: stringValue(form, "pppoe") || undefined,
            vlanId: stringValue(form, "vlan") || undefined,
          });
        }}
      >
        <h4>ONT / ONU</h4>
        <label>
          {isArabic ? "جهاز ONT" : "ONT device"}
          <select required name="ontDevice" defaultValue="">
            <option value="" disabled>
              —
            </option>
            {devices
              .filter(device => /ont|onu/i.test(device.deviceType))
              .map(device => (
                <option key={device.id} value={device.id}>
                  {device.label}
                </option>
              ))}
          </select>
        </label>
        <label>
          ONU ID
          <input name="onu" />
        </label>
        <label>
          PON
          <input name="ponStatus" />
        </label>
        <label>
          Auth
          <input name="auth" />
        </label>
        <label>
          LOS
          <input name="los" />
        </label>
        <label>
          {isArabic ? "المسافة كم" : "Distance km"}
          <input name="distance" type="number" step="any" />
        </label>
        <label>
          PPPoE
          <input name="pppoe" />
        </label>
        <label>
          VLAN
          <input name="vlan" />
        </label>
        <button className="action-button">
          <Plus size={14} />
          {isArabic ? "إضافة ONT" : "Add ONT"}
        </button>
      </form>
    </section>
  );
}
function NetworkSourcePanel({
  devices,
  isArabic,
  onIp,
  onEthernet,
  onWifi,
  onSession,
}: {
  devices: any[];
  isArabic: boolean;
  onIp: (input: any) => void;
  onEthernet: (input: any) => void;
  onWifi: (input: any) => void;
  onSession: (input: any) => void;
}) {
  const deviceSelect = (
    <label>
      {isArabic ? "الجهاز" : "Device"}
      <select name="device" required defaultValue="">
        <option value="" disabled>
          —
        </option>
        {devices.map(device => (
          <option key={device.id} value={device.id}>
            {device.label}
          </option>
        ))}
      </select>
    </label>
  );
  return (
    <section className="data-panel technical-form source-entry">
      <div className="panel-header">
        <h3>
          {isArabic ? "مصادر الشبكة التفصيلية" : "Detailed network sources"}
        </h3>
        <span>IP / ETH / Wi‑FI / SERVICE</span>
      </div>
      <details>
        <summary>IP / DNS / Gateway</summary>
        <form
          onSubmit={event => {
            event.preventDefault();
            const form = new FormData(event.currentTarget);
            onIp({
              deviceId: Number(stringValue(form, "device")),
              address: stringValue(form, "address"),
              family: stringValue(form, "family"),
              scope: stringValue(form, "scope"),
              hostname: stringValue(form, "hostname") || undefined,
              sourceLabel: stringValue(form, "source"),
              observedAt: new Date(),
            });
          }}
        >
          {deviceSelect}
          <label>
            {isArabic ? "العنوان" : "Address"}
            <input required name="address" />
          </label>
          <label>
            {isArabic ? "العائلة" : "Family"}
            <select name="family">
              <option value="ipv4">IPv4</option>
              <option value="ipv6">IPv6</option>
            </select>
          </label>
          <label>
            {isArabic ? "الدور" : "Scope"}
            <select name="scope">
              <option value="management">Management</option>
              <option value="public">Public</option>
              <option value="private">Private</option>
              <option value="local">Local</option>
              <option value="gateway">Gateway</option>
              <option value="dns">DNS</option>
              <option value="client">Client</option>
            </select>
          </label>
          <label>
            Hostname
            <input name="hostname" />
          </label>
          <label>
            {isArabic ? "المصدر" : "Source"}
            <input required name="source" />
          </label>
          <button className="action-button">
            <Plus size={14} />
            {isArabic ? "حفظ IP" : "Save IP"}
          </button>
        </form>
      </details>
      <details>
        <summary>Ethernet / CRC / Link</summary>
        <form
          onSubmit={event => {
            event.preventDefault();
            const form = new FormData(event.currentTarget);
            onEthernet({
              deviceId: Number(stringValue(form, "device")),
              label: stringValue(form, "label"),
              linkStatus: stringValue(form, "status") || undefined,
              negotiatedSpeedMbps: numericValue(form, "speed"),
              duplex: stringValue(form, "duplex") || undefined,
              crcErrors: numericValue(form, "crc"),
              interfaceErrors: numericValue(form, "errors"),
              flappingCount: numericValue(form, "flapping"),
              sourceLabel: stringValue(form, "source"),
              observedAt: new Date(),
            });
          }}
        >
          {deviceSelect}
          <label>
            {isArabic ? "المنفذ" : "Port"}
            <input required name="label" placeholder="LAN1 / GE0/0/1" />
          </label>
          <label>
            {isArabic ? "الحالة" : "Link"}
            <input name="status" />
          </label>
          <label>
            Mbps
            <input name="speed" type="number" />
          </label>
          <label>
            Duplex
            <input name="duplex" />
          </label>
          <label>
            CRC
            <input name="crc" type="number" />
          </label>
          <label>
            {isArabic ? "أخطاء" : "Errors"}
            <input name="errors" type="number" />
          </label>
          <label>
            {isArabic ? "تذبذب" : "Flaps"}
            <input name="flapping" type="number" />
          </label>
          <label>
            {isArabic ? "المصدر" : "Source"}
            <input required name="source" />
          </label>
          <button className="action-button">
            <Plus size={14} />
            {isArabic ? "حفظ منفذ" : "Save port"}
          </button>
        </form>
      </details>
      <details>
        <summary>Wi‑Fi / SSID / Radio</summary>
        <form
          onSubmit={event => {
            event.preventDefault();
            const form = new FormData(event.currentTarget);
            onWifi({
              deviceId: Number(stringValue(form, "device")),
              ssid: stringValue(form, "ssid"),
              band: stringValue(form, "band") || undefined,
              channel: stringValue(form, "channel") || undefined,
              channelWidthMHz: numericValue(form, "width"),
              signalDbm: numericValue(form, "signal"),
              noiseDbm: numericValue(form, "noise"),
              interferenceLevel: stringValue(form, "interference") || undefined,
              authentication: stringValue(form, "authentication") || undefined,
              sourceLabel: stringValue(form, "source"),
              observedAt: new Date(),
            });
          }}
        >
          {deviceSelect}
          <label>
            SSID
            <input required name="ssid" />
          </label>
          <label>
            Band
            <input name="band" placeholder="2.4 / 5 / 6 GHz" />
          </label>
          <label>
            {isArabic ? "القناة" : "Channel"}
            <input name="channel" />
          </label>
          <label>
            {isArabic ? "العرض MHz" : "Width MHz"}
            <input name="width" type="number" />
          </label>
          <label>
            Signal dBm
            <input name="signal" type="number" step="any" />
          </label>
          <label>
            Noise dBm
            <input name="noise" type="number" step="any" />
          </label>
          <label>
            {isArabic ? "التداخل" : "Interference"}
            <input name="interference" />
          </label>
          <label>
            {isArabic ? "المصادقة" : "Auth"}
            <input name="authentication" />
          </label>
          <label>
            {isArabic ? "المصدر" : "Source"}
            <input required name="source" />
          </label>
          <button className="action-button">
            <Plus size={14} />
            {isArabic ? "حفظ Wi‑Fi" : "Save Wi‑Fi"}
          </button>
        </form>
      </details>
      <details>
        <summary>PPPoE / DHCP / DNS / VLAN / ARP</summary>
        <form
          onSubmit={event => {
            event.preventDefault();
            const form = new FormData(event.currentTarget);
            onSession({
              deviceId: Number(stringValue(form, "device")) || undefined,
              sessionType: stringValue(form, "type"),
              username: stringValue(form, "username") || undefined,
              vlanId: stringValue(form, "vlan") || undefined,
              mtu: numericValue(form, "mtu"),
              gatewayAddress: stringValue(form, "gateway") || undefined,
              dnsServers: stringValue(form, "dns")
                ? stringValue(form, "dns")
                    .split(",")
                    .map(item => item.trim())
                    .filter(Boolean)
                : undefined,
              status: stringValue(form, "status") || undefined,
              observedAt: new Date(),
              sourceLabel: stringValue(form, "source"),
            });
          }}
        >
          {deviceSelect}
          <label>
            {isArabic ? "النوع" : "Type"}
            <select name="type">
              <option value="pppoe">PPPoE</option>
              <option value="dhcp">DHCP</option>
              <option value="dns">DNS</option>
              <option value="vlan">VLAN</option>
              <option value="route">Route</option>
              <option value="arp">ARP</option>
            </select>
          </label>
          <label>
            {isArabic ? "المستخدم" : "Username"}
            <input name="username" />
          </label>
          <label>
            VLAN
            <input name="vlan" />
          </label>
          <label>
            MTU
            <input name="mtu" type="number" />
          </label>
          <label>
            Gateway
            <input name="gateway" />
          </label>
          <label>
            DNS
            <input name="dns" placeholder="1.1.1.1, 8.8.8.8" />
          </label>
          <label>
            {isArabic ? "الحالة" : "Status"}
            <input name="status" />
          </label>
          <label>
            {isArabic ? "المصدر" : "Source"}
            <input required name="source" />
          </label>
          <button className="action-button">
            <Plus size={14} />
            {isArabic ? "حفظ الجلسة" : "Save session"}
          </button>
        </form>
      </details>
    </section>
  );
}
function DeviceDetail({
  data,
  devices,
  selectedDeviceId,
  onSelect,
  chart,
  chartMetric,
  metricOptions,
  onMetric,
  isArabic,
  onSaveHealth,
}: {
  data: any;
  devices: any[];
  selectedDeviceId: number | null;
  onSelect: (id: number) => void;
  chart: any[];
  chartMetric: string;
  metricOptions: string[];
  onMetric: (value: string) => void;
  isArabic: boolean;
  onSaveHealth: () => void;
}) {
  return (
    <section className="data-panel device-detail">
      <div className="panel-header">
        <h3>
          {isArabic ? "تفاصيل الجهاز والتشخيص" : "Device detail & diagnosis"}
        </h3>
        <select
          value={selectedDeviceId || ""}
          onChange={event => onSelect(Number(event.target.value))}
        >
          <option value="">{isArabic ? "اختر جهازًا" : "Select device"}</option>
          {devices.map(device => (
            <option key={device.id} value={device.id}>
              {device.label}
            </option>
          ))}
        </select>
      </div>
      {!selectedDeviceId ? (
        <EmptyState
          title={isArabic ? "اختر جهازًا" : "Select a device"}
          copy={
            isArabic
              ? "ستظهر هوية الجهاز والـ IP والبصريات والشبكة والإيثرنت وWi‑Fi والخط الزمني بناءً على بياناته الحقيقية."
              : "Identity, IP, optics, network, Ethernet, Wi‑Fi, and timeline appear from sourced records."
          }
        />
      ) : (
        detailLoading(
          data,
          isArabic,
          chart,
          chartMetric,
          metricOptions,
          onMetric,
          onSaveHealth
        )
      )}
    </section>
  );
}
function detailLoading(
  data: any,
  isArabic: boolean,
  chart: any[],
  chartMetric: string,
  metricOptions: string[],
  onMetric: (value: string) => void,
  onSaveHealth: () => void
) {
  if (!data)
    return (
      <div className="detail-loading">
        <Loader2 className="spin" />
        {isArabic ? "جارٍ تحميل سجلات الجهاز…" : "Loading device records…"}
      </div>
    );
  const health = data.health;
  return (
    <div className="device-detail-body">
      <div className="health-orbit">
        <b>{health.overallScore}%</b>
        <span>{isArabic ? "الصحة التفسيرية" : "Explainable health"}</span>
      </div>
      <div className="health-grid">
        {[
          ["Optical", health.opticalScore],
          ["Network", health.networkScore],
          ["Device", health.deviceScore],
          ["Ethernet", health.ethernetScore],
          ["Wi‑Fi", health.wifiScore],
          ["Auth", health.authenticationScore],
        ].map(([label, score]) => (
          <span key={String(label)}>
            {label}
            <b>{score === null ? "—" : `${score}%`}</b>
          </span>
        ))}
      </div>
      <button className="action-button" onClick={onSaveHealth}>
        <Save size={14} />
        {isArabic ? "حفظ لقطة الصحة" : "Save health snapshot"}
      </button>
      <div className="detail-groups">
        <article>
          <h4>
            <Network size={14} />
            IP / DNS / Gateway
          </h4>
          {data.ips.length ? (
            data.ips.map((ip: any) => (
              <p key={ip.id}>
                {ip.scope}: <b>{ip.address}</b>{" "}
                <small>{ip.hostname || ""}</small>
              </p>
            ))
          ) : (
            <p className="muted">
              {isArabic
                ? "لا توجد عناوين مصدرها موثق."
                : "No sourced addresses."}
            </p>
          )}
        </article>
        <article>
          <h4>
            <Cable size={14} />
            Optics & events
          </h4>
          {health.findings.length ? (
            health.findings.map((finding: any) => (
              <p key={finding.id} className={`finding-line ${finding.level}`}>
                <b>{finding.title}</b>
                <small>{finding.evidence}</small>
              </p>
            ))
          ) : (
            <p className="muted">
              {isArabic
                ? "لا توجد قاعدة تنطبق على السجلات الحالية."
                : "No rule matches current records."}
            </p>
          )}
          {data.prediction.map((finding: any) => (
            <p key={finding.id} className="finding-line medium">
              <b>{finding.title}</b>
              <small>{finding.evidence}</small>
            </p>
          ))}
        </article>
        <article>
          <h4>
            <Cable size={14} />
            Ethernet
          </h4>
          {data.ethernet.length ? (
            data.ethernet.map((port: any) => (
              <p key={port.id}>
                <b>{port.label}</b> · {port.linkStatus || "—"} ·{" "}
                {port.negotiatedSpeedMbps || "—"} Mbps{" "}
                <small>
                  CRC {port.crcErrors ?? "—"} · errors{" "}
                  {port.interfaceErrors ?? "—"}
                </small>
              </p>
            ))
          ) : (
            <p className="muted">
              {isArabic ? "لا توجد منافذ موثقة." : "No sourced ports."}
            </p>
          )}
        </article>
        <article>
          <h4>
            <Wifi size={14} />
            Wi‑Fi & services
          </h4>
          {data.wifi.length ? (
            data.wifi.map((network: any) => (
              <p key={network.id}>
                <b>{network.ssid}</b> · {network.band || "—"} ·{" "}
                {network.channel || "—"}
                <small>
                  {network.signalDbm ?? "—"} dBm ·{" "}
                  {network.interferenceLevel || "—"}
                </small>
              </p>
            ))
          ) : (
            <p className="muted">
              {isArabic ? "لا توجد شبكة Wi‑Fi موثقة." : "No sourced Wi‑Fi."}
            </p>
          )}
          {data.sessions.map((session: any) => (
            <p key={session.id}>
              <b>{session.sessionType}</b> · {session.status || "—"}
              <small>
                {session.username ||
                  session.vlanId ||
                  session.gatewayAddress ||
                  ""}
              </small>
            </p>
          ))}
        </article>
      </div>
      <div className="history-chart">
        <div className="panel-header">
          <h4>
            <LineChart size={15} />
            {isArabic ? "تاريخ القياسات" : "Measurement history"}
          </h4>
          <select
            value={chartMetric}
            onChange={event => onMetric(event.target.value)}
          >
            {metricOptions.length ? (
              metricOptions.map(metric => (
                <option key={metric} value={metric}>
                  {metric}
                </option>
              ))
            ) : (
              <option value="optical_rx_dbm">optical_rx_dbm</option>
            )}
          </select>
        </div>
        {chart.length ? (
          <ResponsiveContainer width="100%" height={220}>
            <AreaChart data={chart}>
              <defs>
                <linearGradient id="fiber-signal" x1="0" x2="0" y1="0" y2="1">
                  <stop offset="0%" stopColor="#49e8ff" stopOpacity={0.5} />
                  <stop offset="100%" stopColor="#49e8ff" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid stroke="#18334b" vertical={false} />
              <XAxis dataKey="at" stroke="#6d8ba1" fontSize={10} />
              <YAxis stroke="#6d8ba1" fontSize={10} />
              <Tooltip />
              <Area
                dataKey="value"
                stroke="#49e8ff"
                fill="url(#fiber-signal)"
              />
            </AreaChart>
          </ResponsiveContainer>
        ) : (
          <p className="muted">
            {isArabic
              ? "لن يظهر الرسم إلا عند وجود قراءات عددية محفوظة لهذا المقياس."
              : "Charts require stored numeric readings for this metric."}
          </p>
        )}
      </div>
    </div>
  );
}
function WhyDown({
  devices,
  selectedDeviceId,
  onSelect,
  data,
  isArabic,
}: {
  devices: any[];
  selectedDeviceId: number | null;
  onSelect: (id: number) => void;
  data: any;
  isArabic: boolean;
}) {
  return (
    <section className="data-panel why-down">
      <div className="panel-header">
        <h3>
          {isArabic ? "لماذا الخدمة متوقفة؟" : "Why is this service down?"}
        </h3>
        <span>TRACEABLE</span>
      </div>
      <div className="why-down-select">
        <label>
          {isArabic ? "الجهاز أو الخدمة" : "Device or service"}
          <select
            value={selectedDeviceId || ""}
            onChange={event => onSelect(Number(event.target.value))}
          >
            <option value="">
              {isArabic ? "اختر جهازًا" : "Select device"}
            </option>
            {devices.map(device => (
              <option key={device.id} value={device.id}>
                {device.label}
              </option>
            ))}
          </select>
        </label>
      </div>
      {!selectedDeviceId || !data ? (
        <EmptyState
          title={
            isArabic ? "اختر جهازًا ذا بيانات مصدر" : "Select a sourced device"
          }
          copy={
            isArabic
              ? "ستظهر الأعراض والدليل والسبب المحتمل فقط من القراءات والحالات والأحداث التي حفظتها."
              : "Symptoms, evidence, and probable cause are derived only from stored readings, states and events."
          }
        />
      ) : (
        <div className="why-down-grid">
          <article>
            <small>{isArabic ? "الحالة الحالية" : "Current status"}</small>
            <b>
              {data.device.connectionStatus ||
                data.unit?.ponStatus ||
                (isArabic ? "غير مؤكدة" : "Unconfirmed")}
            </b>
            <p>
              {data.alerts.length
                ? `${data.alerts.length} ${isArabic ? "تنبيه مفتوح" : "open alert(s)"}`
                : isArabic
                  ? "لا يوجد تنبيه مفتوح محفوظ"
                  : "No stored open alert"}
            </p>
          </article>
          <article>
            <small>{isArabic ? "الأعراض المكتشفة" : "Detected symptoms"}</small>
            {data.currentFindings.length ? (
              data.currentFindings.map((finding: any) => (
                <p key={finding.id}>{finding.title}</p>
              ))
            ) : (
              <p>
                {isArabic
                  ? "لا توجد قاعدة مطابقة للسجلات الحالية."
                  : "No diagnostic rule matches stored records."}
              </p>
            )}
          </article>
          <article>
            <small>{isArabic ? "السبب المحتمل" : "Probable cause"}</small>
            {data.currentFindings.length ? (
              data.currentFindings.slice(0, 2).map((finding: any) => (
                <p key={finding.id}>
                  <b>{finding.domain}</b> · {finding.evidence}
                </p>
              ))
            ) : (
              <p>
                {isArabic
                  ? "لا يمكن استنتاج سبب دون دليل كافٍ."
                  : "No cause can be inferred without sufficient evidence."}
              </p>
            )}
          </article>
          <article>
            <small>
              {isArabic ? "خطوة تحقق آمنة" : "Recommended safe check"}
            </small>
            {data.currentFindings.length ? (
              data.currentFindings
                .slice(0, 2)
                .map((finding: any) => (
                  <p key={finding.id}>{finding.recommendedCheck}</p>
                ))
            ) : (
              <p>
                {isArabic
                  ? "أضف قراءات أو أحداثًا موثقة أولًا."
                  : "Record sourced readings or events first."}
              </p>
            )}
          </article>
        </div>
      )}
    </section>
  );
}
function AlertEntry({
  devices,
  isArabic,
  onAlert,
}: {
  devices: any[];
  isArabic: boolean;
  onAlert: (input: any) => void;
}) {
  return (
    <section className="data-panel technical-form alert-entry">
      <div className="panel-header">
        <h3>{isArabic ? "تنبيه ذكي موثق" : "Sourced smart alert"}</h3>
        <span>ALERT</span>
      </div>
      <form
        onSubmit={event => {
          event.preventDefault();
          const form = new FormData(event.currentTarget);
          onAlert({
            deviceId: Number(stringValue(form, "device")) || undefined,
            severity: stringValue(form, "severity"),
            title: stringValue(form, "title"),
            impact: stringValue(form, "impact") || undefined,
            probableCause: stringValue(form, "cause") || undefined,
            evidence: stringValue(form, "evidence")
              ? stringValue(form, "evidence").split("\n").filter(Boolean)
              : undefined,
            recommendedCheck: stringValue(form, "check") || undefined,
            sourceLabel: stringValue(form, "source"),
            openedAt: new Date(stringValue(form, "time")),
          });
        }}
      >
        <label>
          {isArabic ? "الجهاز" : "Device"}
          <select name="device" defaultValue="">
            <option value="">—</option>
            {devices.map(device => (
              <option key={device.id} value={device.id}>
                {device.label}
              </option>
            ))}
          </select>
        </label>
        <label>
          {isArabic ? "الشدة" : "Severity"}
          <select name="severity">
            <option value="critical">Critical</option>
            <option value="high">High</option>
            <option value="medium">Medium</option>
            <option value="low">Low</option>
            <option value="informational">Informational</option>
          </select>
        </label>
        <label>
          {isArabic ? "المشكلة" : "Issue"}
          <input required name="title" />
        </label>
        <label>
          {isArabic ? "الأثر" : "Impact"}
          <textarea name="impact" />
        </label>
        <label>
          {isArabic ? "السبب المحتمل" : "Probable cause"}
          <textarea name="cause" />
        </label>
        <label>
          {isArabic ? "الدليل" : "Evidence"}
          <textarea name="evidence" />
        </label>
        <label>
          {isArabic ? "خطوة تحقق آمنة" : "Safe check"}
          <textarea name="check" />
        </label>
        <label>
          {isArabic ? "المصدر" : "Source"}
          <input required name="source" />
        </label>
        <label>
          {isArabic ? "وقت الفتح" : "Opened at"}
          <input
            required
            name="time"
            type="datetime-local"
            defaultValue={new Date().toISOString().slice(0, 16)}
          />
        </label>
        <button className="action-button primary">
          <AlertTriangle size={15} />
          {isArabic ? "فتح تنبيه" : "Open alert"}
        </button>
      </form>
    </section>
  );
}
function TopologyCanvas({
  nodes,
  edges,
  isArabic,
}: {
  nodes: any[];
  edges: any[];
  isArabic: boolean;
}) {
  const nodeMap = new Map(nodes.map(node => [node.id, node]));
  return (
    <section className="data-panel topology-canvas">
      <div className="panel-header">
        <h3>
          {isArabic ? "طوبولوجيا المصدر الفعلي" : "Actual sourced topology"}
        </h3>
        <span>{nodes.length} NODES</span>
      </div>
      {nodes.length ? (
        <div className="topology-flow">
          {edges.length
            ? edges.map(edge => (
                <article key={edge.id}>
                  <div>
                    <GitBranch size={14} />
                    <b>
                      {nodeMap.get(edge.sourceNodeId)?.label ||
                        `#${edge.sourceNodeId}`}
                    </b>
                  </div>
                  <span>
                    {edge.relationType}
                    {edge.fiberLengthKm !== null
                      ? ` · ${edge.fiberLengthKm} km`
                      : ""}
                    {edge.baselineLossDb !== null
                      ? ` · ${edge.baselineLossDb} dB`
                      : ""}
                  </span>
                  <div>
                    <b>
                      {nodeMap.get(edge.targetNodeId)?.label ||
                        `#${edge.targetNodeId}`}
                    </b>
                    <Signal size={14} />
                  </div>
                </article>
              ))
            : nodes.map(node => (
                <article key={node.id} className="isolated-node">
                  <b>{node.label}</b>
                  <span>
                    {node.nodeKind} ·{" "}
                    {node.status ||
                      (isArabic ? "حالة غير مؤكدة" : "status unconfirmed")}
                  </span>
                </article>
              ))}
        </div>
      ) : (
        <EmptyState
          title={isArabic ? "لا توجد طوبولوجيا موثقة" : "No sourced topology"}
          copy={
            isArabic
              ? "أضف عقدًا ووصلات من مخطط الشبكة أو سجل التشغيل الحقيقي؛ لا يُنشأ مسار افتراضي."
              : "Add nodes and links from your network plan or operations record; no default path is created."
          }
        />
      )}
    </section>
  );
}
function Timeline({
  events,
  alerts,
  isArabic,
}: {
  events: any[];
  alerts: any[];
  isArabic: boolean;
}) {
  return (
    <section className="data-panel fiber-timeline">
      <div className="panel-header">
        <h3>{isArabic ? "الخط الزمني والتنبيهات" : "Timeline & alerts"}</h3>
        <span>{events.length + alerts.length}</span>
      </div>
      {[
        ...alerts.map(alert => ({
          ...alert,
          kind: "alert",
          at: alert.openedAt,
        })),
        ...events.map(event => ({
          ...event,
          kind: "event",
          at: event.occurredAt,
        })),
      ]
        .sort((a, b) => new Date(b.at).getTime() - new Date(a.at).getTime())
        .slice(0, 80)
        .map(item => (
          <article key={`${item.kind}-${item.id}`}>
            <span className={`timeline-dot ${item.severity}`} />
            <div>
              <b>{item.title}</b>
              <small>
                {new Date(item.at).toLocaleString(isArabic ? "ar" : "en")} ·{" "}
                {item.sourceLabel}
              </small>
              {item.probableCause && <p>{item.probableCause}</p>}
            </div>
            <em>{item.severity}</em>
          </article>
        )) || (
        <EmptyState
          title={
            isArabic
              ? "لا توجد أحداث أو تنبيهات محفوظة"
              : "No stored events or alerts"
          }
          copy={
            isArabic
              ? "سيظهر التسلسل عندما تحفظ مصادر مؤسسة الحدث أو التنبيه."
              : "The sequence appears when organization event or alert sources are stored."
          }
        />
      )}
    </section>
  );
}
