import {
  EmptyState,
  SectionHeading,
  ZeroGramShell,
} from "@/components/ZeroGramShell";
import { useI18n } from "@/lib/i18n";
import { trpc } from "@/lib/trpc";
import {
  Building2,
  Cable,
  ClipboardList,
  Database,
  GitCompareArrows,
  Loader2,
  Network,
  Radio,
  Search,
  UserRound,
  Wifi,
} from "lucide-react";
import { useState } from "react";

export default function SearchCenter() {
  const { isArabic } = useI18n();
  const [query, setQuery] = useState("");
  const enabled = query.trim().length >= 2;
  const fiberSearch = trpc.fiber.globalSearch.useQuery({ query }, { enabled });
  const operationsSearch = trpc.intelligence.search.useQuery(
    { query },
    { enabled }
  );
  const data = fiberSearch.data;
  const operationData = operationsSearch.data;
  const technicalTotal = data
    ? data.devices.length +
      data.ips.length +
      data.onts.length +
      data.ports.length +
      data.clients.length +
      data.sessions.length +
      data.subscribers.length
    : 0;
  const operationTotal = operationData
    ? operationData.incidents.length +
      operationData.changes.length +
      operationData.profiles.length
    : 0;
  const total = technicalTotal + operationTotal;
  const loading = fiberSearch.isLoading || operationsSearch.isLoading;
  return (
    <ZeroGramShell
      title={isArabic ? "البحث الشامل" : "Global search"}
      eyebrow="ZERO GRAM / RELATION INDEX"
    >
      <div className="page-content search-center">
        <SectionHeading
          index="F/S"
          title={
            isArabic ? "فهرس العلاقات والمسارات" : "Relationship & path index"
          }
          description={
            isArabic
              ? "ابحث في السجلات التقنية والحوادث والتغييرات وسياق الشركة. لا تعرض النتائج إلا السجلات المصدرية لمؤسستك."
              : "Search technical records, incidents, changes, and company context. Results contain only sourced records from your organization."
          }
        />
        <section className="data-panel global-search-box">
          <Search size={20} />
          <input
            autoFocus
            value={query}
            onChange={event => setQuery(event.target.value)}
            placeholder={
              isArabic
                ? "IP، MAC، Serial، ONT، PON، PPPoE، Incident، Change، ISP…"
                : "IP, MAC, serial, ONT, PON, PPPoE, incident, change, ISP…"
            }
          />
          <span>
            {enabled ? loading ? <Loader2 className="spin" /> : total : "≥2"}
          </span>
        </section>
        {!enabled ? (
          <EmptyState
            title={isArabic ? "ابدأ بالبحث" : "Start searching"}
            copy={
              isArabic
                ? "اكتب حرفين على الأقل لربط السجلات التقنية والتشغيلية عبر الفهرس الموحد."
                : "Enter at least two characters to connect technical and operational records through the unified index."
            }
          />
        ) : loading ? (
          <div className="panel-loading">
            <Loader2 className="spin" />
          </div>
        ) : !total ? (
          <EmptyState
            title={
              isArabic
                ? "لا توجد مطابقة في سجلات مؤسستك"
                : "No organization record matched"
            }
            copy={
              isArabic
                ? "لا ينشئ ZERO GRAM نتيجة أو مسارًا افتراضيًا عند غياب السجل."
                : "ZERO GRAM never creates a result or topology path when the record is absent."
            }
          />
        ) : (
          <section className="search-result-grid">
            <ResultGroup
              icon={<Network />}
              title={isArabic ? "الأجهزة المرتبطة" : "Related devices"}
              rows={data?.devices || []}
              render={row => (
                <>
                  <b>{row.label}</b>
                  <small>
                    {row.deviceType} ·{" "}
                    {row.managementIpv4 || row.managementIpv6 || "—"}
                  </small>
                </>
              )}
            />
            <ResultGroup
              icon={<Database />}
              title="IP / DNS / Gateway"
              rows={data?.ips || []}
              render={row => (
                <>
                  <b>{row.address}</b>
                  <small>
                    {row.scope} · {row.hostname || "—"}
                  </small>
                </>
              )}
            />
            <ResultGroup
              icon={<Cable />}
              title="OLT / PON / ONU / ONT"
              rows={[...(data?.ports || []), ...(data?.onts || [])]}
              render={row => (
                <>
                  <b>{row.label || row.onuId || "ONT / ONU"}</b>
                  <small>
                    {row.operationalStatus ||
                      row.ponStatus ||
                      row.authenticationStatus ||
                      "—"}
                  </small>
                </>
              )}
            />
            <ResultGroup
              icon={<Wifi />}
              title="Wi‑Fi clients"
              rows={data?.clients || []}
              render={row => (
                <>
                  <b>{row.macAddress || row.hostname || "Wi‑Fi client"}</b>
                  <small>
                    {row.ipAddress || "—"} · RX {row.rxRateMbps ?? "—"} / TX{" "}
                    {row.txRateMbps ?? "—"} Mbps
                  </small>
                </>
              )}
            />
            <ResultGroup
              icon={<Radio />}
              title="PPPoE / DHCP / DNS / VLAN"
              rows={data?.sessions || []}
              render={row => (
                <>
                  <b>
                    {row.sessionType} · {row.username || row.vlanId || "—"}
                  </b>
                  <small>
                    {row.status || "—"} · {row.gatewayAddress || ""}
                  </small>
                </>
              )}
            />
            <ResultGroup
              icon={<UserRound />}
              title={isArabic ? "المشتركون" : "Subscribers"}
              rows={data?.subscribers || []}
              render={row => (
                <>
                  <b>{row.displayName}</b>
                  <small>
                    {row.reference} · {row.status}
                  </small>
                </>
              )}
            />
            <ResultGroup
              icon={<ClipboardList />}
              title={isArabic ? "الحوادث" : "Incidents"}
              rows={operationData?.incidents || []}
              render={row => (
                <>
                  <b>
                    {row.reference} · {row.title}
                  </b>
                  <small>
                    {row.severity} · {row.state} · {row.sourceLabel}
                  </small>
                </>
              )}
            />
            <ResultGroup
              icon={<GitCompareArrows />}
              title={isArabic ? "التغييرات" : "Changes"}
              rows={operationData?.changes || []}
              render={row => (
                <>
                  <b>{row.title}</b>
                  <small>
                    {row.changeType} · {row.sourceLabel}
                  </small>
                </>
              )}
            />
            <ResultGroup
              icon={<Building2 />}
              title={isArabic ? "سياق الشركة" : "Company context"}
              rows={operationData?.profiles || []}
              render={row => (
                <>
                  <b>{row.companyName}</b>
                  <small>
                    {row.networkType || "—"} · {row.sourceLabel}
                  </small>
                </>
              )}
            />
          </section>
        )}
      </div>
    </ZeroGramShell>
  );
}
function ResultGroup({
  icon,
  title,
  rows,
  render,
}: {
  icon: React.ReactNode;
  title: string;
  rows: any[];
  render: (row: any) => React.ReactNode;
}) {
  return (
    <article className="data-panel result-group">
      <header>
        {icon}
        <h3>{title}</h3>
        <span>{rows.length}</span>
      </header>
      {rows.length ? (
        rows.map(row => <div key={row.id}>{render(row)}</div>)
      ) : (
        <p>—</p>
      )}
    </article>
  );
}
