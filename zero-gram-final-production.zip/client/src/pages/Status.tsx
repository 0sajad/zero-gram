import {
  EmptyState,
  SectionHeading,
  ZeroGramShell,
} from "@/components/ZeroGramShell";
import { useI18n } from "@/lib/i18n";
import { trpc } from "@/lib/trpc";
import { Activity, CheckCircle2, ClipboardList, XCircle } from "lucide-react";
export default function Status() {
  const { isArabic, t } = useI18n();
  const status = trpc.monitoring.status.useQuery();
  const operations = trpc.operations.overview.useQuery();
  const events = status.data?.events || [];
  const openTickets = (operations.data?.tickets || []).filter(
    ticket => ticket.state !== "resolved"
  );
  return (
    <ZeroGramShell
      title={t("status")}
      eyebrow="ZERO GRAM / SOURCE-BOUND STATUS"
    >
      <div className="page-content">
        <SectionHeading
          index="07"
          title={
            isArabic
              ? "حالة مبنية على أحداث وتذاكر محفوظة"
              : "Status from stored events and tickets"
          }
          description={
            isArabic
              ? "الملخص لا يظهر إلا من أحداث المراقبة الحقيقية والتذاكر التي أنشأتها مؤسستك."
              : "The summary is built only from real monitoring events and tickets created by your organization."
          }
        />
        <section className="status-grid">
          <article className="data-panel status-hero">
            <span className="terminal-kicker">
              <span />
              EVENT-BASED ONLY
            </span>
            {events.length ? (
              <>
                <b className="metric-value">
                  {events.filter(event => event.state === "success").length}/
                  {events.length}
                </b>
                <h2>
                  {isArabic
                    ? "نجاح في آخر الأحداث المسجلة"
                    : "successful recent stored events"}
                </h2>
              </>
            ) : (
              <EmptyState
                title={t("noData")}
                copy={
                  isArabic
                    ? "أضف وجهة مراقبة وشغّل فحصًا لتظهر الحالة من مصدر حقيقي."
                    : "Add a monitoring target and run a check to show status from a real source."
                }
              />
            )}
          </article>
          <article className="data-panel event-stream">
            <div className="panel-header">
              <h3>{isArabic ? "آخر الأحداث" : "Latest events"}</h3>
              <span>{events.length}</span>
            </div>
            {events.length ? (
              <div className="event-list">
                {events.map(event => (
                  <article key={event.id}>
                    <span
                      className={
                        event.state === "success"
                          ? "event-icon success"
                          : "event-icon critical"
                      }
                    >
                      {event.state === "success" ? (
                        <CheckCircle2 />
                      ) : (
                        <XCircle />
                      )}
                    </span>
                    <div>
                      <b>
                        {event.state === "success"
                          ? isArabic
                            ? "استجابة ناجحة"
                            : "Successful response"
                          : isArabic
                            ? "فشل الفحص"
                            : "Check failed"}
                      </b>
                      <p>
                        {event.statusCode
                          ? `HTTP ${event.statusCode}`
                          : event.errorMessage || "—"}{" "}
                        · {event.responseTimeMs ?? "—"} ms
                      </p>
                    </div>
                    <small>
                      {new Date(event.checkedAt).toLocaleString(
                        isArabic ? "ar" : "en"
                      )}
                    </small>
                  </article>
                ))}
              </div>
            ) : (
              <div className="panel-loading">
                <Activity size={16} />
                {isArabic
                  ? "بانتظار أول حدث مراقبة."
                  : "Waiting for first monitoring event."}
              </div>
            )}
          </article>
        </section>
        <section className="data-panel ticket-status-panel">
          <div className="panel-header">
            <h3>
              <ClipboardList size={15} />
              {isArabic ? "تذاكر غير محلولة" : "Open tickets"}
            </h3>
            <span>{openTickets.length}</span>
          </div>
          {operations.isLoading ? (
            <div className="panel-loading">{t("loading")}</div>
          ) : openTickets.length ? (
            <div className="simple-list">
              {openTickets.map(ticket => (
                <div key={ticket.id}>
                  <b>{ticket.title}</b>
                  <small>
                    {ticket.severity} · {ticket.state}
                  </small>
                </div>
              ))}
            </div>
          ) : (
            <EmptyState
              title={t("noData")}
              copy={
                isArabic
                  ? "لا توجد تذاكر مفتوحة محفوظة ضمن مؤسستك."
                  : "There are no stored open tickets in your organization."
              }
            />
          )}
        </section>
      </div>
    </ZeroGramShell>
  );
}
