import {
  EmptyState,
  SectionHeading,
  ZeroGramShell,
} from "@/components/ZeroGramShell";
import { useI18n } from "@/lib/i18n";
import {
  analyzeTechnicianInput,
  type LabInput,
} from "../../../shared/networkDiagnostics";
import {
  AlertTriangle,
  Check,
  ChevronDown,
  ChevronRight,
  CircleStop,
  Clipboard,
  ClipboardCheck,
  Clock3,
  Copy,
  FileText,
  Filter,
  FlaskConical,
  Gauge,
  Loader2,
  Play,
  RotateCcw,
  ShieldAlert,
  Signal,
  Terminal,
  TimerReset,
  Trash2,
  XCircle,
} from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";
import { toast } from "sonner";

const numberValue = (value: string) =>
  value.trim() === "" ? undefined : Number(value);
type Tab = "gpon" | "mikrotik" | "pppoe";
type SessionState =
  | "idle"
  | "validating"
  | "extracting"
  | "correlating"
  | "complete"
  | "cancelled"
  | "error";
const severityRank = { critical: 0, warning: 1, info: 2 } as const;

export default function Lab() {
  const { isArabic, t } = useI18n();
  const [fields, setFields] = useState<Record<string, string>>({});
  const [findings, setFindings] = useState<
    ReturnType<typeof analyzeTechnicianInput>
  >([]);
  const [tab, setTab] = useState<Tab>("gpon");
  const [session, setSession] = useState<SessionState>("idle");
  const [progress, setProgress] = useState(0);
  const [sessionLog, setSessionLog] = useState<string[]>([]);
  const [startedAt, setStartedAt] = useState<number | null>(null);
  const [elapsed, setElapsed] = useState(0);
  const [severity, setSeverity] = useState<
    "all" | "critical" | "warning" | "info"
  >("all");
  const [source, setSource] = useState("all");
  const [sort, setSort] = useState<"severity" | "source">("severity");
  const [expanded, setExpanded] = useState<Set<string>>(new Set());
  const [expandedSteps, setExpandedSteps] = useState<Set<string>>(new Set());
  const runRef = useRef<ReturnType<typeof setTimeout>[]>([]);
  const update = (key: string, value: string) =>
    setFields(current => ({ ...current, [key]: value }));
  const clearTimers = () => {
    runRef.current.forEach(clearTimeout);
    runRef.current = [];
  };
  useEffect(() => () => clearTimers(), []);
  useEffect(() => {
    if (
      !startedAt ||
      !["validating", "extracting", "correlating"].includes(session)
    )
      return;
    const interval = window.setInterval(
      () => setElapsed(Date.now() - startedAt),
      250
    );
    return () => clearInterval(interval);
  }, [startedAt, session]);
  const input: LabInput = {
    ontModel: fields.ontModel,
    opticalRxDbm: numberValue(fields.opticalRxDbm || ""),
    opticalTxDbm: numberValue(fields.opticalTxDbm || ""),
    oltRxDbm: numberValue(fields.oltRxDbm || ""),
    ponState: fields.ponState,
    snrDb: numberValue(fields.snrDb || ""),
    rsrpDbm: numberValue(fields.rsrpDbm || ""),
    rsrqDb: numberValue(fields.rsrqDb || ""),
    rawLog: fields.rawLog,
  };
  const stages = useMemo(
    () => [
      isArabic ? "التحقق من المدخلات" : "Validate submitted input",
      tab === "gpon"
        ? isArabic
          ? "استخراج قراءات GPON الظاهرة"
          : "Extract visible GPON readings"
        : tab === "mikrotik"
          ? isArabic
            ? "استخراج مؤشرات RouterOS الظاهرة"
            : "Extract visible RouterOS indicators"
          : isArabic
            ? "استخراج مؤشرات PPPoE الظاهرة"
            : "Extract visible PPPoE indicators",
      isArabic
        ? "ربط الدليل بخطوات تحقق آمنة"
        : "Map evidence to safe verification steps",
    ],
    [isArabic, tab]
  );
  const suppliedFields = Object.values(fields).filter(Boolean).length;
  const stageIndex =
    session === "validating"
      ? 0
      : session === "extracting"
        ? 1
        : session === "correlating" || session === "complete"
          ? 2
          : -1;
  const sourceOptions = useMemo(
    () => Array.from(new Set(findings.map(finding => finding.source))),
    [findings]
  );
  const filtered = useMemo(
    () =>
      findings
        .filter(
          finding =>
            (severity === "all" || finding.level === severity) &&
            (source === "all" || finding.source === source)
        )
        .sort((a, b) =>
          sort === "severity"
            ? severityRank[a.level] - severityRank[b.level]
            : a.source.localeCompare(b.source)
        ),
    [findings, severity, source, sort]
  );
  const start = () => {
    const hasValue = Object.values(fields).some(Boolean);
    if (!hasValue) {
      toast.error(
        isArabic
          ? "أدخل قراءة موثقة واحدة أو الصق سجلًا قبل البدء."
          : "Enter one verified reading or paste a log before starting."
      );
      setSession("error");
      setSessionLog([
        isArabic
          ? "رُفض البدء: لا توجد مدخلات مرئية."
          : "Start rejected: no visible input.",
      ]);
      return;
    }
    clearTimers();
    setFindings([]);
    setProgress(8);
    setSession("validating");
    setStartedAt(Date.now());
    setElapsed(0);
    setSessionLog([
      isArabic
        ? "بدأ تحليل محلي للمدخلات؛ لا يوجد اتصال بأي جهاز."
        : "Local input analysis started; no device connection exists.",
    ]);
    const schedule = (delay: number, fn: () => void) =>
      runRef.current.push(setTimeout(fn, delay));
    schedule(450, () => {
      setSession("extracting");
      setProgress(42);
      setSessionLog(current => [
        ...current,
        `${isArabic ? "اكتمل" : "Completed"}: ${stages[0]}`,
      ]);
    });
    schedule(950, () => {
      setSession("correlating");
      setProgress(76);
      setSessionLog(current => [
        ...current,
        `${isArabic ? "اكتمل" : "Completed"}: ${stages[1]}`,
      ]);
    });
    schedule(1450, () => {
      const outcome = analyzeTechnicianInput(input);
      setFindings(outcome);
      setProgress(100);
      setSession("complete");
      setSessionLog(current => [
        ...current,
        `${isArabic ? "اكتمل" : "Completed"}: ${stages[2]}`,
        isArabic
          ? `استُخرج ${outcome.length} مؤشرًا من الدليل الظاهر فقط.`
          : `${outcome.length} indicators extracted from visible evidence only.`,
      ]);
    });
  };
  const cancel = () => {
    clearTimers();
    setSession("cancelled");
    setProgress(0);
    setSessionLog(current => [
      ...current,
      isArabic
        ? "أوقف المشغّل التحليل قبل إكماله."
        : "Operator cancelled analysis before completion.",
    ]);
  };
  const reset = () => {
    clearTimers();
    setFields({});
    setFindings([]);
    setSession("idle");
    setProgress(0);
    setSessionLog([]);
    setElapsed(0);
    setStartedAt(null);
    setExpanded(new Set());
    setExpandedSteps(new Set());
  };
  const copyAll = () => {
    const text = findings
      .map(finding => `• ${finding.title}\n${finding.safeNextStep}`)
      .join("\n\n");
    navigator.clipboard.writeText(text);
    toast.success(
      isArabic
        ? "نُسخت كل خطوات التحقق الآمنة."
        : "All safe verification steps copied."
    );
  };
  const toggleExpand = (id: string) =>
    setExpanded(current => {
      const next = new Set(current);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  const toggleStep = (id: string) =>
    setExpandedSteps(current => {
      const next = new Set(current);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  return (
    <ZeroGramShell title={t("lab")} eyebrow="ZERO GRAM / FIELD EVIDENCE">
      <div className="page-content">
        <SectionHeading
          index="02"
          title={
            isArabic ? "حلل ما هو ظاهر فقط" : "Analyze only what is visible"
          }
          description={
            isArabic
              ? "يعمل المختبر محليًا على القيم والسجل الملصق؛ لا ينفذ أوامر على ONT أو OLT أو MikroTik، ولا يحوّل حالة التحليل إلى قياس شبكة."
              : "The lab processes entered values and pasted logs locally. It never executes commands against ONT, OLT, or MikroTik hardware, and analysis state is not a network measurement."
          }
        />
        <div className="lab-tabs" role="tablist">
          {(["gpon", "mikrotik", "pppoe"] as Tab[]).map(item => (
            <button
              key={item}
              className="has-tooltip"
              data-tooltip={
                item === "gpon"
                  ? "GPON / ONT"
                  : item === "mikrotik"
                    ? "MikroTik / RouterOS"
                    : "PPPoE"
              }
              onClick={() => setTab(item)}
            >
              {item === "gpon"
                ? "GPON / ONT"
                : item === "mikrotik"
                  ? "MikroTik / RouterOS"
                  : "PPPoE"}
            </button>
          ))}
        </div>
        <div className="lab-grid">
          <section className="data-panel lab-form">
            <div className="panel-header">
              <h3>
                {isArabic ? "إدخال GPON / ONT / OLT" : "GPON / ONT / OLT input"}
              </h3>
              <span>MANUAL INPUT</span>
            </div>
            <div className="field-grid">
              <label>
                {isArabic ? "طراز ONT" : "ONT model"}
                <input
                  value={fields.ontModel || ""}
                  onChange={event => update("ontModel", event.target.value)}
                  placeholder="e.g. HG8145V5"
                />
              </label>
              <label>
                PON state
                <input
                  value={fields.ponState || ""}
                  onChange={event => update("ponState", event.target.value)}
                  placeholder="O5 / Up"
                />
              </label>
              <label>
                ONT RX (dBm)
                <input
                  inputMode="decimal"
                  value={fields.opticalRxDbm || ""}
                  onChange={event => update("opticalRxDbm", event.target.value)}
                  placeholder="-24.6"
                />
              </label>
              <label>
                ONT TX (dBm)
                <input
                  inputMode="decimal"
                  value={fields.opticalTxDbm || ""}
                  onChange={event => update("opticalTxDbm", event.target.value)}
                  placeholder="2.1"
                />
              </label>
              <label>
                OLT RX (dBm)
                <input
                  inputMode="decimal"
                  value={fields.oltRxDbm || ""}
                  onChange={event => update("oltRxDbm", event.target.value)}
                  placeholder="-22.3"
                />
              </label>
              <label>
                SNR (dB)
                <input
                  inputMode="decimal"
                  value={fields.snrDb || ""}
                  onChange={event => update("snrDb", event.target.value)}
                  placeholder="—"
                />
              </label>
              <label>
                RSRP (dBm)
                <input
                  inputMode="decimal"
                  value={fields.rsrpDbm || ""}
                  onChange={event => update("rsrpDbm", event.target.value)}
                  placeholder="—"
                />
              </label>
              <label>
                RSRQ (dB)
                <input
                  inputMode="decimal"
                  value={fields.rsrqDb || ""}
                  onChange={event => update("rsrqDb", event.target.value)}
                  placeholder="—"
                />
              </label>
            </div>
            <div className="log-field">
              <label>
                <Terminal size={15} />
                {isArabic ? "سجل RouterOS أو PPPoE" : "RouterOS or PPPoE log"}
                <small>
                  {(fields.rawLog || "").length.toLocaleString()}{" "}
                  {isArabic ? "محرف" : "characters"}
                </small>
              </label>
              <textarea
                value={fields.rawLog || ""}
                onChange={event => update("rawLog", event.target.value)}
                placeholder={
                  isArabic
                    ? "الصق السجل الخام هنا؛ لن يُرسل إلى جهاز أو ينفذ كأمر."
                    : "Paste raw log text here; it will not be sent to a device or executed."
                }
              />
            </div>
            {!suppliedFields && (
              <div className="input-warning">
                <AlertTriangle size={15} />
                {isArabic
                  ? "أدخل قراءة مرئية أو الصق سجلًا قبل التحليل؛ لا تُنشأ بيانات بديلة."
                  : "Enter a visible reading or paste a log before analysis; no substitute data is created."}
              </div>
            )}
            <div className="lab-actions">
              {["validating", "extracting", "correlating"].includes(session) ? (
                <button className="action-button danger" onClick={cancel}>
                  <CircleStop size={16} />
                  {isArabic ? "إيقاف التحليل" : "Stop analysis"}
                </button>
              ) : (
                <button className="action-button primary" onClick={start}>
                  <Play size={16} />
                  {isArabic ? "تحليل المدخلات" : "Analyze input"}
                </button>
              )}
              <button className="action-button" onClick={reset}>
                <Trash2 size={15} />
                {isArabic ? "مسح آمن" : "Safe clear"}
              </button>
            </div>
          </section>
          <section className="data-panel lab-session">
            <div className="panel-header">
              <h3>{isArabic ? "حالة جلسة المختبر" : "Lab session status"}</h3>
              <div className="session-head-actions">
                <span className="local-session-status">
                  <Signal size={12} />
                  {isArabic ? "تحليل محلي" : "LOCAL"}
                </span>
                <span>{session.toUpperCase()}</span>
                <button
                  className="icon-button has-tooltip"
                  data-tooltip={
                    isArabic ? "نسخ سجل الجلسة" : "Copy session log"
                  }
                  aria-label="Copy lab session log"
                  disabled={!sessionLog.length}
                  onClick={() => {
                    navigator.clipboard.writeText(sessionLog.join("\n"));
                    toast.success(
                      isArabic ? "نُسخ سجل الجلسة." : "Session log copied."
                    );
                  }}
                >
                  <Copy size={14} />
                </button>
              </div>
            </div>
            <div className="session-progress">
              <div className="progress-track">
                <i style={{ width: `${progress}%` }} />
              </div>
              <b>{progress}%</b>
            </div>
            <div className="session-stage-list">
              {stages.map((stage, index) => (
                <article
                  className={
                    index < stageIndex || session === "complete"
                      ? "done"
                      : index === stageIndex
                        ? "running"
                        : ""
                  }
                  key={stage}
                >
                  <span>
                    {index < stageIndex || session === "complete" ? (
                      <Check size={14} />
                    ) : index === stageIndex ? (
                      <Loader2 className="spin" size={14} />
                    ) : (
                      <Signal size={14} />
                    )}
                  </span>
                  <div>
                    <b>{stage}</b>
                    <small>
                      {index === stageIndex &&
                      ["validating", "extracting", "correlating"].includes(
                        session
                      )
                        ? isArabic
                          ? "جارٍ محليًا…"
                          : "Processing locally…"
                        : index < stageIndex || session === "complete"
                          ? isArabic
                            ? "مكتمل"
                            : "Done"
                          : isArabic
                            ? "بانتظار المرحلة"
                            : "Queued"}
                    </small>
                  </div>
                </article>
              ))}
            </div>
            <div className="session-metadata">
              <span>
                <TimerReset size={14} />
                {isArabic ? "المدة" : "Duration"}: {(elapsed / 1000).toFixed(1)}
                s
              </span>
              <span>
                <Gauge size={14} />
                {isArabic ? "النمط" : "Mode"}: {tab.toUpperCase()}
              </span>
              <span>
                <Clipboard size={14} />
                {isArabic ? "المدخلات" : "Inputs"}: {suppliedFields}
              </span>
            </div>
            <div className="session-log">
              {sessionLog.length ? (
                sessionLog.map((line, index) => (
                  <p key={`${line}-${index}`}>
                    <ChevronRight size={12} />
                    {line}
                  </p>
                ))
              ) : (
                <p className="muted">
                  {isArabic
                    ? "سيظهر تسلسل المعالجة المحلي هنا عند البدء."
                    : "The local processing sequence appears here when started."}
                </p>
              )}
            </div>
          </section>
        </div>
        <section className="data-panel lab-results">
          <div className="panel-header">
            <h3>
              {isArabic
                ? "المؤشرات وخطوات التحقق"
                : "Indicators & verification steps"}
            </h3>
            <span>NON-EXECUTIVE</span>
          </div>
          {findings.length ? (
            <>
              <div className="lab-toolbar">
                <div>
                  <Filter size={14} />
                  <select
                    value={severity}
                    onChange={event =>
                      setSeverity(event.target.value as typeof severity)
                    }
                  >
                    <option value="all">
                      {isArabic ? "كل الشدات" : "All severities"}
                    </option>
                    <option value="critical">critical</option>
                    <option value="warning">warning</option>
                    <option value="info">info</option>
                  </select>
                  <select
                    value={source}
                    onChange={event => setSource(event.target.value)}
                  >
                    <option value="all">
                      {isArabic ? "كل المصادر" : "All sources"}
                    </option>
                    {sourceOptions.map(item => (
                      <option key={item} value={item}>
                        {item}
                      </option>
                    ))}
                  </select>
                  <select
                    value={sort}
                    onChange={event =>
                      setSort(event.target.value as typeof sort)
                    }
                  >
                    <option value="severity">
                      {isArabic ? "الأعلى خطورة" : "Highest severity"}
                    </option>
                    <option value="source">
                      {isArabic ? "المصدر" : "Source"}
                    </option>
                  </select>
                </div>
                <div>
                  <button className="action-button" onClick={copyAll}>
                    <ClipboardCheck size={14} />
                    {isArabic ? "نسخ الخطوات" : "Copy steps"}
                  </button>
                  <button
                    className="icon-button has-tooltip"
                    data-tooltip={
                      isArabic ? "نسخ JSON للمؤشرات" : "Copy findings JSON"
                    }
                    aria-label="Copy findings JSON"
                    onClick={() => {
                      navigator.clipboard.writeText(
                        JSON.stringify(findings, null, 2)
                      );
                      toast.success(
                        isArabic
                          ? "نُسخ JSON للمؤشرات."
                          : "Findings JSON copied."
                      );
                    }}
                  >
                    <FileText size={15} />
                  </button>
                </div>
              </div>
              <div className="finding-list">
                {filtered.map(finding => (
                  <article className="finding expandable" key={finding.id}>
                    <span className={`badge ${finding.level}`}>
                      {finding.level}
                    </span>
                    <div>
                      <button
                        className="finding-toggle"
                        onClick={() => toggleExpand(finding.id)}
                      >
                        <span>
                          <h4>{finding.title}</h4>
                          <small>
                            {isArabic ? "المصدر: " : "Source: "}
                            {finding.source}
                          </small>
                        </span>
                        {expanded.has(finding.id) ? (
                          <ChevronDown size={16} />
                        ) : (
                          <ChevronRight size={16} />
                        )}
                      </button>
                      {expanded.has(finding.id) && (
                        <div className="finding-detail">
                          <p>
                            <b>{isArabic ? "الدليل: " : "Evidence: "}</b>
                            {finding.evidence}
                          </p>
                          <small>{finding.limitation}</small>
                          <button
                            className="verification-toggle"
                            onClick={() => toggleStep(finding.id)}
                          >
                            <ShieldAlert size={15} />
                            <span>
                              {isArabic
                                ? "خطوة التحقق الآمنة"
                                : "Safe verification step"}
                            </span>
                            {expandedSteps.has(finding.id) ? (
                              <ChevronDown size={15} />
                            ) : (
                              <ChevronRight size={15} />
                            )}
                          </button>
                          {expandedSteps.has(finding.id) && (
                            <div className="safe-step">
                              <span>{finding.safeNextStep}</span>
                              <button
                                className="has-tooltip"
                                data-tooltip={
                                  isArabic ? "نسخ الخطوة" : "Copy step"
                                }
                                aria-label="Copy safe step"
                                onClick={() => {
                                  navigator.clipboard.writeText(
                                    finding.safeNextStep
                                  );
                                  toast.success(
                                    isArabic
                                      ? "نُسخت خطوة التحقق."
                                      : "Verification step copied."
                                  );
                                }}
                              >
                                <Copy size={14} />
                              </button>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  </article>
                ))}
              </div>
              {!filtered.length && (
                <EmptyState
                  title={
                    isArabic
                      ? "لا تطابق الفلاتر أي مؤشر"
                      : "No indicator matches the filters"
                  }
                  copy={
                    isArabic
                      ? "عدّل مصدر الدليل أو مستوى الخطورة لإظهار المؤشرات المستخرجة."
                      : "Adjust evidence source or severity to display extracted indicators."
                  }
                />
              )}
            </>
          ) : (
            <div className="lab-empty">
              <Clipboard size={26} />
              <h3>
                {isArabic
                  ? "لا توجد مؤشرات مستخرجة بعد"
                  : "No extracted indicators yet"}
              </h3>
              <p>
                {isArabic
                  ? "ستظهر هنا المؤشرات التي يمكن ربطها مباشرةً بالقيم أو النص الذي أدخلته."
                  : "Indicators directly linked to values or pasted text will appear here."}
              </p>
            </div>
          )}
        </section>
        <div className="info-strip lab-limit">
          <AlertTriangle size={16} />
          {isArabic
            ? "مؤشرات التقدم تصف تحليل الواجهة محليًا ولا تدّعي اتصالًا مباشرًا أو فحصًا حيًا لأجهزة الشبكة."
            : "Progress indicators describe local UI analysis and do not claim a direct connection to, or live test of, network devices."}
        </div>
      </div>
    </ZeroGramShell>
  );
}
