import { BookOpen, CircleHelp, Search, ShieldCheck, Wrench } from "lucide-react";
import { useMemo, useState } from "react";
import { Link } from "wouter";
import { EmptyState, SectionHeading, ZeroGramShell } from "@/components/ZeroGramShell";
import { useI18n } from "@/lib/i18n";

type HelpArticle = {
  id: string;
  icon: React.ReactNode;
  ar: { title: string; summary: string; steps: string[] };
  iq: { title: string; summary: string; steps: string[] };
  en: { title: string; summary: string; steps: string[] };
  href?: string;
};

const articles: HelpArticle[] = [
  {
    id: "dashboard",
    icon: <BookOpen />,
    ar: { title: "مساحة العمل", summary: "المكان الرئيسي لمراجعة النتائج وملفات المراقبة والأحداث.", steps: ["افتح Dashboard من شريط التنقل.", "استخدم البحث للوصول إلى مرجع أو IP أو MAC.", "افتح الفلاتر لتحديد المصدر وNetScore والفترة."] },
    iq: { title: "لوحة العمل", summary: "هنا تراجع النتائج وملفات المراقبة والأحداث بسرعة.", steps: ["افتح لوحة العمل من التنقل.", "دوّر بالبحث على المرجع أو IP أو MAC.", "استخدم الفلاتر حتى توصل للمعلومة المطلوبة."] },
    en: { title: "Dashboard", summary: "The main place to review results, monitoring profiles, and events.", steps: ["Open Dashboard from navigation.", "Search by reference, IP, MAC, or result details.", "Use filters for source, NetScore, and time window."] },
    href: "/dashboard",
  },
  {
    id: "tools",
    icon: <Wrench />,
    ar: { title: "دليل الأدوات", summary: "يوحّد الوصول إلى الفحص والمراقبة وFiber وذكاء المتصفح.", steps: ["افتح Tools لرؤية الأدوات حسب المجموعة.", "اختر البطاقة المطلوبة لفتح الصفحة الفعلية.", "راجع حالة التحميل أو الخطأ قبل إدخال البيانات."] },
    iq: { title: "دليل الأدوات", summary: "يجمع الفحص والمراقبة وFiber وذكاء المتصفح بمكان واحد.", steps: ["افتح الأدوات وشوف المجموعات.", "اضغط على البطاقة حتى تفتح الأداة.", "إذا صار خطأ، راجع الرسالة قبل ما تعيد العملية."] },
    en: { title: "Tools index", summary: "A single entry point for testing, monitoring, Fiber, and browser intelligence.", steps: ["Open Tools and review the grouped cards.", "Select a card to open the real tool page.", "Check loading or error feedback before entering data."] },
    href: "/tools",
  },
  {
    id: "settings",
    icon: <ShieldCheck />,
    ar: { title: "الإعدادات والمظهر", summary: "تتحكم في اللغة والمظهر والحركة وكثافة العرض محليًا.", steps: ["افتح Settings.", "اختر Original أو Light أو Dark.", "يُحفظ الاختيار تلقائيًا في هذا المتصفح."] },
    iq: { title: "الإعدادات والمظهر", summary: "من هنا تغيّر اللغة والشكل والحركة وكثافة العرض.", steps: ["افتح الإعدادات.", "اختار الأصلي أو الأبيض أو الأسود.", "الإعداد ينحفظ تلقائيًا على هذا المتصفح."] },
    en: { title: "Settings and appearance", summary: "Control language, appearance, motion, and density locally.", steps: ["Open Settings.", "Choose Original, Light, or Dark.", "Your choice is saved automatically in this browser."] },
    href: "/settings",
  },
  {
    id: "privacy",
    icon: <CircleHelp />,
    ar: { title: "الخصوصية والقيود", summary: "تعرض المنصة القياسات المتاحة من المتصفح ولا تدّعي الوصول إلى أجهزة غير متصلة.", steps: ["أدخل بياناتك أو قياساتك الحقيقية فقط.", "اقرأ المصدر والحدود في النتيجة.", "لا تتجاوز صلاحيات المتصفح أو الخادم؛ ستظهر القيود بوضوح."] },
    iq: { title: "الخصوصية والحدود", summary: "المنصة تقيس اللي يقدر عليه المتصفح وما تدّعي وصول لأجهزة ما متصلة.", steps: ["دخل بيانات حقيقية فقط.", "اقرأ المصدر والحدود بالنتيجة.", "إذا أكو صلاحية مطلوبة، راح تنعرض بوضوح وما ننطي وظيفة وهمية."] },
    en: { title: "Privacy and limits", summary: "The platform reports browser-available measurements and never claims access to disconnected devices.", steps: ["Enter only real data or measurements.", "Read the source and limits on every result.", "Browser and server permissions are shown instead of bypassed."] },
    href: "/privacy",
  },
  {
    id: "faq",
    icon: <CircleHelp />,
    ar: { title: "الأسئلة الشائعة", summary: "إجابات سريعة عن البيانات والصلاحيات والتقارير والتشخيص.", steps: ["هل تصل المنصة إلى أجهزة الشبكة؟ لا، تعرض ما يقيسه المتصفح أو ما تدخله يدويًا.", "هل النتائج بيانات وهمية؟ لا، الحالات الفارغة تبقى فارغة حتى توفر بيانات حقيقية.", "ماذا أفعل عند الخطأ؟ اقرأ رسالة الخطأ، تحقق من الاتصال والمدخلات، ثم أعد المحاولة."] },
    iq: { title: "الأسئلة الشائعة", summary: "أجوبة سريعة عن البيانات والصلاحيات والتقارير والتشخيص.", steps: ["المنصة تدخل على أجهزة الشبكة؟ لا، تعرض اللي يقيسه المتصفح أو تدخله إنت.", "النتائج وهمية؟ لا، إذا ماكو بيانات تبقى الصفحة فارغة.", "إذا صار خطأ؟ اقرأ الرسالة، تأكد من النت والمدخلات، وبعدين جرّب مرة ثانية."] },
    en: { title: "Frequently asked questions", summary: "Quick answers about data, permissions, reports, and diagnostics.", steps: ["Does the platform access network devices? No, it reports browser measurements or your manual input.", "Are results fabricated? No, empty states remain empty until real data is available.", "What should I do after an error? Read the message, check connectivity and inputs, then retry."] },
  },
];

export default function HelpCenter() {
  const { language, isArabic } = useI18n();
  const [query, setQuery] = useState("");
  const filtered = useMemo(() => articles.filter(article => {
    const content = article[language];
    return `${content.title} ${content.summary} ${content.steps.join(" ")}`.toLowerCase().includes(query.trim().toLowerCase());
  }), [language, query]);
  return (
    <ZeroGramShell title={language === "en" ? "Help center" : language === "iq" ? "مركز المساعدة" : "مركز المساعدة"} eyebrow="ZERO GRAM / HELP">
      <div className="page-content help-center-page">
        <SectionHeading index="00" title={language === "en" ? "Understand every station" : language === "iq" ? "افهم كل قسم بسهولة" : "افهم كل قسم بسهولة"} description={language === "en" ? "Practical guidance for every major area of ZERO GRAM." : language === "iq" ? "شرح عملي لكل قسم مهم بـ ZERO GRAM." : "شرح عملي لكل قسم مهم في ZERO GRAM."} />
        <label className="knowledge-search help-search">
          <Search size={15} />
          <input value={query} onChange={event => setQuery(event.target.value)} placeholder={language === "en" ? "Search help topics" : language === "iq" ? "دوّر بمركز المساعدة" : "ابحث في مركز المساعدة"} />
          <span>{filtered.length}</span>
        </label>
        <div className="help-grid">
          {filtered.map(article => {
            const content = article[language];
            return <article className="data-panel help-article" key={article.id}>
              <div className="help-article-head"><span>{article.icon}</span><div><h3>{content.title}</h3><p>{content.summary}</p></div></div>
              <ol>{content.steps.map(step => <li key={step}>{step}</li>)}</ol>
              {article.href && <Link className="action-button" href={article.href}>{language === "en" ? "Open section" : language === "iq" ? "افتح القسم" : "فتح القسم"}</Link>}
            </article>;
          })}
        </div>
        {!filtered.length && <EmptyState title={language === "en" ? "No help topic found" : language === "iq" ? "ما لكينا موضوع" : "لم نجد موضوعًا"} copy={language === "en" ? "Try another search phrase." : language === "iq" ? "جرّب كلمة بحث ثانية." : "جرّب عبارة بحث أخرى."} />}
      </div>
    </ZeroGramShell>
  );
}
