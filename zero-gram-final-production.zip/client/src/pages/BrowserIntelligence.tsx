import {
  EmptyState,
  SectionHeading,
  ZeroGramShell,
} from "@/components/ZeroGramShell";
import { useI18n } from "@/lib/i18n";
import {
  browserError,
  browserValue,
  capabilityStatus,
  qualityLabel,
  scoreQuality,
  type BrowserValue,
  type CapabilityStatus,
  type EvidenceState,
} from "../../../shared/browserIntelligence";
import {
  Activity,
  CheckCircle2,
  Clipboard,
  Globe2,
  Monitor,
  Network,
  RefreshCw,
  ShieldCheck,
  Smartphone,
  Timer,
  Wifi,
  XCircle,
} from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";

type Identity = {
  ip: BrowserValue<string>;
  ipv4: BrowserValue<string>;
  ipv6: BrowserValue<string>;
  isp: BrowserValue<string>;
  asn: BrowserValue<string>;
  organization: BrowserValue<string>;
  network: BrowserValue<string>;
  reverseDns: BrowserValue<string>;
  country: BrowserValue<string>;
  region: BrowserValue<string>;
  city: BrowserValue<string>;
  timeZone: BrowserValue<string>;
  connectionType: BrowserValue<string>;
};
type Latency = {
  current: number | null;
  average: number | null;
  minimum: number | null;
  maximum: number | null;
  jitter: number | null;
  loss: number | null;
  samples: number[];
};
type Capability = { name: string; status: CapabilityStatus; detail: string };
const unavailable = <T,>(
  source: string,
  limitation = "Not available from this browser or public source."
) => browserValue<T>(null, "Unavailable", source, limitation);
const nowLabel = () => new Date().toLocaleString();
const fetchJson = async (url: string, timeout = 5000) => {
  const controller = new AbortController();
  const timer = window.setTimeout(() => controller.abort(), timeout);
  try {
    const response = await fetch(url, {
      cache: "no-store",
      signal: controller.signal,
      headers: { accept: "application/json" },
    });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    return (await response.json()) as Record<string, any>;
  } finally {
    window.clearTimeout(timer);
  }
};
const probe = async (url: string) => {
  const start = performance.now();
  try {
    const response = await fetch(
      `${url}${url.includes("?") ? "&" : "?"}zg_probe=${Date.now()}`,
      { cache: "no-store", mode: "cors" }
    );
    return {
      ok: response.ok,
      ms: performance.now() - start,
      status: response.status,
    };
  } catch {
    return { ok: false, ms: null, status: null };
  }
};

export default function BrowserIntelligence() {
  const { isArabic } = useI18n();
  const [identity, setIdentity] = useState<Identity | null>(null);
  const [latency, setLatency] = useState<Latency | null>(null);
  const [status, setStatus] = useState<"idle" | "running" | "done">("idle");
  const [lastRun, setLastRun] = useState<string | null>(null);
  const [events, setEvents] = useState<
    Array<{ at: string; title: string; detail: string; state: EvidenceState }>
  >([]);
  const [localHistory, setLocalHistory] = useState<
    Array<{ at: string; score: number | null; latency: number | null }>
  >(() => {
    try {
      return JSON.parse(
        localStorage.getItem("zg-browser-quality-history") || "[]"
      );
    } catch {
      return [];
    }
  });
  const readNetwork = () => {
    const connection = (navigator as Navigator & { connection?: any })
      .connection;
    return connection
      ? connection.effectiveType || connection.type || "—"
      : "Browser API Not Supported";
  };
  const runSnapshot = async () => {
    setStatus("running");
    const started = Date.now();
    try {
      let publicData: Record<string, any> = {};
      try {
        publicData = await fetchJson("https://ipwho.is/", 5000);
      } catch {
        publicData = {};
      }
      let ipv4: string | null = null;
      let ipv6: string | null = null;
      try {
        ipv4 =
          (await fetchJson("https://api4.ipify.org?format=json", 4000)).ip ||
          null;
      } catch {
        /* unavailable */
      }
      try {
        ipv6 =
          (await fetchJson("https://api6.ipify.org?format=json", 4000)).ip ||
          null;
      } catch {
        /* unavailable */
      }
      const source = Object.keys(publicData).length
        ? "ipwho.is public response"
        : "Public IP service unavailable";
      setIdentity({
        ip: browserValue(
          publicData.ip || ipv4 || ipv6,
          publicData.ip || ipv4 || ipv6 ? "Measured" : "Unavailable",
          source,
          "Public identity is dependent on an allowed public response."
        ),
        ipv4: browserValue(
          publicData.type === "IPv4" ? publicData.ip : ipv4,
          publicData.type === "IPv4" || ipv4 ? "Measured" : "Unavailable",
          publicData.type === "IPv4" ? source : "api4.ipify.org",
          "IPv4 can be unavailable or blocked by the browser/network."
        ),
        ipv6: browserValue(
          publicData.type === "IPv6" ? publicData.ip : ipv6,
          publicData.type === "IPv6" || ipv6 ? "Measured" : "Unavailable",
          publicData.type === "IPv6" ? source : "api6.ipify.org",
          "IPv6 can be unavailable or blocked by the browser/network."
        ),
        isp: browserValue(
          publicData.connection?.isp || null,
          publicData.connection?.isp ? "Measured" : "Unavailable",
          source
        ),
        asn: browserValue(
          publicData.connection?.asn ? `AS${publicData.connection.asn}` : null,
          publicData.connection?.asn ? "Measured" : "Unavailable",
          source
        ),
        organization: browserValue(
          publicData.connection?.org || null,
          publicData.connection?.org ? "Measured" : "Unavailable",
          source
        ),
        network: browserValue(
          publicData.connection?.domain || null,
          publicData.connection?.domain ? "Measured" : "Unavailable",
          source
        ),
        reverseDns: unavailable(
          "Browser/public source",
          "Reverse DNS is not exposed by this browser-safe source."
        ),
        country: browserValue(
          publicData.country || null,
          publicData.country ? "Measured" : "Unavailable",
          source
        ),
        region: browserValue(
          publicData.region || null,
          publicData.region ? "Measured" : "Unavailable",
          source
        ),
        city: browserValue(
          publicData.city || null,
          publicData.city ? "Measured" : "Unavailable",
          source
        ),
        timeZone: browserValue(
          publicData.timezone?.id ||
            Intl.DateTimeFormat().resolvedOptions().timeZone ||
            null,
          publicData.timezone?.id ? "Measured" : "Detected",
          publicData.timezone?.id ? source : "Intl.DateTimeFormat"
        ),
        connectionType: browserValue(
          readNetwork(),
          readNetwork() === "Browser API Not Supported"
            ? "Unavailable"
            : "Detected",
          "Network Information API",
          readNetwork() === "Browser API Not Supported"
            ? "Browser API Not Supported"
            : undefined
        ),
      });
      const samples: number[] = [];
      let received = 0;
      for (let index = 0; index < 6; index++) {
        const result = await probe("/favicon.ico");
        if (result.ms !== null) samples.push(result.ms);
        if (result.ok) received++;
      }
      const average = samples.length
        ? samples.reduce((sum, value) => sum + value, 0) / samples.length
        : null;
      const minimum = samples.length ? Math.min(...samples) : null;
      const maximum = samples.length ? Math.max(...samples) : null;
      const jitter =
        samples.length > 1
          ? samples
              .slice(1)
              .reduce(
                (sum, value, index) => sum + Math.abs(value - samples[index]),
                0
              ) /
            (samples.length - 1)
          : null;
      const nextLatency = {
        current: samples.at(-1) ?? null,
        average,
        minimum,
        maximum,
        jitter,
        loss: samples.length ? ((6 - received) / 6) * 100 : null,
        samples,
      };
      setLatency(nextLatency);
      const score = scoreQuality({
        latencyMs: average,
        jitterMs: jitter,
        packetLossPercent: nextLatency.loss,
      });
      const entry = { at: nowLabel(), score, latency: average };
      setLocalHistory(current => {
        const next = [entry, ...current].slice(0, 50);
        localStorage.setItem(
          "zg-browser-quality-history",
          JSON.stringify(next)
        );
        return next;
      });
      setEvents(current =>
        [
          {
            at: nowLabel(),
            title: "Browser intelligence snapshot completed",
            detail:
              "Public identity, browser latency, and connection metadata were measured or marked unavailable.",
            state: "Detected" as EvidenceState,
          },
          ...current,
        ].slice(0, 30)
      );
      setLastRun(new Date(started).toISOString());
      setStatus("done");
    } catch (error) {
      setEvents(current => [
        {
          at: nowLabel(),
          title: "Browser diagnostic restricted",
          detail: String(error),
          state: "Unavailable" as EvidenceState,
        },
        ...current,
      ]);
      setStatus("done");
    }
  };
  useEffect(() => {
    const onOnline = () =>
      setEvents(current =>
        [
          {
            at: nowLabel(),
            title: "Connection restored",
            detail: "Navigator online event",
            state: "Detected" as EvidenceState,
          },
          ...current,
        ].slice(0, 30)
      );
    const onOffline = () =>
      setEvents(current =>
        [
          {
            at: nowLabel(),
            title: "Internet connection lost",
            detail: "Navigator offline event",
            state: "Detected" as EvidenceState,
          },
          ...current,
        ].slice(0, 30)
      );
    const connection = (navigator as Navigator & { connection?: any })
      .connection;
    const onChange = () =>
      setEvents(current =>
        [
          {
            at: nowLabel(),
            title: "Network information changed",
            detail: `Connection: ${readNetwork()}`,
            state: "Detected" as EvidenceState,
          },
          ...current,
        ].slice(0, 30)
      );
    window.addEventListener("online", onOnline);
    window.addEventListener("offline", onOffline);
    connection?.addEventListener?.("change", onChange);
    return () => {
      window.removeEventListener("online", onOnline);
      window.removeEventListener("offline", onOffline);
      connection?.removeEventListener?.("change", onChange);
    };
  }, []);
  const deviceInfo = useMemo(() => {
    const ua = navigator.userAgent;
    return [
      {
        label: isArabic ? "نظام التشغيل" : "Operating system",
        value: /Windows/i.test(ua)
          ? "Windows"
          : /Mac OS/i.test(ua)
            ? "macOS"
            : /Android/i.test(ua)
              ? "Android"
              : /iPhone|iPad/i.test(ua)
                ? "iOS"
                : "Not Available",
        state: "Detected" as EvidenceState,
      },
      {
        label: isArabic ? "المتصفح" : "Browser",
        value: /Chrome/i.test(ua)
          ? "Chrome"
          : /Firefox/i.test(ua)
            ? "Firefox"
            : /Safari/i.test(ua)
              ? "Safari"
              : "Not Available",
        state: "Detected" as EvidenceState,
      },
      {
        label: isArabic ? "دقة الشاشة" : "Screen resolution",
        value: `${screen.width} × ${screen.height}`,
        state: "Detected" as EvidenceState,
      },
      {
        label: isArabic ? "حجم النافذة" : "Viewport",
        value: `${window.innerWidth} × ${window.innerHeight}`,
        state: "Detected" as EvidenceState,
      },
      {
        label: "DPR",
        value: String(window.devicePixelRatio),
        state: "Detected" as EvidenceState,
      },
      {
        label: isArabic ? "اللغة" : "Language",
        value: navigator.language,
        state: "Detected" as EvidenceState,
      },
      {
        label: isArabic ? "الأنوية" : "Logical cores",
        value: String(navigator.hardwareConcurrency || "Not Available"),
        state: navigator.hardwareConcurrency
          ? ("Detected" as EvidenceState)
          : ("Unavailable" as EvidenceState),
      },
      {
        label: isArabic ? "اللمس" : "Touch support",
        value:
          "ontouchstart" in window || navigator.maxTouchPoints > 0
            ? "Supported"
            : "Not Supported",
        state: "Detected" as EvidenceState,
      },
      {
        label: isArabic ? "الحالة" : "Online status",
        value: navigator.onLine ? "Online" : "Offline",
        state: "Detected" as EvidenceState,
      },
      {
        label: isArabic ? "الوضع الداكن" : "Dark mode",
        value: matchMedia("(prefers-color-scheme: dark)").matches
          ? "Preferred"
          : "Not preferred",
        state: "Detected" as EvidenceState,
      },
    ];
  }, [isArabic, status]);
  const connectionDetails = useMemo(() => {
    const connection = (navigator as Navigator & { connection?: any })
      .connection;
    return [
      {
        label: "effectiveType",
        value: connection?.effectiveType || "Not Available",
        state: connection ? "Detected" : "Unavailable",
      },
      {
        label: "downlink",
        value: connection?.downlink
          ? `${connection.downlink} Mbps`
          : "Not Available",
        state: connection?.downlink ? "Detected" : "Unavailable",
      },
      {
        label: "RTT hint",
        value: connection?.rtt ? `${connection.rtt} ms` : "Not Available",
        state: connection?.rtt ? "Detected" : "Unavailable",
      },
      {
        label: "saveData",
        value:
          connection?.saveData === undefined
            ? "Not Available"
            : String(Boolean(connection.saveData)),
        state: connection?.saveData === undefined ? "Unavailable" : "Detected",
      },
    ];
  }, [status]);
  const performanceInfo = useMemo(() => {
    const navigation = performance.getEntriesByType("navigation")[0] as
      | PerformanceNavigationTiming
      | undefined;
    const memory = (
      performance as Performance & {
        memory?: { usedJSHeapSize: number; jsHeapSizeLimit: number };
      }
    ).memory;
    return [
      {
        label: "DOM complete",
        value: navigation?.domComplete
          ? `${navigation.domComplete.toFixed(1)} ms`
          : "Not Available",
        state: navigation ? "Measured" : "Unavailable",
      },
      {
        label: "Response",
        value: navigation?.responseStart
          ? `${navigation.responseStart.toFixed(1)} ms`
          : "Not Available",
        state: navigation ? "Measured" : "Unavailable",
      },
      {
        label: "Load event",
        value: navigation?.loadEventEnd
          ? `${navigation.loadEventEnd.toFixed(1)} ms`
          : "Not Available",
        state: navigation ? "Measured" : "Unavailable",
      },
      {
        label: "JS heap",
        value: memory
          ? `${(memory.usedJSHeapSize / 1048576).toFixed(1)} MB`
          : "Not Available",
        state: memory ? "Measured" : "Unavailable",
      },
    ];
  }, [status]);
  const capabilities: Capability[] = [
    {
      name: "Network Information API",
      status: capabilityStatus(Boolean((navigator as any).connection)),
      detail: "connection / effectiveType / downlink / RTT",
    },
    {
      name: "WebRTC",
      status: capabilityStatus("RTCPeerConnection" in window),
      detail: "Capability only; no private IP enumeration",
    },
    {
      name: "WebSocket",
      status: capabilityStatus("WebSocket" in window),
      detail: "Browser capability",
    },
    {
      name: "Web Workers",
      status: capabilityStatus("Worker" in window),
      detail: "Browser capability",
    },
    {
      name: "Service Workers",
      status: capabilityStatus("serviceWorker" in navigator),
      detail: "Browser capability",
    },
    {
      name: "WebGL",
      status: capabilityStatus(
        Boolean(document.createElement("canvas").getContext("webgl"))
      ),
      detail: "Rendering capability",
    },
    {
      name: "WebGPU",
      status: capabilityStatus("gpu" in navigator),
      detail: "Optional browser capability",
    },
    {
      name: "WebAssembly",
      status: capabilityStatus("WebAssembly" in window),
      detail: "Runtime capability",
    },
    {
      name: "Clipboard",
      status: capabilityStatus(Boolean(navigator.clipboard)),
      detail: "Permission may still be required",
    },
    {
      name: "Battery API",
      status: capabilityStatus("getBattery" in navigator),
      detail: "Optional and permission/browser dependent",
    },
    {
      name: "IndexedDB",
      status: capabilityStatus(Boolean(window.indexedDB)),
      detail: "Local browser storage",
    },
    {
      name: "HTTPS",
      status: capabilityStatus(location.protocol === "https:"),
      detail: location.protocol,
    },
  ];
  const copy = async (value: string | null) => {
    if (!value) return;
    try {
      await navigator.clipboard.writeText(value);
      toast.success(isArabic ? "تم النسخ." : "Copied.");
    } catch {
      toast.error(isArabic ? "الحافظة غير متاحة." : "Clipboard unavailable.");
    }
  };
  const valueCell = (item: BrowserValue<string>) => (
    <span
      className={`evidence-value ${item.value === null ? "unavailable" : ""}`}
    >
      <b>{item.value ?? "Not Available"}</b>
      <small>
        {item.state} · {item.source}
      </small>
      {item.limitation && <em>{item.limitation}</em>}
    </span>
  );
  return (
    <ZeroGramShell title="ZERO GRAM" eyebrow="ZERO GRAM / BROWSER INTELLIGENCE">
      <div className="page-content browser-intelligence">
        <SectionHeading
          index="B/01"
          title={
            isArabic
              ? "ذكاء الاتصال من المتصفح"
              : "Browser connection intelligence"
          }
          description={
            isArabic
              ? "يقيس المركز ما يسمح به Chrome والمتصفح الحالي وخدمات عامة مسموحة، ويميّز كل قيمة بمصدرها وحالتها. لا يقرأ معدات الشبكة ولا يتجاوز Sandbox."
              : "This center measures what Chrome, the current browser, and allowed public services expose, with source and state on every value. It does not read network equipment or bypass the browser sandbox."
          }
        />
        <div className="browser-actions">
          <button
            className="action-button primary"
            onClick={runSnapshot}
            disabled={status === "running"}
          >
            {status === "running" ? (
              <>
                <RefreshCw className="spin" size={15} />{" "}
                {isArabic ? "جار القياس" : "Measuring"}
              </>
            ) : (
              <>
                <Activity size={15} />{" "}
                {isArabic ? "تشغيل لقطة كاملة" : "Run intelligence snapshot"}
              </>
            )}
          </button>
          <span>
            {lastRun
              ? `${isArabic ? "آخر تشغيل" : "Last run"}: ${new Date(lastRun).toLocaleString()}`
              : isArabic
                ? "لم تُشغّل لقطة بعد"
                : "No snapshot yet"}
          </span>
        </div>
        <section className="data-panel browser-panel">
          <header>
            <Globe2 size={18} />
            <div>
              <h3>
                {isArabic
                  ? "Internet Identity / IP Intelligence"
                  : "Internet Identity / IP Intelligence"}
              </h3>
              <small>
                {isArabic
                  ? "مصادر عامة حقيقية؛ غير المتاح لا يُستبدل بقيمة تقديرية"
                  : "Real public sources; unavailable values are never replaced with estimates"}
              </small>
            </div>
          </header>
          {identity ? (
            <div className="evidence-grid">
              {(
                [
                  "ip",
                  "ipv4",
                  "ipv6",
                  "isp",
                  "asn",
                  "organization",
                  "network",
                  "reverseDns",
                  "country",
                  "region",
                  "city",
                  "timeZone",
                  "connectionType",
                ] as const
              ).map(key => (
                <article key={key}>
                  <label>{key}</label>
                  {valueCell(identity[key])}
                  {identity[key].value && (
                    <button
                      className="icon-button"
                      onClick={() => copy(identity[key].value)}
                    >
                      <Clipboard size={13} />
                    </button>
                  )}
                </article>
              ))}
            </div>
          ) : (
            <EmptyState
              title={
                isArabic ? "لا توجد هوية مقاسة بعد" : "No measured identity yet"
              }
              copy={
                isArabic
                  ? "شغّل لقطة الاتصال لجلب ما تسمح به الخدمات العامة والمتصفح."
                  : "Run a snapshot to retrieve what the public source and browser allow."
              }
            />
          )}
        </section>
        <div className="browser-grid">
          <section className="data-panel browser-panel">
            <header>
              <Timer size={18} />
              <div>
                <h3>
                  {isArabic ? "Latency / Packet Loss" : "Latency / Packet Loss"}
                </h3>
                <small>
                  {isArabic
                    ? "قياس fetch للوجهة الحالية؛ ليس ICMP"
                    : "fetch timing to this origin; not ICMP"}
                </small>
              </div>
            </header>
            {latency ? (
              <div className="metric-matrix">
                {[
                  ["Current", latency.current],
                  ["Average", latency.average],
                  ["Minimum", latency.minimum],
                  ["Maximum", latency.maximum],
                  ["Jitter", latency.jitter],
                  ["Packet loss", latency.loss],
                ].map(([label, value]) => (
                  <div key={String(label)}>
                    <small>{label}</small>
                    <b>
                      {value === null
                        ? "Not Available"
                        : `${Number(value).toFixed(2)}${label === "Packet loss" ? "%" : " ms"}`}
                    </b>
                  </div>
                ))}
              </div>
            ) : (
              <EmptyState
                title="Not Available"
                copy={
                  isArabic
                    ? "تظهر القياسات بعد تشغيل اللقطة."
                    : "Measurements appear after running a snapshot."
                }
              />
            )}
          </section>
          <section className="data-panel browser-panel">
            <header>
              <Monitor size={18} />
              <div>
                <h3>
                  {isArabic ? "Device Information" : "Device Information"}
                </h3>
                <small>
                  {isArabic
                    ? "قراءات غير حساسة من واجهة المتصفح"
                    : "Non-sensitive browser-exposed readings"}
                </small>
              </div>
            </header>
            <div className="device-grid">
              {deviceInfo.map(item => (
                <div key={item.label}>
                  <small>{item.label}</small>
                  <b>{item.value}</b>
                  <em>{item.state}</em>
                </div>
              ))}
            </div>
          </section>
        </div>
        <section className="data-panel browser-panel">
          <header>
            <Network size={18} />
            <div>
              <h3>
                {isArabic
                  ? "Network Information API"
                  : "Network Information API"}
              </h3>
              <small>
                {isArabic
                  ? "التفاصيل لا تظهر إلا إذا دعمها المتصفح"
                  : "Details appear only when the browser exposes them"}
              </small>
            </div>
          </header>
          <div className="device-grid">
            {connectionDetails.map(item => (
              <div key={item.label}>
                <small>{item.label}</small>
                <b>{item.value}</b>
                <em>{item.state}</em>
              </div>
            ))}
          </div>
        </section>
        <section className="data-panel browser-panel">
          <header>
            <ShieldCheck size={18} />
            <div>
              <h3>
                {isArabic ? "Browser Capabilities" : "Browser Capabilities"}
              </h3>
              <small>
                {isArabic
                  ? "لا تُطلب صلاحية إلا عند الحاجة ولا تُجمع معلومات خاصة"
                  : "Permissions are not requested unless needed; private data is not collected"}
              </small>
            </div>
          </header>
          <div className="capability-grid">
            {capabilities.map(item => (
              <article key={item.name}>
                <span>
                  {item.status === "Supported" ? (
                    <CheckCircle2 />
                  ) : item.status === "Not Supported" ? (
                    <XCircle />
                  ) : (
                    <Network />
                  )}
                </span>
                <div>
                  <b>{item.name}</b>
                  <small>
                    {item.status} · {item.detail}
                  </small>
                </div>
              </article>
            ))}
          </div>
        </section>
        <section className="data-panel browser-panel">
          <header>
            <Activity size={18} />
            <div>
              <h3>
                {isArabic ? "Browser Performance" : "Browser Performance"}
              </h3>
              <small>
                {isArabic
                  ? "Timing من Performance API، وليس تقديرًا"
                  : "Performance API timings, never an estimate"}
              </small>
            </div>
          </header>
          <div className="device-grid">
            {performanceInfo.map(item => (
              <div key={item.label}>
                <small>{item.label}</small>
                <b>{item.value}</b>
                <em>{item.state}</em>
              </div>
            ))}
          </div>
        </section>
        <div className="browser-grid">
          <section className="data-panel browser-panel">
            <header>
              <Wifi size={18} />
              <div>
                <h3>
                  {isArabic ? "Connection Timeline" : "Connection Timeline"}
                </h3>
                <small>
                  {isArabic
                    ? "أحداث navigator الحقيقية فقط"
                    : "Real navigator events only"}
                </small>
              </div>
            </header>
            {events.length ? (
              <div className="connection-events">
                {events.map((event, index) => (
                  <article key={`${event.at}-${index}`}>
                    <b>{event.at}</b>
                    <span>{event.title}</span>
                    <small>
                      {event.detail} · {event.state}
                    </small>
                  </article>
                ))}
              </div>
            ) : (
              <EmptyState
                title={isArabic ? "لا توجد أحداث بعد" : "No events yet"}
                copy={
                  isArabic
                    ? "ستظهر أحداث online/offline وتغير الشبكة عندما يكتشفها المتصفح."
                    : "Online/offline and network-change events appear when the browser detects them."
                }
              />
            )}
          </section>
          <section className="data-panel browser-panel">
            <header>
              <BarChart3Icon />
              <div>
                <h3>
                  {isArabic
                    ? "Network Quality History"
                    : "Network Quality History"}
                </h3>
                <small>
                  {isArabic
                    ? "تخزين محلي للقطات هذا المتصفح"
                    : "Local history for this browser"}
                </small>
              </div>
            </header>
            {localHistory.length ? (
              <div className="quality-history">
                {localHistory.map((entry, index) => (
                  <div key={`${entry.at}-${index}`}>
                    <b>
                      {entry.score === null
                        ? "Not Available"
                        : `${entry.score}/100`}
                    </b>
                    <span>
                      {entry.latency === null
                        ? "—"
                        : `${entry.latency.toFixed(1)} ms`}
                    </span>
                    <small>{entry.at}</small>
                  </div>
                ))}
              </div>
            ) : (
              <EmptyState
                title={
                  isArabic ? "السجل المحلي فارغ" : "Local history is empty"
                }
                copy={
                  isArabic
                    ? "شغّل أكثر من لقطة لبناء سجل صادق."
                    : "Run more than one snapshot to build an honest history."
                }
              />
            )}
          </section>
        </div>
      </div>
    </ZeroGramShell>
  );
}
function BarChart3Icon() {
  return <Activity size={18} />;
}
