import { ZeroGramShell, groupFor, navigation } from "@/components/ZeroGramShell";
import { useI18n } from "@/lib/i18n";
import { Link } from "wouter";
import { ArrowUpRight, Cable, Gauge, Network } from "lucide-react";

const groupOrder = ["workspace", "browser", "fiber", "operations", "tools"] as const;

function groupLabel(group: string, isArabic: boolean) {
  if (group === "workspace") return isArabic ? "مساحة العمل" : "Workspace";
  if (group === "browser") return isArabic ? "ذكاء المتصفح" : "Browser intelligence";
  if (group === "fiber") return isArabic ? "الألياف وGPON" : "Fiber & GPON";
  if (group === "operations") return isArabic ? "العمليات" : "Operations";
  return isArabic ? "الأدوات" : "Tools";
}

const groupIcon = (group: string) => {
  if (group === "fiber") return Cable;
  if (group === "browser") return Network;
  if (group === "operations") return Gauge;
  return Network;
};

export default function Tools() {
  const { isArabic, t } = useI18n();
  const items = navigation.filter(([href]) => href !== "/tools");

  return (
    <ZeroGramShell
      title={isArabic ? "دليل الأدوات" : "Tools directory"}
      eyebrow="ZERO GRAM / TOOL INDEX"
    >
      <div className="page-content tools-page">
        <section className="data-panel tools-hero">
          <div className="tools-hero-icon"><Network size={22} /></div>
          <div>
            <h3>{isArabic ? "كل أدوات الفحص في مكان واحد" : "Every diagnostic tool in one place"}</h3>
            <p>
              {isArabic
                ? "اختر الفحص أو المختبر أو لوحة العمليات مباشرة. لا تحتاج إلى فتح قائمة جانبية."
                : "Open a test, lab, or operations console directly. No side menu required."}
            </p>
          </div>
        </section>
        <div className="tools-directory">
          {groupOrder.map(group => {
            const groupItems = items.filter(([href]) => groupFor(href) === group);
            if (!groupItems.length) return null;
            const Icon = groupIcon(group);
            return (
              <section className="data-panel tools-group" key={group}>
                <header className="tools-group-header">
                  <div>
                    <Icon size={17} />
                    <h3>{groupLabel(group, isArabic)}</h3>
                  </div>
                  <span>{String(groupItems.length).padStart(2, "0")}</span>
                </header>
                <div className="tools-grid">
                  {groupItems.map(([href, key, ItemIcon]) => (
                    <Link className="tool-link" href={href} key={href}>
                      <span className="tool-link-icon"><ItemIcon size={17} /></span>
                      <span className="tool-link-copy">
                        <b>{t(key)}</b>
                        <small dir="ltr">{href}</small>
                      </span>
                      <ArrowUpRight size={15} />
                    </Link>
                  ))}
                </div>
              </section>
            );
          })}
        </div>
      </div>
    </ZeroGramShell>
  );
}
