import {
  EmptyState,
  SectionHeading,
  ZeroGramShell,
} from "@/components/ZeroGramShell";
import { useI18n } from "@/lib/i18n";
import { trpc } from "@/lib/trpc";
import {
  Activity,
  CircleHelp,
  GitFork,
  Network,
  RadioTower,
  ShieldCheck,
  Users,
} from "lucide-react";
import { useMemo, useState } from "react";

type ViewMode = "noc" | "engineer" | "customer";
const reach = (
  startId: number,
  edges: Array<{ sourceNodeId: number; targetNodeId: number }>
) => {
  const visited = new Set<number>([startId]);
  const queue = [startId];
  while (queue.length) {
    const current = queue.shift()!;
    for (const edge of edges)
      if (edge.sourceNodeId === current && !visited.has(edge.targetNodeId)) {
        visited.add(edge.targetNodeId);
        queue.push(edge.targetNodeId);
      }
  }
  return visited;
};

export default function CommandCenter() {
  const { isArabic } = useI18n();
  const topology = trpc.topology.context.useQuery();
  const intelligence = trpc.intelligence.overview.useQuery();
  const [mode, setMode] = useState<ViewMode>("noc");
  const [focusNodeId, setFocusNodeId] = useState<number | null>(null);
  const nodes = topology.data?.nodes || [];
  const edges = topology.data?.edges || [];
  const focus = nodes.find(node => node.id === focusNodeId) || null;
  const impacted = useMemo(
    () => (focus ? reach(focus.id, edges) : new Set<number>()),
    [focus, edges]
  );
  const impactedNodes = nodes.filter(node => impacted.has(node.id));
  const unavailable = isArabic ? "غير متوفر" : "Not Available";
  const title =
    mode === "noc"
      ? isArabic
        ? "لوحة NOC"
        : "NOC dashboard"
      : mode === "engineer"
        ? isArabic
          ? "مساحة المهندس"
          : "Engineer workspace"
        : isArabic
          ? "ملخص العميل"
          : "Customer summary";
  return (
    <ZeroGramShell
      title={isArabic ? "مركز القيادة" : "Command center"}
      eyebrow="ZERO GRAM / DIGITAL TWIN · IMPACT"
    >
      <div className="page-content command-page">
        <SectionHeading
          index="C/06"
          title={title}
          description={
            isArabic
              ? "تستند خريطة الاعتماد إلى العقد والروابط التي أُدخلت أو استوردت يدويًا. نطاق الأثر يمثل وصولًا طوبولوجيًا محتملًا، وليس برهانًا على سبب العطل أو عدد العملاء المتضررين."
              : "The dependency map is based on manually entered or imported nodes and edges. Impact scope is potential topology reach, not proof of fault causality or affected-customer count."
          }
        />
        <div className="mode-switch" role="tablist">
          {(["noc", "engineer", "customer"] as const).map(value => (
            <button
              key={value}
              className={mode === value ? "active" : ""}
              onClick={() => setMode(value)}
            >
              {value === "noc" ? (
                <RadioTower size={15} />
              ) : value === "engineer" ? (
                <Network size={15} />
              ) : (
                <Users size={15} />
              )}
              {value === "noc"
                ? "NOC"
                : value === "engineer"
                  ? isArabic
                    ? "مهندس"
                    : "Engineer"
                  : isArabic
                    ? "عميل"
                    : "Customer"}
            </button>
          ))}
        </div>
        {mode === "noc" && (
          <section className="command-grid">
            <article className="data-panel command-overview">
              <h3>
                <RadioTower size={16} />
                {isArabic ? "حالة الشبكة المرصودة" : "Observed network state"}
              </h3>
              <div className="command-stats">
                <Stat
                  label={isArabic ? "تنبيهات مفتوحة" : "Open alerts"}
                  value={topology.data?.openAlerts.length}
                />
                <Stat
                  label={isArabic ? "حوادث مفتوحة" : "Open incidents"}
                  value={intelligence.data?.activeIncidentCount}
                />
                <Stat
                  label={isArabic ? "نجاح فحوصات HTTP" : "HTTP check success"}
                  value={
                    intelligence.data?.reliability
                      .observedCheckSuccessPercent === undefined
                      ? unavailable
                      : `${intelligence.data.reliability.observedCheckSuccessPercent.toFixed(1)}%`
                  }
                />
                <Stat
                  label={isArabic ? "عقد الطوبولوجيا" : "Topology nodes"}
                  value={nodes.length}
                />
              </div>
              <p className="muted">
                {isArabic
                  ? "الأرقام لا تملأ فراغات القياس ولا تحول الفحص المحدود إلى حالة شبكة عامة."
                  : "Numbers do not fill measurement gaps or turn a limited check into a whole-network state."}
              </p>
            </article>
            <article className="data-panel">
              <h3>
                <Activity size={16} />
                {isArabic ? "الأولوية الحالية" : "Current priority"}
              </h3>
              {topology.data?.openAlerts.length ||
              intelligence.data?.activeIncidentCount ? (
                <div className="priority-list">
                  {topology.data?.openAlerts.slice(0, 4).map(alert => (
                    <article key={alert.id}>
                      <b>{alert.title}</b>
                      <span>
                        {alert.severity} · {alert.sourceLabel}
                      </span>
                    </article>
                  ))}
                  {intelligence.data?.incidents
                    .filter(item => item.state !== "resolved")
                    .slice(0, 4)
                    .map(incident => (
                      <article key={`incident-${incident.id}`}>
                        <b>
                          {incident.reference} · {incident.title}
                        </b>
                        <span>
                          {incident.severity} · {incident.state}
                        </span>
                      </article>
                    ))}
                </div>
              ) : (
                <EmptyState
                  title={
                    isArabic
                      ? "لا توجد أولوية مصدرية مفتوحة"
                      : "No sourced open priority"
                  }
                  copy={
                    isArabic
                      ? "ستظهر التنبيهات والحوادث المفتوحة هنا بعد تسجيلها؛ لا توجد حالة خضراء افتراضية."
                      : "Open alerts and incidents appear here after they are recorded; there is no default green state."
                  }
                />
              )}
            </article>
          </section>
        )}
        {mode === "engineer" && (
          <section className="command-grid">
            <article className="data-panel">
              <h3>
                <GitFork size={16} />
                {isArabic ? "خريطة الاعتماد والأثر" : "Dependency & impact map"}
              </h3>
              <label className="command-select">
                {isArabic ? "نقطة الفحص" : "Focus node"}
                <select
                  value={focusNodeId ?? ""}
                  onChange={event =>
                    setFocusNodeId(
                      event.target.value ? Number(event.target.value) : null
                    )
                  }
                >
                  <option value="">
                    {isArabic ? "اختر عقدة موثقة" : "Select a sourced node"}
                  </option>
                  {nodes.map(node => (
                    <option key={node.id} value={node.id}>
                      {node.label} · {node.nodeKind}
                    </option>
                  ))}
                </select>
              </label>
              {focus ? (
                <>
                  <div className="focus-card">
                    <b>{focus.label}</b>
                    <span>
                      {focus.nodeKind} · {focus.status || unavailable} ·{" "}
                      {focus.sourceLabel || unavailable}
                    </span>
                  </div>
                  <p className="muted">
                    {isArabic
                      ? `نطاق الأثر المحتمل: ${impactedNodes.length} عقدة يمكن الوصول إليها عبر الروابط الاتجاهية المسجلة.`
                      : `Potential impact scope: ${impactedNodes.length} nodes reachable through the recorded directional edges.`}
                  </p>
                  <div className="impact-node-list">
                    {impactedNodes.map(node => (
                      <span
                        key={node.id}
                        className={node.id === focus.id ? "focus" : ""}
                      >
                        {node.label}
                        <small>{node.nodeKind}</small>
                      </span>
                    ))}
                  </div>
                </>
              ) : (
                <EmptyState
                  title={isArabic ? "اختر نقطة فحص" : "Select a focus node"}
                  copy={
                    isArabic
                      ? "أضف عقدًا وروابط مصدرية من عمليات الألياف ثم اختر عقدة لحساب الوصول الطوبولوجي المحتمل."
                      : "Add sourced nodes and edges in Fiber Operations, then select a node to calculate potential topology reach."
                  }
                />
              )}
            </article>
            <article className="data-panel">
              <h3>
                <ShieldCheck size={16} />
                {isArabic ? "أدلة يجب مراجعتها" : "Evidence to review"}
              </h3>
              <div className="evidence-list">
                {topology.data?.events.slice(0, 8).map(event => (
                  <article key={event.id}>
                    <b>{event.title}</b>
                    <span>
                      {event.severity} ·{" "}
                      {new Date(event.occurredAt).toLocaleString()}
                    </span>
                    <small>{event.sourceLabel}</small>
                  </article>
                )) || null}
              </div>
              {!topology.data?.events.length && (
                <p className="muted">
                  {isArabic
                    ? "لا توجد أحداث تشغيلية مصدرية لربطها بمسار الأثر."
                    : "No sourced operational events are available to associate with an impact path."}
                </p>
              )}
              <p className="subtle-humor">
                {isArabic
                  ? "نبدأ من الدليل؛ لأن الألياف لا تترك ملاحظات على ورق."
                  : "Start with evidence; fiber rarely leaves a paper trail."}
              </p>
            </article>
          </section>
        )}
        {mode === "customer" && (
          <section className="customer-board">
            <article className="data-panel">
              <h3>
                <Users size={16} />
                {isArabic ? "ملخص شفاف للخدمة" : "Transparent service summary"}
              </h3>
              {intelligence.data?.activeIncidentCount ? (
                <>
                  <b className="customer-state warning">
                    {isArabic
                      ? "توجد حادثة تشغيلية موثقة قيد المتابعة"
                      : "A sourced operational incident is being tracked"}
                  </b>
                  <p>
                    {isArabic
                      ? "لا يعرض هذا الملخص تفاصيل داخلية أو يحدد سببًا نهائيًا قبل تحقق فريق التشغيل."
                      : "This summary does not expose internal details or claim a final cause before operations verify it."}
                  </p>
                </>
              ) : (
                <>
                  <b className="customer-state">
                    {isArabic
                      ? "لا توجد حادثة تشغيلية موثقة مفتوحة"
                      : "No sourced open operational incident"}
                  </b>
                  <p>
                    {isArabic
                      ? "هذه العبارة لا تثبت أداء اتصال فردي؛ استخدم فحص الاتصال لمشاهدة قياس متصفحك وحدوده."
                      : "This statement does not prove individual connection performance; use Connection Test to see your browser measurement and limits."}
                  </p>
                </>
              )}
              <div className="customer-actions">
                <a className="action-button primary" href="/test">
                  {isArabic ? "فحص اتصالي" : "Test my connection"}
                </a>
                <a className="action-button" href="/knowledge">
                  {isArabic ? "مركز المساعدة" : "Help center"}
                </a>
              </div>
            </article>
            <article className="data-panel help-card">
              <h3>
                <CircleHelp size={16} />
                {isArabic ? "مساعدة سياقية" : "Contextual help"}
              </h3>
              <dl>
                <dt>{isArabic ? "بطء مؤقت" : "Temporary slowness"}</dt>
                <dd>
                  {isArabic
                    ? "شغّل قياسين في وقتين مختلفين واحتفظ بالمصدر والحدود."
                    : "Run two tests at different times and retain the sources and limits."}
                </dd>
                <dt>{isArabic ? "انقطاع متكرر" : "Repeated disconnection"}</dt>
                <dd>
                  {isArabic
                    ? "راجع سجل ONT/LOS/LOF الموثق أو افتح بلاغًا للفريق."
                    : "Review sourced ONT/LOS/LOF history or open a ticket with your team."}
                </dd>
                <dt>{isArabic ? "نتيجة غير متاحة" : "Unavailable result"}</dt>
                <dd>
                  {isArabic
                    ? "المتصفح أو المسار لم يوفر القياس؛ لا تستبدلها بتقدير."
                    : "The browser or route did not provide the measurement; do not replace it with an estimate."}
                </dd>
              </dl>
            </article>
          </section>
        )}
      </div>
    </ZeroGramShell>
  );
}
function Stat({
  label,
  value,
}: {
  label: string;
  value: number | string | undefined;
}) {
  return (
    <article>
      <small>{label}</small>
      <b>{value ?? "—"}</b>
    </article>
  );
}
