import {
  EmptyState,
  SectionHeading,
  ZeroGramShell,
} from "@/components/ZeroGramShell";
import { useI18n } from "@/lib/i18n";
import { BookOpen, Cable, Router, Search, Wifi } from "lucide-react";
import { useMemo, useState } from "react";

export default function Knowledge() {
  const { isArabic, t } = useI18n();
  const [query, setQuery] = useState("");
  const items = [
    {
      icon: <Wifi />,
      tag: "WI-FI",
      title: isArabic
        ? "فرّق بين سرعة الرابط وجودة التجربة"
        : "Separate link speed from experience quality",
      body: isArabic
        ? "قد تكون سرعة النقل جيدة في لقطة واحدة، بينما يظل التذبذب أو الازدحام مؤثرًا على المكالمات والألعاب. قارن جلسات متعددة وفي أوقات مختلفة."
        : "A single throughput snapshot can look healthy while jitter or contention still affects calls and games. Compare several sessions at different times.",
    },
    {
      icon: <Cable />,
      tag: "GPON",
      title: isArabic
        ? "القدرة الضوئية مؤشر وليست حكمًا نهائيًا"
        : "Optical power is an indicator, not a final verdict",
      body: isArabic
        ? "راجع حدود عتادك ودليل المُصنّع، ثم طابق ONT RX مع قراءة OLT والسجل الزمني قبل أي تعديل ميداني."
        : "Review device-specific limits, then align ONT RX with OLT reading and event timing before any field change.",
    },
    {
      icon: <Router />,
      tag: "PPPoE",
      title: isArabic ? "اقرأ السجل كخط زمني" : "Read a log as a timeline",
      body: isArabic
        ? "فشل المصادقة أو إنهاء الجلسة يوضحان حدثًا مرئيًا فقط. استخدم الوقت والمعرّف المصرح به لمراجعة النظام المختص بأمان."
        : "Authentication failure or session termination only expose an observable event. Use timing and authorized identifiers to review the right system safely.",
    },
  ];
  const filtered = useMemo(
    () =>
      items.filter(item =>
        `${item.tag} ${item.title} ${item.body}`
          .toLowerCase()
          .includes(query.toLowerCase())
      ),
    [items, query]
  );
  return (
    <ZeroGramShell title={t("knowledge")} eyebrow="ZERO GRAM / PRACTICAL NOTES">
      <div className="page-content">
        <SectionHeading
          index="08"
          title={
            isArabic
              ? "معرفة عملية قابلة للتطبيق"
              : "Practical, usable knowledge"
          }
          description={
            isArabic
              ? "إرشادات قصيرة تساعد على تفسير النتائج دون تحويل المؤشر إلى سبب نهائي أو أمر تنفيذي."
              : "Short guidance to interpret results without turning an indicator into a final cause or an execution command."
          }
        />
        <label className="knowledge-search">
          <Search size={16} />
          <input
            value={query}
            onChange={event => setQuery(event.target.value)}
            placeholder={
              isArabic
                ? "ابحث في Wi‑Fi أو GPON أو PPPoE"
                : "Search Wi‑Fi, GPON, or PPPoE"
            }
          />
          <span>{filtered.length}</span>
        </label>
        {filtered.length ? (
          <div className="knowledge-grid">
            {filtered.map(item => (
              <article className="data-panel knowledge-card" key={item.tag}>
                <span className="knowledge-icon">{item.icon}</span>
                <p>{item.tag}</p>
                <h2>{item.title}</h2>
                <span>{item.body}</span>
                <div>
                  <BookOpen size={14} />
                  {isArabic
                    ? "خطوة تحقق آمنة أولًا"
                    : "Safe verification first"}
                </div>
              </article>
            ))}
          </div>
        ) : (
          <EmptyState
            title={isArabic ? "لا توجد مقالة مطابقة" : "No matching note"}
            copy={
              isArabic
                ? "جرّب مصطلحًا تقنيًا آخر أو امسح البحث لعرض الملاحظات المتاحة."
                : "Try another technical term or clear the search to show available notes."
            }
          />
        )}
      </div>
    </ZeroGramShell>
  );
}
