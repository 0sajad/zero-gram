import {
  EmptyState,
  SectionHeading,
  ZeroGramShell,
} from "@/components/ZeroGramShell";
import { AttachmentVault } from "@/components/AttachmentVault";
import { useI18n } from "@/lib/i18n";
import { trpc } from "@/lib/trpc";
import {
  Building2,
  Cable,
  ClipboardList,
  Plus,
  Search,
  UserRound,
} from "lucide-react";
import { useMemo, useState } from "react";
import { useLocation } from "wouter";
import { toast } from "sonner";

type RecordKind = "subscriber" | "site" | "pop" | "device" | "ticket";

function OpsPanel({
  icon,
  title,
  data,
  empty,
}: {
  icon: React.ReactNode;
  title: string;
  data: Array<Record<string, unknown>>;
  empty: string;
}) {
  return (
    <article className="data-panel ops-panel">
      <div className="panel-header">
        <h3 className="ops-title">
          {icon}
          {title}
        </h3>
        <span>{data.length}</span>
      </div>
      {data.length ? (
        <div className="simple-list">
          {data.map(row => (
            <div key={String(row.id)}>
              <b>
                {String(
                  row.displayName ||
                    row.name ||
                    row.label ||
                    row.title ||
                    row.reference ||
                    row.id
                )}
              </b>
              <small>
                {String(
                  row.status ||
                    row.siteType ||
                    row.deviceType ||
                    row.state ||
                    ""
                )}
              </small>
            </div>
          ))}
        </div>
      ) : (
        <EmptyState title="—" copy={empty} />
      )}
    </article>
  );
}

export default function Operations() {
  const { isArabic, t } = useI18n();
  const [location] = useLocation();
  const team = location === "/isp/team";
  const overview = trpc.operations.overview.useQuery();
  const [kind, setKind] = useState<RecordKind | null>(null);
  const [form, setForm] = useState<Record<string, string>>({});
  const [ticketSearch, setTicketSearch] = useState("");
  const subscriber = trpc.operations.addSubscriber.useMutation({
    onSuccess: () => {
      overview.refetch();
      setKind(null);
    },
  });
  const site = trpc.operations.addSite.useMutation({
    onSuccess: () => {
      overview.refetch();
      setKind(null);
    },
  });
  const pop = trpc.operations.addPop.useMutation({
    onSuccess: () => {
      overview.refetch();
      setKind(null);
    },
  });
  const device = trpc.operations.addDevice.useMutation({
    onSuccess: () => {
      overview.refetch();
      setKind(null);
    },
  });
  const ticket = trpc.operations.addTicket.useMutation({
    onSuccess: () => {
      overview.refetch();
      setKind(null);
    },
  });

  const save = () => {
    if (kind === "subscriber")
      subscriber.mutate({
        reference: form.reference || "",
        displayName: form.name || "",
      });
    if (kind === "site")
      site.mutate({
        name: form.name || "",
        siteType: form.type || "",
        reference: form.reference || undefined,
      });
    if (kind === "pop")
      pop.mutate({
        label: form.name || "",
        code: form.type || "",
        locationReference: form.reference || undefined,
      });
    if (kind === "device")
      device.mutate({
        label: form.name || "",
        deviceType: form.type || "",
        managementReference: form.reference || undefined,
      });
    if (kind === "ticket")
      ticket.mutate({
        title: form.name || "",
        severity: (form.severity || "medium") as
          | "low"
          | "medium"
          | "high"
          | "critical",
      });
    toast.success(isArabic ? "حُفظ السجل." : "Record saved.");
  };
  const audit = overview.data?.audit || [];
  const filteredTickets = useMemo(
    () =>
      (overview.data?.tickets || []).filter(ticket =>
        `${ticket.title} ${ticket.severity} ${ticket.state}`
          .toLowerCase()
          .includes(ticketSearch.toLowerCase())
      ),
    [overview.data?.tickets, ticketSearch]
  );

  return (
    <ZeroGramShell
      title={team ? t("team") : t("isp")}
      eyebrow={team ? "ZERO GRAM / GOVERNANCE" : "ZERO GRAM / OPERATIONS"}
    >
      <div className="page-content">
        <SectionHeading
          index={team ? "06" : "05"}
          title={
            team
              ? isArabic
                ? "الفريق وسجل العمليات الحساسة"
                : "Team and sensitive-operation audit"
              : isArabic
                ? "عمليات ISP ضمن المؤسسة"
                : "ISP operations inside your organization"
          }
          description={
            team
              ? isArabic
                ? "سيظهر هنا سجل لا يمكن ملؤه إلا بإجراءات مستخدم موثقة."
                : "Only documented user actions appear here."
              : isArabic
                ? "أضف المشتركين والمواقع وPOP والأجهزة والتذاكر التي تملكها مؤسستك. لا توجد سجلات تمهيدية."
                : "Add subscribers, sites, POPs, devices, and tickets owned by your organization. There are no seeded records."
          }
          action={
            !team ? (
              <div className="quick-actions">
                <button
                  className="action-button"
                  onClick={() => setKind("subscriber")}
                >
                  <UserRound size={14} />
                  {isArabic ? "مشترك" : "Subscriber"}
                </button>
                <button
                  className="action-button"
                  onClick={() => setKind("site")}
                >
                  <Building2 size={14} />
                  {isArabic ? "موقع" : "Site"}
                </button>
                <button
                  className="action-button"
                  onClick={() => setKind("pop")}
                >
                  <Cable size={14} />
                  POP
                </button>
                <button
                  className="action-button"
                  onClick={() => setKind("device")}
                >
                  <Cable size={14} />
                  {isArabic ? "جهاز" : "Device"}
                </button>
                <button
                  className="action-button primary"
                  onClick={() => setKind("ticket")}
                >
                  <ClipboardList size={14} />
                  {isArabic ? "تذكرة" : "Ticket"}
                </button>
              </div>
            ) : undefined
          }
        />
        {kind && (
          <section className="data-panel inline-form">
            <div className="panel-header">
              <h3>
                {isArabic ? "سجل جديد" : "New record"} — {kind}
              </h3>
            </div>
            <div className="field-grid">
              <label>
                {isArabic ? "الاسم / العنوان" : "Name / title"}
                <input
                  value={form.name || ""}
                  onChange={event =>
                    setForm({ ...form, name: event.target.value })
                  }
                />
              </label>
              {kind !== "ticket" && (
                <label>
                  {kind === "subscriber"
                    ? isArabic
                      ? "مرجع المشترك"
                      : "Subscriber reference"
                    : kind === "pop"
                      ? isArabic
                        ? "رمز POP"
                        : "POP code"
                      : isArabic
                        ? "النوع"
                        : "Type"}
                  <input
                    value={
                      kind === "subscriber"
                        ? form.reference || ""
                        : form.type || ""
                    }
                    onChange={event =>
                      setForm({
                        ...form,
                        [kind === "subscriber" ? "reference" : "type"]:
                          event.target.value,
                      })
                    }
                  />
                </label>
              )}
              {kind === "ticket" && (
                <label>
                  {isArabic ? "الخطورة" : "Severity"}
                  <select
                    value={form.severity || "medium"}
                    onChange={event =>
                      setForm({ ...form, severity: event.target.value })
                    }
                  >
                    <option value="low">low</option>
                    <option value="medium">medium</option>
                    <option value="high">high</option>
                    <option value="critical">critical</option>
                  </select>
                </label>
              )}
              {(kind === "site" || kind === "pop" || kind === "device") && (
                <label>
                  {isArabic
                    ? "مرجع إداري/موقع (اختياري)"
                    : "Management/location reference (optional)"}
                  <input
                    value={form.reference || ""}
                    onChange={event =>
                      setForm({ ...form, reference: event.target.value })
                    }
                  />
                </label>
              )}
            </div>
            <button className="action-button primary" onClick={save}>
              <Plus size={14} />
              {t("save")}
            </button>
          </section>
        )}
        {!team && (
          <label className="ops-ticket-search">
            <Search size={14} />
            <input
              value={ticketSearch}
              onChange={event => setTicketSearch(event.target.value)}
              placeholder={
                isArabic ? "ابحث في التذاكر المحفوظة" : "Search stored tickets"
              }
            />
            <span>{filteredTickets.length}</span>
          </label>
        )}
        {team ? (
          <section className="ops-grid">
            <article className="data-panel ops-panel">
              <div className="panel-header">
                <h3>{isArabic ? "سجل التدقيق" : "Audit log"}</h3>
                <span>IMMUTABLE RECORD</span>
              </div>
              {overview.isLoading ? (
                <div className="panel-loading">{t("loading")}</div>
              ) : audit.length ? (
                <div className="audit-list">
                  {audit.map(item => (
                    <article key={item.id}>
                      <b>{item.action}</b>
                      <span>
                        {item.entityType} #{item.entityId || "—"}
                      </span>
                      <small>
                        {new Date(item.createdAt).toLocaleString(
                          isArabic ? "ar" : "en"
                        )}
                      </small>
                    </article>
                  ))}
                </div>
              ) : (
                <EmptyState
                  title={t("noData")}
                  copy={
                    isArabic
                      ? "عند حفظ اختبار أو إضافة سجل أو تحديث ملف مراقبة، يظهر أثر العملية هنا."
                      : "When a test is saved, a record is added, or a monitoring profile changes, its audit trace appears here."
                  }
                />
              )}
            </article>
          </section>
        ) : (
          <>
            <section className="ops-grid">
              <OpsPanel
                icon={<UserRound />}
                title={isArabic ? "المشتركون" : "Subscribers"}
                data={overview.data?.subscribers || []}
                empty={
                  isArabic
                    ? "أضف المشتركين المعتمدين لديك."
                    : "Add your authorized subscribers."
                }
              />
              <OpsPanel
                icon={<Building2 />}
                title={isArabic ? "المواقع" : "Sites"}
                data={overview.data?.sites || []}
                empty={
                  isArabic
                    ? "أضف مواقع الشبكة الفعلية."
                    : "Add actual network sites."
                }
              />
              <OpsPanel
                icon={<Cable />}
                title="POP"
                data={overview.data?.pops || []}
                empty={
                  isArabic
                    ? "أضف نقاط الحضور الفعلية."
                    : "Add actual points of presence."
                }
              />
              <OpsPanel
                icon={<Cable />}
                title={isArabic ? "الأجهزة" : "Devices"}
                data={overview.data?.devices || []}
                empty={
                  isArabic
                    ? "أضف أجهزة الشبكة المصرح بها."
                    : "Add authorized network devices."
                }
              />
              <OpsPanel
                icon={<ClipboardList />}
                title={isArabic ? "التذاكر" : "Tickets"}
                data={filteredTickets}
                empty={
                  isArabic
                    ? "لا توجد تذكرة تطابق البحث أو لم تُنشأ تذاكر بعد."
                    : "No ticket matches search or no ticket has been created."
                }
              />
            </section>
            <AttachmentVault />
          </>
        )}
      </div>
    </ZeroGramShell>
  );
}
