import { SectionHeading, ZeroGramShell } from "@/components/ZeroGramShell";
import { useI18n } from "@/lib/i18n";
import { Download, Printer } from "lucide-react";
import { useMemo } from "react";

type Entry = { at: string; score: number | null; latency: number | null };
export default function BrowserReport() {
  const { isArabic } = useI18n();
  const history = useMemo<Entry[]>(() => {
    try {
      return JSON.parse(
        localStorage.getItem("zg-browser-quality-history") || "[]"
      );
    } catch {
      return [];
    }
  }, []);
  const report = {
    product: "ZERO GRAM",
    generatedAt: new Date().toISOString(),
    evidencePolicy: "Measured, Detected, Calculated, Estimated, Unavailable",
    browser: {
      userAgent: navigator.userAgent,
      language: navigator.language,
      online: navigator.onLine,
      viewport: `${innerWidth}x${innerHeight}`,
      protocol: location.protocol,
    },
    performance: performance.getEntriesByType("navigation")[0] || null,
    localQualityHistory: history,
    limitations: [
      "Browser sandbox may hide TLS, redirects, DNS timing, private IP, MTU, ICMP and equipment details.",
      "Values not exposed by the browser remain Unavailable; no demo data is included.",
    ],
  };
  const download = () => {
    const blob = new Blob([JSON.stringify(report, null, 2)], {
      type: "application/json",
    });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = `zero-gram-browser-report-${Date.now()}.json`;
    anchor.click();
    URL.revokeObjectURL(url);
  };
  return (
    <ZeroGramShell title="ZERO GRAM" eyebrow="ZERO GRAM / BROWSER REPORT">
      <div className="page-content browser-report">
        <SectionHeading
          index="B/04"
          title={isArabic ? "تقرير تشخيص المتصفح" : "Browser diagnostic report"}
          description={
            isArabic
              ? "تقرير قابل للمشاركة يجمع ما قيس أو اكتُشف من هذا المتصفح فقط، ويحتفظ بالقيود بدل إخفائها."
              : "A shareable report of what this browser measured or detected, preserving limitations instead of hiding them."
          }
        />
        <div className="browser-actions">
          <button className="action-button primary" onClick={download}>
            <Download size={15} /> {isArabic ? "تنزيل JSON" : "Download JSON"}
          </button>
          <button className="action-button" onClick={() => window.print()}>
            <Printer size={15} /> {isArabic ? "طباعة / PDF" : "Print / PDF"}
          </button>
        </div>
        <section className="data-panel browser-panel report-preview">
          <header>
            <Download size={18} />
            <div>
              <h3>ZERO GRAM / Browser Intelligence</h3>
              <small>
                {new Date(report.generatedAt).toLocaleString()} ·{" "}
                {history.length} local sessions
              </small>
            </div>
          </header>
          <div className="report-facts">
            <div>
              <b>Evidence</b>
              <span>Measured / Detected / Calculated</span>
            </div>
            <div>
              <b>Browser</b>
              <span>
                {navigator.userAgent.split(" ").slice(-1)[0] || "Not Available"}
              </span>
            </div>
            <div>
              <b>Online</b>
              <span>{navigator.onLine ? "Online" : "Offline"}</span>
            </div>
            <div>
              <b>History</b>
              <span>
                {history.length
                  ? `${history.length} sessions`
                  : "Not Available"}
              </span>
            </div>
          </div>
          <blockquote>
            Only browser-exposed evidence is included. OLT/ONT and private
            network equipment are not queried.
          </blockquote>
        </section>
      </div>
    </ZeroGramShell>
  );
}
