import {
  EmptyState,
  SectionHeading,
  ZeroGramShell,
} from "@/components/ZeroGramShell";
import { useI18n } from "@/lib/i18n";
import { trpc } from "@/lib/trpc";
import {
  Activity,
  Clock3,
  Loader2,
  SlidersHorizontal,
  TrendingDown,
} from "lucide-react";
import { useMemo, useState } from "react";
import {
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";

export default function HistoryTimeline() {
  const { isArabic } = useI18n();
  const overview = trpc.fiber.overview.useQuery();
  const [deviceId, setDeviceId] = useState<number | null>(null);
  const [severity, setSeverity] = useState("");
  const [source, setSource] = useState("");
  const [metric, setMetric] = useState("optical_rx_dbm");
  const timeline = trpc.fiber.timeline.useQuery({
    deviceId: deviceId || undefined,
    severity: (severity as never) || undefined,
    sourceContains: source || undefined,
  });
  const detail = trpc.fiber.deviceDetails.useQuery(
    { deviceId: deviceId || 1, telemetryDays: 90 },
    { enabled: Boolean(deviceId) }
  );
  const devices = overview.data?.devices || [];
  const points = useMemo(
    () =>
      (detail.data?.samples || [])
        .filter(
          sample => sample.metric === metric && sample.valueDouble !== null
        )
        .map(sample => ({
          time: new Date(sample.measuredAt).toLocaleDateString(),
          measuredAt: new Date(sample.measuredAt).getTime(),
          value: sample.valueDouble!,
          source: sample.sourceLabel,
        }))
        .sort((a, b) => a.measuredAt - b.measuredAt),
    [detail.data?.samples, metric]
  );
  const metrics = Array.from(
    new Set(
      (detail.data?.samples || [])
        .filter(sample => sample.valueDouble !== null)
        .map(sample => sample.metric)
    )
  );
  const stats = useMemo(() => {
    if (!points.length) return null;
    const values = points.map(point => point.value);
    const last = points.at(-1)!;
    const previous = points.at(-2) ?? null;
    const first = points[0]!;
    const average =
      values.reduce((sum, value) => sum + value, 0) / values.length;
    return {
      latest: last.value,
      previous: previous?.value ?? null,
      first: first.value,
      min: Math.min(...values),
      max: Math.max(...values),
      average,
      change: last.value - first.value,
      source: last.source,
      count: points.length,
    };
  }, [points]);
  return (
    <ZeroGramShell
      title={isArabic ? "الخط الزمني والتاريخ" : "Timeline & history"}
      eyebrow="ZERO GRAM / TELEMETRY ARCHIVE"
    >
      <div className="page-content history-page">
        <SectionHeading
          index="F/T"
          title={
            isArabic
              ? "الأحداث والقياسات المحفوظة"
              : "Stored events & measurements"
          }
          description={
            isArabic
              ? "تتيح المرشحات قراءة تاريخ السجلات المصدرية؛ لا تحوّل المنصة الحالة المفقودة إلى حدث أو رسم تقديري."
              : "Filters operate on sourced historical records; absent data is never transformed into a synthetic event or chart."
          }
        />
        <section className="data-panel timeline-filters">
          <label>
            {isArabic ? "الجهاز" : "Device"}
            <select
              value={deviceId || ""}
              onChange={event =>
                setDeviceId(Number(event.target.value) || null)
              }
            >
              <option value="">
                {isArabic ? "كل الأجهزة" : "All devices"}
              </option>
              {devices.map(device => (
                <option key={device.id} value={device.id}>
                  {device.label}
                </option>
              ))}
            </select>
          </label>
          <label>
            {isArabic ? "الشدة" : "Severity"}
            <select
              value={severity}
              onChange={event => setSeverity(event.target.value)}
            >
              <option value="">{isArabic ? "الكل" : "All"}</option>
              {["critical", "high", "medium", "low", "informational"].map(
                value => (
                  <option value={value} key={value}>
                    {value}
                  </option>
                )
              )}
            </select>
          </label>
          <label>
            {isArabic ? "المصدر" : "Source"}
            <input
              value={source}
              onChange={event => setSource(event.target.value)}
              placeholder={
                isArabic ? "جزء من اسم المصدر" : "Part of source label"
              }
            />
          </label>
        </section>
        <section className="timeline-layout">
          <article className="data-panel timeline-panel">
            <h3>
              <Clock3 size={16} />
              {isArabic ? "الخط الزمني الموحد" : "Unified timeline"}
            </h3>
            {timeline.isLoading ? (
              <Loader2 className="spin" />
            ) : timeline.data?.length ? (
              timeline.data.map(event => (
                <div
                  className={`timeline-event ${event.severity}`}
                  key={event.id}
                >
                  <b>{event.title}</b>
                  <small>
                    {event.eventType} · {event.sourceLabel} ·{" "}
                    {new Date(event.occurredAt).toLocaleString()}
                  </small>
                </div>
              ))
            ) : (
              <p className="muted">
                {isArabic
                  ? "لا يوجد حدث حقيقي ضمن نطاق المرشحات."
                  : "No real event is available within these filters."}
              </p>
            )}
          </article>
          <article className="data-panel chart-panel">
            <h3>
              <Activity size={16} />
              {isArabic
                ? "رسم القياسات التاريخية"
                : "Historical measurement chart"}
            </h3>
            {deviceId ? (
              <>
                <label className="metric-filter">
                  <SlidersHorizontal size={14} />
                  <select
                    value={metric}
                    onChange={event => setMetric(event.target.value)}
                  >
                    {metrics.map(value => (
                      <option value={value} key={value}>
                        {value}
                      </option>
                    ))}
                  </select>
                </label>
                {stats && (
                  <section className="history-stats">
                    <span>
                      <b>{isArabic ? "الأحدث" : "Latest"}</b>
                      {stats.latest.toFixed(2)}
                    </span>
                    <span>
                      <b>{isArabic ? "السابق" : "Previous"}</b>
                      {stats.previous === null
                        ? "—"
                        : stats.previous.toFixed(2)}
                    </span>
                    <span>
                      <b>{isArabic ? "الحد الأدنى" : "Min"}</b>
                      {stats.min.toFixed(2)}
                    </span>
                    <span>
                      <b>{isArabic ? "المتوسط" : "Average"}</b>
                      {stats.average.toFixed(2)}
                    </span>
                    <span>
                      <b>{isArabic ? "الحد الأعلى" : "Max"}</b>
                      {stats.max.toFixed(2)}
                    </span>
                    <span className={stats.change < 0 ? "down" : ""}>
                      <TrendingDown size={12} />
                      <b>{isArabic ? "التغير" : "Change"}</b>
                      {stats.change >= 0 ? "+" : ""}
                      {stats.change.toFixed(2)}
                    </span>
                    <small>
                      {stats.count} {isArabic ? "عينة" : "samples"} ·{" "}
                      {stats.source}
                    </small>
                  </section>
                )}
                {points.length ? (
                  <div className="history-chart">
                    <ResponsiveContainer width="100%" height={250}>
                      <LineChart data={points}>
                        <XAxis
                          dataKey="time"
                          tick={{ fill: "#7e9eaf", fontSize: 9 }}
                        />
                        <YAxis tick={{ fill: "#7e9eaf", fontSize: 9 }} />
                        <Tooltip />
                        <Line
                          type="monotone"
                          dataKey="value"
                          stroke="#43dbf4"
                          strokeWidth={2}
                          dot={false}
                        />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                ) : (
                  <p className="muted">
                    {isArabic
                      ? "لا توجد عيّنات رقمية لهذا المقياس والجهاز."
                      : "No numeric samples are available for this metric and device."}
                  </p>
                )}
              </>
            ) : (
              <EmptyState
                title={
                  isArabic ? "اختر جهازًا للرسم" : "Select a device to chart"
                }
                copy={
                  isArabic
                    ? "تظهر الرسوم عند وجود قياسات رقمية موثقة فقط."
                    : "Charts appear only when sourced numeric measurements exist."
                }
              />
            )}
          </article>
        </section>
      </div>
    </ZeroGramShell>
  );
}
