import {
  ConsolePreferencesButton,
  useConsolePreferences,
  type VisualMode,
} from "@/components/ConsolePreferences";
import { ZeroGramShell } from "@/components/ZeroGramShell";
import { useI18n } from "@/lib/i18n";
import { RotateCcw, Settings2 } from "lucide-react";
import { toast } from "sonner";

type ToggleKey =
  | "darkMode"
  | "systemTheme"
  | "lowGlare"
  | "compact"
  | "reduceMotion"
  | "scanlines"
  | "glow"
  | "autoRefresh"
  | "focusMode"
  | "showUnits";

export default function Settings() {
  const { isArabic } = useI18n();
  const prefs = useConsolePreferences();
  const toggle = (key: ToggleKey) => {
    if (key === "darkMode") {
      prefs.setPreference("visualMode", "original");
    }
    prefs.setPreference(key, !prefs[key]);
    toast.success(isArabic ? "تم حفظ الإعداد." : "Setting saved.");
  };
  const reset = () => {
    prefs.reset();
    toast.success(isArabic ? "تمت إعادة ضبط الإعدادات." : "Settings reset.");
  };
  const labels: Record<ToggleKey, [string, string]> = {
    darkMode: ["الوضع الداكن", "Dark mode"],
    systemTheme: ["اتباع نظام الجهاز", "Follow system theme"],
    lowGlare: ["توهج منخفض", "Low glare"],
    compact: ["كثافة مدمجة", "Compact density"],
    reduceMotion: ["تقليل الحركة", "Reduce motion"],
    scanlines: ["خطوط المسح", "Scanlines"],
    glow: ["توهج الإشارة", "Signal glow"],
    autoRefresh: ["التحديث التلقائي", "Auto refresh"],
    focusMode: ["وضع التركيز", "Focus mode"],
    showUnits: ["إظهار الوحدات", "Show units"],
  };
  return (
    <ZeroGramShell title={isArabic ? "الإعدادات" : "Settings"} eyebrow="ZERO GRAM / CONFIG">
      <div className="page-content">
        <section className="data-panel settings-panel">
          <header className="panel-header">
            <div>
              <h3>{isArabic ? "إعدادات العرض والتشغيل" : "Display and runtime settings"}</h3>
              <p>{isArabic ? "كل خيار يطبق مباشرة ويحفظ في هذا المتصفح." : "Every option applies immediately and is saved in this browser."}</p>
            </div>
            <div className="settings-actions">
              <ConsolePreferencesButton />
              <button className="action-button" onClick={reset}>
                <RotateCcw size={14} />
                {isArabic ? "إعادة الضبط" : "Reset"}
              </button>
            </div>
          </header>
          <div className="settings-grid">
            {(Object.keys(labels) as ToggleKey[]).map(key => (
              <button
                key={key}
                className={`settings-toggle ${prefs[key] ? "on" : ""}`}
                aria-pressed={prefs[key]}
                onClick={() => toggle(key)}
              >
                <span>
                  <Settings2 size={14} />
                  {isArabic ? labels[key][0] : labels[key][1]}
                </span>
                <i />
              </button>
            ))}
          </div>
          <div className="settings-selects">
            <label>
              {isArabic ? "نمط الألوان" : "Color mode"}
              <select
                value={prefs.visualMode}
                onChange={e =>
                  prefs.setPreference("visualMode", e.target.value as VisualMode)
                }
              >
                <option value="original">{isArabic ? "الأصلي" : "Original"}</option>
                <option value="color">{isArabic ? "ألوان حيوية" : "Vivid color"}</option>
                <option value="white">{isArabic ? "أبيض" : "White"}</option>
                <option value="black">{isArabic ? "أسود" : "Black"}</option>
              </select>
            </label>
            <label>
              {isArabic ? "حجم الخط" : "Font scale"}
              <select value={prefs.fontScale} onChange={e => prefs.setPreference("fontScale", e.target.value as "small" | "normal" | "large")}>
                <option value="small">{isArabic ? "صغير" : "Small"}</option>
                <option value="normal">{isArabic ? "عادي" : "Normal"}</option>
                <option value="large">{isArabic ? "كبير" : "Large"}</option>
              </select>
            </label>
            <label>
              {isArabic ? "الزمن" : "Time display"}
              <select value={prefs.timeMode} onChange={e => prefs.setPreference("timeMode", e.target.value as "local" | "utc")}>
                <option value="local">{isArabic ? "محلي" : "Local"}</option>
                <option value="utc">UTC</option>
              </select>
            </label>
          </div>
          <p className="settings-note">
            {isArabic
              ? "لا يتغير مصدر قياسات الشبكة بهذه الإعدادات؛ إنها تتحكم في العرض وسلوك التحديث فقط."
              : "These settings do not alter network measurement sources; they control presentation and refresh behavior only."}
          </p>
        </section>
      </div>
    </ZeroGramShell>
  );
}
