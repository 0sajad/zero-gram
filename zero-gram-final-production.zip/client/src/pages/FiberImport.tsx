import {
  EmptyState,
  SectionHeading,
  ZeroGramShell,
} from "@/components/ZeroGramShell";
import { useI18n } from "@/lib/i18n";
import { trpc } from "@/lib/trpc";
import {
  ArrowRight,
  CheckCircle2,
  FileUp,
  Loader2,
  ShieldCheck,
} from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

const splitCsv = (text: string) => {
  const lines = text.split(/\r?\n/).filter(Boolean);
  if (lines.length < 2) return [];
  const split = (line: string) => {
    const values: string[] = [];
    let value = "";
    let quote = false;
    for (let index = 0; index < line.length; index++) {
      const char = line[index]!;
      if (char === '"') {
        if (quote && line[index + 1] === '"') {
          value += '"';
          index++;
        } else quote = !quote;
      } else if (char === "," && !quote) {
        values.push(value.trim());
        value = "";
      } else value += char;
    }
    values.push(value.trim());
    return values;
  };
  const headers = split(lines[0]!);
  return lines
    .slice(1)
    .map(line =>
      Object.fromEntries(
        headers.map((header, index) => [header, split(line)[index] || ""])
      )
    );
};

export default function FiberImport() {
  const { isArabic } = useI18n();
  const [summary, setSummary] = useState<{
    devices: number;
    telemetry: number;
  } | null>(null);
  const importMutation = trpc.fiber.importDeviceTelemetry.useMutation({
    onSuccess: result => {
      toast.success(
        isArabic
          ? `اكتمل الاستيراد: قبول ${result.accepted} ورفض ${result.rejected}.`
          : `Import complete: ${result.accepted} accepted, ${result.rejected} rejected.`
      );
    },
  });
  const importFile = async (file: File) => {
    try {
      const text = await file.text();
      const raw = file.name.toLowerCase().endsWith(".json")
        ? JSON.parse(text)
        : splitCsv(text);
      const rows = Array.isArray(raw)
        ? raw
        : Array.isArray(raw.records)
          ? raw.records
          : [];
      const source = `Import: ${file.name}`;
      const devices = (
        Array.isArray(raw.devices)
          ? raw.devices
          : rows.filter((row: any) => (row.recordType || row.kind) === "device")
      )
        .map((row: any) => ({
          label: String(row.label || row.deviceLabel || "").trim(),
          deviceType: String(row.deviceType || row.assetType || "ont").trim(),
          vendor: row.vendor || undefined,
          model: row.model || undefined,
          serialNumber: row.serialNumber || row.serial || undefined,
          macAddress: row.macAddress || row.mac || undefined,
          hostname: row.hostname || undefined,
          managementIpv4: row.managementIpv4 || row.ipv4 || undefined,
          managementIpv6: row.managementIpv6 || row.ipv6 || undefined,
          firmwareVersion: row.firmwareVersion || row.firmware || undefined,
          sourceLabel: row.sourceLabel || source,
          sourceObservedAt: row.sourceObservedAt
            ? new Date(row.sourceObservedAt)
            : new Date(),
        }))
        .filter((row: any) => row.label.length >= 2);
      const telemetry = (
        Array.isArray(raw.telemetry)
          ? raw.telemetry
          : rows.filter(
              (row: any) => (row.recordType || row.kind) === "telemetry"
            )
      )
        .map((row: any) => ({
          deviceLabel: String(row.deviceLabel || row.label || "").trim(),
          metric: String(row.metric || "").trim(),
          valueDouble:
            row.valueDouble !== undefined && row.valueDouble !== ""
              ? Number(row.valueDouble)
              : row.value !== undefined && row.value !== ""
                ? Number(row.value)
                : undefined,
          valueText: row.valueText || undefined,
          unit: row.unit || undefined,
          state: row.state || undefined,
          sourceLabel: row.sourceLabel || source,
          measuredAt: row.measuredAt ? new Date(row.measuredAt) : new Date(),
        }))
        .filter(
          (row: any) =>
            row.deviceLabel.length >= 2 &&
            row.metric.length >= 2 &&
            (Number.isFinite(row.valueDouble) || row.valueText)
        );
      setSummary({ devices: devices.length, telemetry: telemetry.length });
      if (!devices.length && !telemetry.length) {
        toast.error(
          isArabic
            ? "لم نعثر على سجلات صالحة. راجع هيكل الملف أدناه."
            : "No valid records were found. Review the expected structure below."
        );
        return;
      }
      importMutation.mutate({
        sourceName: file.name,
        sourceType: file.name.toLowerCase().endsWith(".json") ? "json" : "csv",
        devices,
        telemetry,
      });
    } catch {
      toast.error(
        isArabic
          ? "تعذر تحليل الملف. تأكد من أنه JSON أو CSV سليم."
          : "The file could not be parsed. Ensure it is valid JSON or CSV."
      );
    }
  };
  return (
    <ZeroGramShell
      title={isArabic ? "استيراد بيانات الألياف" : "Fiber data import"}
      eyebrow="ZERO GRAM / SOURCE GATE"
    >
      <div className="page-content import-page">
        <SectionHeading
          index="F/IMP"
          title={
            isArabic ? "بوابة السجلات اليدوية" : "Manual source-record gateway"
          }
          description={
            isArabic
              ? "تعتمد ZERO GRAM هنا على إدخال أو استيراد يدويين فقط من المؤسسة. لا يوجد ربط مباشر أو مفاتيح وصول أو قراءة آلية من OLT/ONT؛ يحتفظ النظام باسم الملف ومصدر وتوقيت كل سجل."
              : "ZERO GRAM here relies only on organization-provided manual entry or file import. There is no direct connection, credential or automated OLT/ONT reading; every record retains its file, source and time."
          }
        />
        <section className="manual-only-banner">
          <ShieldCheck size={16} />
          <span>
            {isArabic
              ? "وضع الإدخال اليدوي فقط: استخدم تصديرًا موثقًا أو قراءات ميدانية موقّعة؛ لا تقبل المنصة أي قياس متخيل."
              : "Manual-input-only mode: use a documented export or signed field reading; the platform accepts no inferred measurement."}
          </span>
        </section>
        <section className="data-panel import-drop">
          <FileUp size={33} />
          <h2>
            {isArabic ? "اختر ملف CSV أو JSON" : "Choose a CSV or JSON file"}
          </h2>
          <p>
            {isArabic
              ? "يتحقق النظام من الحقول قبل الحفظ ويعرض عدد السجلات المقبولة والمرفوضة."
              : "The system validates fields before storage and returns accepted and rejected record counts."}
          </p>
          <label className="action-button primary">
            <FileUp size={15} />
            {importMutation.isPending
              ? isArabic
                ? "جارٍ الاستيراد…"
                : "Importing…"
              : isArabic
                ? "اختيار ملف"
                : "Choose file"}
            <input
              hidden
              type="file"
              accept=".csv,.json,text/csv,application/json"
              disabled={importMutation.isPending}
              onChange={event => {
                const file = event.target.files?.[0];
                if (file) void importFile(file);
                event.currentTarget.value = "";
              }}
            />
          </label>
          {summary && (
            <div className="import-summary">
              <CheckCircle2 size={16} />
              <span>
                {summary.devices} {isArabic ? "جهاز" : "devices"}
              </span>
              <span>
                {summary.telemetry} {isArabic ? "قراءة" : "telemetry samples"}
              </span>
            </div>
          )}
        </section>
        <section className="manual-field-guide">
          <h3>
            {isArabic ? "الحقول اليدوية المقبولة" : "Accepted manual fields"}
          </h3>
          <p>
            <b>Device:</b> label, deviceType, vendor, model, serialNumber,
            macAddress, managementIpv4/Ipv6, hostname, firmwareVersion,
            sourceLabel, sourceObservedAt.
          </p>
          <p>
            <b>Telemetry:</b> deviceLabel, metric, value/valueDouble, valueText,
            unit, state, sourceLabel, measuredAt.
          </p>
          <p>
            {isArabic
              ? "أمثلة metric: optical_rx_dbm، optical_tx_dbm، optical_loss_db، los_state، lof_state، dying_gasp، temperature_c، cpu_percent، jitter_ms، dns_ms، ethernet_crc، wifi_signal_dbm."
              : "Metric examples: optical_rx_dbm, optical_tx_dbm, optical_loss_db, los_state, lof_state, dying_gasp, temperature_c, cpu_percent, jitter_ms, dns_ms, ethernet_crc, wifi_signal_dbm."}
          </p>
        </section>
        <section className="import-contract">
          <article>
            <ShieldCheck size={17} />
            <div>
              <h3>{isArabic ? "هيكل JSON" : "JSON shape"}</h3>
              <pre>{`{
  "devices": [{ "label": "ONT-01", "deviceType": "ont", "sourceLabel": "OLT export" }],
  "telemetry": [{ "deviceLabel": "ONT-01", "metric": "optical_rx_dbm", "value": -22.4, "unit": "dBm", "sourceLabel": "OLT export", "measuredAt": "2026-08-24T10:00:00Z" }]
}`}</pre>
            </div>
          </article>
          <article>
            <ShieldCheck size={17} />
            <div>
              <h3>{isArabic ? "هيكل CSV" : "CSV shape"}</h3>
              <pre>{`recordType,label,deviceType,metric,value,unit,sourceLabel,measuredAt
device,ONT-01,ont,,,,OLT export,
telemetry,ONT-01,,optical_rx_dbm,-22.4,dBm,OLT export,2026-08-24T10:00:00Z`}</pre>
            </div>
          </article>
        </section>
        <a href="/fiber" className="action-button">
          <ArrowRight size={15} />
          {isArabic ? "العودة إلى عمليات الألياف" : "Back to Fiber operations"}
        </a>
      </div>
    </ZeroGramShell>
  );
}
