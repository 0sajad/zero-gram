import {
  EmptyState,
  SectionHeading,
  ZeroGramShell,
} from "@/components/ZeroGramShell";
import { useI18n } from "@/lib/i18n";
import { trpc } from "@/lib/trpc";
import { Cable, DatabaseZap, Loader2, Radio, Save, Wifi } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

export default function InterfaceMonitoring() {
  const { isArabic } = useI18n();
  const overview = trpc.fiber.overview.useQuery();
  const [deviceId, setDeviceId] = useState<number | null>(null);
  const detail = trpc.fiber.deviceDetails.useQuery(
    { deviceId: deviceId || 1, telemetryDays: 30 },
    { enabled: Boolean(deviceId) }
  );
  const utils = trpc.useUtils();
  const refresh = () =>
    deviceId
      ? utils.fiber.deviceDetails.invalidate({ deviceId, telemetryDays: 30 })
      : Promise.resolve();
  const ethernet = trpc.fiber.addEthernetPort.useMutation({
    onSuccess: async () => {
      await refresh();
      toast.success(isArabic ? "حُفظ سجل Ethernet." : "Ethernet record saved.");
    },
  });
  const wifiClient = trpc.fiber.addWifiClient.useMutation({
    onSuccess: async () => {
      await refresh();
      toast.success(
        isArabic ? "حُفظ سجل عميل Wi‑Fi." : "Wi-Fi client record saved."
      );
    },
  });
  const devices = overview.data?.devices || [];
  return (
    <ZeroGramShell
      title={
        isArabic ? "واجهات Ethernet وWi‑Fi" : "Ethernet & Wi‑Fi interfaces"
      }
      eyebrow="ZERO GRAM / ACCESS LAYER"
    >
      <div className="page-content interface-page">
        <SectionHeading
          index="F/IF"
          title={
            isArabic
              ? "عدادات الوصول والعملاء المرتبطون"
              : "Access counters & connected clients"
          }
          description={
            isArabic
              ? "يسجل هذا القسم عدادات ومعلومات مصدرها معداتك. لا يقرأ بطاقة الشبكة أو عملاء Wi‑Fi مباشرة من المتصفح."
              : "This area records counters and details sourced from your equipment. It does not read NIC or Wi‑Fi clients directly from the browser."
          }
        />
        <section className="data-panel interface-selector">
          <label>
            {isArabic ? "اختر جهازًا" : "Select device"}
            <select
              value={deviceId || ""}
              onChange={event =>
                setDeviceId(Number(event.target.value) || null)
              }
            >
              <option value="">—</option>
              {devices.map(device => (
                <option key={device.id} value={device.id}>
                  {device.label} · {device.deviceType}
                </option>
              ))}
            </select>
          </label>
        </section>
        {!deviceId ? (
          <EmptyState
            title={
              isArabic ? "اختر جهازًا من الجرد" : "Select an inventory device"
            }
            copy={
              isArabic
                ? "ستظهر منافذه اللاسلكية والسلكية الحقيقية هنا عند وجودها، ويمكنك إضافة سجل مصدر جديد."
                : "Its sourced wired and wireless records will appear here; you can add a new source record."
            }
          />
        ) : detail.isLoading ? (
          <div className="panel-loading">
            <Loader2 className="spin" />
          </div>
        ) : (
          <section className="interface-grid">
            <form
              className="data-panel interface-form"
              onSubmit={event => {
                event.preventDefault();
                const form = new FormData(event.currentTarget);
                ethernet.mutate({
                  deviceId,
                  label: String(form.get("label") || ""),
                  linkStatus: String(form.get("status") || "") || undefined,
                  negotiatedSpeedMbps: form.get("speed")
                    ? Number(form.get("speed"))
                    : undefined,
                  duplex: String(form.get("duplex") || "") || undefined,
                  rxPackets: form.get("rx")
                    ? Number(form.get("rx"))
                    : undefined,
                  txPackets: form.get("tx")
                    ? Number(form.get("tx"))
                    : undefined,
                  crcErrors: form.get("crc")
                    ? Number(form.get("crc"))
                    : undefined,
                  interfaceErrors: form.get("errors")
                    ? Number(form.get("errors"))
                    : undefined,
                  flappingCount: form.get("flaps")
                    ? Number(form.get("flaps"))
                    : undefined,
                  sourceLabel: String(form.get("source") || ""),
                  observedAt: new Date(),
                });
              }}
            >
              <h3>
                <Cable size={16} />
                Ethernet
              </h3>
              <div className="field-grid">
                <label>
                  {isArabic ? "المنفذ" : "Port"}
                  <input required name="label" />
                </label>
                <label>
                  {isArabic ? "الحالة" : "Link"}
                  <input name="status" />
                </label>
                <label>
                  Mbps
                  <input name="speed" type="number" />
                </label>
                <label>
                  Duplex
                  <input name="duplex" />
                </label>
                <label>
                  RX packets
                  <input name="rx" type="number" />
                </label>
                <label>
                  TX packets
                  <input name="tx" type="number" />
                </label>
                <label>
                  CRC
                  <input name="crc" type="number" />
                </label>
                <label>
                  {isArabic ? "أخطاء" : "Errors"}
                  <input name="errors" type="number" />
                </label>
                <label>
                  {isArabic ? "تذبذب الرابط" : "Link flaps"}
                  <input name="flaps" type="number" />
                </label>
              </div>
              <label>
                {isArabic ? "المصدر" : "Source"}
                <input required name="source" />
              </label>
              <button className="action-button primary">
                <Save size={14} />
                {isArabic ? "حفظ عدادات Ethernet" : "Save Ethernet counters"}
              </button>
              <div className="record-list">
                {detail.data?.ethernet.map(port => (
                  <p key={port.id}>
                    <b>{port.label}</b> · {port.linkStatus || "—"} ·{" "}
                    {port.negotiatedSpeedMbps || "—"} Mbps{" "}
                    <small>
                      RX {port.rxPackets ?? "—"} · TX {port.txPackets ?? "—"} ·
                      CRC {port.crcErrors ?? "—"} · Flaps{" "}
                      {port.flappingCount ?? "—"}
                    </small>
                  </p>
                ))}
              </div>
            </form>
            <form
              className="data-panel interface-form"
              onSubmit={event => {
                event.preventDefault();
                const form = new FormData(event.currentTarget);
                wifiClient.mutate({
                  wifiNetworkId: Number(form.get("wifi")),
                  macAddress: String(form.get("mac") || "") || undefined,
                  ipAddress: String(form.get("ip") || "") || undefined,
                  hostname: String(form.get("host") || "") || undefined,
                  signalDbm: form.get("signal")
                    ? Number(form.get("signal"))
                    : undefined,
                  rxRateMbps: form.get("rx")
                    ? Number(form.get("rx"))
                    : undefined,
                  txRateMbps: form.get("tx")
                    ? Number(form.get("tx"))
                    : undefined,
                  sourceLabel: String(form.get("source") || ""),
                  observedAt: new Date(),
                });
              }}
            >
              <h3>
                <Wifi size={16} />
                Wi‑Fi clients
              </h3>
              {detail.data?.wifi.length ? (
                <>
                  <label>
                    SSID
                    <select required name="wifi" defaultValue="">
                      <option value="" disabled>
                        —
                      </option>
                      {detail.data.wifi.map(network => (
                        <option key={network.id} value={network.id}>
                          {network.ssid} · {network.band || "—"}
                        </option>
                      ))}
                    </select>
                  </label>
                  <div className="field-grid">
                    <label>
                      MAC
                      <input name="mac" />
                    </label>
                    <label>
                      IP
                      <input name="ip" />
                    </label>
                    <label>
                      Hostname
                      <input name="host" />
                    </label>
                    <label>
                      Signal dBm
                      <input name="signal" type="number" step="any" />
                    </label>
                    <label>
                      RX Mbps
                      <input name="rx" type="number" step="any" />
                    </label>
                    <label>
                      TX Mbps
                      <input name="tx" type="number" step="any" />
                    </label>
                  </div>
                  <label>
                    {isArabic ? "المصدر" : "Source"}
                    <input required name="source" />
                  </label>
                  <button className="action-button primary">
                    <Radio size={14} />
                    {isArabic ? "حفظ عميل Wi‑Fi" : "Save Wi‑Fi client"}
                  </button>
                </>
              ) : (
                <p className="muted">
                  {isArabic
                    ? "أضف شبكة Wi‑Fi مصدرها موثقًا أولًا من صفحة الألياف."
                    : "Add a sourced Wi‑Fi network from the Fiber page first."}
                </p>
              )}
            </form>
          </section>
        )}
      </div>
    </ZeroGramShell>
  );
}
