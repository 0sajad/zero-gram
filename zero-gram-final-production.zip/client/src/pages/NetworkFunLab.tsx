import {
  EmptyState,
  SectionHeading,
  ZeroGramShell,
} from "@/components/ZeroGramShell";
import { useI18n } from "@/lib/i18n";
import {
  diagnosis,
  health,
  personality,
  roast,
  ticketFrom,
  type Metrics,
  type Symptom,
} from "../../../shared/networkFunLab";
import {
  Activity,
  Cable,
  ClipboardCheck,
  Gauge,
  HeartPulse,
  RotateCcw,
  Search,
  ShieldAlert,
  Ticket,
  UserRound,
  Wrench,
} from "lucide-react";
import { useMemo, useState } from "react";

type HistoryEntry = {
  at: string;
  score: number | null;
  latency: number | null;
};
const symptomOptions: Array<{ key: Symptom; ar: string; en: string }> = [
  { key: "slow", ar: "الإنترنت بطيء", en: "Internet slow" },
  { key: "offline", ar: "لا يوجد إنترنت", en: "No internet" },
  { key: "high_latency", ar: "Ping مرتفع", en: "High ping" },
  { key: "disconnects", ar: "انقطاعات عشوائية", en: "Random disconnects" },
  { key: "wifi_weak", ar: "Wi‑Fi ضعيف", en: "Wi‑Fi weak" },
  { key: "dns", ar: "مشكلات DNS", en: "DNS problems" },
  {
    key: "below_package",
    ar: "السرعة أقل من الباقة",
    en: "Speed below package",
  },
  {
    key: "stuck_100",
    ar: "السرعة ثابتة عند 100 Mbps",
    en: "Stuck at 100 Mbps",
  },
];

export default function NetworkFunLab() {
  const { isArabic, language } = useI18n();
  const [mode, setMode] = useState<"simple" | "engineer">("simple");
  const [selected, setSelected] = useState<Symptom[]>([]);
  const [ticketText, setTicketText] = useState("");
  const history = useMemo<HistoryEntry[]>(() => {
    try {
      return JSON.parse(
        localStorage.getItem("zg-browser-quality-history") || "[]"
      );
    } catch {
      return [];
    }
  }, []);
  const latest = history[0];
  const metrics: Metrics = {
    latencyMs: latest?.latency ?? null,
    stabilityScore: latest?.score ?? null,
    online: navigator.onLine,
    connectionType:
      (navigator as Navigator & { connection?: { effectiveType?: string } })
        .connection?.effectiveType ?? null,
  };
  const found = diagnosis(selected, metrics);
  const healthResult = health(metrics);
  const ticket = ticketFrom(ticketText, language);
  const noData = !latest && selected.length === 0;
  const toggle = (symptom: Symptom) =>
    setSelected(current =>
      current.includes(symptom)
        ? current.filter(value => value !== symptom)
        : [...current, symptom]
    );
  const latencyText =
    metrics.latencyMs === null || metrics.latencyMs === undefined
      ? "Not Available"
      : `${metrics.latencyMs.toFixed(1)} ms`;
  const qualityText =
    metrics.stabilityScore === null || metrics.stabilityScore === undefined
      ? "Not Available"
      : `${metrics.stabilityScore}/100`;

  return (
    <ZeroGramShell title="ZERO GRAM" eyebrow="ZERO GRAM / NETWORK FUN LAB">
      <div className="page-content fun-lab">
        <SectionHeading
          index="F/01"
          title={isArabic ? "مختبر الشبكة التفاعلي" : "Network Fun Lab"}
          description={
            isArabic
              ? "تحقيقات تقنية مع طبقة خفيفة اختيارية. الأدلة تقاس محليًا أو تُظهر غير متوفر؛ لا تستخدم المحاكاة كسجل حقيقي."
              : "Technical investigations with an optional light layer. Evidence is locally measured or unavailable; simulation never becomes a real record."
          }
        />
        <div className="fun-mode">
          <button
            className={mode === "simple" ? "active" : ""}
            onClick={() => setMode("simple")}
          >
            <UserRound size={14} /> {isArabic ? "الوضع البسيط" : "Simple Mode"}
          </button>
          <button
            className={mode === "engineer" ? "active" : ""}
            onClick={() => setMode("engineer")}
          >
            <Wrench size={14} /> {isArabic ? "وضع المهندس" : "Engineer Mode"}
          </button>
        </div>
        <section className="data-panel fun-hero">
          <header>
            <Search size={18} />
            <div>
              <h3>DIAGNOSE MY INTERNET</h3>
              <small>
                {isArabic
                  ? "اختر الأعراض؛ ستُدمج فقط مع القياسات المحلية المتاحة."
                  : "Select symptoms; they are combined only with available local measurements."}
              </small>
            </div>
          </header>
          <div className="symptom-picker">
            {symptomOptions.map(option => (
              <button
                key={option.key}
                className={selected.includes(option.key) ? "selected" : ""}
                onClick={() => toggle(option.key)}
              >
                {isArabic ? option.ar : option.en}
              </button>
            ))}
          </div>
        </section>
        {noData ? (
          <section className="data-panel browser-panel">
            <EmptyState
              title={
                isArabic
                  ? "لا توجد قياسات محلية بعد"
                  : "No local measurements yet"
              }
              copy={
                isArabic
                  ? "يمكنك اختيار أعراض لاستكشاف فحوص آمنة، أو تشغيل Browser Intelligence للحصول على latency وquality حقيقيين."
                  : "Choose symptoms for safe checks, or run Browser Intelligence for real local latency and quality."
              }
            />
          </section>
        ) : (
          <>
            <div className="fun-grid">
              <section className="data-panel browser-panel">
                <header>
                  <HeartPulse size={18} />
                  <div>
                    <h3>INTERNET HEALTH CHECK</h3>
                    <small>
                      {isArabic
                        ? "من السجل المحلي والمتصفح"
                        : "From local history and browser state"}
                    </small>
                  </div>
                </header>
                <strong className="fun-score">
                  {healthResult.score === null
                    ? "Not Available"
                    : `${healthResult.score} / 100`}
                </strong>
                <p>
                  {healthResult.score === null
                    ? isArabic
                      ? "لا توجد بيانات كافية لحساب الصحة."
                      : "Insufficient evidence to calculate health."
                    : `${healthResult.label} · ${personality(metrics)}`}
                </p>
                <small>
                  {isArabic
                    ? "Network Survival طبقة ترفيهية وليست قياسًا علميًا."
                    : "Network Survival is an entertainment layer, not a scientific measurement."}
                </small>
                <b className="survival">
                  NETWORK SURVIVAL:{" "}
                  {healthResult.survival === null
                    ? "Not Available"
                    : `${healthResult.survival}%`}
                </b>
              </section>
              <section className="data-panel browser-panel">
                <header>
                  <ShieldAlert size={18} />
                  <div>
                    <h3>NETWORK DISASTER LEVEL</h3>
                    <small>
                      {isArabic
                        ? "مشتق من الأدلة المتاحة فقط"
                        : "Derived only from available evidence"}
                    </small>
                  </div>
                </header>
                <strong className="fun-score">
                  {healthResult.disaster === null
                    ? "Not Available"
                    : `LEVEL ${healthResult.disaster}`}
                </strong>
                <p>{healthResult.label}</p>
                <small>
                  {isArabic
                    ? "لا يرفع المستوى غياب القياسات."
                    : "Missing measurements never raise the level."}
                </small>
              </section>
            </div>
            <section className="data-panel browser-panel">
              <header>
                <ClipboardCheck size={18} />
                <div>
                  <h3>WHO IS GUILTY? / NETWORK DETECTIVE</h3>
                  <small>
                    {isArabic
                      ? "احتمالات فنية قابلة للتفسير وليست إدانة نهائية."
                      : "Explainable technical probabilities, never a final conviction."}
                  </small>
                </div>
              </header>
              <div className="suspect-grid">
                {found.suspects.map(suspect => (
                  <article key={suspect.name}>
                    <b>{suspect.name}</b>
                    <strong>{suspect.probability}%</strong>
                    <small>{suspect.reason}</small>
                  </article>
                ))}
              </div>
              <div className="verdict">
                <b>{isArabic ? "الحكم النهائي" : "FINAL VERDICT"}</b>
                <strong>{found.finalVerdict}</strong>
                <span>
                  {isArabic
                    ? `الثقة: ${found.confidence}%`
                    : `Confidence: ${found.confidence}%`}
                </span>
              </div>
            </section>
            <section className="data-panel browser-panel">
              <header>
                <Activity size={18} />
                <div>
                  <h3>INTERNET CRIME SCENE / WHY IS MY INTERNET SLOW?</h3>
                  <small>
                    {isArabic ? "الدليل المتاح فقط" : "Available evidence only"}
                  </small>
                </div>
              </header>
              <div className="evidence-list">
                {found.evidence.map(item => (
                  <article key={item.metric}>
                    <b>{item.metric}</b>
                    <strong>{item.value}</strong>
                    <small>
                      {item.state} · {item.note}
                    </small>
                  </article>
                ))}
              </div>
              <div className="safe-checks">
                <b>{isArabic ? "فحوص مقترحة" : "Recommended checks"}</b>
                {found.checks.map(check => (
                  <span key={check}>{check}</span>
                ))}
              </div>
            </section>
          </>
        )}
        {mode === "engineer" && (
          <section className="data-panel browser-panel engineer-view">
            <header>
              <Gauge size={18} />
              <div>
                <h3>ENGINEER MODE</h3>
                <small>
                  {isArabic
                    ? "بيانات المتصفح التي يمكن الوصول إليها فقط"
                    : "Browser-accessible data only"}
                </small>
              </div>
            </header>
            <div className="evidence-list">
              <article>
                <b>Connection type</b>
                <strong>{metrics.connectionType ?? "Not Available"}</strong>
                <small>Detected · Network Information API</small>
              </article>
              <article>
                <b>Latency</b>
                <strong>{latencyText}</strong>
                <small>
                  {metrics.latencyMs === null || metrics.latencyMs === undefined
                    ? "Unavailable"
                    : "Measured"}{" "}
                  · local browser history
                </small>
              </article>
              <article>
                <b>Quality</b>
                <strong>{qualityText}</strong>
                <small>
                  {metrics.stabilityScore === null ||
                  metrics.stabilityScore === undefined
                    ? "Unavailable"
                    : "Calculated"}{" "}
                  · local browser history
                </small>
              </article>
              <article>
                <b>Online</b>
                <strong>{String(navigator.onLine)}</strong>
                <small>Detected · Navigator API</small>
              </article>
            </div>
          </section>
        )}
        <div className="fun-grid">
          <section className="data-panel browser-panel">
            <header>
              <RotateCcw size={18} />
              <div>
                <h3>SHOULD I RESTART IT?</h3>
                <small>
                  {isArabic
                    ? "إعادة التشغيل قد تخفف عرضًا ولا تثبت السبب."
                    : "Restart may relieve a symptom; it does not prove a cause."}
                </small>
              </div>
            </header>
            <strong>
              {found.confidence >= 45 ? "Possible" : "Insufficient Evidence"}
            </strong>
            <p>
              {isArabic
                ? "تحقق من الحالة وGateway وDNS والواجهة قبل إعادة التشغيل."
                : "Check connection status, gateway, DNS, and interface state before restarting."}
            </p>
          </section>
          <section className="data-panel browser-panel">
            <header>
              <Cable size={18} />
              <div>
                <h3>CABLE DETECTIVE</h3>
                <small>
                  {isArabic
                    ? "يستند إلى عرض 100 Mbps الذي يختاره المستخدم، وليس قراءة NIC مباشرة."
                    : "Uses user-selected 100 Mbps symptom, not direct NIC access."}
                </small>
              </div>
            </header>
            <strong>
              {selected.includes("stuck_100")
                ? isArabic
                  ? "المشتبه الأول: الكابل"
                  : "First suspect: The cable"
                : "Not Available"}
            </strong>
            <p>
              {isArabic
                ? "إذا تفاوضت الواجهة عند 100 Mbps رغم دعم Gigabit، افحص الكابل والموصل والمنفذ وAuto-negotiation."
                : "If an interface negotiates at 100 Mbps despite Gigabit capability, inspect cable, connector, port, and auto-negotiation."}
            </p>
          </section>
        </div>
        <section className="data-panel browser-panel">
          <header>
            <Ticket size={18} />
            <div>
              <h3>TICKET TRANSLATOR / TECHNICAL EXCUSE</h3>
              <small>
                {isArabic
                  ? "يحول الوصف المبسط إلى مسودة فنية مفيدة، لا تذكرة مرسلة تلقائيًا."
                  : "Turns a simple description into a useful technical draft; it does not submit a ticket."}
              </small>
            </div>
          </header>
          <textarea
            value={ticketText}
            onChange={event => setTicketText(event.target.value)}
            placeholder={
              isArabic
                ? "مثال: النت يقطع كل شوي"
                : "Example: internet keeps disconnecting"
            }
          />
          {ticketText && (
            <div className="ticket-draft">
              <b>{ticket.title}</b>
              <p>{ticket.description}</p>
              <small>{ticket.checks.join(" · ")}</small>
            </div>
          )}
        </section>
        <section className="data-panel browser-panel roast">
          <header>
            <Gauge size={18} />
            <div>
              <h3>ROAST MY CONNECTION</h3>
              <small>
                {isArabic
                  ? "اختياري، مهني، ومبني على القياس المتاح."
                  : "Optional, professional, and based on available measurements."}
              </small>
            </div>
          </header>
          <p>{roast(metrics)}</p>
        </section>
      </div>
    </ZeroGramShell>
  );
}
