import {
  EmptyState,
  SectionHeading,
  ZeroGramShell,
} from "@/components/ZeroGramShell";
import { useI18n } from "@/lib/i18n";
import { trpc } from "@/lib/trpc";
import {
  filterDashboardRows,
  type DashboardScoreFilter,
  type DashboardSourceFilter,
  type DashboardTimeFilter,
} from "../../../shared/dashboardFilters";
import {
  canRunManualMonitoring,
  manualMonitoringLabel,
  manualMonitoringStatusLabel,
  type ManualMonitoringState,
} from "../../../shared/manualMonitoring";
import {
  Activity,
  ArrowUp,
  ArrowUpRight,
  BarChart3,
  Copy,
  Database,
  EyeOff,
  FileBarChart,
  FileJson,
  Filter,
  Gauge,
  Pin,
  RefreshCw,
  PinOff,
  RadioTower,
  RotateCcw,
  Search,
  Share2,
  X,
} from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";
import { toast } from "sonner";
import { Link } from "wouter";

const asObject = (value: string) => {
  try {
    return JSON.parse(value) as {
      measurement?: Record<string, unknown>;
      diagnosis?: { netScore?: number };
    };
  } catch {
    return {};
  }
};
type WidgetId = "tests" | "monitors" | "incidents" | "capacity";
type WidgetPref = { id: WidgetId; enabled: boolean; pinned: boolean };
const widgetKey = "zero-gram-dashboard-widgets";
const defaults = (): WidgetPref[] => [
  { id: "tests", enabled: true, pinned: false },
  { id: "monitors", enabled: true, pinned: false },
  { id: "incidents", enabled: true, pinned: false },
  { id: "capacity", enabled: true, pinned: false },
];

export default function Dashboard() {
  const { isArabic, t } = useI18n();
  const history = trpc.network.history.useQuery();
  const monitors = trpc.monitoring.list.useQuery();
  const intelligence = trpc.intelligence.overview.useQuery();
  const utils = trpc.useUtils();
  const measured = history.data || [];
  const [shareUrl, setShareUrl] = useState("");
  const [query, setQuery] = useState("");
  const [filtersOpen, setFiltersOpen] = useState(false);
  const [scoreFilter, setScoreFilter] = useState<DashboardScoreFilter>("all");
  const [sourceFilter, setSourceFilter] = useState<DashboardSourceFilter>("all");
  const [timeFilter, setTimeFilter] = useState<DashboardTimeFilter>("all");
  const [monitorStates, setMonitorStates] = useState<
    Record<number, ManualMonitoringState>
  >({});
  const searchRef = useRef<HTMLInputElement>(null);
  const [widgets, setWidgets] = useState<WidgetPref[]>(() => {
    try {
      const saved = JSON.parse(
        localStorage.getItem(widgetKey) || ""
      ) as WidgetPref[];
      return saved.length ? saved : defaults();
    } catch {
      return defaults();
    }
  });
  useEffect(() => {
    localStorage.setItem(widgetKey, JSON.stringify(widgets));
  }, [widgets]);
  useEffect(() => {
    if (sessionStorage.getItem("zg-focus-dashboard-search") === "1") {
      sessionStorage.removeItem("zg-focus-dashboard-search");
      window.setTimeout(() => searchRef.current?.focus(), 0);
    }
  }, []);
  const filtered = useMemo(
    () =>
      filterDashboardRows(measured, {
        query,
        scoreFilter,
        sourceFilter,
        timeFilter,
      }),
    [measured, query, scoreFilter, sourceFilter, timeFilter]
  );
  const clearFilters = () => {
    setQuery("");
    setScoreFilter("all");
    setSourceFilter("all");
    setTimeFilter("all");
  };
  const runMonitor = trpc.monitoring.runNow.useMutation({
    onMutate: input => {
      setMonitorStates(current => ({ ...current, [input.profileId]: "running" }));
    },
    onSuccess: (event, input) => {
      const state: ManualMonitoringState =
        event.state === "success" ? "success" : "failure";
      setMonitorStates(current => ({ ...current, [input.profileId]: state }));
      void utils.monitoring.list.invalidate();
      toast[state === "success" ? "success" : "warning"](
        state === "success"
          ? isArabic
            ? "اكتمل فحص المراقبة اليدوي."
            : "Manual monitoring check completed."
          : isArabic
            ? "اكتمل الفحص وسُجلت حالة فشل."
            : "Check completed with a recorded failure."
      );
    },
    onError: (error, input) => {
      if (input)
        setMonitorStates(current => ({ ...current, [input.profileId]: "failure" }));
      toast.error(error.message);
    },
  });
  const share = trpc.network.createShare.useMutation({
    onSuccess: result => {
      setShareUrl(result.shareUrl);
      toast.success(
        isArabic
          ? "أُنشئ رابط مشاركة قابل للتتبع."
          : "A traceable sharing link was created."
      );
    },
    onError: error => toast.error(error.message),
  });
  const copy = (value: string, message: string) => {
    navigator.clipboard.writeText(value);
    toast.success(message);
  };
  const move = (index: number, direction: -1 | 1) =>
    setWidgets(current => {
      const next = [...current];
      const target = index + direction;
      if (target < 0 || target >= next.length) return current;
      [next[index], next[target]] = [next[target], next[index]];
      return next;
    });
  const update = (id: WidgetId, patch: Partial<WidgetPref>) =>
    setWidgets(current =>
      current.map(widget =>
        widget.id === id ? { ...widget, ...patch } : widget
      )
    );
  const reset = () => setWidgets(defaults());
  const widgetData: Record<
    WidgetId,
    {
      label: string;
      detail: string;
      value: string | number;
      href: string;
      icon: React.ReactNode;
    }
  > = {
    tests: {
      label: isArabic ? "نتائج محفوظة" : "Saved results",
      detail: isArabic
        ? "من جلسات قياس فعلية"
        : "from actual measurement sessions",
      value: history.isLoading ? "—" : measured.length,
      href: "/test",
      icon: <Activity />,
    },
    monitors: {
      label: isArabic ? "ملفات مراقبة" : "Monitoring profiles",
      detail: isArabic ? "وجهات أضافها المستخدم" : "user-added targets",
      value: monitors.isLoading ? "—" : monitors.data?.length || 0,
      href: "/monitoring",
      icon: <RadioTower />,
    },
    incidents: {
      label: isArabic ? "حوادث مفتوحة" : "Open incidents",
      detail: isArabic ? "من السجل التشغيلي" : "from operations records",
      value: intelligence.data?.activeIncidentCount ?? "—",
      href: "/intelligence",
      icon: <BarChart3 />,
    },
    capacity: {
      label: isArabic ? "استخدام السعة" : "Capacity utilization",
      detail: isArabic
        ? "من لقطات سعة موثقة"
        : "from sourced capacity snapshots",
      value:
        intelligence.data?.capacity.utilizationPercent === undefined
          ? "—"
          : `${intelligence.data.capacity.utilizationPercent.toFixed(1)}%`,
      href: "/network-context",
      icon: <Gauge />,
    },
  };
  return (
    <ZeroGramShell title={t("dashboard")} eyebrow="ZERO GRAM / PERSONAL SPACE">
      <div className="page-content">
        <SectionHeading
          index="00"
          title={isArabic ? "سجل قابل للتتبع" : "Traceable record"}
          description={
            isArabic
              ? "هذه المساحة لا تملأ نفسها ببيانات عرض. ستظهر نتائجك المحفوظة وملفات المراقبة الفعلية فقط."
              : "This space never fills itself with display data. Only your saved results and actual monitoring profiles appear here."
          }
        />
        <section className="widget-board">
          <header>
            <div>
              <Gauge size={16} />
              <b>{isArabic ? "لوحة Widgets" : "Widget board"}</b>
              <small>
                {isArabic
                  ? "الترتيب والتثبيت والإخفاء محفوظة محليًا"
                  : "Order, pinning, and hiding are saved locally"}
              </small>
            </div>
            <button className="action-button" onClick={reset}>
              <RotateCcw size={14} />
              {isArabic ? "إعادة ضبط" : "Reset"}
            </button>
          </header>
          <div className="widget-grid">
            {widgets
              .filter(widget => widget.enabled)
              .map((widget, index) => {
                const item = widgetData[widget.id];
                return (
                  <article
                    className={widget.pinned ? "pinned" : ""}
                    key={widget.id}
                  >
                    <Link href={item.href} className="widget-value">
                      <span>
                        {item.icon}
                        {item.label}
                      </span>
                      <b>{item.value}</b>
                      <small>{item.detail}</small>
                      <ArrowUpRight size={14} />
                    </Link>
                    <div className="widget-controls">
                      <button
                        aria-label="Move widget up"
                        disabled={!index}
                        onClick={() => move(index, -1)}
                      >
                        <ArrowUp size={13} />
                      </button>
                      <button
                        aria-label="Move widget down"
                        disabled={
                          index ===
                          widgets.filter(row => row.enabled).length - 1
                        }
                        onClick={() => move(index, 1)}
                      >
                        <ArrowUp className="turn" size={13} />
                      </button>
                      <button
                        aria-label="Pin widget"
                        onClick={() =>
                          update(widget.id, { pinned: !widget.pinned })
                        }
                      >
                        {widget.pinned ? (
                          <PinOff size={13} />
                        ) : (
                          <Pin size={13} />
                        )}
                      </button>
                      <button
                        aria-label="Hide widget"
                        onClick={() => update(widget.id, { enabled: false })}
                      >
                        <EyeOff size={13} />
                      </button>
                    </div>
                  </article>
                );
              })}
          </div>
          {widgets.some(widget => !widget.enabled) && (
            <div className="hidden-widgets">
              {widgets
                .filter(widget => !widget.enabled)
                .map(widget => (
                  <button
                    key={widget.id}
                    onClick={() => update(widget.id, { enabled: true })}
                  >
                    + {widgetData[widget.id].label}
                  </button>
                ))}
            </div>
          )}
        </section>
        <section className="data-panel dashboard-monitor-panel">
          <div className="panel-header">
            <div>
              <h3>{isArabic ? "تشغيل المراقبة يدويًا" : "Run monitoring manually"}</h3>
              <small>
                {isArabic
                  ? "شغّل فحصًا فوريًا لأي وجهة محفوظة دون انتظار Cron."
                  : "Run an immediate check for any saved target without waiting for Cron."}
              </small>
            </div>
            <Link href="/monitoring">
              {isArabic ? "إدارة الوجهات" : "Manage targets"}
            </Link>
          </div>
          {monitors.isLoading ? (
            <div className="panel-loading">{t("loading")}</div>
          ) : monitors.data?.length ? (
            <div className="dashboard-monitor-list">
              {monitors.data.map(profile => {
                const state = monitorStates[profile.id] || "idle";
                const actionState: ManualMonitoringState =
                  state === "running" || runMonitor.isPending ? "running" : "idle";
                return (
                  <article key={profile.id}>
                    <div>
                      <b>{profile.label}</b>
                      <small dir="ltr">{profile.targetUrl}</small>
                    </div>
                    <span
                      className={`monitor-state ${state}`}
                      aria-live="polite"
                    >
                      <i aria-hidden="true" />
                      {manualMonitoringStatusLabel(state, isArabic)}
                    </span>
                    <button
                      className="action-button primary"
                      onClick={() => runMonitor.mutate({ profileId: profile.id })}
                      disabled={
                        !canRunManualMonitoring(
                          profile.id,
                          actionState,
                          runMonitor.isPending
                        )
                      }
                    >
                      <RefreshCw className={state === "running" ? "spin" : ""} size={14} />
                      {manualMonitoringLabel(actionState, isArabic)}
                    </button>
                  </article>
                );
              })}
            </div>
          ) : (
            <EmptyState
              title={isArabic ? "لا توجد وجهات مراقبة" : "No monitoring targets"}
              copy={
                isArabic
                  ? "أضف وجهة أولًا ثم شغّل فحصها يدويًا من هذه اللوحة."
                  : "Add a target first, then run its check manually from this dashboard."
              }
              action={
                <Link href="/monitoring" className="action-button primary">
                  {isArabic ? "إضافة وجهة" : "Add target"}
                </Link>
              }
            />
          )}
        </section>
        <section className="data-panel history-panel">
          <div className="panel-header">
            <h3>{isArabic ? "أحدث نتائج الفحص" : "Latest test results"}</h3>
            <Link href="/reports">
              {isArabic ? "عرض التقارير" : "View reports"}
            </Link>
          </div>
          <div className="dashboard-search-stack dashboard-search-always-visible">
            <div className="dashboard-search-row">
              <label className="history-search">
                <Search size={14} />
                <input ref={searchRef} value={query} onChange={event => setQuery(event.target.value)} placeholder={isArabic ? "ابحث بالمرجع أو IP أو MAC أو تفاصيل النتيجة" : "Search reference, IP, MAC, or result details"} />
                <span>{filtered.length}</span>
              </label>
              <button className={filtersOpen ? "action-button primary" : "action-button"} onClick={() => setFiltersOpen(current => !current)} aria-expanded={filtersOpen}>
                <Filter size={14} />
                {isArabic ? "فلاتر متقدمة" : "Advanced filters"}
              </button>
              {(query || scoreFilter !== "all" || sourceFilter !== "all" || timeFilter !== "all") && (
                <button className="icon-button" onClick={clearFilters} aria-label={isArabic ? "مسح الفلاتر" : "Clear filters"} title={isArabic ? "مسح الفلاتر" : "Clear filters"}>
                  <X size={15} />
                </button>
              )}
            </div>
            {filtersOpen && (
              <div className="dashboard-filter-panel" role="region" aria-label={isArabic ? "الفلاتر المتقدمة" : "Advanced filters"}>
                <label><span>{isArabic ? "مصدر النتيجة" : "Result source"}</span><select value={sourceFilter} onChange={event => setSourceFilter(event.target.value as DashboardSourceFilter)}><option value="all">{isArabic ? "كل النتائج" : "All results"}</option><option value="scored">{isArabic ? "نتائج مع NetScore" : "With NetScore"}</option><option value="raw">{isArabic ? "نتائج دون NetScore" : "Without NetScore"}</option></select></label>
                <label><span>{isArabic ? "نطاق NetScore" : "NetScore range"}</span><select value={scoreFilter} onChange={event => setScoreFilter(event.target.value as DashboardScoreFilter)}><option value="all">{isArabic ? "كل المستويات" : "All levels"}</option><option value="strong">{isArabic ? "قوي 80–100" : "Strong 80–100"}</option><option value="watch">{isArabic ? "مراقبة 50–79" : "Watch 50–79"}</option><option value="critical">{isArabic ? "حرج أقل من 50" : "Critical below 50"}</option></select></label>
                <label><span>{isArabic ? "الفترة الزمنية" : "Time window"}</span><select value={timeFilter} onChange={event => setTimeFilter(event.target.value as DashboardTimeFilter)}><option value="all">{isArabic ? "كل الفترات" : "Any time"}</option><option value="7">{isArabic ? "آخر 7 أيام" : "Last 7 days"}</option><option value="30">{isArabic ? "آخر 30 يومًا" : "Last 30 days"}</option><option value="90">{isArabic ? "آخر 90 يومًا" : "Last 90 days"}</option></select></label>
                <button className="filter-clear-button" onClick={clearFilters}>{isArabic ? "مسح كل الفلاتر" : "Clear all filters"}</button>
              </div>
            )}
          </div>
          {history.isLoading ? (
            <div className="panel-loading">{t("loading")}</div>
          ) : measured.length ? (
            <>
              <div className="history-table">
                {filtered.map(row => {
                  const value = asObject(row.payloadJson);
                  const reference = `RESULT-${String(row.id).padStart(6, "0")}`;
                  return (
                    <article key={row.id}>
                      <span className="metric-value">
                        #{String(row.id).padStart(4, "0")}
                      </span>
                      <div>
                        <b>
                          {value.diagnosis?.netScore !== undefined
                            ? `NetScore ${value.diagnosis.netScore}/100`
                            : isArabic
                              ? "نتيجة بلا NetScore"
                              : "Result without NetScore"}
                        </b>
                        <small>
                          {new Date(row.createdAt).toLocaleString(
                            isArabic ? "ar" : "en"
                          )}
                        </small>
                      </div>
                      <div className="row-metrics">
                        {typeof value.measurement?.downloadMbps === "number"
                          ? `${Number(value.measurement.downloadMbps).toFixed(2)} Mbps`
                          : "—"}
                        <span>
                          {isArabic ? "من فحص محفوظ" : "from saved test"}
                        </span>
                      </div>
                      <button
                        className="icon-button"
                        aria-label="Copy result reference"
                        onClick={() =>
                          copy(
                            reference,
                            isArabic
                              ? "نُسخ مرجع النتيجة."
                              : "Result reference copied."
                          )
                        }
                      >
                        <Copy size={14} />
                      </button>
                      <button
                        className="icon-button"
                        aria-label="Copy result JSON"
                        onClick={() =>
                          copy(
                            row.payloadJson,
                            isArabic
                              ? "نُسخ JSON للنتيجة."
                              : "Result JSON copied."
                          )
                        }
                      >
                        <FileJson size={14} />
                      </button>
                      <button
                        className="action-button share-result"
                        onClick={() =>
                          share.mutate({
                            resultId: row.id,
                            origin: window.location.origin,
                          })
                        }
                        disabled={share.isPending}
                      >
                        <Share2 size={14} />
                        {isArabic ? "مشاركة" : "Share"}
                      </button>
                    </article>
                  );
                })}
              </div>
              {!filtered.length && (
                <EmptyState
                  title={
                    isArabic
                      ? "لا تطابق نتيجة البحث"
                      : "No result matches search"
                  }
                  copy={
                    isArabic
                      ? "امسح البحث لإظهار كل السجلات المحفوظة."
                      : "Clear search to display all saved records."
                  }
                />
              )}
            </>
          ) : (
            <EmptyState
              title={t("noData")}
              copy={
                isArabic
                  ? "شغّل فحص الاتصال ثم احفظه هنا لبناء مقارنة زمنية موثقة."
                  : "Run and save a connection test to build a documented time comparison."
              }
              action={
                <Link href="/test" className="action-button primary">
                  <Database size={15} />
                  {t("start")}
                </Link>
              }
            />
          )}
        </section>
        {shareUrl && (
          <div className="share-link-banner">
            <Share2 size={15} />
            <code dir="ltr">{shareUrl}</code>
            <button
              onClick={() =>
                copy(
                  shareUrl,
                  isArabic ? "نُسخ رابط المشاركة." : "Share link copied."
                )
              }
            >
              <Copy size={15} />
            </button>
          </div>
        )}
      </div>
    </ZeroGramShell>
  );
}
