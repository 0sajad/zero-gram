import {
  EmptyState,
  SectionHeading,
  ZeroGramShell,
} from "@/components/ZeroGramShell";
import { useI18n } from "@/lib/i18n";
import { BarChart3, BookOpenCheck, Swords, Trophy } from "lucide-react";
import { useMemo, useState } from "react";

type Entry = { at: string; score: number | null; latency: number | null };
const myths = [
  [
    "More Mbps always means lower ping.",
    "False",
    "Bandwidth and latency are separate characteristics.",
  ],
  [
    "Jitter is only a gaming metric.",
    "False",
    "Variation in timing affects voice, video and other real-time flows.",
  ],
  [
    "Changing DNS increases every download speed.",
    "False",
    "DNS influences name resolution; throughput depends on the transfer path.",
  ],
  [
    "5 GHz always reaches farther than 2.4 GHz.",
    "False",
    "5 GHz usually offers more capacity but commonly less range through obstacles.",
  ],
  [
    "Ethernet at 100 Mbps is always an ISP problem.",
    "False",
    "Cable pairs, port negotiation, and interface capability can limit a local link.",
  ],
  [
    "Fiber makes every Wi‑Fi issue disappear.",
    "False",
    "Fiber may improve the access link while Wi‑Fi remains its own radio environment.",
  ],
  [
    "Packet loss is harmless when browsing looks normal.",
    "False",
    "Small loss can still affect calls, gaming, and retransmission-heavy applications.",
  ],
  [
    "IPv6 and IPv4 are identical in every network.",
    "False",
    "Availability and routing can differ by service and provider.",
  ],
  [
    "A reboot explains the root cause.",
    "False",
    "It may reset a symptom without explaining why it occurred.",
  ],
  [
    "A router location never matters.",
    "False",
    "Placement, walls, and interference can materially affect Wi‑Fi.",
  ],
  [
    "VPN always improves latency.",
    "False",
    "A VPN adds routing and encryption overhead and may help only on specific paths.",
  ],
  [
    "A fast speed test guarantees a fast website.",
    "False",
    "The target server, browser, DNS, and route may still be limiting.",
  ],
];

export default function NetworkPlaybook() {
  const { isArabic } = useI18n();
  const [selected, setSelected] = useState<string[]>([]);
  const history = useMemo<Entry[]>(() => {
    try {
      return JSON.parse(
        localStorage.getItem("zg-browser-quality-history") || "[]"
      );
    } catch {
      return [];
    }
  }, []);
  const chosen = history.filter(entry => selected.includes(entry.at));
  const first = chosen[0];
  const last = chosen.at(-1);
  const scoreDiff =
    first?.score !== null &&
    first?.score !== undefined &&
    last?.score !== null &&
    last?.score !== undefined
      ? last.score - first.score
      : null;
  const latencyDiff =
    first?.latency !== null &&
    first?.latency !== undefined &&
    last?.latency !== null &&
    last?.latency !== undefined &&
    first.latency > 0
      ? ((last.latency - first.latency) / first.latency) * 100
      : null;
  const winner =
    scoreDiff === null
      ? "Not Available"
      : scoreDiff > 0
        ? "Connection B"
        : scoreDiff < 0
          ? "Connection A"
          : "Draw";
  const common =
    history.length < 2
      ? "Not Available"
      : history.filter(item => (item.latency ?? 0) > 120).length >
          history.filter(item => (item.score ?? 100) < 55).length
        ? "High Latency"
        : "Low Quality";
  return (
    <ZeroGramShell title="ZERO GRAM" eyebrow="ZERO GRAM / NETWORK PLAYBOOK">
      <div className="page-content playbook-page">
        <SectionHeading
          index="F/03"
          title={
            isArabic ? "دليل الشبكة التفاعلي" : "Network interactive playbook"
          }
          description={
            isArabic
              ? "حقائق قصيرة ومقارنات زمنية محلية. لا ترفع هذه الصفحة سجل المتصفح ولا تنشئ عينات تجريبية."
              : "Short facts and local time comparisons. This page does not upload browser history or create demo samples."
          }
        />
        <section className="data-panel browser-panel">
          <header>
            <BookOpenCheck size={18} />
            <div>
              <h3>NETWORK MYTHS</h3>
              <small>
                {isArabic
                  ? "محتوى تعليمي ثابت، لا يدّعي قياسًا."
                  : "Educational static content; it does not claim a measurement."}
              </small>
            </div>
          </header>
          <div className="myth-grid">
            {myths.map(([claim, verdict, explanation]) => (
              <article key={claim}>
                <b>{claim}</b>
                <strong>{verdict}</strong>
                <small>{explanation}</small>
              </article>
            ))}
          </div>
        </section>
        <div className="fun-grid">
          <section className="data-panel browser-panel">
            <header>
              <BarChart3 size={18} />
              <div>
                <h3>NETWORK TIME MACHINE</h3>
                <small>
                  {isArabic
                    ? "مقارنة محلية بين أول وآخر جلستين تختارهما."
                    : "Local comparison of the first and last sessions you select."}
                </small>
              </div>
            </header>
            {history.length ? (
              <>
                <div className="playbook-list">
                  {history.map(item => (
                    <label key={item.at}>
                      <input
                        type="checkbox"
                        checked={selected.includes(item.at)}
                        onChange={event =>
                          setSelected(current =>
                            event.target.checked
                              ? [...current, item.at]
                              : current.filter(value => value !== item.at)
                          )
                        }
                      />
                      <b>{item.score ?? "—"}/100</b>
                      <span>
                        {item.latency === null
                          ? "—"
                          : `${item.latency.toFixed(1)} ms`}
                      </span>
                      <small>{item.at}</small>
                    </label>
                  ))}
                </div>
                <p>
                  {latencyDiff === null
                    ? "Select two measured sessions."
                    : `Average latency changed by ${latencyDiff.toFixed(1)}%.`}
                </p>
              </>
            ) : (
              <EmptyState
                title={isArabic ? "لا يوجد تاريخ" : "No history"}
                copy={
                  isArabic
                    ? "شغل Browser Intelligence لإنشاء لقطة حقيقية محليًا."
                    : "Run Browser Intelligence to create a real local snapshot."
                }
              />
            )}
          </section>
          <section className="data-panel browser-panel">
            <header>
              <Swords size={18} />
              <div>
                <h3>NETWORK BATTLE</h3>
                <small>
                  {isArabic
                    ? "المقارنة تستخدم الجلسات المحلية المختارة فقط."
                    : "The comparison uses selected local sessions only."}
                </small>
              </div>
            </header>
            <strong className="fun-score">{winner}</strong>
            <p>
              {scoreDiff === null
                ? "Not Available"
                : `Quality difference: ${scoreDiff > 0 ? "+" : ""}${scoreDiff} points.`}
            </p>
            <small>
              {isArabic
                ? "لا تظهر فائزًا من دون جلستين بمؤشرات فعلية."
                : "No winner appears without two sessions with actual metrics."}
            </small>
          </section>
        </div>
        <section className="data-panel browser-panel">
          <header>
            <Trophy size={18} />
            <div>
              <h3>NOC WALL OF SHAME</h3>
              <small>
                {isArabic
                  ? "تجميع مجهول ومحلي من سجل هذا المتصفح، وليس تحليلاً للخادم."
                  : "Anonymous local aggregation from this browser history, not server analytics."}
              </small>
            </div>
          </header>
          <div className="wall-status">
            <b>{common}</b>
            <span>
              {history.length < 2
                ? isArabic
                  ? "تحتاج جلستين محليتين على الأقل."
                  : "At least two local sessions are required."
                : isArabic
                  ? "أكثر نمط ظاهر في السجل الحالي."
                  : "Most visible pattern in the current local history."}
            </span>
          </div>
        </section>
      </div>
    </ZeroGramShell>
  );
}
