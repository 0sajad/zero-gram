import { SectionHeading, ZeroGramShell } from "@/components/ZeroGramShell";
import { useI18n } from "@/lib/i18n";
import { Database, Eraser, LockKeyhole, ShieldCheck } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

export default function PrivacyDashboard() {
  const { isArabic } = useI18n();
  const [clearedAt, setClearedAt] = useState<string | null>(null);
  const clearLocalData = () => {
    [
      "zg-browser-quality-history",
      "zg-browser-connection-events",
      "zero-gram-dashboard-widgets",
    ].forEach(key => localStorage.removeItem(key));
    setClearedAt(new Date().toLocaleString());
    toast.success(
      isArabic
        ? "تم حذف بيانات المتصفح المحلية."
        : "Local browser data cleared."
    );
  };
  return (
    <ZeroGramShell title="ZERO GRAM" eyebrow="ZERO GRAM / PRIVACY & DATA">
      <div className="page-content privacy-page">
        <SectionHeading
          index="P/01"
          title={isArabic ? "الخصوصية والبيانات" : "Privacy & data"}
          description={
            isArabic
              ? "توضح هذه الصفحة ما يقيسه المتصفح وما يُحفظ محليًا وما لا تستطيع المنصة الوصول إليه. لا تجمع ZERO GRAM معلومات تعريفية غير ضرورية."
              : "This page explains what the browser measures, what stays local, and what the platform cannot access. ZERO GRAM does not collect unnecessary identifying information."
          }
        />
        <div className="privacy-grid">
          <article className="data-panel privacy-card">
            <ShieldCheck />
            <h3>
              {isArabic
                ? "ما يتم جمعه عند التشغيل"
                : "Collected when you run a check"}
            </h3>
            <p>
              {isArabic
                ? "قيم يتيحها المتصفح أو مصدر عام مسموح: حالة الاتصال، قياسات fetch، Network Information API، خصائص شاشة غير حساسة، وهوية عامة عند استجابة المصدر."
                : "Values exposed by the browser or an allowed public source: connectivity state, fetch timing, Network Information API, non-sensitive screen properties, and public identity when the source responds."}
            </p>
          </article>
          <article className="data-panel privacy-card">
            <Database />
            <h3>{isArabic ? "ما يبقى محليًا" : "What stays local"}</h3>
            <p>
              {isArabic
                ? "سجل جودة اللقطات وترتيب Widgets وبعض أحداث المتصفح تُحفظ في localStorage لهذا المتصفح فقط. لا تُستخدم كبيانات معدات."
                : "Snapshot quality history, Widget order, and some browser events are stored in this browser's localStorage only. They are not equipment data."}
            </p>
          </article>
          <article className="data-panel privacy-card">
            <LockKeyhole />
            <h3>{isArabic ? "الخدمات الخارجية" : "External services"}</h3>
            <p>
              {isArabic
                ? "قد تطلب لقطة الهوية استجابة من ipwho.is وipify.org عبر المتصفح. لا توجد مفاتيح API أو تكامل معدات. فشل المصدر يظهر كـ Not Available."
                : "An identity snapshot may request ipwho.is and ipify.org through the browser. There are no API keys or equipment integrations. Source failure appears as Not Available."}
            </p>
          </article>
        </div>
        <section className="data-panel privacy-clear">
          <div>
            <Eraser size={18} />
            <div>
              <h3>{isArabic ? "حذف البيانات المحلية" : "Clear local data"}</h3>
              <p>
                {isArabic
                  ? "يحذف سجل جودة Browser Intelligence وتفضيلات Widgets من هذا المتصفح فقط، ولا يحذف سجلات المؤسسة المحفوظة على الخادم."
                  : "Removes Browser Intelligence quality history and Widget preferences from this browser only; it does not delete organization records stored on the server."}
              </p>
            </div>
          </div>
          <button className="action-button" onClick={clearLocalData}>
            {isArabic ? "Clear Local Data" : "Clear Local Data"}
          </button>
          {clearedAt && (
            <small>
              {isArabic
                ? `آخر حذف: ${clearedAt}`
                : `Last cleared: ${clearedAt}`}
            </small>
          )}
        </section>
        <section className="data-panel privacy-card">
          <h3>{isArabic ? "الصلاحيات والحدود" : "Permissions and limits"}</h3>
          <p>
            {isArabic
              ? "لا تطلب الصفحة الموقع الجغرافي أو البطارية أو كشف IP الداخلي. تظهر القدرات كـ Supported أو Not Supported أو Permission Required أو Unavailable. لا يتجاوز التطبيق Sandbox المتصفح ولا يقرأ OLT/ONT أو SNMP أو DHCP/ARP مباشرة."
              : "This page does not request geolocation, battery, or private IP discovery. Capabilities appear as Supported, Not Supported, Permission Required, or Unavailable. The app never bypasses the browser sandbox or reads OLT/ONT, SNMP, or DHCP/ARP directly."}
          </p>
        </section>
      </div>
    </ZeroGramShell>
  );
}
