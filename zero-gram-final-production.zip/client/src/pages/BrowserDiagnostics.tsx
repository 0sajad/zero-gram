import {
  EmptyState,
  SectionHeading,
  ZeroGramShell,
} from "@/components/ZeroGramShell";
import { useI18n } from "@/lib/i18n";
import {
  Activity,
  CheckCircle2,
  Globe2,
  Info,
  Play,
  Timer,
  XCircle,
} from "lucide-react";
import { useState } from "react";

const withTimeout = async (url: string, ms = 5000) => {
  const controller = new AbortController();
  const timer = window.setTimeout(() => controller.abort(), ms);
  const started = performance.now();
  try {
    const response = await fetch(
      `${url}${url.includes("?") ? "&" : "?"}zg=${Date.now()}`,
      { cache: "no-store", signal: controller.signal, mode: "cors" }
    );
    return {
      ok: response.ok,
      status: response.status,
      ms: performance.now() - started,
    };
  } catch {
    return { ok: false, status: null, ms: null };
  } finally {
    window.clearTimeout(timer);
  }
};

type Result = {
  label: string;
  value: string;
  state: "Measured" | "Calculated" | "Unavailable";
  detail?: string;
};
export default function BrowserDiagnostics() {
  const { isArabic } = useI18n();
  const [results, setResults] = useState<Result[]>([]);
  const [running, setRunning] = useState(false);
  const [duration, setDuration] = useState("30");
  const [target, setTarget] = useState("https://example.com");
  const runFull = async () => {
    setRunning(true);
    const next: Result[] = [];
    const ipv4 = await withTimeout("https://api4.ipify.org?format=json", 4000);
    const ipv6 = await withTimeout("https://api6.ipify.org?format=json", 4000);
    next.push({
      label: "IPv4 connectivity",
      value: ipv4.ok ? "Available" : "Not Available",
      state: ipv4.ok ? "Measured" : "Unavailable",
      detail:
        ipv4.ms === null
          ? "Browser/public endpoint unavailable"
          : `${ipv4.ms.toFixed(1)} ms`,
    });
    next.push({
      label: "IPv6 connectivity",
      value: ipv6.ok ? "Available" : "IPv6 Not Available",
      state: ipv6.ok ? "Measured" : "Unavailable",
      detail:
        ipv6.ms === null
          ? "Browser/public endpoint unavailable"
          : `${ipv6.ms.toFixed(1)} ms`,
    });
    const dnsTargets = [
      {
        label: "Google DNS",
        url: "https://dns.google/resolve?name=example.com&type=A",
      },
      {
        label: "Cloudflare DNS",
        url: "https://cloudflare-dns.com/dns-query?name=example.com&type=A",
      },
    ];
    for (const dns of dnsTargets) {
      const dnsSamples: number[] = [];
      let dnsSuccesses = 0;
      for (let index = 0; index < 3; index++) {
        const response = await withTimeout(dns.url, 5000);
        if (response.ms !== null) dnsSamples.push(response.ms);
        if (response.ok) dnsSuccesses++;
      }
      const dnsAverage = dnsSamples.length
        ? dnsSamples.reduce((sum, value) => sum + value, 0) / dnsSamples.length
        : null;
      next.push({
        label: `${dns.label} resolution`,
        value:
          dnsAverage === null
            ? "Not Available"
            : `${dnsAverage.toFixed(1)} ms avg`,
        state: dnsAverage === null ? "Unavailable" : "Measured",
        detail: `min ${dnsSamples.length ? Math.min(...dnsSamples).toFixed(1) : "—"} / max ${dnsSamples.length ? Math.max(...dnsSamples).toFixed(1) : "—"} / availability ${((dnsSuccesses / 3) * 100).toFixed(0)}% / ${dnsSamples.length ? "source response" : "CORS or endpoint unavailable"}`,
      });
    }
    const stabilitySamples: number[] = [];
    let stabilityAttempts = 0;
    let stabilitySuccesses = 0;
    const started = Date.now();
    const limit = Math.max(1, Math.min(Number(duration), 300));
    while (Date.now() - started < limit * 1000) {
      const response = await withTimeout("/favicon.ico", 3000);
      stabilityAttempts++;
      if (response.ms !== null) stabilitySamples.push(response.ms);
      if (response.ok) stabilitySuccesses++;
      await new Promise(resolve => window.setTimeout(resolve, 500));
    }
    const average = stabilitySamples.length
      ? stabilitySamples.reduce((sum, value) => sum + value, 0) /
        stabilitySamples.length
      : null;
    const minimum = stabilitySamples.length
      ? Math.min(...stabilitySamples)
      : null;
    const maximum = stabilitySamples.length
      ? Math.max(...stabilitySamples)
      : null;
    const jitter =
      stabilitySamples.length > 1
        ? stabilitySamples
            .slice(1)
            .reduce(
              (sum, value, index) =>
                sum + Math.abs(value - stabilitySamples[index]),
              0
            ) /
          (stabilitySamples.length - 1)
        : null;
    const consistency =
      stabilitySamples.length &&
      maximum !== null &&
      minimum !== null &&
      average !== null &&
      average > 0
        ? Math.max(0, 100 - ((maximum - minimum) / average) * 100)
        : null;
    const stabilityScore =
      average === null
        ? null
        : Math.round(
            ((consistency ?? 0) +
              Math.max(0, 100 - (jitter ?? 100) * 2) +
              Math.max(
                0,
                100 -
                  ((stabilityAttempts - stabilitySuccesses) /
                    Math.max(1, stabilityAttempts)) *
                    100
              )) /
              3
          );
    next.push({
      label: "Connection stability",
      value:
        average === null ? "Not Available" : `${average.toFixed(1)} ms average`,
      state: average === null ? "Unavailable" : "Calculated",
      detail: `min ${minimum?.toFixed(1) ?? "—"} / max ${maximum?.toFixed(1) ?? "—"} / jitter ${jitter?.toFixed(1) ?? "—"} / consistency ${consistency?.toFixed(1) ?? "—"} / samples ${stabilitySamples.length}`,
    });
    next.push({
      label: "Stability score",
      value:
        stabilityScore === null ? "Not Available" : `${stabilityScore}/100`,
      state: stabilityScore === null ? "Unavailable" : "Calculated",
      detail:
        "Calculated from measured consistency, jitter, and successful fetch ratio",
    });
    next.push({
      label: "Packet loss",
      value: `${stabilityAttempts ? (((stabilityAttempts - stabilitySuccesses) / stabilityAttempts) * 100).toFixed(1) : "Not Available"}%`,
      state: "Calculated",
      detail: "Fetch samples to this origin; not an ICMP measurement",
    });
    next.push({
      label: "MTU diagnostics",
      value: "Browser Restricted",
      state: "Unavailable",
      detail:
        "Raw packet-size and fragmentation testing is not exposed by the browser security model.",
    });
    const site = await withTimeout(target, 5000);
    next.push({
      label: "Website reachability",
      value:
        site.ms === null
          ? "Not Available"
          : site.ok
            ? "Reachable"
            : "HTTP error",
      state: site.ms === null ? "Unavailable" : "Measured",
      detail:
        site.ms === null
          ? "CORS or browser security restrictions prevented a reliable result."
          : `HTTP ${site.status ?? "—"} / ${site.ms.toFixed(1)} ms; redirects and TLS details may be hidden.`,
    });
    setResults(next);
    setRunning(false);
  };
  return (
    <ZeroGramShell title="ZERO GRAM" eyebrow="ZERO GRAM / BROWSER TEST LAB">
      <div className="page-content browser-lab">
        <SectionHeading
          index="B/02"
          title={isArabic ? "مختبر اختبارات الاتصال" : "Connection test lab"}
          description={
            isArabic
              ? "يشغل فقط ما يسمح به المتصفح: DNS عام، IPv4/IPv6، عينات استقرار fetch، وفحص وجهة يحددها المستخدم. كل نتيجة تحمل حالة وقيودًا."
              : "Runs only what the browser allows: public DNS, IPv4/IPv6, fetch stability samples, and a user-provided destination. Every result carries a state and limitation."
          }
        />
        <section className="data-panel browser-lab-controls">
          <div>
            <label>{isArabic ? "مدة الاستقرار" : "Stability duration"}</label>
            <select
              value={duration}
              onChange={event => setDuration(event.target.value)}
            >
              <option value="30">30 Seconds</option>
              <option value="60">1 Minute</option>
              <option value="300">5 Minutes</option>
            </select>
          </div>
          <div>
            <label>
              {isArabic ? "وجهة مسموحة للفحص" : "Allowed diagnostic URL"}
            </label>
            <input
              value={target}
              onChange={event => setTarget(event.target.value)}
              inputMode="url"
            />
          </div>
          <button
            className="action-button primary"
            onClick={runFull}
            disabled={running}
          >
            {running ? (
              <>
                <Timer className="spin" size={15} />{" "}
                {isArabic ? "جار الاختبار" : "Running"}
              </>
            ) : (
              <>
                <Play size={15} /> RUN FULL DIAGNOSTIC
              </>
            )}
          </button>
        </section>
        <section className="data-panel browser-panel">
          <header>
            <Globe2 size={18} />
            <div>
              <h3>{isArabic ? "اختبارات مصدرية" : "Sourced tests"}</h3>
              <small>
                {isArabic
                  ? "لا تستخدم هذه الأداة ICMP أو MTU خامًا أو قراءة شبكة داخلية"
                  : "This lab does not use ICMP, raw MTU, or private-network discovery"}
              </small>
            </div>
          </header>
          {results.length ? (
            <div className="diagnostic-results">
              {results.map((result, index) => (
                <article key={`${result.label}-${index}`}>
                  <span>
                    {result.state === "Unavailable" ? (
                      <XCircle />
                    ) : (
                      <CheckCircle2 />
                    )}
                  </span>
                  <div>
                    <b>{result.label}</b>
                    <strong>{result.value}</strong>
                    <small>
                      {result.state} · {result.detail}
                    </small>
                  </div>
                </article>
              ))}
            </div>
          ) : (
            <EmptyState
              title={isArabic ? "لم يبدأ الاختبار" : "Test not started"}
              copy={
                isArabic
                  ? "شغّل الاختبار لقياس ما يمكن الوصول إليه من هذا المتصفح فقط."
                  : "Run the lab to measure only what this browser can reach."
              }
            />
          )}
        </section>
        <section className="data-panel browser-panel diagnostic-limit">
          <Info size={17} />
          <p>
            {isArabic
              ? "قد تمنع CORS أو سياسة المتصفح قراءة HTTP Status أو Redirects أو TLS أو DNS timing لوجهات أخرى. عند ذلك تظهر Browser Restricted أو Not Available بدل نتيجة غير موثوقة."
              : "CORS or browser policy may hide HTTP status, redirects, TLS, or DNS timing for other destinations. In that case the lab shows Browser Restricted or Not Available instead of an unreliable result."}
          </p>
        </section>
      </div>
    </ZeroGramShell>
  );
}
