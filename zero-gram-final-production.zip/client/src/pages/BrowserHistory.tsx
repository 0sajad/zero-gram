import {
  EmptyState,
  SectionHeading,
  ZeroGramShell,
} from "@/components/ZeroGramShell";
import { useI18n } from "@/lib/i18n";
import { GitCompare, Trash2 } from "lucide-react";
import { useMemo, useState } from "react";

type Entry = { at: string; score: number | null; latency: number | null };
export default function BrowserHistory() {
  const { isArabic } = useI18n();
  const [range, setRange] = useState("all");
  const [customDate, setCustomDate] = useState("");
  const [selected, setSelected] = useState<string[]>([]);
  const [version, setVersion] = useState(0);
  const entries = useMemo<Entry[]>(() => {
    try {
      return JSON.parse(
        localStorage.getItem("zg-browser-quality-history") || "[]"
      );
    } catch {
      return [];
    }
  }, [version]);
  const filtered = useMemo(() => {
    const cutoff =
      range === "today"
        ? Date.now() - 86400000
        : range === "7"
          ? Date.now() - 7 * 86400000
          : range === "30"
            ? Date.now() - 30 * 86400000
            : range === "custom" && customDate
              ? new Date(customDate).getTime()
              : 0;
    return entries.filter(
      item => !cutoff || new Date(item.at).getTime() >= cutoff
    );
  }, [entries, range, customDate]);
  const selectedEntries = filtered.filter(item => selected.includes(item.at));
  const baseline = selectedEntries[0];
  const current = selectedEntries.at(-1);
  const difference =
    baseline?.score !== null &&
    baseline?.score !== undefined &&
    current?.score !== null &&
    current?.score !== undefined
      ? current.score - baseline.score
      : null;
  const clear = () => {
    localStorage.removeItem("zg-browser-quality-history");
    setVersion(value => value + 1);
    setSelected([]);
  };
  return (
    <ZeroGramShell title="ZERO GRAM" eyebrow="ZERO GRAM / BROWSER HISTORY">
      <div className="page-content browser-history">
        <SectionHeading
          index="B/03"
          title={isArabic ? "تاريخ جودة الاتصال" : "Network quality history"}
          description={
            isArabic
              ? "سجل محلي للقطات المتصفح السابقة فقط. لا يُعرض أي اتجاه أو مقارنة قبل توفر قياسات فعلية."
              : "Local history of browser snapshots only. No trend or comparison appears before actual measurements exist."
          }
        />
        <div className="history-toolbar">
          <select
            value={range}
            onChange={event => setRange(event.target.value)}
          >
            <option value="all">All time</option>
            <option value="today">Today</option>
            <option value="7">7 days</option>
            <option value="30">30 days</option>
            <option value="custom">Custom</option>
          </select>
          {range === "custom" && (
            <input
              type="date"
              value={customDate}
              onChange={event => setCustomDate(event.target.value)}
            />
          )}
          <button className="action-button" onClick={clear}>
            <Trash2 size={14} /> Clear local history
          </button>
        </div>
        {filtered.length ? (
          <>
            <section className="data-panel browser-panel">
              <header>
                <GitCompare size={18} />
                <div>
                  <h3>
                    {isArabic ? "Compare Connections" : "Compare connections"}
                  </h3>
                  <small>
                    {isArabic
                      ? "اختر جلستين أو أكثر من السجل المحلي"
                      : "Select two or more local sessions"}
                  </small>
                </div>
              </header>
              <div className="comparison-summary">
                <b>
                  {difference === null
                    ? "Not Available"
                    : `${difference > 0 ? "+" : ""}${difference} score points`}
                </b>
                <span>
                  {selectedEntries.length < 2
                    ? "Select at least two sessions"
                    : "Performance difference from first to last selected session"}
                </span>
              </div>
              <div className="history-list">
                {filtered.map(item => (
                  <label key={item.at}>
                    <input
                      type="checkbox"
                      checked={selected.includes(item.at)}
                      onChange={event =>
                        setSelected(current =>
                          event.target.checked
                            ? [...current, item.at]
                            : current.filter(value => value !== item.at)
                        )
                      }
                    />
                    <b>
                      {item.score === null
                        ? "Not Available"
                        : `${item.score}/100`}
                    </b>
                    <span>
                      {item.latency === null
                        ? "—"
                        : `${item.latency.toFixed(1)} ms`}
                    </span>
                    <small>{item.at}</small>
                  </label>
                ))}
              </div>
            </section>
          </>
        ) : (
          <section className="data-panel browser-panel">
            <EmptyState
              title={isArabic ? "لا يوجد تاريخ محلي" : "No local history"}
              copy={
                isArabic
                  ? "شغّل لقطة من Browser Intelligence أولًا؛ لن يتم إنشاء جلسة تجريبية."
                  : "Run a Browser Intelligence snapshot first; no demo session is created."
              }
            />
          </section>
        )}
      </div>
    </ZeroGramShell>
  );
}
