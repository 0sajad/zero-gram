import {
  EmptyState,
  SectionHeading,
  ZeroGramShell,
} from "@/components/ZeroGramShell";
import { useI18n } from "@/lib/i18n";
import { trpc } from "@/lib/trpc";
import {
  AlertTriangle,
  ChartNoAxesCombined,
  ClipboardList,
  Gauge,
  GitCompareArrows,
  Network,
  Plus,
  ShieldAlert,
  Wrench,
} from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

const manualSource = "manual entry";
const parseJsonObject = (value: string) => {
  if (!value.trim()) return undefined;
  const parsed = JSON.parse(value) as unknown;
  if (!parsed || Array.isArray(parsed) || typeof parsed !== "object")
    throw new Error("JSON object required");
  return parsed as Record<string, unknown>;
};

export default function OperationsIntelligence() {
  const { isArabic } = useI18n();
  const utils = trpc.useUtils();
  const data = trpc.intelligence.overview.useQuery();
  const [incident, setIncident] = useState({
    title: "",
    severity: "high" as "critical" | "high" | "medium" | "low",
    sourceLabel: manualSource,
    rootCause: "",
    rootCauseConfidence: "",
    affectedServiceCount: "",
    engineerNotes: "",
  });
  const [change, setChange] = useState({
    deviceId: "",
    changeType: "",
    title: "",
    before: "",
    after: "",
    sourceLabel: manualSource,
  });
  const invalidate = () => utils.intelligence.overview.invalidate();
  const createIncident = trpc.intelligence.createIncident.useMutation({
    onSuccess: () => {
      toast.success(
        isArabic ? "حُفظت الحادثة المصدرية." : "Sourced incident saved."
      );
      setIncident({
        title: "",
        severity: "high",
        sourceLabel: manualSource,
        rootCause: "",
        rootCauseConfidence: "",
        affectedServiceCount: "",
        engineerNotes: "",
      });
      void invalidate();
    },
  });
  const updateIncident = trpc.intelligence.updateIncident.useMutation({
    onSuccess: () => {
      toast.success(isArabic ? "حُدّثت الحادثة." : "Incident updated.");
      void invalidate();
    },
  });
  const recordChange = trpc.intelligence.recordChange.useMutation({
    onSuccess: () => {
      toast.success(
        isArabic ? "حُفظ التغيير المصدر." : "Sourced change saved."
      );
      setChange({
        deviceId: "",
        changeType: "",
        title: "",
        before: "",
        after: "",
        sourceLabel: manualSource,
      });
      void invalidate();
    },
  });
  const unavailable = isArabic ? "غير متوفر" : "Not Available";
  const reliability = data.data?.reliability;
  const capacity = data.data?.capacity;
  const startIncidentFromSuggestion = (
    title: string,
    severity: "critical" | "high" | "medium" | "low",
    sourceLabel: string
  ) => setIncident(current => ({ ...current, title, severity, sourceLabel }));
  return (
    <ZeroGramShell
      title={isArabic ? "ذكاء العمليات" : "Operations intelligence"}
      eyebrow="ZERO GRAM / INCIDENT · CHANGE · RELIABILITY"
    >
      <div className="page-content intelligence-page">
        <SectionHeading
          index="I/05"
          title={
            isArabic
              ? "السعة والموثوقية والحوادث"
              : "Capacity, reliability & incidents"
          }
          description={
            isArabic
              ? "تحلل هذه الشاشة السجلات المحفوظة فقط. التنبيه التحليلي ليس سببًا مؤكّدًا، واقتراح الحادثة لا يتحول إلى سجل رسمي إلا بعد حفظه بمصدر."
              : "This screen analyzes stored records only. An analytical alert is not a confirmed cause, and an incident suggestion becomes an official record only after it is saved with a source."
          }
        />
        <section className="intelligence-stat-grid">
          <Stat
            icon={<Gauge />}
            label={isArabic ? "استخدام السعة" : "Capacity utilization"}
            value={
              capacity?.utilizationPercent === undefined
                ? unavailable
                : `${capacity.utilizationPercent.toFixed(1)}%`
            }
            detail={
              capacity?.sampleCount
                ? `${capacity.sampleCount} ${isArabic ? "لقطات" : "snapshots"}`
                : unavailable
            }
          />
          <Stat
            icon={<Network />}
            label={
              isArabic ? "نجاح الفحوصات المرصود" : "Observed check success"
            }
            value={
              reliability?.observedCheckSuccessPercent === undefined
                ? unavailable
                : `${reliability.observedCheckSuccessPercent.toFixed(1)}%`
            }
            detail={
              reliability?.sampleCount
                ? `${reliability.sampleCount} ${isArabic ? "فحوصات" : "checks"}`
                : unavailable
            }
          />
          <Stat
            icon={<AlertTriangle />}
            label={isArabic ? "حوادث مفتوحة" : "Open incidents"}
            value={data.data?.activeIncidentCount}
            detail={isArabic ? "من السجل المؤسسي" : "from organization records"}
          />
          <Stat
            icon={<ChartNoAxesCombined />}
            label={isArabic ? "جلسات سرعة محفوظة" : "Stored speed sessions"}
            value={data.data?.testSampleCount}
            detail={isArabic ? "لتحليل الشذوذ" : "for anomaly analysis"}
          />
        </section>
        <section className="intelligence-layout">
          <article className="data-panel">
            <h3>
              <ChartNoAxesCombined size={16} />
              {isArabic
                ? "تحليل السعة والموثوقية"
                : "Capacity & reliability analysis"}
            </h3>
            <div className="intelligence-details">
              <dl>
                <dt>{isArabic ? "الحالي" : "Current"}</dt>
                <dd>
                  {capacity?.current === undefined
                    ? unavailable
                    : `${capacity.current.toFixed(2)} Mbps`}
                </dd>
                <dt>{isArabic ? "الذروة" : "Peak"}</dt>
                <dd>
                  {capacity?.peak === undefined
                    ? unavailable
                    : `${capacity.peak.toFixed(2)} Mbps`}
                </dd>
                <dt>{isArabic ? "المتوسط" : "Average"}</dt>
                <dd>
                  {capacity?.average === undefined
                    ? unavailable
                    : `${capacity.average.toFixed(2)} Mbps`}
                </dd>
                <dt>{isArabic ? "اتجاه النمو" : "Growth trend"}</dt>
                <dd>
                  {capacity?.growthPercent === undefined
                    ? unavailable
                    : `${capacity.growthPercent >= 0 ? "+" : ""}${capacity.growthPercent.toFixed(1)}%`}
                </dd>
                <dt>MTBF</dt>
                <dd>
                  {reliability?.mtbfMs === undefined
                    ? unavailable
                    : formatDuration(reliability.mtbfMs)}
                </dd>
                <dt>MTTR</dt>
                <dd>
                  {reliability?.mttrMs === undefined
                    ? unavailable
                    : formatDuration(reliability.mttrMs)}
                </dd>
                <dt>
                  {isArabic
                    ? "عدد فترات الفشل المرصودة"
                    : "Observed outage runs"}
                </dt>
                <dd>{reliability?.outageCount ?? unavailable}</dd>
                <dt>{isArabic ? "التوقف المحسوب" : "Measured downtime"}</dt>
                <dd>
                  {reliability?.totalDowntimeMs === undefined
                    ? unavailable
                    : formatDuration(reliability.totalDowntimeMs)}
                </dd>
              </dl>
              <p className="muted">
                {isArabic
                  ? "الموثوقية هنا تمثل نجاح فحوصات HTTP المحفوظة، وليست ضمان Uptime شاملًا خارج أوقات الفحص أو لخدمات لم تُراقَب."
                  : "Reliability here represents stored HTTP-check success, not guaranteed global uptime outside sampled times or unmonitored services."}
              </p>
            </div>
          </article>
          <article className="data-panel">
            <h3>
              <AlertTriangle size={16} />
              {isArabic ? "كشف الشذوذ" : "Anomaly detection"}
            </h3>
            {data.data?.anomalies.length ? (
              <div className="anomaly-list">
                {data.data.anomalies.map(
                  item =>
                    item && (
                      <article key={item.metric}>
                        <b>{item.metric}</b>
                        <span>
                          {isArabic ? "الأحدث" : "Latest"}:{" "}
                          {item.latest.toFixed(2)} ·{" "}
                          {isArabic ? "الوسيط المرجعي" : "Baseline median"}:{" "}
                          {item.baselineMedian.toFixed(2)}
                        </span>
                        <small>
                          {isArabic ? "الفرق" : "Difference"}:{" "}
                          {item.difference >= 0 ? "+" : ""}
                          {item.difference.toFixed(2)} ·{" "}
                          {isArabic ? "الثقة" : "Confidence"}: {item.confidence}{" "}
                          · {item.evidenceCount}{" "}
                          {isArabic ? "سجلات مرجعية" : "baseline records"}
                        </small>
                      </article>
                    )
                )}
              </div>
            ) : (
              <EmptyState
                title={
                  isArabic
                    ? "لا يوجد شذوذ قابل للاستنتاج"
                    : "No inferable anomaly"
                }
                copy={
                  isArabic
                    ? "يلزم أربع عينات رقمية حقيقية على الأقل للمقياس نفسه؛ لا تنشئ المنصة خط أساس افتراضيًا."
                    : "At least four real numeric samples for the same metric are required; ZERO GRAM never creates a default baseline."
                }
              />
            )}
          </article>
        </section>
        <section className="intelligence-layout">
          <article className="data-panel">
            <h3>
              <ShieldAlert size={16} />
              {isArabic
                ? "اقتراحات حوادث من الأحداث الشديدة"
                : "Incident suggestions from severe events"}
            </h3>
            <p className="muted">
              {isArabic
                ? "تعتمد الاقتراحات على أحداث Critical/High محفوظة، ولا تعني أنها مرتبطة سببيًا أو أنها أصبحت Incident مسجلاً."
                : "Suggestions originate from stored Critical/High events. They do not establish causality or become recorded incidents automatically."}
            </p>
            {data.data?.suggestedIncidents.length ? (
              <div className="suggestion-list">
                {data.data.suggestedIncidents.map(item => (
                  <article key={item.eventId}>
                    <div>
                      <b>{item.title}</b>
                      <small>
                        {item.severity} ·{" "}
                        {new Date(item.occurredAt).toLocaleString()} ·{" "}
                        {item.sourceLabel}
                      </small>
                    </div>
                    <button
                      className="action-button"
                      onClick={() =>
                        startIncidentFromSuggestion(
                          item.title,
                          item.severity === "critical" ? "critical" : "high",
                          item.sourceLabel
                        )
                      }
                    >
                      <Plus size={14} />
                      {isArabic ? "استخدام كمسودة" : "Use as draft"}
                    </button>
                  </article>
                ))}
              </div>
            ) : (
              <p className="muted">
                {isArabic
                  ? "لا توجد أحداث شديدة محفوظة لاقتراح حادثة."
                  : "No severe stored event is available for an incident suggestion."}
              </p>
            )}
          </article>
          <article className="data-panel">
            <h3>
              <ClipboardList size={16} />
              {isArabic ? "تسجيل حادثة" : "Record incident"}
            </h3>
            <div className="intelligence-form two">
              <Field
                label={isArabic ? "عنوان الحادثة" : "Incident title"}
                value={incident.title}
                onChange={value => setIncident({ ...incident, title: value })}
                required
              />
              <label>
                {isArabic ? "الشدة" : "Severity"}
                <select
                  value={incident.severity}
                  onChange={event =>
                    setIncident({
                      ...incident,
                      severity: event.target.value as typeof incident.severity,
                    })
                  }
                >
                  {["critical", "high", "medium", "low"].map(value => (
                    <option key={value}>{value}</option>
                  ))}
                </select>
              </label>
              <Field
                label={isArabic ? "عدد الخدمات المتأثرة" : "Affected services"}
                type="number"
                value={incident.affectedServiceCount}
                onChange={value =>
                  setIncident({ ...incident, affectedServiceCount: value })
                }
              />
              <Field
                label={isArabic ? "ثقة السبب (%)" : "Root-cause confidence (%)"}
                type="number"
                value={incident.rootCauseConfidence}
                onChange={value =>
                  setIncident({ ...incident, rootCauseConfidence: value })
                }
              />
              <Field
                label={isArabic ? "المصدر" : "Sourced record"}
                value={incident.sourceLabel}
                onChange={value =>
                  setIncident({ ...incident, sourceLabel: value })
                }
                required
              />
            </div>
            <TextArea
              label={
                isArabic
                  ? "سبب محتمل / محقق"
                  : "Potential / confirmed root cause"
              }
              value={incident.rootCause}
              onChange={value => setIncident({ ...incident, rootCause: value })}
            />
            <TextArea
              label={isArabic ? "ملاحظات المهندس" : "Engineer notes"}
              value={incident.engineerNotes}
              onChange={value =>
                setIncident({ ...incident, engineerNotes: value })
              }
            />
            <button
              className="action-button primary"
              disabled={
                createIncident.isPending ||
                !incident.title.trim() ||
                !incident.sourceLabel.trim()
              }
              onClick={() =>
                createIncident.mutate({
                  title: incident.title.trim(),
                  severity: incident.severity,
                  startedAt: new Date(),
                  affectedServiceCount: incident.affectedServiceCount
                    ? Number(incident.affectedServiceCount)
                    : undefined,
                  rootCause: incident.rootCause.trim() || undefined,
                  rootCauseConfidence: incident.rootCauseConfidence
                    ? Number(incident.rootCauseConfidence)
                    : undefined,
                  engineerNotes: incident.engineerNotes.trim() || undefined,
                  sourceLabel: incident.sourceLabel.trim(),
                })
              }
            >
              <Plus size={15} />
              {isArabic ? "حفظ حادثة" : "Save incident"}
            </button>
          </article>
        </section>
        <section className="intelligence-layout">
          <article className="data-panel">
            <h3>
              <GitCompareArrows size={16} />
              {isArabic ? "التغييرات قبل / بعد" : "Before / after changes"}
            </h3>
            <div className="intelligence-form two">
              <label>
                {isArabic ? "الجهاز (اختياري)" : "Device (optional)"}
                <select
                  value={change.deviceId}
                  onChange={event =>
                    setChange({ ...change, deviceId: event.target.value })
                  }
                >
                  <option value="">{unavailable}</option>
                  {(data.data?.devices || []).map(device => (
                    <option value={device.id} key={device.id}>
                      {device.label}
                    </option>
                  ))}
                </select>
              </label>
              <Field
                label={isArabic ? "نوع التغيير" : "Change type"}
                value={change.changeType}
                onChange={value => setChange({ ...change, changeType: value })}
                required
              />
              <Field
                label={isArabic ? "العنوان" : "Title"}
                value={change.title}
                onChange={value => setChange({ ...change, title: value })}
                required
              />
              <Field
                label={isArabic ? "المصدر" : "Sourced record"}
                value={change.sourceLabel}
                onChange={value => setChange({ ...change, sourceLabel: value })}
                required
              />
            </div>
            <div className="intelligence-form two">
              <TextArea
                label={isArabic ? "قبل (JSON)" : "Before (JSON)"}
                value={change.before}
                onChange={value => setChange({ ...change, before: value })}
              />
              <TextArea
                label={isArabic ? "بعد (JSON)" : "After (JSON)"}
                value={change.after}
                onChange={value => setChange({ ...change, after: value })}
              />
            </div>
            <button
              className="action-button"
              disabled={
                recordChange.isPending ||
                !change.title.trim() ||
                !change.changeType.trim() ||
                (!change.before.trim() && !change.after.trim()) ||
                !change.sourceLabel.trim()
              }
              onClick={() => {
                try {
                  recordChange.mutate({
                    deviceId: change.deviceId
                      ? Number(change.deviceId)
                      : undefined,
                    changeType: change.changeType.trim(),
                    title: change.title.trim(),
                    before: parseJsonObject(change.before),
                    after: parseJsonObject(change.after),
                    sourceLabel: change.sourceLabel.trim(),
                    changedAt: new Date(),
                  });
                } catch {
                  toast.error(
                    isArabic
                      ? "أدخل كائن JSON صالحًا قبل أو بعد."
                      : "Enter a valid before or after JSON object."
                  );
                }
              }}
            >
              <Plus size={15} />
              {isArabic ? "تسجيل تغيير" : "Record change"}
            </button>
            <div className="change-list">
              {data.data?.changes.length ? (
                data.data.changes.slice(0, 12).map(item => (
                  <article key={item.id}>
                    <b>{item.title}</b>
                    <span>
                      {item.changeType} ·{" "}
                      {new Date(item.changedAt).toLocaleString()}
                    </span>
                    <small>{item.sourceLabel}</small>
                  </article>
                ))
              ) : (
                <p className="muted">
                  {isArabic
                    ? "لا توجد تغييرات مصدرية بعد."
                    : "No sourced changes yet."}
                </p>
              )}
            </div>
          </article>
          <article className="data-panel">
            <h3>
              <Wrench size={16} />
              {isArabic ? "سجل الحوادث" : "Incident register"}
            </h3>
            <div className="incident-list">
              {data.data?.incidents.length ? (
                data.data.incidents.map(item => (
                  <article key={item.id}>
                    <div>
                      <b>
                        {item.reference} · {item.title}
                      </b>
                      <span>
                        {item.severity} · {item.state} ·{" "}
                        {new Date(item.startedAt).toLocaleString()}
                      </span>
                      <small>
                        {item.rootCause || unavailable} · {item.sourceLabel}
                      </small>
                    </div>
                    {item.state !== "resolved" && (
                      <button
                        className="action-button"
                        disabled={updateIncident.isPending}
                        onClick={() =>
                          updateIncident.mutate({
                            incidentId: item.id,
                            state: "resolved",
                            endedAt: new Date(),
                          })
                        }
                      >
                        {isArabic ? "حل" : "Resolve"}
                      </button>
                    )}
                  </article>
                ))
              ) : (
                <p className="muted">
                  {isArabic
                    ? "لا توجد حادثة موثقة بعد."
                    : "No sourced incident yet."}
                </p>
              )}
            </div>
          </article>
        </section>
      </div>
    </ZeroGramShell>
  );
}
function Stat({
  icon,
  label,
  value,
  detail,
}: {
  icon: React.ReactNode;
  label: string;
  value: string | number | undefined;
  detail: string;
}) {
  return (
    <article>
      <span>
        {icon}
        {label}
      </span>
      <b>{value ?? "—"}</b>
      <small>{detail}</small>
    </article>
  );
}
function Field({
  label,
  value,
  onChange,
  type = "text",
  required = false,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  type?: string;
  required?: boolean;
}) {
  return (
    <label>
      {label}
      {required && <em> *</em>}
      <input
        type={type}
        value={value}
        onChange={event => onChange(event.target.value)}
      />
    </label>
  );
}
function TextArea({
  label,
  value,
  onChange,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
}) {
  return (
    <label className="intelligence-textarea">
      {label}
      <textarea
        value={value}
        onChange={event => onChange(event.target.value)}
      />
    </label>
  );
}
function formatDuration(ms: number) {
  const minutes = Math.round(ms / 60_000);
  return minutes >= 60 ? `${(minutes / 60).toFixed(1)} h` : `${minutes} min`;
}
