import {
  EmptyState,
  SectionHeading,
  ZeroGramShell,
} from "@/components/ZeroGramShell";
import { useI18n } from "@/lib/i18n";
import { trpc } from "@/lib/trpc";
import {
  Box,
  Cable,
  ChevronDown,
  Cpu,
  Loader2,
  Radio,
  Router,
} from "lucide-react";
import { useState } from "react";

export default function AccessDetails({ mode }: { mode: "ont" | "olt" }) {
  const { isArabic } = useI18n();
  const overview = trpc.fiber.overview.useQuery();
  const [deviceId, setDeviceId] = useState<number | null>(null);
  const detail = trpc.fiber.deviceDetails.useQuery(
    { deviceId: deviceId || 1, telemetryDays: 90 },
    { enabled: Boolean(deviceId) }
  );
  const devices = (overview.data?.devices || []).filter(device =>
    mode === "ont"
      ? ["ont", "onu"].includes(device.deviceType.toLowerCase())
      : device.deviceType.toLowerCase() === "olt"
  );
  const ports = (overview.data?.ports || []).filter(
    port => port.oltDeviceId === deviceId
  );
  const title =
    mode === "ont"
      ? isArabic
        ? "تفاصيل ONU / ONT"
        : "ONU / ONT details"
      : isArabic
        ? "تفاصيل OLT / PON"
        : "OLT / PON details";
  return (
    <ZeroGramShell
      title={title}
      eyebrow={`ZERO GRAM / ${mode.toUpperCase()} DEEP VIEW`}
    >
      <div className="page-content access-page">
        <SectionHeading
          index={mode === "ont" ? "F/ONT" : "F/OLT"}
          title={title}
          description={
            isArabic
              ? "التفاصيل تقرأ فقط السجلات المصدرية المحفوظة وتجمع الهوية والحالة والقياسات والواجهات والأحداث عبر أقسام قابلة للطي."
              : "Details read only stored sourced records and group identity, state, telemetry, interfaces and events in expandable sections."
          }
        />
        <section className="data-panel health-selector">
          <label>
            {isArabic ? "العنصر" : "Element"}
            <select
              value={deviceId || ""}
              onChange={event =>
                setDeviceId(Number(event.target.value) || null)
              }
            >
              <option value="">—</option>
              {devices.map(device => (
                <option value={device.id} key={device.id}>
                  {device.label} ·{" "}
                  {device.serialNumber || device.hostname || "—"}
                </option>
              ))}
            </select>
          </label>
        </section>
        {!deviceId ? (
          <EmptyState
            title={
              isArabic ? "اختر عنصرًا من الجرد" : "Select an inventory element"
            }
            copy={
              isArabic
                ? "لا يظهر قسم تفاصيل أو قراءة افتراضية عند غياب الجهاز الحقيقي."
                : "No detail section or inferred reading appears without a real inventory device."
            }
          />
        ) : detail.isLoading ? (
          <div className="panel-loading">
            <Loader2 className="spin" />
          </div>
        ) : (
          <section className="access-detail-stack">
            <Disclosure
              title={isArabic ? "الهوية والحالة" : "Identity & state"}
              icon={<Cpu size={16} />}
            >
              {detail.data && (
                <dl>
                  <dt>Serial</dt>
                  <dd>{detail.data.device.serialNumber || "—"}</dd>
                  <dt>MAC</dt>
                  <dd>{detail.data.device.macAddress || "—"}</dd>
                  <dt>IP</dt>
                  <dd>
                    {detail.data.device.managementIpv4 ||
                      detail.data.device.managementIpv6 ||
                      "—"}
                  </dd>
                  <dt>{isArabic ? "المورّد/الطراز" : "Vendor / model"}</dt>
                  <dd>
                    {detail.data.device.vendor || "—"} /{" "}
                    {detail.data.device.model || "—"}
                  </dd>
                  <dt>{isArabic ? "المصدر" : "Source"}</dt>
                  <dd>{detail.data.device.sourceLabel || "—"}</dd>
                </dl>
              )}
            </Disclosure>
            {mode === "ont" ? (
              <>
                <Disclosure
                  title={isArabic ? "البصريات وPON" : "Optical & PON"}
                  icon={<Cable size={16} />}
                >
                  {detail.data?.unit ? (
                    <dl>
                      <dt>ONU ID</dt>
                      <dd>{detail.data.unit.onuId || "—"}</dd>
                      <dt>LOS / LOF</dt>
                      <dd>
                        {detail.data.unit.losState || "—"} /{" "}
                        {detail.data.unit.lofState || "—"}
                      </dd>
                      <dt>Dying Gasp</dt>
                      <dd>{detail.data.unit.dyingGaspState || "—"}</dd>
                      <dt>PON / Auth</dt>
                      <dd>
                        {detail.data.unit.ponStatus || "—"} /{" "}
                        {detail.data.unit.authenticationStatus || "—"}
                      </dd>
                      <dt>{isArabic ? "المسافة" : "Distance"}</dt>
                      <dd>{detail.data.unit.opticalDistanceKm ?? "—"} km</dd>
                    </dl>
                  ) : (
                    <p className="muted">
                      {isArabic
                        ? "لا توجد وحدة ONT مصدرية مرتبطة."
                        : "No sourced ONT unit is linked."}
                    </p>
                  )}
                </Disclosure>
                <Disclosure
                  title={
                    isArabic
                      ? "الشبكة والواجهات وWi‑Fi"
                      : "Network, interfaces & Wi‑Fi"
                  }
                  icon={<Radio size={16} />}
                >
                  {detail.data && (
                    <div className="mini-columns">
                      <div>
                        <b>IP</b>
                        {detail.data.ips.map(ip => (
                          <p key={ip.id}>
                            {ip.address} · {ip.scope}
                          </p>
                        )) || "—"}
                      </div>
                      <div>
                        <b>Ethernet</b>
                        {detail.data.ethernet.map(port => (
                          <p key={port.id}>
                            {port.label} · {port.negotiatedSpeedMbps || "—"}{" "}
                            Mbps · CRC {port.crcErrors ?? "—"}
                          </p>
                        )) || "—"}
                      </div>
                      <div>
                        <b>Wi‑Fi</b>
                        {detail.data.wifi.map(wifi => (
                          <p key={wifi.id}>
                            {wifi.ssid} · {wifi.channel || "—"} ·{" "}
                            {wifi.signalDbm ?? "—"} dBm
                          </p>
                        )) || "—"}
                      </div>
                    </div>
                  )}
                </Disclosure>
              </>
            ) : (
              <>
                <Disclosure
                  title={isArabic ? "منافذ PON المرتبطة" : "Attached PON ports"}
                  icon={<Router size={16} />}
                >
                  {ports.length ? (
                    <div className="pon-list">
                      {ports.map(port => (
                        <p key={port.id}>
                          <b>{port.label}</b>
                          <span>
                            {port.ponIndex || "—"} ·{" "}
                            {port.operationalStatus || "—"} ·{" "}
                            {port.maxOnts ?? "—"} ONTs
                          </span>
                        </p>
                      ))}
                    </div>
                  ) : (
                    <p className="muted">
                      {isArabic
                        ? "لا توجد منافذ PON مصدرية مرتبطة بهذا OLT."
                        : "No sourced PON ports are attached to this OLT."}
                    </p>
                  )}
                </Disclosure>
                <Disclosure
                  title={
                    isArabic
                      ? "التنبيهات ومسار الربط"
                      : "Alerts & path references"
                  }
                  icon={<Box size={16} />}
                >
                  {detail.data && (
                    <div className="mini-columns">
                      <div>
                        <b>{isArabic ? "تنبيهات مفتوحة" : "Open alerts"}</b>
                        {detail.data.alerts.map(alert => (
                          <p key={alert.id}>
                            {alert.severity} · {alert.title}
                          </p>
                        )) || "—"}
                      </div>
                      <div>
                        <b>{isArabic ? "الأحداث" : "Events"}</b>
                        {detail.data.events.slice(0, 8).map(event => (
                          <p key={event.id}>
                            {event.eventType} · {event.severity}
                          </p>
                        )) || "—"}
                      </div>
                    </div>
                  )}
                </Disclosure>
              </>
            )}
            <Disclosure
              title={isArabic ? "القياسات والتاريخ" : "Measurements & history"}
              icon={<Cable size={16} />}
            >
              {detail.data?.samples.length ? (
                <div className="measurement-list">
                  {detail.data.samples.slice(0, 30).map(sample => (
                    <p key={sample.id}>
                      {sample.metric}:{" "}
                      {sample.valueDouble ?? sample.valueText ?? "—"}{" "}
                      {sample.unit || ""} <small>{sample.sourceLabel}</small>
                    </p>
                  ))}
                </div>
              ) : (
                <p className="muted">
                  {isArabic
                    ? "لا توجد قياسات مصدرية محفوظة."
                    : "No sourced measurements are stored."}
                </p>
              )}
            </Disclosure>
          </section>
        )}
      </div>
    </ZeroGramShell>
  );
}
function Disclosure({
  title,
  icon,
  children,
}: {
  title: string;
  icon: React.ReactNode;
  children: React.ReactNode;
}) {
  return (
    <details className="data-panel access-disclosure" open>
      <summary>
        {icon}
        <b>{title}</b>
        <ChevronDown size={15} />
      </summary>
      <div>{children}</div>
    </details>
  );
}
