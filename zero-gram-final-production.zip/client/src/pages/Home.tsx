import { BrandMark, LanguageToggle } from "@/components/ZeroGramShell";
import { useI18n } from "@/lib/i18n";
import {
  ArrowLeft,
  ArrowRight,
  Braces,
  ChevronDown,
  CircleDotDashed,
  Radar,
  ShieldCheck,
  Workflow,
} from "lucide-react";
import { Link } from "wouter";

export default function Home() {
  const { isArabic, t } = useI18n();
  const Arrow = isArabic ? ArrowLeft : ArrowRight;
  return (
    <div className="landing">
      <div className="scanlines" aria-hidden="true" />
      <header className="landing-nav">
        <Link href="/">
          <BrandMark />
        </Link>
        <div className="landing-nav-actions">
          <Link href="/knowledge" className="nav-text">
            {t("knowledge")}
          </Link>
          <LanguageToggle />
        </div>
      </header>
      <main>
        <section className="hero-grid">
          <div className="hero-copy">
            <p className="terminal-kicker">
              <span /> NETWORK INTELLIGENCE / 01
            </p>
            <h1>
              <span>WHAT IS</span>
              <strong>HAPPENING</strong>
              <i>ON YOUR NETWORK?</i>
            </h1>
            <p className="hero-description">
              {isArabic
                ? "قياسات قابلة للتفسير، وتشخيص قائم على الدليل، وعمليات شبكة لا تتظاهر بمعرفة ما لا يمكن قياسه."
                : "Explainable measurements, evidence-led diagnosis, and network operations that never pretend to know what was not measured."}
            </p>
            <div className="hero-actions">
              <Link href="/test" className="primary-cta">
                {t("start")}
                <Arrow size={18} />
              </Link>
              <a href="#method" className="ghost-cta">
                {isArabic ? "كيف نقيس؟" : "How we measure"}
                <ChevronDown size={16} />
              </a>
            </div>
            <div className="hero-meta">
              <span>HTTP / HTTPS</span>
              <span>NO SYNTHETIC STATS</span>
              <span>RTL · LTR</span>
            </div>
          </div>
          <div
            className="hero-console"
            aria-label="ZERO GRAM network signal visualization"
          >
            <div className="console-top">
              <span>ZG::SIGNAL_WINDOW</span>
              <span>LIVE INPUT ONLY</span>
            </div>
            <div className="console-radar">
              <div className="radar-rings" />
              <div className="radar-sweep" />
              <span className="radar-node node-a" />
              <span className="radar-node node-b" />
              <span className="radar-node node-c" />
              <div className="console-core">
                ZERO
                <br />
                GRAM
              </div>
            </div>
            <div className="console-bottom">
              <div>
                <small>PROTOCOL</small>
                <b>HTTP / HTTPS</b>
              </div>
              <div>
                <small>STATE</small>
                <b>AWAITING INPUT</b>
              </div>
              <div>
                <small>LIMIT</small>
                <b>NO ICMP</b>
              </div>
            </div>
          </div>
        </section>
        <section id="method" className="capability-grid">
          <article>
            <span className="cap-icon">
              <Radar />
            </span>
            <p>01 / {isArabic ? "الفحص" : "TEST"}</p>
            <h2>
              {isArabic ? "قياس صادق من المتصفح" : "Honest browser measurement"}
            </h2>
            <span>
              {isArabic
                ? "نزودك بالمصدر والدقة والحدود مع كل نتيجة."
                : "Source, precision, and limitations travel with every result."}
            </span>
          </article>
          <article>
            <span className="cap-icon">
              <Workflow />
            </span>
            <p>02 / {isArabic ? "التشخيص" : "DIAGNOSE"}</p>
            <h2>{isArabic ? "دليل لا ادعاء" : "Evidence, not assertion"}</h2>
            <span>
              {isArabic
                ? "قواعد قابلة للمراجعة وخطوات تحقق آمنة."
                : "Reviewable rules with safe verification steps."}
            </span>
          </article>
          <article>
            <span className="cap-icon">
              <Braces />
            </span>
            <p>03 / {isArabic ? "العمليات" : "OPERATE"}</p>
            <h2>{isArabic ? "سجل تشغيلي محمي" : "Protected ops record"}</h2>
            <span>
              {isArabic
                ? "راقب وجهاتك ونظم التذاكر ضمن مؤسستك."
                : "Monitor targets and organize tickets inside your organization."}
            </span>
          </article>
        </section>
        <section className="method-note">
          <ShieldCheck />
          <p>
            {isArabic
              ? "قاعدة ZERO GRAM: لا نعرض حالة أو رقمًا أو حادثة دون إدخال موثق أو اختبار فعلي أو سجل مراقبة محفوظ."
              : "ZERO GRAM rule: no status, number, or incident appears without verified input, an actual test, or a stored monitoring record."}
          </p>
        </section>
      </main>
    </div>
  );
}
