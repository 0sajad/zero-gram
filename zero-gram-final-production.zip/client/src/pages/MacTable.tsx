import {
  EmptyState,
  SectionHeading,
  ZeroGramShell,
} from "@/components/ZeroGramShell";
import { useI18n } from "@/lib/i18n";
import { trpc } from "@/lib/trpc";
import { Database, Loader2, Save } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

export default function MacTable() {
  const { isArabic } = useI18n();
  const overview = trpc.fiber.overview.useQuery();
  const [deviceId, setDeviceId] = useState<number | null>(null);
  const rows = trpc.fiber.listMacTableEntries.useQuery(
    { deviceId: deviceId || 1 },
    { enabled: Boolean(deviceId) }
  );
  const utils = trpc.useUtils();
  const save = trpc.fiber.addMacTableEntry.useMutation({
    onSuccess: async () => {
      if (deviceId)
        await utils.fiber.listMacTableEntries.invalidate({ deviceId });
      toast.success(
        isArabic ? "حُفظ سجل MAC table." : "MAC table record saved."
      );
    },
  });
  const devices = overview.data?.devices || [];
  return (
    <ZeroGramShell title="MAC table" eyebrow="ZERO GRAM / LAYER-2 INDEX">
      <div className="page-content mac-page">
        <SectionHeading
          index="F/MAC"
          title={
            isArabic ? "فهرس MAC / ARP المصدرى" : "Sourced MAC / ARP index"
          }
          description={
            isArabic
              ? "يحتفظ القسم بسجل MAC/IP/VLAN/منفذ مصدره جهاز مؤسستك أو استيراد مصرح. لا يستنتج عناوين طبقة 2 من المتصفح."
              : "This area preserves MAC/IP/VLAN/interface data sourced from organization equipment or an authorized import. It never infers layer-2 addresses from the browser."
          }
        />
        <section className="data-panel health-selector">
          <label>
            {isArabic ? "الجهاز" : "Device"}
            <select
              value={deviceId || ""}
              onChange={event =>
                setDeviceId(Number(event.target.value) || null)
              }
            >
              <option value="">—</option>
              {devices.map(device => (
                <option value={device.id} key={device.id}>
                  {device.label} · {device.deviceType}
                </option>
              ))}
            </select>
          </label>
        </section>
        {!deviceId ? (
          <EmptyState
            title={isArabic ? "اختر جهازًا" : "Select a device"}
            copy={
              isArabic
                ? "ستظهر سجلات MAC/ARP الحقيقية لهذا الجهاز فقط."
                : "Only sourced MAC/ARP records for that device appear here."
            }
          />
        ) : (
          <section className="mac-layout">
            <form
              className="data-panel interface-form"
              onSubmit={event => {
                event.preventDefault();
                const data = new FormData(event.currentTarget);
                save.mutate({
                  deviceId,
                  macAddress: String(data.get("mac")),
                  ipAddress: String(data.get("ip") || "") || undefined,
                  vlanId: String(data.get("vlan") || "") || undefined,
                  interfaceLabel: String(data.get("port") || "") || undefined,
                  hostname: String(data.get("host") || "") || undefined,
                  sourceLabel: String(data.get("source")),
                });
              }}
            >
              <h3>
                <Database size={16} />
                MAC / ARP
              </h3>
              <div className="field-grid">
                <label>
                  MAC
                  <input required name="mac" />
                </label>
                <label>
                  IP
                  <input name="ip" />
                </label>
                <label>
                  VLAN
                  <input name="vlan" />
                </label>
                <label>
                  {isArabic ? "المنفذ" : "Interface"}
                  <input name="port" />
                </label>
                <label>
                  Hostname
                  <input name="host" />
                </label>
              </div>
              <label>
                {isArabic ? "المصدر" : "Source"}
                <input required name="source" />
              </label>
              <button className="action-button primary">
                <Save size={14} />
                {isArabic ? "حفظ السجل" : "Save record"}
              </button>
            </form>
            <article className="data-panel mac-records">
              <h3>
                {isArabic ? "السجل المرتبط بالجهاز" : "Device-bound records"}
              </h3>
              {rows.isLoading ? (
                <Loader2 className="spin" />
              ) : rows.data?.length ? (
                <table>
                  <thead>
                    <tr>
                      <th>MAC</th>
                      <th>IP</th>
                      <th>VLAN</th>
                      <th>{isArabic ? "المنفذ" : "Interface"}</th>
                      <th>{isArabic ? "المصدر" : "Source"}</th>
                    </tr>
                  </thead>
                  <tbody>
                    {rows.data.map(row => (
                      <tr key={row.id}>
                        <td>{row.macAddress}</td>
                        <td>{row.ipAddress || "—"}</td>
                        <td>{row.vlanId || "—"}</td>
                        <td>{row.interfaceLabel || "—"}</td>
                        <td>{row.sourceLabel}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              ) : (
                <p className="muted">
                  {isArabic
                    ? "لا توجد سجلات MAC/ARP مصدرية بعد."
                    : "No sourced MAC/ARP entries yet."}
                </p>
              )}
            </article>
          </section>
        )}
      </div>
    </ZeroGramShell>
  );
}
