import {
  EmptyState,
  SectionHeading,
  ZeroGramShell,
} from "@/components/ZeroGramShell";
import { useI18n } from "@/lib/i18n";
import { trpc } from "@/lib/trpc";
import {
  Building2,
  Database,
  Gauge,
  Globe2,
  Network,
  Plus,
  Save,
  Server,
  Users,
} from "lucide-react";
import { useEffect, useState } from "react";
import { toast } from "sonner";

const manualSource = "manual entry";
const asNumber = (value: string) =>
  value.trim() === "" ? undefined : Number(value);
const optionalText = (value: string) => value.trim() || undefined;
const stamp = () => new Date().toISOString().slice(0, 16);

type ProfileForm = {
  companyName: string;
  logoUrl: string;
  description: string;
  networkType: string;
  declaredUserCount: string;
  declaredBranchCount: string;
  totalBandwidthMbps: string;
  capacityWarningPercent: string;
  nocInformation: string;
  technicalSupportInformation: string;
  contactInformation: string;
  maintenanceInformation: string;
  sourceLabel: string;
};
type IdentityForm = {
  label: string;
  ispName: string;
  asn: string;
  asName: string;
  organizationName: string;
  publicIp: string;
  ipv4Status: string;
  ipv6Status: string;
  ispDomain: string;
  networkPrefix: string;
  country: string;
  region: string;
  city: string;
  hostname: string;
  reverseDns: string;
  connectionType: string;
  detectedNetwork: string;
  networkProvider: string;
  sourceLabel: string;
  isPrimary: boolean;
};
type PackageForm = {
  label: string;
  downloadMbps: string;
  uploadMbps: string;
  expectedDownloadMinMbps: string;
  expectedDownloadMaxMbps: string;
  expectedUploadMinMbps: string;
  expectedUploadMaxMbps: string;
  sourceLabel: string;
};
type CapacityForm = {
  currentUsageMbps: string;
  peakUsageMbps: string;
  averageUsageMbps: string;
  peakWindow: string;
  sourceLabel: string;
  measuredAt: string;
};

const defaultProfile = (): ProfileForm => ({
  companyName: "",
  logoUrl: "",
  description: "",
  networkType: "",
  declaredUserCount: "",
  declaredBranchCount: "",
  totalBandwidthMbps: "",
  capacityWarningPercent: "80",
  nocInformation: "",
  technicalSupportInformation: "",
  contactInformation: "",
  maintenanceInformation: "",
  sourceLabel: manualSource,
});
const defaultIdentity = (): IdentityForm => ({
  label: "",
  ispName: "",
  asn: "",
  asName: "",
  organizationName: "",
  publicIp: "",
  ipv4Status: "",
  ipv6Status: "",
  ispDomain: "",
  networkPrefix: "",
  country: "",
  region: "",
  city: "",
  hostname: "",
  reverseDns: "",
  connectionType: "",
  detectedNetwork: "",
  networkProvider: "",
  sourceLabel: manualSource,
  isPrimary: true,
});
const defaultPackage = (): PackageForm => ({
  label: "",
  downloadMbps: "",
  uploadMbps: "",
  expectedDownloadMinMbps: "",
  expectedDownloadMaxMbps: "",
  expectedUploadMinMbps: "",
  expectedUploadMaxMbps: "",
  sourceLabel: manualSource,
});
const defaultCapacity = (): CapacityForm => ({
  currentUsageMbps: "",
  peakUsageMbps: "",
  averageUsageMbps: "",
  peakWindow: "",
  sourceLabel: manualSource,
  measuredAt: stamp(),
});

export default function NetworkContext() {
  const { isArabic } = useI18n();
  const utils = trpc.useUtils();
  const overview = trpc.networkContext.overview.useQuery();
  const [profile, setProfile] = useState<ProfileForm>(defaultProfile);
  const [identity, setIdentity] = useState<IdentityForm>(defaultIdentity);
  const [pkg, setPkg] = useState<PackageForm>(defaultPackage);
  const [capacity, setCapacity] = useState<CapacityForm>(defaultCapacity);
  const invalidate = () => utils.networkContext.overview.invalidate();
  const saveProfile = trpc.networkContext.saveProfile.useMutation({
    onSuccess: () => {
      toast.success(isArabic ? "حُفظ سياق الشركة." : "Company context saved.");
      void invalidate();
    },
  });
  const addIdentity = trpc.networkContext.addIdentity.useMutation({
    onSuccess: () => {
      toast.success(
        isArabic ? "حُفظت هوية الشبكة." : "Network identity saved."
      );
      setIdentity(defaultIdentity());
      void invalidate();
    },
  });
  const addPackage = trpc.networkContext.addPackage.useMutation({
    onSuccess: () => {
      toast.success(
        isArabic ? "حُفظت الحزمة المرجعية." : "Reference package saved."
      );
      setPkg(defaultPackage());
      void invalidate();
    },
  });
  const addCapacity = trpc.networkContext.addCapacitySnapshot.useMutation({
    onSuccess: () => {
      toast.success(
        isArabic ? "حُفظت لقطة السعة." : "Capacity snapshot saved."
      );
      setCapacity(defaultCapacity());
      void invalidate();
    },
  });
  useEffect(() => {
    const item = overview.data?.profile;
    if (!item) return;
    setProfile({
      companyName: item.companyName,
      logoUrl: item.logoUrl || "",
      description: item.description || "",
      networkType: item.networkType || "",
      declaredUserCount: item.declaredUserCount?.toString() || "",
      declaredBranchCount: item.declaredBranchCount?.toString() || "",
      totalBandwidthMbps: item.totalBandwidthMbps?.toString() || "",
      capacityWarningPercent: item.capacityWarningPercent?.toString() || "80",
      nocInformation: item.nocInformation || "",
      technicalSupportInformation: item.technicalSupportInformation || "",
      contactInformation: item.contactInformation || "",
      maintenanceInformation: item.maintenanceInformation || "",
      sourceLabel: item.sourceLabel,
    });
  }, [overview.data?.profile]);
  const unavailable = isArabic ? "غير متوفر" : "Not Available";
  const show = (value?: string | null) => value || unavailable;
  const capacityState = overview.data?.capacity;
  const warning = Boolean(
    capacityState &&
      capacityState.utilizationPercent !== null &&
      capacityState.warningPercent !== null &&
      capacityState.utilizationPercent >= capacityState.warningPercent
  );
  const identityField = (
    label: string,
    key: Exclude<keyof IdentityForm, "isPrimary">
  ) => (
    <Field
      label={label}
      value={identity[key] as string}
      onChange={value => setIdentity(current => ({ ...current, [key]: value }))}
    />
  );
  return (
    <ZeroGramShell
      title={isArabic ? "سياق الشركة والشبكة" : "Company & network context"}
      eyebrow="ZERO GRAM / NETWORK CONTEXT"
    >
      <div className="page-content network-context-page">
        <SectionHeading
          index="C/01"
          title={
            isArabic
              ? "ملف المؤسسة وسياق التشغيل"
              : "Organization profile & operating context"
          }
          description={
            isArabic
              ? "هذه حقائق تعلنها المؤسسة أو تستوردها يدويًا. لا تستنتج المنصة ISP أو ASN أو استخدام السعة عند غياب سجل مصدر."
              : "These are organization-declared or manually imported facts. ZERO GRAM does not infer ISP, ASN, or capacity usage without a sourced record."
          }
        />
        <section className="metric-grid context-count-grid">
          <Metric
            icon={<Server />}
            label={isArabic ? "أجهزة مسجلة" : "Registered devices"}
            value={overview.data?.actualCounts.devices}
            fallback={unavailable}
          />
          <Metric
            icon={<Network />}
            label="OLT"
            value={overview.data?.actualCounts.olts}
            fallback={unavailable}
          />
          <Metric
            icon={<Gauge />}
            label="ONT / ONU"
            value={overview.data?.actualCounts.onts}
            fallback={unavailable}
          />
          <Metric
            icon={<Users />}
            label={isArabic ? "مشتركون مسجلون" : "Registered subscribers"}
            value={overview.data?.actualCounts.subscribers}
            fallback={unavailable}
          />
        </section>
        <section className="context-layout">
          <article className="data-panel">
            <h3>
              <Building2 size={17} />
              {isArabic ? "ملف الشركة" : "Company profile"}
            </h3>
            <p className="muted">
              {isArabic
                ? "تُحسب عدادات الأجهزة وOLT وONT والمشتركين من الجرد. الأرقام المعلنة تبقى مرجعًا مؤسسيًا ولا تستبدل السجل الفعلي."
                : "Device, OLT, ONT, and subscriber counts are calculated from inventory. Declared values remain organization references and never replace actual inventory."}
            </p>
            <div className="context-form two-col">
              <Field
                label={isArabic ? "اسم الشركة" : "Company name"}
                value={profile.companyName}
                onChange={value =>
                  setProfile({ ...profile, companyName: value })
                }
                required
              />
              <Field
                label={isArabic ? "نوع الشبكة" : "Network type"}
                value={profile.networkType}
                onChange={value =>
                  setProfile({ ...profile, networkType: value })
                }
              />
              <Field
                label={isArabic ? "رابط الشعار" : "Logo URL"}
                value={profile.logoUrl}
                onChange={value => setProfile({ ...profile, logoUrl: value })}
              />
              <Field
                label={isArabic ? "المستخدمون المعلنون" : "Declared users"}
                type="number"
                value={profile.declaredUserCount}
                onChange={value =>
                  setProfile({ ...profile, declaredUserCount: value })
                }
              />
              <Field
                label={isArabic ? "الفروع المعلنة" : "Declared branches"}
                type="number"
                value={profile.declaredBranchCount}
                onChange={value =>
                  setProfile({ ...profile, declaredBranchCount: value })
                }
              />
              <Field
                label={
                  isArabic ? "السعة الكلية (Mbps)" : "Total bandwidth (Mbps)"
                }
                type="number"
                value={profile.totalBandwidthMbps}
                onChange={value =>
                  setProfile({ ...profile, totalBandwidthMbps: value })
                }
              />
              <Field
                label={isArabic ? "حد تحذير السعة (%)" : "Capacity warning (%)"}
                type="number"
                value={profile.capacityWarningPercent}
                onChange={value =>
                  setProfile({ ...profile, capacityWarningPercent: value })
                }
              />
              <Field
                label={isArabic ? "سجل مصدر موثق" : "Sourced record"}
                value={profile.sourceLabel}
                onChange={value =>
                  setProfile({ ...profile, sourceLabel: value })
                }
                required
              />
            </div>
            <TextArea
              label={isArabic ? "الوصف" : "Description"}
              value={profile.description}
              onChange={value => setProfile({ ...profile, description: value })}
            />
            <div className="context-form two-col">
              <TextArea
                label="NOC"
                value={profile.nocInformation}
                onChange={value =>
                  setProfile({ ...profile, nocInformation: value })
                }
              />
              <TextArea
                label={isArabic ? "الدعم الفني" : "Technical support"}
                value={profile.technicalSupportInformation}
                onChange={value =>
                  setProfile({ ...profile, technicalSupportInformation: value })
                }
              />
              <TextArea
                label={isArabic ? "بيانات الاتصال" : "Contact information"}
                value={profile.contactInformation}
                onChange={value =>
                  setProfile({ ...profile, contactInformation: value })
                }
              />
              <TextArea
                label={isArabic ? "معلومات الصيانة" : "Maintenance information"}
                value={profile.maintenanceInformation}
                onChange={value =>
                  setProfile({ ...profile, maintenanceInformation: value })
                }
              />
            </div>
            <button
              className="action-button primary"
              disabled={
                saveProfile.isPending ||
                !profile.companyName.trim() ||
                !profile.sourceLabel.trim()
              }
              onClick={() =>
                saveProfile.mutate({
                  companyName: profile.companyName.trim(),
                  logoUrl: optionalText(profile.logoUrl),
                  description: optionalText(profile.description),
                  networkType: optionalText(profile.networkType),
                  declaredUserCount: asNumber(profile.declaredUserCount),
                  declaredBranchCount: asNumber(profile.declaredBranchCount),
                  totalBandwidthMbps: asNumber(profile.totalBandwidthMbps),
                  capacityWarningPercent: asNumber(
                    profile.capacityWarningPercent
                  ),
                  nocInformation: optionalText(profile.nocInformation),
                  technicalSupportInformation: optionalText(
                    profile.technicalSupportInformation
                  ),
                  contactInformation: optionalText(profile.contactInformation),
                  maintenanceInformation: optionalText(
                    profile.maintenanceInformation
                  ),
                  sourceLabel: profile.sourceLabel.trim(),
                })
              }
            >
              <Save size={15} />
              {isArabic ? "حفظ السياق" : "Save context"}
            </button>
          </article>
          <article
            className={`data-panel capacity-card ${warning ? "warning" : ""}`}
          >
            <h3>
              <Gauge size={17} />
              {isArabic ? "تخطيط السعة" : "Capacity planning"}
            </h3>
            {capacityState?.totalBandwidthMbps !== null &&
            capacityState?.totalBandwidthMbps !== undefined ? (
              <>
                <div className="capacity-number">
                  <b>{capacityState.totalBandwidthMbps.toFixed(2)}</b>
                  <span>
                    Mbps {isArabic ? "سعة معلنة" : "declared capacity"}
                  </span>
                </div>
                <dl>
                  <dt>{isArabic ? "الاستخدام الحالي" : "Current usage"}</dt>
                  <dd>
                    {capacityState.currentUsageMbps === null
                      ? unavailable
                      : `${capacityState.currentUsageMbps.toFixed(2)} Mbps`}
                  </dd>
                  <dt>{isArabic ? "نسبة الاستخدام" : "Utilization"}</dt>
                  <dd>
                    {capacityState.utilizationPercent === null
                      ? unavailable
                      : `${capacityState.utilizationPercent.toFixed(1)}%`}
                  </dd>
                  <dt>{isArabic ? "حد التحذير" : "Warning threshold"}</dt>
                  <dd>
                    {capacityState.warningPercent === null
                      ? unavailable
                      : `${capacityState.warningPercent}%`}
                  </dd>
                </dl>
                {warning && (
                  <p className="warning-copy">
                    {isArabic
                      ? "تحذير سعة: الاستخدام الموثق يساوي أو يتجاوز الحد الذي ضبطته المؤسسة."
                      : "Capacity warning: sourced usage meets or exceeds the organization-defined threshold."}
                  </p>
                )}
              </>
            ) : (
              <EmptyState
                title={isArabic ? "لا توجد سعة معلنة" : "No declared capacity"}
                copy={
                  isArabic
                    ? "أدخل سعة المؤسسة المرجعية أولاً؛ لن تُنشأ نسبة استخدام دونها."
                    : "Enter the organization reference capacity first; utilization is not created without it."
                }
              />
            )}
            <div className="context-form two-col">
              <Field
                label={isArabic ? "الحالي Mbps" : "Current Mbps"}
                type="number"
                value={capacity.currentUsageMbps}
                onChange={value =>
                  setCapacity({ ...capacity, currentUsageMbps: value })
                }
              />
              <Field
                label={isArabic ? "الذروة Mbps" : "Peak Mbps"}
                type="number"
                value={capacity.peakUsageMbps}
                onChange={value =>
                  setCapacity({ ...capacity, peakUsageMbps: value })
                }
              />
              <Field
                label={isArabic ? "المتوسط Mbps" : "Average Mbps"}
                type="number"
                value={capacity.averageUsageMbps}
                onChange={value =>
                  setCapacity({ ...capacity, averageUsageMbps: value })
                }
              />
              <Field
                label={isArabic ? "نافذة الذروة" : "Peak window"}
                value={capacity.peakWindow}
                onChange={value =>
                  setCapacity({ ...capacity, peakWindow: value })
                }
              />
              <Field
                label={isArabic ? "المصدر" : "Source"}
                value={capacity.sourceLabel}
                onChange={value =>
                  setCapacity({ ...capacity, sourceLabel: value })
                }
                required
              />
              <Field
                label={isArabic ? "وقت القياس UTC" : "Measured at UTC"}
                type="datetime-local"
                value={capacity.measuredAt}
                onChange={value =>
                  setCapacity({ ...capacity, measuredAt: value })
                }
              />
            </div>
            <button
              className="action-button"
              disabled={
                addCapacity.isPending ||
                (!capacity.currentUsageMbps &&
                  !capacity.peakUsageMbps &&
                  !capacity.averageUsageMbps) ||
                !capacity.sourceLabel.trim()
              }
              onClick={() =>
                addCapacity.mutate({
                  currentUsageMbps: asNumber(capacity.currentUsageMbps),
                  peakUsageMbps: asNumber(capacity.peakUsageMbps),
                  averageUsageMbps: asNumber(capacity.averageUsageMbps),
                  peakWindow: optionalText(capacity.peakWindow),
                  sourceLabel: capacity.sourceLabel.trim(),
                  measuredAt: new Date(capacity.measuredAt),
                })
              }
            >
              <Plus size={15} />
              {isArabic ? "حفظ لقطة سعة" : "Record capacity snapshot"}
            </button>
          </article>
        </section>
        <section className="context-layout">
          <article className="data-panel">
            <h3>
              <Globe2 size={17} />
              NETWORK IDENTITY
            </h3>
            <p className="muted">
              {isArabic
                ? "لا تُملأ الحقول غير المتاحة. تظهر في الواجهة والتقرير كـ «غير متوفر»، ولا تُحوّل إلى تقدير."
                : "Leave unavailable fields empty. They are rendered as “Not Available” in the interface and reports, never converted to estimates."}
            </p>
            <div className="context-form three-col">
              <Field
                label={isArabic ? "تسمية السجل" : "Record label"}
                value={identity.label}
                onChange={value => setIdentity({ ...identity, label: value })}
                required
              />
              {identityField("ISP", "ispName")}
              {identityField("ASN", "asn")}
              {identityField("AS Name", "asName")}
              {identityField(
                isArabic ? "اسم المنظمة" : "Organization name",
                "organizationName"
              )}
              {identityField(
                isArabic ? "العنوان العام" : "Public IP",
                "publicIp"
              )}
              {identityField("IPv4", "ipv4Status")}
              {identityField("IPv6", "ipv6Status")}
              {identityField(isArabic ? "نطاق ISP" : "ISP domain", "ispDomain")}
              {identityField(
                isArabic ? "بادئة الشبكة" : "Network prefix",
                "networkPrefix"
              )}
              {identityField(isArabic ? "الدولة" : "Country", "country")}
              {identityField(isArabic ? "المنطقة" : "Region", "region")}
              {identityField(isArabic ? "المدينة" : "City", "city")}
              {identityField("Hostname", "hostname")}
              {identityField("Reverse DNS", "reverseDns")}
              {identityField(
                isArabic ? "نوع الاتصال" : "Connection type",
                "connectionType"
              )}
              {identityField(
                isArabic ? "الشبكة المكتشفة" : "Detected network",
                "detectedNetwork"
              )}
              {identityField(
                isArabic ? "موفر الشبكة" : "Network provider",
                "networkProvider"
              )}
              <Field
                label={isArabic ? "المصدر" : "Source"}
                value={identity.sourceLabel}
                onChange={value =>
                  setIdentity({ ...identity, sourceLabel: value })
                }
                required
              />
            </div>
            <label className="context-check">
              <input
                type="checkbox"
                checked={identity.isPrimary}
                onChange={event =>
                  setIdentity({ ...identity, isPrimary: event.target.checked })
                }
              />
              {isArabic
                ? "اجعلها هوية الشبكة الأساسية"
                : "Mark as primary network identity"}
            </label>
            <button
              className="action-button primary"
              disabled={
                addIdentity.isPending ||
                !identity.label.trim() ||
                !identity.sourceLabel.trim()
              }
              onClick={() =>
                addIdentity.mutate({
                  label: identity.label.trim(),
                  isPrimary: identity.isPrimary,
                  ispName: optionalText(identity.ispName),
                  asn: optionalText(identity.asn),
                  asName: optionalText(identity.asName),
                  organizationName: optionalText(identity.organizationName),
                  publicIp: optionalText(identity.publicIp),
                  ipv4Status: optionalText(identity.ipv4Status),
                  ipv6Status: optionalText(identity.ipv6Status),
                  ispDomain: optionalText(identity.ispDomain),
                  networkPrefix: optionalText(identity.networkPrefix),
                  country: optionalText(identity.country),
                  region: optionalText(identity.region),
                  city: optionalText(identity.city),
                  hostname: optionalText(identity.hostname),
                  reverseDns: optionalText(identity.reverseDns),
                  connectionType: optionalText(identity.connectionType),
                  detectedNetwork: optionalText(identity.detectedNetwork),
                  networkProvider: optionalText(identity.networkProvider),
                  sourceLabel: identity.sourceLabel.trim(),
                })
              }
            >
              <Plus size={15} />
              {isArabic ? "إضافة هوية" : "Add identity"}
            </button>
            <div className="identity-list">
              {overview.data?.identities.length ? (
                overview.data.identities.map(item => (
                  <article key={item.id}>
                    <b>
                      {item.label}
                      {item.isPrimary
                        ? ` · ${isArabic ? "أساسية" : "Primary"}`
                        : ""}
                    </b>
                    <span>
                      {show(item.ispName)} · {show(item.asn)} ·{" "}
                      {show(item.publicIp)}
                    </span>
                    <small>
                      {show(item.networkPrefix)} · {show(item.country)} /{" "}
                      {show(item.city)} · {item.sourceLabel}
                    </small>
                  </article>
                ))
              ) : (
                <p className="muted">
                  {isArabic
                    ? "لا توجد هوية شبكة موثقة بعد."
                    : "No sourced network identity yet."}
                </p>
              )}
            </div>
          </article>
          <article className="data-panel">
            <h3>
              <Database size={17} />
              {isArabic ? "الحزم المرجعية" : "Reference packages"}
            </h3>
            <p className="muted">
              {isArabic
                ? "تُستخدم الحزمة فقط لمقارنة قياس محفوظ بنطاق أداء موثق؛ ليست منتجًا أو بوابة دفع أو اشتراكًا."
                : "A package is used only to compare a saved measurement against a sourced performance range; it is not a product, payment flow, or subscription."}
            </p>
            <div className="context-form two-col">
              <Field
                label={isArabic ? "اسم الحزمة" : "Package label"}
                value={pkg.label}
                onChange={value => setPkg({ ...pkg, label: value })}
                required
              />
              <Field
                label="Download Mbps"
                type="number"
                value={pkg.downloadMbps}
                onChange={value => setPkg({ ...pkg, downloadMbps: value })}
              />
              <Field
                label="Upload Mbps"
                type="number"
                value={pkg.uploadMbps}
                onChange={value => setPkg({ ...pkg, uploadMbps: value })}
              />
              <Field
                label={isArabic ? "حد تنزيل أدنى" : "Download min"}
                type="number"
                value={pkg.expectedDownloadMinMbps}
                onChange={value =>
                  setPkg({ ...pkg, expectedDownloadMinMbps: value })
                }
              />
              <Field
                label={isArabic ? "حد تنزيل أعلى" : "Download max"}
                type="number"
                value={pkg.expectedDownloadMaxMbps}
                onChange={value =>
                  setPkg({ ...pkg, expectedDownloadMaxMbps: value })
                }
              />
              <Field
                label={isArabic ? "حد رفع أدنى" : "Upload min"}
                type="number"
                value={pkg.expectedUploadMinMbps}
                onChange={value =>
                  setPkg({ ...pkg, expectedUploadMinMbps: value })
                }
              />
              <Field
                label={isArabic ? "حد رفع أعلى" : "Upload max"}
                type="number"
                value={pkg.expectedUploadMaxMbps}
                onChange={value =>
                  setPkg({ ...pkg, expectedUploadMaxMbps: value })
                }
              />
              <Field
                label={isArabic ? "المصدر" : "Source"}
                value={pkg.sourceLabel}
                onChange={value => setPkg({ ...pkg, sourceLabel: value })}
                required
              />
            </div>
            <button
              className="action-button"
              disabled={
                addPackage.isPending ||
                !pkg.label.trim() ||
                !pkg.sourceLabel.trim()
              }
              onClick={() =>
                addPackage.mutate({
                  label: pkg.label.trim(),
                  downloadMbps: asNumber(pkg.downloadMbps),
                  uploadMbps: asNumber(pkg.uploadMbps),
                  expectedDownloadMinMbps: asNumber(
                    pkg.expectedDownloadMinMbps
                  ),
                  expectedDownloadMaxMbps: asNumber(
                    pkg.expectedDownloadMaxMbps
                  ),
                  expectedUploadMinMbps: asNumber(pkg.expectedUploadMinMbps),
                  expectedUploadMaxMbps: asNumber(pkg.expectedUploadMaxMbps),
                  sourceLabel: pkg.sourceLabel.trim(),
                })
              }
            >
              <Plus size={15} />
              {isArabic ? "إضافة حزمة" : "Add package"}
            </button>
            <div className="identity-list">
              {overview.data?.packages.length ? (
                overview.data.packages.map(item => (
                  <article key={item.id}>
                    <b>{item.label}</b>
                    <span>
                      {item.downloadMbps === null
                        ? unavailable
                        : `${item.downloadMbps} Mbps ↓`}{" "}
                      ·{" "}
                      {item.uploadMbps === null
                        ? unavailable
                        : `${item.uploadMbps} Mbps ↑`}
                    </span>
                    <small>
                      {item.expectedDownloadMinMbps === null ||
                      item.expectedDownloadMaxMbps === null
                        ? unavailable
                        : `${item.expectedDownloadMinMbps}–${item.expectedDownloadMaxMbps} Mbps ↓`}{" "}
                      · {item.sourceLabel}
                    </small>
                  </article>
                ))
              ) : (
                <p className="muted">
                  {isArabic
                    ? "لا توجد حزمة موثقة بعد."
                    : "No sourced package yet."}
                </p>
              )}
            </div>
          </article>
        </section>
      </div>
    </ZeroGramShell>
  );
}

function Metric({
  icon,
  label,
  value,
  fallback,
}: {
  icon: React.ReactNode;
  label: string;
  value?: number;
  fallback: string;
}) {
  return (
    <article className="metric-card">
      <span>
        {icon}
        {label}
      </span>
      <b className="metric-value">{value === undefined ? fallback : value}</b>
      <i>INVENTORY / VERIFIED</i>
    </article>
  );
}
function Field({
  label,
  value,
  onChange,
  type = "text",
  required = false,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  type?: string;
  required?: boolean;
}) {
  return (
    <label>
      {label}
      {required && <em> *</em>}
      <input
        type={type}
        value={value}
        onChange={event => onChange(event.target.value)}
      />
    </label>
  );
}
function TextArea({
  label,
  value,
  onChange,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
}) {
  return (
    <label className="context-textarea">
      {label}
      <textarea
        value={value}
        onChange={event => onChange(event.target.value)}
      />
    </label>
  );
}
