import {
  EmptyState,
  SectionHeading,
  ZeroGramShell,
} from "@/components/ZeroGramShell";
import { useI18n } from "@/lib/i18n";
import { trpc } from "@/lib/trpc";
import {
  Activity,
  AlertTriangle,
  HeartPulse,
  Loader2,
  Radar,
} from "lucide-react";
import { useState } from "react";

const labels: Record<string, string> = {
  opticalScore: "Optical",
  networkScore: "Network",
  deviceScore: "Device",
  ethernetScore: "Ethernet",
  wifiScore: "Wi‑Fi",
  authenticationScore: "Authentication",
  serviceStabilityScore: "Service stability",
};
export default function FiberHealth() {
  const { isArabic } = useI18n();
  const overview = trpc.fiber.overview.useQuery();
  const [deviceId, setDeviceId] = useState<number | null>(null);
  const detail = trpc.fiber.deviceDetails.useQuery(
    { deviceId: deviceId || 1, telemetryDays: 90 },
    { enabled: Boolean(deviceId) }
  );
  const devices = overview.data?.devices || [];
  const health = detail.data?.health;
  return (
    <ZeroGramShell
      title={
        isArabic
          ? "صحة الألياف واستقرار الخدمة"
          : "Fiber health & service stability"
      }
      eyebrow="ZERO GRAM / HEALTH MATRIX"
    >
      <div className="page-content health-page">
        <SectionHeading
          index="F/H"
          title={
            isArabic
              ? "مصفوفة الصحة القابلة للتفسير"
              : "Explainable health matrix"
          }
          description={
            isArabic
              ? "تُحسب الدرجات من القياسات والحالات المحفوظة فقط. يظهر الاستقرار كتقييم مستقل لخدمة الوصول، لا كتنبؤ بضمان استمرار الخدمة."
              : "Scores are calculated only from stored measurements and states. Stability is an independent access-service assessment, not a guarantee of continuity."
          }
        />
        <section className="data-panel health-selector">
          <label>
            {isArabic ? "الجهاز" : "Device"}
            <select
              value={deviceId || ""}
              onChange={event =>
                setDeviceId(Number(event.target.value) || null)
              }
            >
              <option value="">—</option>
              {devices.map(device => (
                <option key={device.id} value={device.id}>
                  {device.label} · {device.deviceType}
                </option>
              ))}
            </select>
          </label>
        </section>
        {!deviceId ? (
          <EmptyState
            title={
              isArabic ? "اختر جهازًا من الجرد" : "Select an inventory device"
            }
            copy={
              isArabic
                ? "ستظهر LOF وDying Gasp ودرجات الصحة والتنبؤات فقط إن وفّرها سجلك الموثق."
                : "LOF, Dying Gasp, health scores and predictions only appear when they are supplied by your sourced records."
            }
          />
        ) : detail.isLoading ? (
          <div className="panel-loading">
            <Loader2 className="spin" />
          </div>
        ) : (
          <>
            <section className="health-matrix">
              <Score
                name={isArabic ? "الصحة العامة" : "Overall health"}
                score={health?.overallScore ?? null}
                icon={<HeartPulse />}
              />
              {Object.entries(labels).map(([key, name]) => (
                <Score
                  key={key}
                  name={
                    isArabic
                      ? (
                          {
                            opticalScore: "البصريات",
                            networkScore: "الشبكة",
                            deviceScore: "الجهاز",
                            ethernetScore: "Ethernet",
                            wifiScore: "Wi‑Fi",
                            authenticationScore: "المصادقة",
                            serviceStabilityScore: "استقرار الخدمة",
                          } as Record<string, string>
                        )[key]!
                      : name
                  }
                  score={(health as any)?.[key] ?? null}
                  icon={<Activity />}
                />
              ))}
            </section>
            <section className="health-detail-grid">
              <article className="data-panel">
                <h3>
                  <Radar size={16} />
                  {isArabic ? "حالة ONT / PON" : "ONT / PON state"}
                </h3>
                {detail.data?.unit ? (
                  <dl>
                    <dt>LOS</dt>
                    <dd>{detail.data.unit.losState || "—"}</dd>
                    <dt>LOF</dt>
                    <dd>{detail.data.unit.lofState || "—"}</dd>
                    <dt>Dying Gasp</dt>
                    <dd>{detail.data.unit.dyingGaspState || "—"}</dd>
                    <dt>PON</dt>
                    <dd>{detail.data.unit.ponStatus || "—"}</dd>
                    <dt>{isArabic ? "المصادقة" : "Authentication"}</dt>
                    <dd>{detail.data.unit.authenticationStatus || "—"}</dd>
                  </dl>
                ) : (
                  <p className="muted">
                    {isArabic
                      ? "لا توجد وحدة ONT/ONU مرتبطة بهذا الجهاز."
                      : "No ONT/ONU unit is linked to this device."}
                  </p>
                )}
              </article>
              <article className="data-panel">
                <h3>
                  <AlertTriangle size={16} />
                  {isArabic ? "التحذيرات التنبؤية" : "Predictive warnings"}
                </h3>
                {detail.data?.prediction.length ? (
                  detail.data.prediction.map(finding => (
                    <div className="finding-row" key={finding.id}>
                      <b>{finding.title}</b>
                      <small>{finding.evidence}</small>
                      <p>{finding.limitation}</p>
                    </div>
                  ))
                ) : (
                  <p className="muted">
                    {isArabic
                      ? "لا يوجد تاريخ كافٍ أو حدث متكرر لإنتاج تحذير مبكر."
                      : "There is not enough history or recurrence for an early warning."}
                  </p>
                )}
              </article>
            </section>
          </>
        )}
      </div>
    </ZeroGramShell>
  );
}
function Score({
  name,
  score,
  icon,
}: {
  name: string;
  score: number | null;
  icon: React.ReactNode;
}) {
  return (
    <article className="score-tile">
      <span>{icon}</span>
      <b>{score ?? "—"}</b>
      <small>{name}</small>
    </article>
  );
}
