import {
  EmptyState,
  SectionHeading,
  ZeroGramShell,
} from "@/components/ZeroGramShell";
import { useI18n } from "@/lib/i18n";
import { trpc } from "@/lib/trpc";
import { Copy, Link2, ShieldCheck, UserPlus, UsersRound } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

export default function TeamPage() {
  const { isArabic, t } = useI18n();
  const team = trpc.team.overview.useQuery();
  const [email, setEmail] = useState("");
  const [role, setRole] = useState<"admin" | "operator" | "viewer">("operator");
  const [inviteUrl, setInviteUrl] = useState("");
  const invite = trpc.team.createInvite.useMutation({
    onSuccess: result => {
      setInviteUrl(result.inviteUrl);
      team.refetch();
      toast.success(
        isArabic
          ? "أُنشئت دعوة قابلة للمشاركة."
          : "A shareable invitation was created."
      );
    },
    onError: error => toast.error(error.message),
  });
  const updateRole = trpc.team.updateRole.useMutation({
    onSuccess: () => {
      team.refetch();
      toast.success(
        isArabic ? "حُدّث الدور وسُجلت العملية." : "Role updated and logged."
      );
    },
    onError: error => toast.error(error.message),
  });
  return (
    <ZeroGramShell title={t("team")} eyebrow="ZERO GRAM / GOVERNANCE">
      <div className="page-content">
        <SectionHeading
          index="06"
          title={
            isArabic
              ? "أعضاء المؤسسة وسجل التدقيق"
              : "Organization members & audit log"
          }
          description={
            isArabic
              ? "الدعوات مقيدة بالبريد المحدد، وتنتهي بعد سبعة أيام. لا تمنح الصلاحيات إلا بعد أن يقبل المدعو الرابط بحسابه المطابق."
              : "Invites are restricted to their addressed email and expire after seven days. Roles are granted only after the recipient accepts the link with a matching account."
          }
        />
        <div className="team-grid">
          <section className="data-panel">
            <div className="panel-header">
              <h3>
                <UsersRound size={15} />
                {isArabic ? "الأعضاء" : "Members"}
              </h3>
              <span>{team.data?.members.length || 0}</span>
            </div>
            {team.isLoading ? (
              <div className="panel-loading">{t("loading")}</div>
            ) : team.data?.members.length ? (
              <div className="member-list">
                {team.data.members.map(member => (
                  <article key={member.id}>
                    <span>{member.name?.slice(0, 1).toUpperCase() || "Z"}</span>
                    <div>
                      <b>
                        {member.name ||
                          (isArabic ? "عضو مؤسسي" : "Organization member")}
                      </b>
                      <small>{member.email || "—"}</small>
                    </div>
                    {member.role === "owner" ? (
                      <i>{member.role}</i>
                    ) : (
                      <select
                        value={member.role}
                        onChange={event =>
                          updateRole.mutate({
                            memberId: member.id,
                            role: event.target.value as
                              | "admin"
                              | "operator"
                              | "viewer",
                          })
                        }
                      >
                        <option value="admin">admin</option>
                        <option value="operator">operator</option>
                        <option value="viewer">viewer</option>
                      </select>
                    )}
                  </article>
                ))}
              </div>
            ) : (
              <EmptyState
                title={t("noData")}
                copy={
                  isArabic
                    ? "سيظهر مالك المؤسسة هنا بعد أول عملية محمية."
                    : "The organization owner will appear here after the first protected operation."
                }
              />
            )}
          </section>
          <section className="data-panel invite-panel">
            <div className="panel-header">
              <h3>
                <UserPlus size={15} />
                {isArabic ? "دعوة عضو" : "Invite member"}
              </h3>
              <span>EMAIL BOUND</span>
            </div>
            <div className="invite-fields">
              <label>
                {isArabic ? "البريد الإلكتروني" : "Email address"}
                <input
                  dir="ltr"
                  value={email}
                  onChange={event => setEmail(event.target.value)}
                  placeholder="engineer@example.com"
                />
              </label>
              <label>
                {isArabic ? "الدور" : "Role"}
                <select
                  value={role}
                  onChange={event => setRole(event.target.value as typeof role)}
                >
                  <option value="admin">admin</option>
                  <option value="operator">operator</option>
                  <option value="viewer">viewer</option>
                </select>
              </label>
              <button
                className="action-button primary"
                disabled={invite.isPending}
                onClick={() =>
                  invite.mutate({ email, role, origin: window.location.origin })
                }
              >
                <Link2 size={15} />
                {isArabic ? "إنشاء رابط دعوة" : "Create invite link"}
              </button>
            </div>
            {inviteUrl && (
              <div className="invite-link">
                <code dir="ltr">{inviteUrl}</code>
                <button
                  onClick={() => {
                    navigator.clipboard.writeText(inviteUrl);
                    toast.success(isArabic ? "نُسخ الرابط." : "Link copied.");
                  }}
                >
                  <Copy size={15} />
                </button>
              </div>
            )}
          </section>
        </div>
        <section className="data-panel invitation-panel">
          <div className="panel-header">
            <h3>
              <ShieldCheck size={15} />
              {isArabic ? "حالة الدعوات" : "Invitation status"}
            </h3>
            <span>{team.data?.invitations.length || 0}</span>
          </div>
          {team.data?.invitations.length ? (
            <div className="invite-list">
              {team.data.invitations.map(item => (
                <article key={item.id}>
                  <div>
                    <b dir="ltr">{item.email}</b>
                    <small>
                      {isArabic ? "الدور: " : "Role: "}
                      {item.role} · {isArabic ? "تنتهي: " : "Expires: "}
                      {new Date(item.expiresAt).toLocaleDateString(
                        isArabic ? "ar" : "en"
                      )}
                    </small>
                  </div>
                  <span
                    className={`badge ${item.status === "accepted" ? "success" : "info"}`}
                  >
                    {item.status}
                  </span>
                </article>
              ))}
            </div>
          ) : (
            <EmptyState
              title={t("noData")}
              copy={
                isArabic
                  ? "أنشئ رابط دعوة آمنًا ليظهر هنا كسجل قابل للتدقيق."
                  : "Create a secure invite link to display it here as an auditable record."
              }
            />
          )}
        </section>
      </div>
    </ZeroGramShell>
  );
}
