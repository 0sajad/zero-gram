import { SectionHeading, ZeroGramShell } from "@/components/ZeroGramShell";
import { useI18n } from "@/lib/i18n";
import { trpc } from "@/lib/trpc";
import { Gauge, Save, ShieldCheck, SlidersHorizontal } from "lucide-react";
import { useEffect, useState } from "react";
import { toast } from "sonner";

type FormState = {
  opticalRxWarningDbm: string;
  opticalLossWarningDb: string;
  latencyWarningMs: string;
  jitterWarningMs: string;
  retentionDays: string;
  alertRepeatThreshold: string;
  sourceLabel: string;
};

const blank: FormState = {
  opticalRxWarningDbm: "",
  opticalLossWarningDb: "",
  latencyWarningMs: "",
  jitterWarningMs: "",
  retentionDays: "",
  alertRepeatThreshold: "",
  sourceLabel: "",
};

export default function MonitoringPolicy() {
  const { isArabic } = useI18n();
  const policy = trpc.fiber.monitoringPolicy.useQuery();
  const utils = trpc.useUtils();
  const [form, setForm] = useState<FormState>(blank);

  useEffect(() => {
    if (!policy.data) return;
    setForm({
      opticalRxWarningDbm: String(policy.data.opticalRxWarningDbm ?? ""),
      opticalLossWarningDb: String(policy.data.opticalLossWarningDb ?? ""),
      latencyWarningMs: String(policy.data.latencyWarningMs ?? ""),
      jitterWarningMs: String(policy.data.jitterWarningMs ?? ""),
      retentionDays: String(policy.data.retentionDays ?? ""),
      alertRepeatThreshold: String(policy.data.alertRepeatThreshold ?? ""),
      sourceLabel: policy.data.sourceLabel || "",
    });
  }, [policy.data]);

  const save = trpc.fiber.saveMonitoringPolicy.useMutation({
    onSuccess: async () => {
      await utils.fiber.monitoringPolicy.invalidate();
      toast.success(
        isArabic ? "حُفظت سياسة المراقبة." : "Monitoring policy saved."
      );
    },
  });

  const numeric = (value: string) => (value === "" ? undefined : Number(value));
  const update = (key: keyof FormState, value: string) =>
    setForm(current => ({ ...current, [key]: value }));
  const submit = (event: React.FormEvent) => {
    event.preventDefault();
    save.mutate({
      opticalRxWarningDbm: numeric(form.opticalRxWarningDbm),
      opticalLossWarningDb: numeric(form.opticalLossWarningDb),
      latencyWarningMs: numeric(form.latencyWarningMs),
      jitterWarningMs: numeric(form.jitterWarningMs),
      retentionDays: numeric(form.retentionDays),
      alertRepeatThreshold: numeric(form.alertRepeatThreshold),
      sourceLabel: form.sourceLabel,
    });
  };

  return (
    <ZeroGramShell
      title={isArabic ? "سياسة المراقبة" : "Monitoring policy"}
      eyebrow="ZERO GRAM / ORGANIZATION CONTROLS"
    >
      <div className="page-content policy-page">
        <SectionHeading
          index="F/POL"
          title={
            isArabic
              ? "عتبات مؤسستك وحدود التنبيه"
              : "Organization thresholds & alert boundaries"
          }
          description={
            isArabic
              ? "لا تُنشئ السياسة قياسات. تضبط متى ينبغي تفسير القياسات الحقيقية وإبقاؤها، ويظل مصدرها مرجعًا إلزاميًا."
              : "A policy does not create measurements. It controls when real measurements are interpreted and retained; a source reference remains required."
          }
        />
        <section className="policy-notice">
          <ShieldCheck size={17} />
          <p>
            {isArabic
              ? "تُحفظ القيم كسياسة للمؤسسة. راجع ميزانية البصريات ومواصفات المورد قبل اعتماد أي حد."
              : "Values are stored as organization policy. Review optical budgets and vendor specifications before adopting any threshold."}
          </p>
        </section>
        <form className="data-panel policy-form" onSubmit={submit}>
          <Field
            label={
              isArabic ? "تحذير Optical RX (dBm)" : "Optical RX warning (dBm)"
            }
            value={form.opticalRxWarningDbm}
            onChange={value => update("opticalRxWarningDbm", value)}
          />
          <Field
            label={
              isArabic ? "تحذير Optical Loss (dB)" : "Optical loss warning (dB)"
            }
            value={form.opticalLossWarningDb}
            onChange={value => update("opticalLossWarningDb", value)}
          />
          <Field
            label={isArabic ? "تحذير Latency (ms)" : "Latency warning (ms)"}
            value={form.latencyWarningMs}
            onChange={value => update("latencyWarningMs", value)}
          />
          <Field
            label={isArabic ? "تحذير Jitter (ms)" : "Jitter warning (ms)"}
            value={form.jitterWarningMs}
            onChange={value => update("jitterWarningMs", value)}
          />
          <Field
            label={isArabic ? "الاحتفاظ (أيام)" : "Retention (days)"}
            value={form.retentionDays}
            onChange={value => update("retentionDays", value)}
          />
          <Field
            label={isArabic ? "تكرار التنبيه" : "Alert repeat threshold"}
            value={form.alertRepeatThreshold}
            onChange={value => update("alertRepeatThreshold", value)}
          />
          <label className="policy-source">
            <span>
              {isArabic ? "مرجع مصدر السياسة" : "Policy source reference"}
            </span>
            <input
              required
              value={form.sourceLabel}
              onChange={event => update("sourceLabel", event.target.value)}
              placeholder={
                isArabic
                  ? "مثال: ميزانية ODN المعتمدة / سياسة NOC"
                  : "Example: approved ODN budget / NOC policy"
              }
            />
          </label>
          <button className="action-button primary" disabled={save.isPending}>
            <Save size={15} />
            {isArabic ? "حفظ السياسة" : "Save policy"}
          </button>
        </form>
        <section className="policy-explainer">
          <article>
            <Gauge size={17} />
            <b>{isArabic ? "العتبات" : "Thresholds"}</b>
            <p>
              {isArabic
                ? "تساعد في تفسير القياسات ولا تستبدل حدود المصنّع أو تصميم الشبكة."
                : "They guide interpretation; they do not replace manufacturer limits or network design."}
            </p>
          </article>
          <article>
            <SlidersHorizontal size={17} />
            <b>{isArabic ? "الاحتفاظ" : "Retention"}</b>
            <p>
              {isArabic
                ? "سجل مدة الاحتفاظ المطلوبة لتطبيقها ضمن سياسة التصدير والتنظيف المؤسسية."
                : "Records the requested retention window for organization export and cleanup policy."}
            </p>
          </article>
        </section>
      </div>
    </ZeroGramShell>
  );
}

function Field({
  label,
  value,
  onChange,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
}) {
  return (
    <label>
      <span>{label}</span>
      <input
        type="number"
        step="any"
        value={value}
        onChange={event => onChange(event.target.value)}
      />
    </label>
  );
}
