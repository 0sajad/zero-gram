import {
  EmptyState,
  SectionHeading,
  ZeroGramShell,
} from "@/components/ZeroGramShell";
import { useI18n } from "@/lib/i18n";
import { trpc } from "@/lib/trpc";
import { Cable, CheckCircle2, GitBranch, Loader2, Save } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

const nodeKinds = ["olt", "pon", "splitter", "fiber", "ont", "client"] as const;
export default function GponPath() {
  const { isArabic } = useI18n();
  const overview = trpc.fiber.overview.useQuery();
  const mutation = trpc.fiber.addGponPath.useMutation({
    onSuccess: result =>
      toast.success(
        isArabic
          ? `تم ربط ${result.edgeCount} وصلات في المسار.`
          : `${result.edgeCount} path links were created.`
      ),
  });
  const [values, setValues] = useState<Record<string, string>>({});
  const nodes = overview.data?.nodes || [];
  const submit = (event: React.FormEvent) => {
    event.preventDefault();
    mutation.mutate({
      oltNodeId: Number(values.olt),
      ponNodeId: Number(values.pon),
      splitterNodeId: Number(values.splitter),
      fiberNodeId: Number(values.fiber),
      ontNodeId: Number(values.ont),
      clientNodeId: Number(values.client),
      fiberLengthKm: values.length ? Number(values.length) : undefined,
      baselineLossDb: values.loss ? Number(values.loss) : undefined,
      sourceLabel: values.source || "Manual topology record",
    });
  };
  return (
    <ZeroGramShell
      title={isArabic ? "مسار GPON" : "GPON path"}
      eyebrow="ZERO GRAM / PATH BUILDER"
    >
      <div className="page-content gpon-path-page">
        <SectionHeading
          index="F/PATH"
          title={
            isArabic
              ? "سلسلة OLT → PON → Splitter → Fiber → ONT → Client"
              : "OLT → PON → Splitter → Fiber → ONT → Client"
          }
          description={
            isArabic
              ? "ينشئ هذا النموذج سلسلة تشغيلية صريحة من عقد موجودة ضمن مؤسستك، ويمنع تكرار العقدة ضمن المرحلة نفسها."
              : "This form creates one explicit operational path from existing organization nodes and prevents reusing a node as multiple stages."
          }
        />
        {overview.isLoading ? (
          <div className="panel-loading">
            <Loader2 className="spin" />
          </div>
        ) : !nodes.length ? (
          <EmptyState
            title={
              isArabic
                ? "أنشئ عقد الطوبولوجيا أولًا"
                : "Create topology nodes first"
            }
            copy={
              isArabic
                ? "أضف عقد OLT وPON وSplitter وFiber وONT وClient من صفحة Topology، ثم عد هنا لبناء المسار الموثق."
                : "Add OLT, PON, Splitter, Fiber, ONT and Client nodes from the Topology page, then return to build the sourced path."
            }
            action={
              <a className="action-button primary" href="/fiber">
                <GitBranch size={15} />
                {isArabic ? "فتح الطوبولوجيا" : "Open topology"}
              </a>
            }
          />
        ) : (
          <form className="data-panel gpon-path-form" onSubmit={submit}>
            {nodeKinds.map(kind => (
              <label key={kind}>
                <span>
                  <Cable size={13} />
                  {kind.toUpperCase()}
                </span>
                <select
                  required
                  value={values[kind] || ""}
                  onChange={event =>
                    setValues(current => ({
                      ...current,
                      [kind]: event.target.value,
                    }))
                  }
                >
                  <option value="">—</option>
                  {nodes
                    .filter(
                      node =>
                        node.nodeKind === kind ||
                        (kind === "ont" && node.nodeKind === "onu")
                    )
                    .map(node => (
                      <option key={node.id} value={node.id}>
                        {node.label} ·{" "}
                        {node.status ||
                          (isArabic ? "حالة غير مؤكدة" : "unconfirmed")}
                      </option>
                    ))}
                </select>
              </label>
            ))}
            <label>
              <span>{isArabic ? "طول الألياف (كم)" : "Fiber length (km)"}</span>
              <input
                type="number"
                step="any"
                min="0"
                value={values.length || ""}
                onChange={event =>
                  setValues(current => ({
                    ...current,
                    length: event.target.value,
                  }))
                }
              />
            </label>
            <label>
              <span>
                {isArabic ? "فقد خط الأساس (dB)" : "Baseline loss (dB)"}
              </span>
              <input
                type="number"
                step="any"
                min="0"
                value={values.loss || ""}
                onChange={event =>
                  setValues(current => ({
                    ...current,
                    loss: event.target.value,
                  }))
                }
              />
            </label>
            <label className="gpon-source">
              <span>
                {isArabic ? "مصدر التصميم أو السجل" : "Design or record source"}
              </span>
              <input
                required
                value={values.source || ""}
                onChange={event =>
                  setValues(current => ({
                    ...current,
                    source: event.target.value,
                  }))
                }
                placeholder={
                  isArabic
                    ? "مثال: مخطط توزيع Fiber الموثق"
                    : "Example: approved Fiber distribution plan"
                }
              />
            </label>
            <button
              className="action-button primary"
              disabled={mutation.isPending}
            >
              <Save size={15} />
              {mutation.isPending
                ? isArabic
                  ? "جارٍ الربط…"
                  : "Linking…"
                : isArabic
                  ? "حفظ المسار الصريح"
                  : "Save explicit path"}
            </button>
          </form>
        )}
        <div className="path-stage-legend">
          {nodeKinds.map((kind, index) => (
            <span key={kind}>
              {index ? <GitBranch size={13} /> : null}
              <b>{kind}</b>
            </span>
          ))}
          <span>
            <CheckCircle2 size={13} />
            {isArabic ? "دليل مصدر مطلوب" : "Source required"}
          </span>
        </div>
      </div>
    </ZeroGramShell>
  );
}
