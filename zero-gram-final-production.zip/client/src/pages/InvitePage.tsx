import { BrandMark } from "@/components/ZeroGramShell";
import { ShieldCheck } from "lucide-react";

export default function InvitePage({ params }: { params: { code: string } }) {
  void params;
  return (
    <main className="invite-page">
      <div className="scanlines" />
      <BrandMark />
      <section className="invite-card" role="status">
        <ShieldCheck />
        <p>ZERO GRAM / LOCAL WORKSPACE</p>
        <h1>Invitation access is disabled</h1>
        <span>
          This standalone build uses local guest mode and does not verify external
          email identities. Team invitations remain disabled until a local
          identity provider is configured on the server.
        </span>
      </section>
    </main>
  );
}
