import {
  EmptyState,
  SectionHeading,
  ZeroGramShell,
} from "@/components/ZeroGramShell";
import { useI18n } from "@/lib/i18n";
import { trpc } from "@/lib/trpc";
import {
  Activity,
  AlertTriangle,
  Check,
  ChevronRight,
  CircleHelp,
  Database,
  Download,
  Gauge,
  Loader2,
  Network,
  Save,
  Server,
  ShieldAlert,
  Upload,
  Wifi,
} from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import {
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { toast } from "sonner";
import type {
  ConnectionMeasurement,
  Diagnosis,
  SpeedTrace,
} from "../../../shared/networkDiagnostics";
import {
  calculateSpeedConsistency,
  diagnoseConnection,
} from "../../../shared/networkDiagnostics";

type Phase =
  | "idle"
  | "network"
  | "latency"
  | "download"
  | "upload"
  | "dns"
  | "complete"
  | "error";
type NavConnection = Navigator & {
  connection?: { type?: string; effectiveType?: string; saveData?: boolean };
};
type HistoryItem = {
  id: number;
  createdAt: Date;
  measurement: ConnectionMeasurement;
  quality?: string;
};
const now = () => performance.now();
const mean = (values: number[]) =>
  values.length
    ? values.reduce((sum, value) => sum + value, 0) / values.length
    : undefined;
const median = (values: number[]) => {
  const sorted = [...values].sort((a, b) => a - b);
  if (!sorted.length) return undefined;
  const middle = Math.floor(sorted.length / 2);
  return sorted.length % 2
    ? sorted[middle]
    : (sorted[middle - 1] + sorted[middle]) / 2;
};
const elapsedFetch = async (url: string, options?: RequestInit) => {
  const start = now();
  const response = await fetch(url, { cache: "no-store", ...options });
  const end = now();
  if (!response.ok) throw new Error(`HTTP ${response.status}`);
  await response.arrayBuffer();
  return { ms: end - start, response };
};
const fetchWithTimeout = async (
  url: string,
  options: RequestInit,
  timeoutMs: number
) => {
  const controller = new AbortController();
  const timeout = window.setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fetch(url, { ...options, signal: controller.signal });
  } finally {
    window.clearTimeout(timeout);
  }
};
const toSpeedTrace = (
  startedAt: number,
  bytes: number,
  elapsedMs: number
): SpeedTrace => ({
  elapsedMs: now() - startedAt,
  mbps: (bytes * 8) / (elapsedMs / 1000) / 1_000_000,
});

export default function TestPage() {
  const { isArabic, t } = useI18n();
  const isAuthenticated = true;
  const utils = trpc.useUtils();
  const [phase, setPhase] = useState<Phase>("idle");
  const [measurement, setMeasurement] = useState<ConnectionMeasurement | null>(
    null
  );
  const [diagnosis, setDiagnosis] = useState<Diagnosis | null>(null);
  const [sources, setSources] = useState<string[]>([]);
  const [limitations, setLimitations] = useState<string[]>([]);
  const [downloadTrace, setDownloadTrace] = useState<SpeedTrace[]>([]);
  const [uploadTrace, setUploadTrace] = useState<SpeedTrace[]>([]);
  const [historyWindow, setHistoryWindow] = useState<
    "today" | "yesterday" | "7d" | "30d" | "all"
  >("7d");
  const [selectedHistory, setSelectedHistory] = useState<number[]>([]);
  const [selectedPackageId, setSelectedPackageId] = useState<number | null>(
    null
  );
  const history = trpc.network.history.useQuery(undefined, {
    enabled: isAuthenticated,
  });
  const context = trpc.networkContext.overview.useQuery(undefined, {
    enabled: isAuthenticated,
  });
  const save = trpc.network.saveResult.useMutation({
    onSuccess: () => {
      toast.success(
        isArabic
          ? "حُفظت الجلسة ومنحنياتها ومصادرها."
          : "Session, traces, sources, and limits saved."
      );
      void history.refetch();
      void utils.networkContext.overview.invalidate();
    },
  });
  const phaseLabel: Record<Phase, string> = {
    idle: isArabic ? "بانتظار البدء" : "Waiting to start",
    network: isArabic
      ? "قراءة إمكانات المتصفح"
      : "Reading browser capabilities",
    latency: isArabic ? "قياس زمن استجابة الويب" : "Measuring web latency",
    download: isArabic
      ? "قياس تنزيل HTTP بعينات"
      : "Measuring sampled HTTP download",
    upload: isArabic ? "قياس رفع HTTP بعينات" : "Measuring sampled HTTP upload",
    dns: isArabic ? "قياس DoH DNS" : "Measuring DoH DNS",
    complete: isArabic ? "اكتمل القياس" : "Measurement complete",
    error: isArabic ? "تعذر إكمال القياس" : "Could not complete measurement",
  };
  const unavailable = isArabic ? "غير متوفر" : "Not Available";
  const runTest = async () => {
    const startedAt = now();
    setPhase("network");
    setMeasurement(null);
    setDiagnosis(null);
    setSources([]);
    setLimitations([]);
    setDownloadTrace([]);
    setUploadTrace([]);
    const browser = navigator as NavConnection;
    const next: ConnectionMeasurement = {
      networkType: browser.connection?.type,
      effectiveType: browser.connection?.effectiveType,
      saveData: browser.connection?.saveData,
      webrtc: Boolean(window.RTCPeerConnection),
    };
    const currentSources = [
      isArabic
        ? "إمكانات المتصفح: Network Information API عند دعمها، وWebRTC capability."
        : "Browser capability: Network Information API when supported, plus WebRTC capability.",
    ];
    const currentLimits = [
      isArabic
        ? "لا يستطيع المتصفح تنفيذ ICMP ping أو قراءة معدل الخط التعاقدي أو Gateway أو MTU أو تحديد سبب العطل النهائي."
        : "The browser cannot run ICMP ping, read contractual line speed, Gateway, MTU, or determine a final fault cause.",
    ];
    try {
      setPhase("latency");
      const latencySamples = await Promise.all(
        Array.from({ length: 4 }, () =>
          elapsedFetch(`/api/measure/bytes?bytes=1024&r=${crypto.randomUUID()}`)
        )
      );
      const latencyValues = latencySamples.map(sample => sample.ms);
      const latency = mean(latencyValues)!;
      const jitter =
        latencyValues
          .slice(1)
          .reduce(
            (sum, value, index) => sum + Math.abs(value - latencyValues[index]),
            0
          ) / Math.max(1, latencyValues.length - 1);
      const entry = performance
        .getEntriesByType("resource")
        .filter(
          (item): item is PerformanceResourceTiming =>
            item instanceof PerformanceResourceTiming
        )
        .filter(item => item.name.includes("/api/measure/bytes"))
        .at(-1);
      next.webLatencyMs = latency;
      next.jitterMs = jitter;
      if (entry && entry.responseStart > 0 && entry.requestStart > 0)
        next.ttfbMs = entry.responseStart - entry.requestStart;
      currentSources.push(
        isArabic
          ? "زمن استجابة الويب والتذبذب: أربع طلبات HTTP إلى نقطة قياس ZERO GRAM."
          : "Web latency and jitter: four HTTP requests to the ZERO GRAM measurement endpoint."
      );
      setPhase("download");
      const downloadPoints: SpeedTrace[] = [];
      for (let index = 0; index < 4; index++) {
        const sample = await elapsedFetch(
          `/api/measure/bytes?bytes=${512 * 1024}&r=${crypto.randomUUID()}`
        );
        const point = toSpeedTrace(startedAt, 512 * 1024, sample.ms);
        downloadPoints.push(point);
        setDownloadTrace([...downloadPoints]);
      }
      next.downloadTrace = downloadPoints;
      next.downloadMbps = mean(downloadPoints.map(point => point.mbps));
      next.downloadConsistencyPercent =
        calculateSpeedConsistency(downloadPoints);
      currentSources.push(
        isArabic
          ? "التنزيل: أربع عينات HTTP بحجم 512KiB من نقطة ZERO GRAM، والرسمة تعرض العينة عند إتمامها."
          : "Download: four 512 KiB HTTP samples from ZERO GRAM; the chart shows each completed sample."
      );
      currentLimits.push(
        isArabic
          ? "معدل التنزيل يتأثر بالمتصفح والخادم ونقطة القياس؛ ولا يمثل سعة الخط المضمونة."
          : "Download rate is affected by browser, server, and endpoint; it does not represent guaranteed line capacity."
      );
      setPhase("upload");
      const uploadPoints: SpeedTrace[] = [];
      const uploadBody = new Uint8Array(256 * 1024);
      for (let index = 0; index < 4; index++) {
        const sampleStart = now();
        const response = await fetch("/api/measure/upload", {
          method: "POST",
          headers: {
            "Content-Type": "application/octet-stream",
            "Cache-Control": "no-store",
          },
          body: uploadBody,
        });
        if (!response.ok) throw new Error(`Upload HTTP ${response.status}`);
        await response.json();
        const point = toSpeedTrace(
          startedAt,
          uploadBody.byteLength,
          now() - sampleStart
        );
        uploadPoints.push(point);
        setUploadTrace([...uploadPoints]);
      }
      next.uploadTrace = uploadPoints;
      next.uploadMbps = mean(uploadPoints.map(point => point.mbps));
      next.uploadConsistencyPercent = calculateSpeedConsistency(uploadPoints);
      currentSources.push(
        isArabic
          ? "الرفع: أربع عينات HTTP بحجم 256KiB إلى نقطة ZERO GRAM، والرسمة تعرض العينة عند إتمامها."
          : "Upload: four 256 KiB HTTP samples to ZERO GRAM; the chart shows each completed sample."
      );
      setPhase("dns");
      try {
        const dnsStart = now();
        const dnsResponse = await fetchWithTimeout(
          `https://cloudflare-dns.com/dns-query?name=example.com&type=A&r=${crypto.randomUUID()}`,
          { headers: { Accept: "application/dns-json" }, cache: "no-store" },
          5_000
        );
        if (dnsResponse.ok) {
          await dnsResponse.json();
          next.dnsMs = now() - dnsStart;
          currentSources.push(
            isArabic
              ? "DNS: طلب DNS-over-HTTPS إلى Cloudflare للاسم example.com."
              : "DNS: DNS-over-HTTPS request to Cloudflare for example.com."
          );
          currentLimits.push(
            isArabic
              ? "زمن DNS يرتبط بالخدمة الخارجية والتخزين المؤقت والمسار، ولا يصف كل خوادم DNS."
              : "DNS time depends on the external resolver, caching, and route; it does not describe every DNS server."
          );
        } else
          currentLimits.push(
            isArabic
              ? "لم تكتمل عينة DoH DNS في هذه الجلسة."
              : "The DoH DNS sample did not complete in this session."
          );
      } catch {
        currentLimits.push(
          isArabic
            ? "لم تتوفر عينة DoH DNS خلال مهلة 5 ثوانٍ بسبب قيود المتصفح أو المسار في هذه الجلسة."
            : "The DoH DNS sample was unavailable within the 5-second limit because of browser or route constraints."
        );
      }
      const lossResults = await Promise.allSettled(
        Array.from({ length: 5 }, () =>
          elapsedFetch(`/api/measure/bytes?bytes=512&r=${crypto.randomUUID()}`)
        )
      );
      const failed = lossResults.filter(
        item => item.status === "rejected"
      ).length;
      if (failed) {
        next.packetLossEstimate = (failed / lossResults.length) * 100;
        currentSources.push(
          isArabic
            ? "تقدير فقد العينات: طلبات HTTP صغيرة إلى نقطة القياس."
            : "Sample-loss estimate: small HTTP requests to the measurement endpoint."
        );
        currentLimits.push(
          isArabic
            ? "فشل عينة HTTP ليس مكافئًا لفقد حزم طبقة الشبكة."
            : "A failed HTTP sample is not equivalent to network-layer packet loss."
        );
      }
      next.testDurationMs = now() - startedAt;
      const builtDiagnosis = diagnoseConnection(next);
      setMeasurement(next);
      setDiagnosis(builtDiagnosis);
      setSources(currentSources);
      setLimitations(currentLimits);
      setPhase("complete");
    } catch (error) {
      setPhase("error");
      setLimitations([
        ...currentLimits,
        error instanceof Error ? error.message : String(error),
      ]);
      toast.error(
        isArabic
          ? "توقف الفحص قبل اكتمال بعض القياسات."
          : "The test stopped before all measurements completed."
      );
    }
  };
  useEffect(() => {
    if (sessionStorage.getItem("zg-start-test") === "1" && phase === "idle") {
      sessionStorage.removeItem("zg-start-test");
      void runTest();
    }
  }, [phase]);
  const metricTrace = useMemo(
    () => ({
      downloadMbps: {
        source: isArabic
          ? "أربع عينات تنزيل HTTP"
          : "Four HTTP download samples",
        precision: "0.01 Mbps",
        limitation: isArabic
          ? "لا يمثل سعة الخط التعاقدية."
          : "Does not represent contractual line capacity.",
      },
      uploadMbps: {
        source: isArabic ? "أربع عينات رفع HTTP" : "Four HTTP upload samples",
        precision: "0.01 Mbps",
        limitation: isArabic
          ? "يتأثر بالمتصفح والخادم والمسار."
          : "Affected by browser, server, and route.",
      },
      webLatencyMs: {
        source: isArabic
          ? "متوسط أربع رحلات HTTP"
          : "Mean of four HTTP round trips",
        precision: "1 ms",
        limitation: isArabic ? "ليس ICMP ping." : "Not ICMP ping.",
      },
      jitterMs: {
        source: isArabic
          ? "فروق عينات HTTP المتتالية"
          : "Differences between consecutive HTTP samples",
        precision: "1 ms",
        limitation: isArabic
          ? "يقيس نقطة الاختبار فقط."
          : "Measures the test endpoint only.",
      },
      ttfbMs: {
        source: isArabic
          ? "Performance Resource Timing"
          : "Browser Performance Resource Timing",
        precision: "1 ms",
        limitation: isArabic
          ? "قد لا يتاح عند غياب توقيت المورد."
          : "Unavailable if resource timing is absent.",
      },
      dnsMs: {
        source: isArabic ? "DoH إلى Cloudflare" : "Cloudflare DoH request",
        precision: "1 ms",
        limitation: isArabic
          ? "يتأثر بالتخزين المؤقت والخدمة."
          : "Affected by caching and resolver.",
      },
      downloadConsistencyPercent: {
        source: isArabic
          ? "تباين عينات التنزيل الفعلية"
          : "Actual download sample variation",
        precision: "1%",
        limitation: isArabic ? "ليس معيار SLA." : "Not an SLA measurement.",
      },
      uploadConsistencyPercent: {
        source: isArabic
          ? "تباين عينات الرفع الفعلية"
          : "Actual upload sample variation",
        precision: "1%",
        limitation: isArabic ? "ليس معيار SLA." : "Not an SLA measurement.",
      },
    }),
    [isArabic]
  );
  const formatted = useMemo(
    () =>
      measurement
        ? [
            {
              key: "downloadMbps",
              label: isArabic ? "تنزيل HTTP" : "HTTP download",
              value: measurement.downloadMbps,
              unit: "Mbps",
            },
            {
              key: "uploadMbps",
              label: isArabic ? "رفع HTTP" : "HTTP upload",
              value: measurement.uploadMbps,
              unit: "Mbps",
            },
            {
              key: "webLatencyMs",
              label: isArabic ? "استجابة الويب" : "Web latency",
              value: measurement.webLatencyMs,
              unit: "ms",
            },
            {
              key: "jitterMs",
              label: isArabic ? "التذبذب" : "Jitter",
              value: measurement.jitterMs,
              unit: "ms",
            },
            {
              key: "ttfbMs",
              label: "TTFB",
              value: measurement.ttfbMs,
              unit: "ms",
            },
            {
              key: "dnsMs",
              label: "DoH DNS",
              value: measurement.dnsMs,
              unit: "ms",
            },
            {
              key: "downloadConsistencyPercent",
              label: isArabic ? "اتساق التنزيل" : "Download consistency",
              value: measurement.downloadConsistencyPercent,
              unit: "%",
            },
            {
              key: "uploadConsistencyPercent",
              label: isArabic ? "اتساق الرفع" : "Upload consistency",
              value: measurement.uploadConsistencyPercent,
              unit: "%",
            },
          ]
        : [],
    [measurement, isArabic]
  );
  const identity =
    context.data?.identities.find(item => item.isPrimary) ||
    context.data?.identities[0];
  const packageRef = context.data?.packages.find(
    item => item.id === selectedPackageId
  );
  const packagePerformance =
    packageRef?.downloadMbps && measurement?.downloadMbps
      ? (measurement.downloadMbps / packageRef.downloadMbps) * 100
      : undefined;
  const historyItems = useMemo<HistoryItem[]>(
    () =>
      (history.data || []).flatMap(row => {
        try {
          const payload = JSON.parse(row.payloadJson) as {
            measurement?: ConnectionMeasurement;
            diagnosis?: Diagnosis;
          };
          return payload.measurement
            ? [
                {
                  id: row.id,
                  createdAt: new Date(row.createdAt),
                  measurement: payload.measurement,
                  quality: payload.diagnosis?.quality,
                },
              ]
            : [];
        } catch {
          return [];
        }
      }),
    [history.data]
  );
  const historyCutoff = useMemo(() => {
    const date = new Date();
    if (historyWindow === "today") date.setHours(0, 0, 0, 0);
    else if (historyWindow === "yesterday") {
      date.setDate(date.getDate() - 1);
      date.setHours(0, 0, 0, 0);
    } else if (historyWindow === "7d") date.setDate(date.getDate() - 7);
    else if (historyWindow === "30d") date.setDate(date.getDate() - 30);
    else return new Date(0);
    return date;
  }, [historyWindow]);
  const visibleHistory = useMemo(
    () =>
      historyItems.filter(item =>
        historyWindow !== "yesterday"
          ? item.createdAt >= historyCutoff
          : item.createdAt >= historyCutoff &&
            item.createdAt < new Date(historyCutoff.getTime() + 86_400_000)
      ),
    [historyItems, historyWindow, historyCutoff]
  );
  const compared = visibleHistory.filter(item =>
    selectedHistory.includes(item.id)
  );
  const comparison = useMemo(() => {
    if (compared.length < 2) return null;
    const downloads = compared
      .map(item => item.measurement.downloadMbps)
      .filter((value): value is number => value !== undefined);
    const latencies = compared
      .map(item => item.measurement.webLatencyMs)
      .filter((value): value is number => value !== undefined);
    const stability = compared
      .map(item => item.measurement.downloadConsistencyPercent)
      .filter((value): value is number => value !== undefined);
    const first = compared.at(-1)?.measurement.downloadMbps;
    const last = compared[0]?.measurement.downloadMbps;
    return {
      best: downloads.length ? Math.max(...downloads) : undefined,
      worst: downloads.length ? Math.min(...downloads) : undefined,
      average: mean(downloads),
      median: median(downloads),
      averagePing: mean(latencies),
      highestLatency: latencies.length ? Math.max(...latencies) : undefined,
      stability: mean(stability),
      change:
        first !== undefined && last !== undefined ? last - first : undefined,
      percentageDifference:
        first && last !== undefined
          ? ((last - first) / first) * 100
          : undefined,
    };
  }, [compared]);
  const setSelected = (id: number) =>
    setSelectedHistory(current =>
      current.includes(id)
        ? current.filter(value => value !== id)
        : [...current, id].slice(0, 8)
    );
  return (
    <ZeroGramShell title={t("test")} eyebrow="ZERO GRAM / SPEED & DIAGNOSTICS">
      <div className="page-content test-page">
        <SectionHeading
          index="01"
          title={
            isArabic
              ? "جلسة سرعة وتحليل متدرج"
              : "Progressive speed & diagnostics session"
          }
          description={
            isArabic
              ? "العينات والرسوم المعروضة تقيس HTTP/DoH من المتصفح فقط. لا يُستبدل Ping بـ ICMP ولا تُعرض معلومة شبكة غير موثقة."
              : "Displayed samples and charts measure browser HTTP/DoH only. Web latency is not presented as ICMP ping, and unsourced network facts are never fabricated."
          }
          action={
            <button
              onClick={runTest}
              disabled={!["idle", "complete", "error"].includes(phase)}
              className="action-button primary"
            >
              {phase === "idle" || phase === "complete" || phase === "error" ? (
                <Activity size={16} />
              ) : (
                <Loader2 className="spin" size={16} />
              )}
              {phase === "complete"
                ? isArabic
                  ? "فحص جديد"
                  : "New test"
                : t("start")}
            </button>
          }
        />
        <div className="test-layout">
          <section className="data-panel phase-panel">
            <div className="panel-header">
              <h3>{isArabic ? "مراحل الجلسة" : "Session stages"}</h3>
              <span>{phaseLabel[phase]}</span>
            </div>
            <div className="phase-list">
              {(
                [
                  [
                    "network",
                    isArabic ? "بيئة المتصفح" : "Browser environment",
                  ],
                  ["latency", isArabic ? "استجابة الويب" : "Web latency"],
                  ["download", isArabic ? "تنزيل HTTP ×4" : "HTTP download ×4"],
                  ["upload", isArabic ? "رفع HTTP ×4" : "HTTP upload ×4"],
                  ["dns", "DoH DNS"],
                ] as const
              ).map(([key, label], index) => (
                <div
                  key={key}
                  className={
                    phase === key ||
                    (["complete", "error"].includes(phase) && measurement)
                      ? "phase active"
                      : "phase"
                  }
                >
                  <span>{String(index + 1).padStart(2, "0")}</span>
                  <b>{label}</b>
                  {phase === key ? (
                    <Loader2 className="spin" size={15} />
                  ) : phase === "complete" && measurement ? (
                    <Check size={15} />
                  ) : (
                    <span className="phase-dot" />
                  )}
                </div>
              ))}
            </div>
            <div className="browser-facts">
              <Wifi size={17} />
              <div>
                <b>
                  {isArabic ? "المتاح من المتصفح" : "Available from browser"}
                </b>
                <p>
                  {measurement?.effectiveType ||
                    (navigator as NavConnection).connection?.effectiveType ||
                    t("unavailable")}{" "}
                  · WebRTC{" "}
                  {(measurement?.webrtc ?? Boolean(window.RTCPeerConnection))
                    ? "supported"
                    : "unavailable"}
                </p>
              </div>
            </div>
          </section>
          <section className="results-column">
            {measurement ? (
              <>
                <div className="metric-grid">
                  {formatted.map(metric => (
                    <article className="metric-card" key={metric.key}>
                      <span>{metric.label}</span>
                      <b className="metric-value">
                        {metric.value !== undefined
                          ? metric.value.toFixed(metric.unit === "Mbps" ? 2 : 0)
                          : "—"}
                        <small>
                          {metric.value !== undefined ? metric.unit : ""}
                        </small>
                      </b>
                      <i>
                        {metric.value !== undefined
                          ? `${t("live")} · ${metricTrace[metric.key as keyof typeof metricTrace].precision}`
                          : t("unavailable")}
                      </i>
                    </article>
                  ))}
                </div>
                <section className="data-panel speed-trace-panel">
                  <header>
                    <div>
                      <Activity size={16} />
                      <b>
                        {isArabic
                          ? "منحنيات العينات الحية"
                          : "Live sample traces"}
                      </b>
                    </div>
                    <small>
                      {isArabic
                        ? "كل نقطة عينة HTTP مكتملة"
                        : "Each point is a completed HTTP sample"}
                    </small>
                  </header>
                  <SpeedChart
                    title={isArabic ? "التنزيل" : "Download"}
                    color="#43dbf4"
                    points={downloadTrace}
                  />
                  <SpeedChart
                    title={isArabic ? "الرفع" : "Upload"}
                    color="#e85dc9"
                    points={uploadTrace}
                  />
                </section>
                <div className="data-panel result-panel">
                  <div className="panel-header">
                    <h3>
                      {isArabic
                        ? "ذكاء جودة الجلسة"
                        : "Session quality intelligence"}
                    </h3>
                    {diagnosis?.netScore !== undefined ? (
                      <span className="score-chip">
                        {diagnosis.quality} · {diagnosis.netScore}/100
                      </span>
                    ) : (
                      <span>{t("unavailable")}</span>
                    )}
                  </div>
                  <div className="finding-list">
                    {diagnosis?.findings.map(finding => (
                      <article className="finding" key={finding.id}>
                        <span className={`badge ${finding.level}`}>
                          {finding.level}
                        </span>
                        <div>
                          <h4>{finding.title}</h4>
                          <p>
                            <b>{isArabic ? "الدليل: " : "Evidence: "}</b>
                            {finding.evidence}
                          </p>
                          <small>
                            {isArabic ? "الثقة: " : "Confidence: "}
                            {finding.confidence} · {finding.limitation}
                          </small>
                          <div className="safe-step">
                            <ShieldAlert size={15} />
                            {finding.safeNextStep}
                          </div>
                        </div>
                      </article>
                    ))}
                  </div>
                  {diagnosis?.missing.length ? (
                    <div className="missing-note">
                      <CircleHelp size={15} />
                      {diagnosis.missing.join(" ")}
                    </div>
                  ) : null}
                  <div className="methodology">
                    <Gauge size={16} />
                    {diagnosis?.methodology}
                  </div>
                </div>
                <div className="test-actions">
                  <button
                    className="action-button"
                    onClick={() =>
                      toast.info(
                        isArabic
                          ? "يُحفظ السجل في مساحة العمل المحلية لهذا الخادم."
                          : "Saved to this server's local workspace."
                      )
                    }
                  >
                    {isAuthenticated ? (
                      <Save size={15} />
                    ) : (
                      <Database size={15} />
                    )}
                    {t("save")}
                  </button>
                  {isAuthenticated && (
                    <button
                      className="action-button primary"
                      disabled={save.isPending}
                      onClick={() =>
                        save.mutate({
                          measurement,
                          sources,
                          limitations,
                          metricTrace,
                        })
                      }
                    >
                      <Save size={15} />
                      {save.isPending ? t("loading") : t("save")}
                    </button>
                  )}
                </div>
              </>
            ) : (
              <EmptyState
                title={
                  isArabic ? "لم تبدأ جلسة قياس" : "No measurement session yet"
                }
                copy={
                  isArabic
                    ? "ابدأ الاختبار لرؤية قياسات HTTP/DoH حقيقية ومنحنيات العينات؛ وما لا يستطيع المتصفح قياسه سيبقى معلنًا بوضوح."
                    : "Start a test to see real HTTP/DoH measurements and sample traces; anything the browser cannot measure stays clearly unavailable."
                }
                action={
                  <button className="action-button primary" onClick={runTest}>
                    <Activity size={16} />
                    {t("start")}
                  </button>
                }
              />
            )}
          </section>
        </div>
        <section className="speed-context-grid">
          <article className="data-panel">
            <h3>
              <Globe2Icon />
              {isArabic ? "هوية الشبكة المرتبطة" : "Linked network identity"}
            </h3>
            {identity ? (
              <dl>
                <dt>ISP</dt>
                <dd>{identity.ispName || unavailable}</dd>
                <dt>ASN</dt>
                <dd>{identity.asn || unavailable}</dd>
                <dt>{isArabic ? "العنوان العام" : "Public IP"}</dt>
                <dd>{identity.publicIp || unavailable}</dd>
                <dt>{isArabic ? "الموقع" : "Location"}</dt>
                <dd>
                  {[identity.country, identity.region, identity.city]
                    .filter(Boolean)
                    .join(" / ") || unavailable}
                </dd>
                <dt>{isArabic ? "المصدر" : "Source"}</dt>
                <dd>{identity.sourceLabel}</dd>
              </dl>
            ) : (
              <EmptyState
                title={isArabic ? "لا توجد هوية موثقة" : "No sourced identity"}
                copy={
                  isArabic
                    ? "أضف هوية يدويًا من سياق الشبكة لربط ISP وASN والعناوين بالتاريخ والتقرير."
                    : "Add a manual identity in Network Context to link ISP, ASN, and addresses to history and reports."
                }
              />
            )}
          </article>
          <article className="data-panel">
            <h3>
              <Server size={16} />
              {isArabic
                ? "نقطة الاختبار والبيانات غير المتاحة"
                : "Test server & unavailable facts"}
            </h3>
            <dl>
              <dt>{isArabic ? "معرّف الخادم" : "Server ID"}</dt>
              <dd>ZERO-GRAM-HTTP</dd>
              <dt>{isArabic ? "المضيف" : "Server host"}</dt>
              <dd>{window.location.host}</dd>
              <dt>
                {isArabic ? "موقع/مسافة الخادم" : "Server location/distance"}
              </dt>
              <dd>{unavailable}</dd>
              <dt>{isArabic ? "Gateway / MTU" : "Gateway / MTU"}</dt>
              <dd>{unavailable}</dd>
              <dt>{isArabic ? "الواجهة" : "Network interface"}</dt>
              <dd>{measurement?.networkType || unavailable}</dd>
              <dt>DNS</dt>
              <dd>
                {measurement?.dnsMs === undefined
                  ? unavailable
                  : `${measurement.dnsMs.toFixed(0)} ms (DoH)`}
              </dd>
            </dl>
            <p className="muted">
              {isArabic
                ? "هذه الجلسة لا تقرأ Gateway أو MTU أو الموقع أو المسافة من المتصفح؛ لذلك لا تُقدّرها المنصة."
                : "This browser session cannot read Gateway, MTU, location, or distance, so ZERO GRAM does not estimate them."}
            </p>
          </article>
          <article className="data-panel">
            <h3>
              <Network size={16} />
              {isArabic ? "أداء الحزمة" : "Package performance"}
            </h3>
            <label className="metric-filter">
              <select
                value={selectedPackageId || ""}
                onChange={event =>
                  setSelectedPackageId(Number(event.target.value) || null)
                }
              >
                <option value="">
                  {isArabic ? "اختر حزمة موثقة" : "Select a sourced package"}
                </option>
                {(context.data?.packages || []).map(item => (
                  <option key={item.id} value={item.id}>
                    {item.label}
                  </option>
                ))}
              </select>
            </label>
            {packageRef && measurement ? (
              <dl>
                <dt>{isArabic ? "المقاس" : "Measured"}</dt>
                <dd>
                  {measurement.downloadMbps?.toFixed(2) || unavailable} Mbps
                </dd>
                <dt>{isArabic ? "المتوقع" : "Expected"}</dt>
                <dd>
                  {packageRef.expectedDownloadMinMbps === null ||
                  packageRef.expectedDownloadMaxMbps === null
                    ? unavailable
                    : `${packageRef.expectedDownloadMinMbps}–${packageRef.expectedDownloadMaxMbps} Mbps`}
                </dd>
                <dt>{isArabic ? "مقابل المرجع" : "Against reference"}</dt>
                <dd>
                  {packagePerformance === undefined
                    ? unavailable
                    : `${packagePerformance.toFixed(1)}%`}
                </dd>
              </dl>
            ) : (
              <p className="muted">
                {isArabic
                  ? "تتطلب المقارنة حزمة موثقة وجلسة قياس مكتملة. مقارنة HTTP لا تثبت أداء العقد التعاقدي وحدها."
                  : "Comparison requires a sourced package and a completed session. HTTP comparison alone does not prove contractual performance."}
              </p>
            )}
          </article>
        </section>
        <div className="data-panel sources-panel">
          <div className="panel-header">
            <h3>
              {t("source")} + {t("limitations")}
            </h3>
            <span>TRACEABLE / HUMAN-READABLE</span>
          </div>
          <div className="source-columns">
            <div>
              <h4>{t("source")}</h4>
              {sources.length ? (
                sources.map(source => (
                  <p key={source}>
                    <ChevronRight size={13} />
                    {source}
                  </p>
                ))
              ) : (
                <p className="muted">
                  {isArabic
                    ? "ستظهر مصادر القياس بعد تشغيل جلسة حقيقية."
                    : "Measurement sources appear after a real session runs."}
                </p>
              )}
            </div>
            <div>
              <h4>{t("limitations")}</h4>
              {limitations.length ? (
                limitations.map(limit => (
                  <p key={limit}>
                    <AlertTriangle size={13} />
                    {limit}
                  </p>
                ))
              ) : (
                <p className="muted">
                  {isArabic
                    ? "ستظهر حدود القياس هنا بعد التشغيل."
                    : "Measurement limits appear here after the run."}
                </p>
              )}
            </div>
          </div>
          {measurement && (
            <div className="metric-trace-list">
              {formatted.map(metric => {
                const trace =
                  metricTrace[metric.key as keyof typeof metricTrace];
                return (
                  <article key={metric.key}>
                    <b>{metric.label}</b>
                    <span>
                      {isArabic ? "المصدر: " : "Source: "}
                      {trace.source}
                    </span>
                    <span>
                      {isArabic ? "الدقة: " : "Precision: "}
                      {trace.precision}
                    </span>
                    <small>
                      {isArabic ? "الحد: " : "Limit: "}
                      {trace.limitation}
                    </small>
                  </article>
                );
              })}
            </div>
          )}
        </div>
        {isAuthenticated && (
          <section className="data-panel speed-history-panel">
            <header>
              <div>
                <Database size={16} />
                <h3>
                  {isArabic
                    ? "تاريخ السرعة والمقارنة"
                    : "Speed history & comparison"}
                </h3>
              </div>
              <div className="history-window">
                {(["today", "yesterday", "7d", "30d", "all"] as const).map(
                  value => (
                    <button
                      key={value}
                      className={historyWindow === value ? "active" : ""}
                      onClick={() => setHistoryWindow(value)}
                    >
                      {value === "today"
                        ? isArabic
                          ? "اليوم"
                          : "Today"
                        : value === "yesterday"
                          ? isArabic
                            ? "أمس"
                            : "Yesterday"
                          : value === "all"
                            ? isArabic
                              ? "الكل"
                              : "All"
                            : value}
                    </button>
                  )
                )}
              </div>
            </header>
            {visibleHistory.length ? (
              <>
                <div className="history-result-list">
                  {visibleHistory.map(item => (
                    <label key={item.id}>
                      <input
                        type="checkbox"
                        checked={selectedHistory.includes(item.id)}
                        onChange={() => setSelected(item.id)}
                      />
                      <span>
                        {item.createdAt.toLocaleString()} · ↓{" "}
                        {item.measurement.downloadMbps?.toFixed(2) ||
                          unavailable}{" "}
                        Mbps · {item.quality || unavailable}
                      </span>
                    </label>
                  ))}
                </div>
                {comparison && (
                  <div className="comparison-grid">
                    <Compare
                      label={isArabic ? "الأفضل" : "Best"}
                      value={comparison.best}
                      unit="Mbps"
                    />
                    <Compare
                      label={isArabic ? "الأسوأ" : "Worst"}
                      value={comparison.worst}
                      unit="Mbps"
                    />
                    <Compare
                      label={isArabic ? "المتوسط" : "Average"}
                      value={comparison.average}
                      unit="Mbps"
                    />
                    <Compare
                      label={isArabic ? "الوسيط" : "Median"}
                      value={comparison.median}
                      unit="Mbps"
                    />
                    <Compare
                      label={isArabic ? "متوسط الاستجابة" : "Average latency"}
                      value={comparison.averagePing}
                      unit="ms"
                    />
                    <Compare
                      label={isArabic ? "أعلى استجابة" : "Highest latency"}
                      value={comparison.highestLatency}
                      unit="ms"
                    />
                    <Compare
                      label={isArabic ? "الثبات" : "Stability"}
                      value={comparison.stability}
                      unit="%"
                    />
                    <Compare
                      label={isArabic ? "تغير الأداء" : "Performance change"}
                      value={comparison.percentageDifference}
                      unit="%"
                    />
                  </div>
                )}
                <p className="muted">
                  {isArabic
                    ? "اختر جلستين أو أكثر (بحد أقصى 8) لحساب الأفضل والأسوأ والوسيط والثبات والتغير من السجل المحفوظ."
                    : "Select two to eight sessions to calculate best, worst, median, stability, and change from stored records."}
                </p>
              </>
            ) : (
              <EmptyState
                title={
                  isArabic
                    ? "لا توجد جلسات ضمن الفترة"
                    : "No sessions in this period"
                }
                copy={
                  isArabic
                    ? "احفظ جلسة مكتملة أولاً؛ لا يعرض السجل نتائج افتراضية."
                    : "Save a completed session first; history never displays default results."
                }
              />
            )}
          </section>
        )}
      </div>
    </ZeroGramShell>
  );
}

function SpeedChart({
  title,
  points,
  color,
}: {
  title: string;
  points: SpeedTrace[];
  color: string;
}) {
  return (
    <div className="speed-trace">
      <b>{title}</b>
      {points.length ? (
        <ResponsiveContainer width="100%" height={140}>
          <LineChart data={points}>
            <XAxis
              dataKey="elapsedMs"
              tickFormatter={value => `${(value / 1000).toFixed(1)}s`}
              tick={{ fill: "#7e9eaf", fontSize: 9 }}
            />
            <YAxis tick={{ fill: "#7e9eaf", fontSize: 9 }} unit=" Mbps" />
            <Tooltip
              formatter={(value: number) => [`${value.toFixed(2)} Mbps`, title]}
              labelFormatter={value => `${Number(value).toFixed(0)} ms`}
            />
            <Line
              type="monotone"
              dataKey="mbps"
              stroke={color}
              strokeWidth={2}
              dot={{ r: 3 }}
            />
          </LineChart>
        </ResponsiveContainer>
      ) : (
        <p>—</p>
      )}
    </div>
  );
}
function Compare({
  label,
  value,
  unit,
}: {
  label: string;
  value?: number;
  unit: string;
}) {
  return (
    <article>
      <small>{label}</small>
      <b>{value === undefined ? "—" : `${value.toFixed(1)} ${unit}`}</b>
    </article>
  );
}
function Globe2Icon() {
  return <Network size={16} />;
}
