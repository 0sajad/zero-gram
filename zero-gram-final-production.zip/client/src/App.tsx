import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { lazy, Suspense } from "react";
import { I18nProvider } from "@/lib/i18n";
import Dashboard from "@/pages/Dashboard";
import Home from "@/pages/Home";
import Knowledge from "@/pages/Knowledge";
import HelpCenter from "@/pages/HelpCenter";
import Lab from "@/pages/Lab";
import Monitoring from "@/pages/Monitoring";
import Operations from "@/pages/Operations";
import Reports from "@/pages/Reports";
import Status from "@/pages/Status";
import TestPage from "@/pages/TestPage";
import TeamPage from "@/pages/TeamPage";
import InvitePage from "@/pages/InvitePage";
import SharePage from "@/pages/SharePage";
const FiberConsole = lazy(() => import("@/pages/FiberConsole"));
import FiberImport from "@/pages/FiberImport";
import GponPath from "@/pages/GponPath";
import InterfaceMonitoring from "@/pages/InterfaceMonitoring";
import SearchCenter from "@/pages/SearchCenter";
import FiberHealth from "@/pages/FiberHealth";
import MacTable from "@/pages/MacTable";
import HistoryTimeline from "@/pages/HistoryTimeline";
import AccessDetails from "@/pages/AccessDetails";
import TopologyMap from "@/pages/TopologyMap";
import MonitoringPolicy from "@/pages/MonitoringPolicy";
import NetworkContext from "@/pages/NetworkContext";
import OperationsIntelligence from "@/pages/OperationsIntelligence";
import CommandCenter from "@/pages/CommandCenter";
import OperationsReports from "@/pages/OperationsReports";
const BrowserIntelligence = lazy(() => import("@/pages/BrowserIntelligence"));
import PrivacyDashboard from "@/pages/PrivacyDashboard";
import BrowserDiagnostics from "@/pages/BrowserDiagnostics";
import BrowserHistory from "@/pages/BrowserHistory";
import BrowserReport from "@/pages/BrowserReport";
const NetworkFunLab = lazy(() => import("@/pages/NetworkFunLab"));
const NetworkSimulations = lazy(() => import("@/pages/NetworkSimulations"));
import NetworkPlaybook from "@/pages/NetworkPlaybook";
import NotFound from "@/pages/NotFound";
import Profile from "@/pages/Profile";
import Settings from "@/pages/Settings";
import Tools from "@/pages/Tools";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import { ConsolePreferencesProvider } from "./components/ConsolePreferences";

function Router() {
  return (
    <Suspense fallback={<div className="route-loading" aria-live="polite">Loading ZERO GRAM…</div>}>
      <Switch>
      <Route path="/" component={Dashboard} />
      <Route path="/home" component={Home} />
      <Route path="/test" component={TestPage} />
      <Route path="/dashboard" component={Dashboard} />
      <Route path="/profile" component={Profile} />
      <Route path="/settings" component={Settings} />
      <Route path="/tools" component={Tools} />
      <Route path="/network-context" component={NetworkContext} />
      <Route path="/intelligence" component={OperationsIntelligence} />
      <Route path="/command" component={CommandCenter} />
      <Route path="/operations-reports" component={OperationsReports} />
      <Route path="/browser-intelligence" component={BrowserIntelligence} />
      <Route path="/network-fun" component={NetworkFunLab} />
      <Route path="/network-simulations" component={NetworkSimulations} />
      <Route path="/network-playbook" component={NetworkPlaybook} />
      <Route path="/privacy" component={PrivacyDashboard} />
      <Route path="/browser-tests" component={BrowserDiagnostics} />
      <Route path="/browser-history" component={BrowserHistory} />
      <Route path="/browser-report" component={BrowserReport} />
      <Route path="/search" component={SearchCenter} />
      <Route path="/fiber/policy" component={MonitoringPolicy} />
      <Route path="/fiber/topology" component={TopologyMap} />
      <Route path="/fiber/olt" component={() => <AccessDetails mode="olt" />} />
      <Route path="/fiber/ont" component={() => <AccessDetails mode="ont" />} />
      <Route path="/fiber/history" component={HistoryTimeline} />
      <Route path="/fiber/mac-table" component={MacTable} />
      <Route path="/fiber/health" component={FiberHealth} />
      <Route path="/fiber/interfaces" component={InterfaceMonitoring} />
      <Route path="/fiber/path" component={GponPath} />
      <Route path="/fiber/import" component={FiberImport} />
      <Route path="/fiber" component={FiberConsole} />
      <Route path="/lab" component={Lab} />
      <Route path="/monitoring" component={Monitoring} />
      <Route path="/reports" component={Reports} />
      <Route path="/isp" component={Operations} />
      <Route path="/isp/team" component={TeamPage} />
      <Route path="/invite/:code" component={InvitePage} />
      <Route path="/share/:token" component={SharePage} />
      <Route path="/status" component={Status} />
      <Route path="/knowledge" component={Knowledge} />
      <Route path="/help" component={HelpCenter} />
        <Route component={NotFound} />
      </Switch>
    </Suspense>
  );
}
export default function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="dark" switchable>
        <I18nProvider>
          <ConsolePreferencesProvider>
            <TooltipProvider>
              <Toaster />
              <Router />
            </TooltipProvider>
          </ConsolePreferencesProvider>
        </I18nProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}
