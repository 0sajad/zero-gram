import { createContext, useContext, useEffect, useMemo, useState } from "react";

export type Language = "ar" | "iq" | "en";
type Dictionary = Record<string, { ar: string; en: string; iq: string }>;

const copy: Dictionary = {
  home: { ar: "الرئيسية", iq: "الرئيسية", en: "Home" },
  test: { ar: "فحص الاتصال", iq: "فحص النت", en: "Connection test" },
  dashboard: { ar: "مساحة العمل", iq: "لوحة العمل", en: "Workspace" },
  profile: { ar: "الملف الشخصي", iq: "الملف الشخصي", en: "Profile" },
  settings: { ar: "الإعدادات", iq: "الإعدادات", en: "Settings" },
  tools: { ar: "الأدوات", iq: "الأدوات", en: "Tools" },
  browser: { ar: "ذكاء المتصفح", iq: "ذكاء المتصفح", en: "Browser intelligence" },
  funLab: { ar: "مختبر الشبكة", iq: "مختبر الشبكة", en: "Network Fun Lab" },
  simulations: { ar: "المحاكاة", iq: "المحاكاة", en: "Simulations" },
  playbook: { ar: "دليل الشبكة", iq: "دليل الشبكة", en: "Network Playbook" },
  browserTests: { ar: "مختبر المتصفح", iq: "مختبر المتصفح", en: "Browser test lab" },
  browserHistory: { ar: "تاريخ جودة الاتصال", iq: "سجل جودة النت", en: "Quality history" },
  browserReport: { ar: "تقرير المتصفح", iq: "تقرير المتصفح", en: "Browser report" },
  privacy: { ar: "الخصوصية والبيانات", iq: "الخصوصية والبيانات", en: "Privacy & data" },
  context: { ar: "سياق الشبكة", iq: "معلومات الشبكة", en: "Network context" },
  intelligence: { ar: "ذكاء العمليات", iq: "ذكاء العمليات", en: "Operations intelligence" },
  command: { ar: "مركز القيادة", iq: "مركز القيادة", en: "Command center" },
  lab: { ar: "مختبر الفني", iq: "مختبر الفني", en: "Technician lab" },
  monitoring: { ar: "المراقبة", iq: "المراقبة", en: "Monitoring" },
  reports: { ar: "التقارير", iq: "التقارير", en: "Reports" },
  isp: { ar: "عمليات ISP", iq: "شغل ISP", en: "ISP operations" },
  team: { ar: "الفريق والتدقيق", iq: "الفريق والتدقيق", en: "Team & audit" },
  status: { ar: "مركز الحالة", iq: "حالة النظام", en: "Status center" },
  knowledge: { ar: "المعرفة", iq: "المعرفة", en: "Knowledge" },
  help: { ar: "مركز المساعدة", iq: "مركز المساعدة", en: "Help center" },
  fiber: { ar: "عمليات الألياف وGPON", iq: "شغل الألياف وGPON", en: "Fiber & GPON" },
  start: { ar: "ابدأ فحصًا", iq: "ابدأ الفحص", en: "Start a test" },
  source: { ar: "المصدر", iq: "المصدر", en: "Source" },
  limitations: { ar: "حدود القياس", iq: "حدود القياس", en: "Measurement limits" },
  noData: { ar: "لا توجد بيانات حقيقية بعد", iq: "ماكو بيانات حقيقية بعد", en: "No real data yet" },
  save: { ar: "حفظ النتيجة", iq: "حفظ النتيجة", en: "Save result" },
  retry: { ar: "إعادة المحاولة", iq: "جرّب مرة ثانية", en: "Retry" },
  run: { ar: "تنفيذ فحص", iq: "شغّل الفحص", en: "Run check" },
  created: { ar: "تم الإنشاء", iq: "انعمل", en: "Created" },
  active: { ar: "نشط", iq: "شغال", en: "Active" },
  paused: { ar: "موقوف", iq: "متوقف", en: "Paused" },
  export: { ar: "تصدير", iq: "تصدير", en: "Export" },
  print: { ar: "طباعة", iq: "طباعة", en: "Print" },
  loading: { ar: "جارٍ التحميل", iq: "دا يحمل", en: "Loading" },
  nav: { ar: "التنقل", iq: "التنقل", en: "Navigation" },
  backHome: { ar: "العودة للرئيسية", iq: "الرجوع للرئيسية", en: "Back to home" },
  live: { ar: "بيانات مقاسة", iq: "بيانات مقاسة", en: "Measured data" },
  unavailable: { ar: "غير متاح", iq: "مو متاح", en: "Unavailable" },
};

type I18n = {
  language: Language;
  setLanguage: (language: Language) => void;
  t: (key: keyof typeof copy) => string;
  isArabic: boolean;
};
const I18nContext = createContext<I18n | null>(null);

export function I18nProvider({ children }: { children: React.ReactNode }) {
  const [language, setLanguage] = useState<Language>(() => {
    const stored = localStorage.getItem("zero-gram-language");
    return stored === "iq" || stored === "en" ? stored : "ar";
  });
  useEffect(() => {
    document.documentElement.lang = language === "iq" ? "ar-IQ" : language;
    document.documentElement.dir = language === "en" ? "ltr" : "rtl";
    localStorage.setItem("zero-gram-language", language);
  }, [language]);
  const value = useMemo(
    () => ({
      language,
      setLanguage,
      isArabic: language !== "en",
      t: (key: keyof typeof copy) => copy[key][language],
    }),
    [language]
  );
  return <I18nContext.Provider value={value}>{children}</I18nContext.Provider>;
}

export function useI18n() {
  const context = useContext(I18nContext);
  if (!context) throw new Error("I18nProvider is missing");
  return context;
}
