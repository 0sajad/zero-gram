import { jsPDF } from "jspdf";
import * as XLSX from "xlsx";

type ResultRow = {
  id: number;
  createdAt: Date;
  payloadJson: string;
  sourceJson: string;
  limitationsJson: string;
};
type MonitorProfile = {
  id: number;
  label: string;
  targetUrl: string;
  slaTargetPercent: number;
};
type MonitorEvent = {
  profileId: number;
  state: "success" | "failure";
  statusCode: number | null;
  responseTimeMs: number | null;
  errorMessage: string | null;
  checkedAt: Date;
};
const date = (value: Date, timeMode: "local" | "utc") =>
  timeMode === "utc" ? value.toISOString() : value.toLocaleString();
const safeJson = <T>(value: string, fallback: T): T => {
  try {
    return JSON.parse(value) as T;
  } catch {
    return fallback;
  }
};
const filename = (kind: string) =>
  `zero-gram-${kind}-${new Date().toISOString().replaceAll(":", "-").slice(0, 19)}`;

export function exportDiagnosticsPdf(
  results: ResultRow[],
  timeMode: "local" | "utc"
) {
  const doc = new jsPDF({ unit: "pt", format: "a4" });
  results.forEach((row, index) => {
    if (index) doc.addPage();
    const payload = safeJson<{
      measurement?: Record<string, unknown>;
      diagnosis?: {
        netScore?: number;
        findings?: Array<{ title: string; evidence: string; level: string }>;
      };
      metricTrace?: Record<
        string,
        { source: string; precision: string; limitation: string }
      >;
    }>(row.payloadJson, {});
    const sources = safeJson<string[]>(row.sourceJson, []);
    const limits = safeJson<string[]>(row.limitationsJson, []);
    let y = 48;
    const line = (text: string, size = 10) => {
      doc.setFontSize(size);
      const lines = doc.splitTextToSize(text, 495);
      doc.text(lines, 50, y);
      y += lines.length * (size + 4) + 8;
    };
    doc.setTextColor(0, 100, 120);
    doc.setFontSize(18);
    doc.text("ZERO GRAM / DIAGNOSTIC REPORT", 50, y);
    y += 28;
    doc.setTextColor(25, 25, 30);
    line(
      `Reference: RESULT-${String(row.id).padStart(6, "0")}  |  Saved: ${date(new Date(row.createdAt), timeMode)}`,
      9
    );
    line(`NetScore: ${payload.diagnosis?.netScore ?? "Unavailable"}`, 13);
    line("Measurements", 12);
    Object.entries(payload.measurement || {}).forEach(([key, value]) =>
      line(`${key}: ${String(value)}`, 10)
    );
    line("Sources and precision", 12);
    Object.entries(payload.metricTrace || {}).forEach(([key, trace]) =>
      line(
        `${key} | source: ${trace.source} | precision: ${trace.precision} | limit: ${trace.limitation}`,
        9
      )
    );
    sources.forEach(source => line(`Source: ${source}`, 9));
    limits.forEach(limit => line(`Limit: ${limit}`, 9));
    line("Diagnostic findings", 12);
    (payload.diagnosis?.findings || []).forEach(finding =>
      line(`[${finding.level}] ${finding.title}: ${finding.evidence}`, 9)
    );
    doc.setTextColor(90, 100, 112);
    doc.setFontSize(8);
    doc.text(
      "Stored evidence only. This report does not claim a current live network state.",
      50,
      800
    );
  });
  doc.save(`${filename("diagnostic")}.pdf`);
}

export function exportDiagnosticsExcel(
  results: ResultRow[],
  timeMode: "local" | "utc"
) {
  const workbook = XLSX.utils.book_new();
  const summary = results.map(row => {
    const payload = safeJson<{ diagnosis?: { netScore?: number } }>(
      row.payloadJson,
      {}
    );
    return {
      Reference: `RESULT-${String(row.id).padStart(6, "0")}`,
      SavedAt: date(new Date(row.createdAt), timeMode),
      NetScore: payload.diagnosis?.netScore ?? "",
    };
  });
  const measurements = results.flatMap(row => {
    const payload = safeJson<{ measurement?: Record<string, unknown> }>(
      row.payloadJson,
      {}
    );
    return Object.entries(payload.measurement || {}).map(([metric, value]) => ({
      Reference: `RESULT-${String(row.id).padStart(6, "0")}`,
      Metric: metric,
      Value: value,
    }));
  });
  const methodology = results.flatMap(row => {
    const payload = safeJson<{
      metricTrace?: Record<
        string,
        { source: string; precision: string; limitation: string }
      >;
    }>(row.payloadJson, {});
    return Object.entries(payload.metricTrace || {}).map(([metric, trace]) => ({
      Reference: `RESULT-${String(row.id).padStart(6, "0")}`,
      Metric: metric,
      Source: trace.source,
      Precision: trace.precision,
      Limitation: trace.limitation,
    }));
  });
  XLSX.utils.book_append_sheet(
    workbook,
    XLSX.utils.json_to_sheet(summary),
    "Summary"
  );
  XLSX.utils.book_append_sheet(
    workbook,
    XLSX.utils.json_to_sheet(measurements),
    "Measurements"
  );
  XLSX.utils.book_append_sheet(
    workbook,
    XLSX.utils.json_to_sheet(methodology),
    "Methodology"
  );
  XLSX.writeFile(workbook, `${filename("diagnostic")}.xlsx`);
}

export function exportSlaPdf(
  profiles: MonitorProfile[],
  events: MonitorEvent[],
  timeMode: "local" | "utc"
) {
  const doc = new jsPDF({ unit: "pt", format: "a4" });
  let y = 48;
  const line = (text: string, size = 10) => {
    doc.setFontSize(size);
    const lines = doc.splitTextToSize(text, 495);
    doc.text(lines, 50, y);
    y += lines.length * (size + 4) + 8;
    if (y > 770) {
      doc.addPage();
      y = 48;
    }
  };
  doc.setTextColor(0, 100, 120);
  doc.setFontSize(18);
  doc.text("ZERO GRAM / SLA REPORT", 50, y);
  y += 30;
  doc.setTextColor(25, 25, 30);
  profiles.forEach(profile => {
    const related = events.filter(event => event.profileId === profile.id);
    const successful = related.filter(
      event => event.state === "success"
    ).length;
    const sla = related.length
      ? (successful / related.length) * 100
      : undefined;
    line(`${profile.label} (${profile.targetUrl})`, 13);
    line(
      `Stored events: ${related.length} | Successful: ${successful} | Calculated SLA: ${sla === undefined ? "Unavailable" : `${sla.toFixed(2)}%`} | Target: ${profile.slaTargetPercent}%`
    );
    related
      .slice(0, 40)
      .forEach(event =>
        line(
          `${date(new Date(event.checkedAt), timeMode)} | ${event.state.toUpperCase()} | ${event.statusCode ?? "—"} | ${event.responseTimeMs ?? "—"} ms | ${event.errorMessage ?? ""}`,
          8
        )
      );
  });
  doc.save(`${filename("sla")}.pdf`);
}

export function exportSlaExcel(
  profiles: MonitorProfile[],
  events: MonitorEvent[],
  timeMode: "local" | "utc"
) {
  const workbook = XLSX.utils.book_new();
  const summary = profiles.map(profile => {
    const related = events.filter(event => event.profileId === profile.id);
    const successful = related.filter(
      event => event.state === "success"
    ).length;
    return {
      Profile: profile.label,
      Target: profile.targetUrl,
      Events: related.length,
      Successful: successful,
      SLA: related.length ? (successful / related.length) * 100 : "",
      TargetSLA: profile.slaTargetPercent,
    };
  });
  const eventRows = events.map(event => ({
    ProfileId: event.profileId,
    CheckedAt: date(new Date(event.checkedAt), timeMode),
    State: event.state,
    HttpStatus: event.statusCode ?? "",
    ResponseMs: event.responseTimeMs ?? "",
    Error: event.errorMessage ?? "",
  }));
  XLSX.utils.book_append_sheet(
    workbook,
    XLSX.utils.json_to_sheet(summary),
    "SLA Summary"
  );
  XLSX.utils.book_append_sheet(
    workbook,
    XLSX.utils.json_to_sheet(eventRows),
    "Monitoring events"
  );
  XLSX.writeFile(workbook, `${filename("sla")}.xlsx`);
}

type FiberReport = {
  devices: Array<{
    id: number;
    label: string;
    deviceType: string;
    vendor: string | null;
    model: string | null;
    serialNumber: string | null;
    managementIpv4: string | null;
    managementIpv6: string | null;
    sourceLabel: string | null;
    sourceObservedAt: Date | null;
  }>;
  telemetry: Array<{
    deviceId: number | null;
    metric: string;
    valueDouble: number | null;
    valueText: string | null;
    unit: string | null;
    state: string | null;
    sourceLabel: string;
    measuredAt: Date;
  }>;
  snapshots: Array<{
    deviceId: number;
    overallScore: number;
    opticalScore: number | null;
    networkScore: number | null;
    deviceScore: number | null;
    ethernetScore: number | null;
    wifiScore: number | null;
    authenticationScore: number | null;
    sourceLabel: string;
    calculatedAt: Date;
  }>;
  events: Array<{
    deviceId: number | null;
    eventType: string;
    title: string;
    severity: string;
    sourceLabel: string;
    occurredAt: Date;
  }>;
  alerts: Array<{
    deviceId: number | null;
    title: string;
    severity: string;
    status: string;
    impact: string | null;
    probableCause: string | null;
    recommendedCheck: string | null;
    sourceLabel: string;
    openedAt: Date;
  }>;
  nodes: Array<{
    id: number;
    nodeKind: string;
    label: string;
    status: string | null;
    reference: string | null;
    sourceLabel: string | null;
  }>;
  edges: Array<{
    sourceNodeId: number;
    targetNodeId: number;
    relationType: string;
    fiberLengthKm: number | null;
    baselineLossDb: number | null;
    sourceLabel: string | null;
  }>;
};

export function exportFiberPdf(report: FiberReport, timeMode: "local" | "utc") {
  const doc = new jsPDF({ unit: "pt", format: "a4" });
  let y = 48;
  const deviceName = new Map(
    report.devices.map(device => [device.id, device.label])
  );
  const line = (text: string, size = 9) => {
    doc.setFontSize(size);
    const lines = doc.splitTextToSize(text, 495);
    doc.text(lines, 50, y);
    y += lines.length * (size + 4) + 7;
    if (y > 760) {
      doc.addPage();
      y = 48;
    }
  };
  doc.setTextColor(0, 100, 120);
  doc.setFontSize(18);
  doc.text("ZERO GRAM / FIBER & GPON EVIDENCE REPORT", 50, y);
  y += 28;
  doc.setTextColor(25, 25, 30);
  line(
    `Stored devices: ${report.devices.length} | Telemetry: ${report.telemetry.length} | Events: ${report.events.length} | Alerts: ${report.alerts.length}`,
    10
  );
  line("DEVICE INVENTORY", 12);
  report.devices.forEach(device =>
    line(
      `${device.label} | ${device.deviceType} | ${device.vendor ?? "—"} ${device.model ?? ""} | serial: ${device.serialNumber ?? "—"} | IPv4: ${device.managementIpv4 ?? "—"} | IPv6: ${device.managementIpv6 ?? "—"} | source: ${device.sourceLabel ?? "—"}`,
      8
    )
  );
  line("HEALTH SNAPSHOTS", 12);
  report.snapshots.forEach(snapshot =>
    line(
      `${deviceName.get(snapshot.deviceId) ?? `#${snapshot.deviceId}`} | overall ${snapshot.overallScore}% | optical ${snapshot.opticalScore ?? "—"}% | network ${snapshot.networkScore ?? "—"}% | device ${snapshot.deviceScore ?? "—"}% | ethernet ${snapshot.ethernetScore ?? "—"}% | Wi‑Fi ${snapshot.wifiScore ?? "—"}% | auth ${snapshot.authenticationScore ?? "—"}% | ${date(new Date(snapshot.calculatedAt), timeMode)} | source: ${snapshot.sourceLabel}`,
      8
    )
  );
  line("ALERTS AND EVENT TIMELINE", 12);
  report.alerts.forEach(alert =>
    line(
      `[${alert.severity}/${alert.status}] ${deviceName.get(alert.deviceId ?? 0) ?? "Network"} | ${alert.title} | impact: ${alert.impact ?? "—"} | probable cause: ${alert.probableCause ?? "—"} | safe check: ${alert.recommendedCheck ?? "—"} | ${date(new Date(alert.openedAt), timeMode)} | source: ${alert.sourceLabel}`,
      8
    )
  );
  report.events.forEach(event =>
    line(
      `[${event.severity}] ${deviceName.get(event.deviceId ?? 0) ?? "Network"} | ${event.eventType}: ${event.title} | ${date(new Date(event.occurredAt), timeMode)} | source: ${event.sourceLabel}`,
      8
    )
  );
  line("TELEMETRY", 12);
  report.telemetry
    .slice(0, 1000)
    .forEach(sample =>
      line(
        `${deviceName.get(sample.deviceId ?? 0) ?? "Network"} | ${sample.metric}: ${sample.valueDouble ?? sample.valueText ?? "—"} ${sample.unit ?? ""} | state: ${sample.state ?? "—"} | ${date(new Date(sample.measuredAt), timeMode)} | source: ${sample.sourceLabel}`,
        8
      )
    );
  line("TOPOLOGY", 12);
  const nodeName = new Map(report.nodes.map(node => [node.id, node.label]));
  report.edges.forEach(edge =>
    line(
      `${nodeName.get(edge.sourceNodeId) ?? `#${edge.sourceNodeId}`} -> ${nodeName.get(edge.targetNodeId) ?? `#${edge.targetNodeId}`} | ${edge.relationType} | fiber: ${edge.fiberLengthKm ?? "—"} km | baseline loss: ${edge.baselineLossDb ?? "—"} dB | source: ${edge.sourceLabel ?? "—"}`,
      8
    )
  );
  doc.setTextColor(90, 100, 112);
  doc.setFontSize(8);
  doc.text(
    "Stored evidence only. The report does not claim a live device state or issue network commands.",
    50,
    800
  );
  doc.save(`${filename("fiber-gpon")}.pdf`);
}

export function exportFiberExcel(
  report: FiberReport,
  timeMode: "local" | "utc"
) {
  const workbook = XLSX.utils.book_new();
  const deviceName = new Map(
    report.devices.map(device => [device.id, device.label])
  );
  const inventory = report.devices.map(device => ({
    DeviceId: device.id,
    Label: device.label,
    Type: device.deviceType,
    Vendor: device.vendor ?? "",
    Model: device.model ?? "",
    Serial: device.serialNumber ?? "",
    IPv4: device.managementIpv4 ?? "",
    IPv6: device.managementIpv6 ?? "",
    Source: device.sourceLabel ?? "",
    ObservedAt: device.sourceObservedAt
      ? date(new Date(device.sourceObservedAt), timeMode)
      : "",
  }));
  const telemetry = report.telemetry.map(sample => ({
    Device: deviceName.get(sample.deviceId ?? 0) ?? "",
    Metric: sample.metric,
    NumericValue: sample.valueDouble ?? "",
    TextValue: sample.valueText ?? "",
    Unit: sample.unit ?? "",
    State: sample.state ?? "",
    MeasuredAt: date(new Date(sample.measuredAt), timeMode),
    Source: sample.sourceLabel,
  }));
  const health = report.snapshots.map(snapshot => ({
    Device: deviceName.get(snapshot.deviceId) ?? "",
    Overall: snapshot.overallScore,
    Optical: snapshot.opticalScore ?? "",
    Network: snapshot.networkScore ?? "",
    DeviceHealth: snapshot.deviceScore ?? "",
    Ethernet: snapshot.ethernetScore ?? "",
    WiFi: snapshot.wifiScore ?? "",
    Authentication: snapshot.authenticationScore ?? "",
    CalculatedAt: date(new Date(snapshot.calculatedAt), timeMode),
    Source: snapshot.sourceLabel,
  }));
  const alerts = report.alerts.map(alert => ({
    Device: deviceName.get(alert.deviceId ?? 0) ?? "",
    Severity: alert.severity,
    Status: alert.status,
    Title: alert.title,
    Impact: alert.impact ?? "",
    ProbableCause: alert.probableCause ?? "",
    SafeCheck: alert.recommendedCheck ?? "",
    OpenedAt: date(new Date(alert.openedAt), timeMode),
    Source: alert.sourceLabel,
  }));
  const events = report.events.map(event => ({
    Device: deviceName.get(event.deviceId ?? 0) ?? "",
    Severity: event.severity,
    Type: event.eventType,
    Title: event.title,
    OccurredAt: date(new Date(event.occurredAt), timeMode),
    Source: event.sourceLabel,
  }));
  const nodeName = new Map(report.nodes.map(node => [node.id, node.label]));
  const topology = report.edges.map(edge => ({
    From: nodeName.get(edge.sourceNodeId) ?? edge.sourceNodeId,
    To: nodeName.get(edge.targetNodeId) ?? edge.targetNodeId,
    Relation: edge.relationType,
    FiberKm: edge.fiberLengthKm ?? "",
    BaselineLossDb: edge.baselineLossDb ?? "",
    Source: edge.sourceLabel ?? "",
  }));
  XLSX.utils.book_append_sheet(
    workbook,
    XLSX.utils.json_to_sheet(inventory),
    "Inventory"
  );
  XLSX.utils.book_append_sheet(
    workbook,
    XLSX.utils.json_to_sheet(telemetry),
    "Telemetry"
  );
  XLSX.utils.book_append_sheet(
    workbook,
    XLSX.utils.json_to_sheet(health),
    "Health history"
  );
  XLSX.utils.book_append_sheet(
    workbook,
    XLSX.utils.json_to_sheet(alerts),
    "Alerts"
  );
  XLSX.utils.book_append_sheet(
    workbook,
    XLSX.utils.json_to_sheet(events),
    "Events"
  );
  XLSX.utils.book_append_sheet(
    workbook,
    XLSX.utils.json_to_sheet(topology),
    "Topology"
  );
  XLSX.writeFile(workbook, `${filename("fiber-gpon")}.xlsx`);
}

type OperationsReport = {
  profile: {
    companyName: string;
    sourceLabel: string;
    totalBandwidthMbps: number | null;
  } | null;
  capacity: {
    current?: number;
    peak?: number;
    average?: number;
    utilizationPercent?: number;
    growthPercent?: number;
    sampleCount: number;
  };
  reliability: {
    observedCheckSuccessPercent?: number;
    outageCount: number;
    totalDowntimeMs?: number;
    mtbfMs?: number;
    mttrMs?: number;
    sampleCount: number;
  };
  anomalies: Array<{
    metric: string;
    latest: number;
    baselineMedian: number;
    difference: number;
    confidence: string;
    evidenceCount: number;
  }>;
  incidents: Array<{
    reference: string;
    title: string;
    severity: string;
    state: string;
    startedAt: Date;
    endedAt: Date | null;
    rootCause: string | null;
    resolution: string | null;
    sourceLabel: string;
  }>;
  changes: Array<{
    changeType: string;
    title: string;
    changedAt: Date;
    sourceLabel: string;
    beforeJson: string | null;
    afterJson: string | null;
  }>;
};

export function exportOperationsPdf(
  report: OperationsReport,
  timeMode: "local" | "utc"
) {
  const doc = new jsPDF({ unit: "pt", format: "a4" });
  let y = 48;
  const line = (text: string, size = 9) => {
    doc.setFontSize(size);
    const lines = doc.splitTextToSize(text, 495);
    doc.text(lines, 50, y);
    y += lines.length * (size + 4) + 7;
    if (y > 760) {
      doc.addPage();
      y = 48;
    }
  };
  const value = (number?: number) =>
    number === undefined ? "Unavailable" : number.toFixed(2);
  doc.setTextColor(0, 100, 120);
  doc.setFontSize(18);
  doc.text("ZERO GRAM / OPERATIONS EVIDENCE REPORT", 50, y);
  y += 28;
  doc.setTextColor(25, 25, 30);
  line(
    `Company context: ${report.profile?.companyName ?? "Unavailable"} | source: ${report.profile?.sourceLabel ?? "Unavailable"}`,
    10
  );
  line("CAPACITY (sourced snapshots only)", 12);
  line(
    `Declared bandwidth: ${report.profile?.totalBandwidthMbps ?? "Unavailable"} Mbps | current: ${value(report.capacity.current)} Mbps | peak: ${value(report.capacity.peak)} Mbps | average: ${value(report.capacity.average)} Mbps | utilization: ${value(report.capacity.utilizationPercent)}% | growth: ${value(report.capacity.growthPercent)}% | samples: ${report.capacity.sampleCount}`
  );
  line("OBSERVED RELIABILITY", 12);
  line(
    `HTTP check success: ${value(report.reliability.observedCheckSuccessPercent)}% | observed outage runs: ${report.reliability.outageCount} | downtime: ${report.reliability.totalDowntimeMs ?? "Unavailable"} ms | MTBF: ${report.reliability.mtbfMs ?? "Unavailable"} ms | MTTR: ${report.reliability.mttrMs ?? "Unavailable"} ms | checks: ${report.reliability.sampleCount}`
  );
  line("ANOMALIES (deviation evidence, not root cause)", 12);
  report.anomalies.forEach(item =>
    line(
      `${item.metric} | latest ${item.latest.toFixed(2)} | baseline median ${item.baselineMedian.toFixed(2)} | difference ${item.difference.toFixed(2)} | confidence ${item.confidence} | baseline records ${item.evidenceCount}`
    )
  );
  line("INCIDENT REGISTER", 12);
  report.incidents.forEach(item =>
    line(
      `${item.reference} | ${item.title} | ${item.severity}/${item.state} | started ${date(new Date(item.startedAt), timeMode)} | ended ${item.endedAt ? date(new Date(item.endedAt), timeMode) : "—"} | root cause: ${item.rootCause ?? "—"} | resolution: ${item.resolution ?? "—"} | source: ${item.sourceLabel}`
    )
  );
  line("CHANGE RECORDS", 12);
  report.changes.forEach(item =>
    line(
      `${item.changeType} | ${item.title} | ${date(new Date(item.changedAt), timeMode)} | before: ${item.beforeJson ?? "—"} | after: ${item.afterJson ?? "—"} | source: ${item.sourceLabel}`
    )
  );
  doc.setTextColor(90, 100, 112);
  doc.setFontSize(8);
  doc.text(
    "Stored evidence only. Observed reliability is not a guarantee of overall uptime; anomalies do not establish a root cause.",
    50,
    800
  );
  doc.save(`${filename("operations-evidence")}.pdf`);
}

export function exportOperationsExcel(
  report: OperationsReport,
  timeMode: "local" | "utc"
) {
  const workbook = XLSX.utils.book_new();
  const capacity = [
    {
      Company: report.profile?.companyName ?? "",
      ContextSource: report.profile?.sourceLabel ?? "",
      DeclaredBandwidthMbps: report.profile?.totalBandwidthMbps ?? "",
      CurrentMbps: report.capacity.current ?? "",
      PeakMbps: report.capacity.peak ?? "",
      AverageMbps: report.capacity.average ?? "",
      UtilizationPercent: report.capacity.utilizationPercent ?? "",
      GrowthPercent: report.capacity.growthPercent ?? "",
      SnapshotCount: report.capacity.sampleCount,
    },
  ];
  const reliability = [
    {
      ObservedCheckSuccessPercent:
        report.reliability.observedCheckSuccessPercent ?? "",
      OutageRuns: report.reliability.outageCount,
      DowntimeMs: report.reliability.totalDowntimeMs ?? "",
      MTBFMs: report.reliability.mtbfMs ?? "",
      MTTRMs: report.reliability.mttrMs ?? "",
      CheckCount: report.reliability.sampleCount,
    },
  ];
  const anomalies = report.anomalies.map(item => ({
    Metric: item.metric,
    Latest: item.latest,
    BaselineMedian: item.baselineMedian,
    Difference: item.difference,
    Confidence: item.confidence,
    BaselineRecords: item.evidenceCount,
  }));
  const incidentRows = report.incidents.map(item => ({
    Reference: item.reference,
    Title: item.title,
    Severity: item.severity,
    State: item.state,
    StartedAt: date(new Date(item.startedAt), timeMode),
    EndedAt: item.endedAt ? date(new Date(item.endedAt), timeMode) : "",
    RootCause: item.rootCause ?? "",
    Resolution: item.resolution ?? "",
    Source: item.sourceLabel,
  }));
  const changeRows = report.changes.map(item => ({
    Type: item.changeType,
    Title: item.title,
    ChangedAt: date(new Date(item.changedAt), timeMode),
    Before: item.beforeJson ?? "",
    After: item.afterJson ?? "",
    Source: item.sourceLabel,
  }));
  XLSX.utils.book_append_sheet(
    workbook,
    XLSX.utils.json_to_sheet(capacity),
    "Capacity"
  );
  XLSX.utils.book_append_sheet(
    workbook,
    XLSX.utils.json_to_sheet(reliability),
    "Reliability"
  );
  XLSX.utils.book_append_sheet(
    workbook,
    XLSX.utils.json_to_sheet(anomalies),
    "Anomalies"
  );
  XLSX.utils.book_append_sheet(
    workbook,
    XLSX.utils.json_to_sheet(incidentRows),
    "Incidents"
  );
  XLSX.utils.book_append_sheet(
    workbook,
    XLSX.utils.json_to_sheet(changeRows),
    "Changes"
  );
  XLSX.writeFile(workbook, `${filename("operations-evidence")}.xlsx`);
}
