import { useI18n } from "@/lib/i18n";
import { trpc } from "@/lib/trpc";
import { FileUp, FileText, Loader2, Paperclip } from "lucide-react";
import { useRef } from "react";
import { toast } from "sonner";

const toBase64 = (file: File) =>
  new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result).split(",")[1] || "");
    reader.onerror = () => reject(new Error("تعذر قراءة الملف."));
    reader.readAsDataURL(file);
  });

export function AttachmentVault() {
  const { isArabic } = useI18n();
  const inputRef = useRef<HTMLInputElement>(null);
  const attachments = trpc.network.attachments.useQuery({});
  const upload = trpc.network.uploadAttachment.useMutation({
    onSuccess: () => {
      toast.success(
        isArabic
          ? "رُفع المرفق إلى التخزين الخارجي."
          : "Attachment uploaded to external storage."
      );
      attachments.refetch();
    },
  });
  const handleFile = async (file?: File) => {
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) {
      toast.error(
        isArabic
          ? "الحد الأقصى للمرفق 5MB."
          : "Maximum attachment size is 5 MB."
      );
      return;
    }
    const allowed = [
      "application/pdf",
      "text/plain",
      "image/png",
      "image/jpeg",
      "image/webp",
    ];
    if (!allowed.includes(file.type)) {
      toast.error(
        isArabic
          ? "يسمح فقط بملفات PDF والنصوص وصور PNG/JPEG/WebP."
          : "Only PDF, text, PNG, JPEG, and WebP files are allowed."
      );
      return;
    }
    try {
      upload.mutate({
        filename: file.name,
        contentType: file.type,
        base64: await toBase64(file),
      });
    } catch {
      toast.error(
        isArabic
          ? "تعذر تجهيز الملف للرفع."
          : "Could not prepare file for upload."
      );
    }
  };
  return (
    <section className="data-panel attachment-vault">
      <div className="panel-header">
        <h3>
          <Paperclip size={15} />
          {isArabic ? "مرفقات التشغيل" : "Operational attachments"}
        </h3>
        <span>EXTERNAL STORAGE</span>
      </div>
      <div className="attachment-content">
        <p>
          {isArabic
            ? "تُحفظ بيانات الملف الوصفية فقط في قاعدة البيانات، بينما تُرسل البايتات إلى التخزين الخارجي. الأنواع المسموحة: PDF أو نص أو PNG/JPEG/WebP حتى 5MB."
            : "Only file metadata is saved in the database; bytes are sent to external storage. Allowed: PDF, text, PNG/JPEG/WebP up to 5 MB."}
        </p>
        <input
          ref={inputRef}
          className="file-input"
          type="file"
          accept="application/pdf,text/plain,image/png,image/jpeg,image/webp"
          onChange={event => handleFile(event.target.files?.[0])}
        />
        <button
          className="action-button primary"
          disabled={upload.isPending}
          onClick={() => inputRef.current?.click()}
        >
          {upload.isPending ? (
            <Loader2 className="spin" size={15} />
          ) : (
            <FileUp size={15} />
          )}{" "}
          {isArabic ? "رفع مرفق" : "Upload attachment"}
        </button>
      </div>
      {attachments.data?.length ? (
        <div className="attachment-list">
          {attachments.data.map(item => (
            <a
              href={`/manus-storage/${item.storageKey}`}
              target="_blank"
              rel="noreferrer"
              key={item.id}
            >
              <FileText size={15} />
              <span>{item.filename}</span>
              <small>{Math.ceil(item.sizeBytes / 1024)} KB</small>
            </a>
          ))}
        </div>
      ) : null}
    </section>
  );
}
