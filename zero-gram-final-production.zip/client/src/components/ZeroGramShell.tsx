import {
  ConsolePreferencesButton,
  useConsolePreferences,
} from "@/components/ConsolePreferences";
import { useI18n } from "@/lib/i18n";
import { cn } from "@/lib/utils";
import {
  Activity,
  BarChart3,
  BookOpen,
  Building2,
  Cable,
  CircleHelp,
  ChevronLeft,
  ChevronRight,
  Eye,
  EyeOff,
  FileBarChart,
  FlaskConical,
  Gauge,
  GitFork,
  GripVertical,
  Keyboard,
  Network,
  Moon,
  Sun,
  Pin,
  PinOff,
  RadioTower,
  RotateCcw,
  Settings2,
  ShieldCheck,
  WifiOff,
  Globe2,
  X,
  UserCircle,
} from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";
import { resolveMobileSwipe } from "../../../shared/mobileSwipe";
import { Link, useLocation } from "wouter";

export const navigation = [
  ["/dashboard", "dashboard", Gauge],
  ["/profile", "profile", UserCircle],
  ["/settings", "settings", Settings2],
  ["/tools", "tools", Network],
  ["/browser-intelligence", "browser", Globe2],
  ["/network-fun", "funLab", FlaskConical],
  ["/network-simulations", "simulations", WifiOff],
  ["/network-playbook", "playbook", BookOpen],
  ["/browser-tests", "browserTests", Activity],
  ["/browser-history", "browserHistory", BarChart3],
  ["/browser-report", "browserReport", FileBarChart],
  ["/privacy", "privacy", ShieldCheck],
  ["/network-context", "context", Network],
  ["/intelligence", "intelligence", BarChart3],
  ["/command", "command", GitFork],
  ["/fiber", "fiber", Cable],
  ["/test", "test", Activity],
  ["/lab", "lab", FlaskConical],
  ["/monitoring", "monitoring", RadioTower],
  ["/reports", "reports", FileBarChart],
  ["/isp", "isp", Building2],
  ["/isp/team", "team", ShieldCheck],
  ["/status", "status", BarChart3],
  ["/knowledge", "knowledge", BookOpen],
  ["/help", "help", CircleHelp],
] as const;
type NavKey = (typeof navigation)[number][1];
type NavPreference = {
  href: string;
  key: NavKey;
  pinned: boolean;
  enabled: boolean;
};
const preferenceKey = "zero-gram-sidebar-layout";
const mobileNavigation = [
  "/dashboard",
  "/test",
  "/monitoring",
  "/tools",
  "/settings",
] as const;
export const groupFor = (href: string) => {
  if (["/dashboard", "/profile", "/settings"].includes(href)) return "workspace";
  if (href.startsWith("/browser") || href === "/privacy" || href === "/network-fun" || href === "/network-simulations" || href === "/network-playbook") return "browser";
  if (href.startsWith("/fiber")) return "fiber";
  if (["/intelligence", "/command", "/monitoring", "/reports", "/isp", "/isp/team", "/status", "/network-context"].includes(href)) return "operations";
  return "tools";
};
const defaultNavPreferences = (): NavPreference[] =>
  navigation.map(([href, key]) => ({
    href,
    key,
    pinned: false,
    enabled: true,
  }));

export function BrandMark({ compact = false }: { compact?: boolean }) {
  return (
    <div className="brand-mark" aria-label="ZERO GRAM">
      <span className="brand-orbit" aria-hidden="true" />
      <span className="brand-name">
        ZERO
        <br className={compact ? "hidden" : ""} /> GRAM
      </span>
    </div>
  );
}
export function LanguageToggle() {
  const { language, setLanguage, isArabic } = useI18n();
  const nextLanguage = language === "ar" ? "iq" : language === "iq" ? "en" : "ar";
  return (
    <button
      className="language-toggle"
      onClick={() => setLanguage(nextLanguage)}
      aria-label={isArabic ? "تغيير اللغة" : "Change language"}
      title={isArabic ? "العربية الفصحى ← العراقية ← English" : "English → العربية الفصحى → العراقية"}
    >
      <span className={language === "ar" ? "active" : ""}>فصحى</span>
      <span className={language === "iq" ? "active" : ""}>عراقي</span>
      <span className={language === "en" ? "active" : ""}>EN</span>
    </button>
  );
}

export function ZeroGramShell({
  children,
  title,
  eyebrow,
}: {
  children: React.ReactNode;
  title: string;
  eyebrow?: string;
}) {
  const { t, isArabic } = useI18n();
  const prefs = useConsolePreferences();
  const [location, setLocation] = useLocation();
  const [collapsed, setCollapsed] = useState(false);
  const [shortcutOpen, setShortcutOpen] = useState(false);
  const [sidebarSetupOpen, setSidebarSetupOpen] = useState(false);
  const [online, setOnline] = useState(() => navigator.onLine);
  const [navPreferences, setNavPreferences] = useState<NavPreference[]>(() => {
    try {
      const saved = JSON.parse(
        localStorage.getItem(preferenceKey) || "[]"
      ) as NavPreference[];
      const defaults = defaultNavPreferences();
      return defaults.map(item => ({
        ...item,
        ...(saved.find(savedItem => savedItem.href === item.href) || {}),
      }));
    } catch {
      return defaultNavPreferences();
    }
  });
  useEffect(
    () => localStorage.setItem(preferenceKey, JSON.stringify(navPreferences)),
    [navPreferences]
  );
  useEffect(() => {
    const refreshOnline = () => setOnline(navigator.onLine);
    const keys = (event: KeyboardEvent) => {
      const target = event.target as HTMLElement;
      if (
        target?.tagName === "INPUT" ||
        target?.tagName === "TEXTAREA" ||
        target?.tagName === "SELECT"
      )
        return;
      if (event.key === "Escape") {
        setShortcutOpen(false);
        setSidebarSetupOpen(false);
      }
      if (event.key === "?") {
        event.preventDefault();
        setShortcutOpen(current => !current);
      }
      if (event.altKey && event.key.toLowerCase() === "t") {
        event.preventDefault();
        sessionStorage.setItem("zg-start-test", "1");
        setLocation("/test");
      }
      if (event.altKey && event.key.toLowerCase() === "f") {
        event.preventDefault();
        sessionStorage.setItem("zg-focus-dashboard-search", "1");
        setLocation("/dashboard");
      }
      if (event.altKey && event.key.toLowerCase() === "l") {
        event.preventDefault();
        setLocation("/lab");
      }
      if (event.altKey && event.key.toLowerCase() === "r") {
        event.preventDefault();
        setLocation("/reports");
      }
    };
    window.addEventListener("online", refreshOnline);
    window.addEventListener("offline", refreshOnline);
    window.addEventListener("keydown", keys);
    return () => {
      window.removeEventListener("online", refreshOnline);
      window.removeEventListener("offline", refreshOnline);
      window.removeEventListener("keydown", keys);
    };
  }, [setLocation]);
  const touchStart = useRef<{ x: number; y: number } | null>(null);
  useEffect(() => {
    const onTouchStart = (event: TouchEvent) => {
      if (window.innerWidth > 700 || event.touches.length !== 1) return;
      const touch = event.touches[0];
      touchStart.current = { x: touch.clientX, y: touch.clientY };
    };
    const onTouchEnd = (event: TouchEvent) => {
      if (window.innerWidth > 700 || !touchStart.current) return;
      const touch = event.changedTouches[0];
      const direction = resolveMobileSwipe(
        touchStart.current.x,
        touchStart.current.y,
        touch.clientX,
        touch.clientY
      );
      touchStart.current = null;
      if (!direction) return;
      const currentIndex = mobileNavigation.indexOf(
        location as (typeof mobileNavigation)[number]
      );
      if (currentIndex < 0) return;
      const nextIndex = direction === "next" ? currentIndex + 1 : currentIndex - 1;
      const next = mobileNavigation[nextIndex];
      if (next) setLocation(next);
    };
    window.addEventListener("touchstart", onTouchStart, { passive: true });
    window.addEventListener("touchend", onTouchEnd, { passive: true });
    return () => {
      window.removeEventListener("touchstart", onTouchStart);
      window.removeEventListener("touchend", onTouchEnd);
    };
  }, [location, setLocation]);
  const visibleNavigation = useMemo(
    () =>
      navPreferences
        .filter(item => item.enabled)
        .sort((a, b) => Number(b.pinned) - Number(a.pinned)),
    [navPreferences]
  );
  const iconFor = (href: string) =>
    navigation.find(item => item[0] === href)?.[2] || Network;
  const move = (fromHref: string, toHref: string) =>
    setNavPreferences(current => {
      const from = current.findIndex(item => item.href === fromHref);
      const to = current.findIndex(item => item.href === toHref);
      if (from < 0 || to < 0 || from === to) return current;
      const next = [...current];
      const [moved] = next.splice(from, 1);
      next.splice(to, 0, moved!);
      return next;
    });
  const patchNav = (href: string, patch: Partial<NavPreference>) =>
    setNavPreferences(current =>
      current.map(item => (item.href === href ? { ...item, ...patch } : item))
    );
  const sidebar = (
    <aside
      id="zero-gram-sidebar"
      className={cn(
        "zg-sidebar",
        collapsed && "collapsed"
      )}
    >
      <div className="sidebar-head">
        <Link href="/">
          <BrandMark compact={collapsed} />
        </Link>
        <div>
          <button
            className="icon-button desktop-only has-tooltip"
            data-tooltip={isArabic ? "تخصيص التنقل" : "Customize navigation"}
            onClick={() => setSidebarSetupOpen(current => !current)}
            aria-label="Customize navigation"
          >
            <Settings2 size={15} />
          </button>
          <button
            className="icon-button desktop-only has-tooltip"
            data-tooltip={isArabic ? "طي الشريط" : "Collapse sidebar"}
            onClick={() => setCollapsed(!collapsed)}
            aria-label="Toggle sidebar"
          >
            {isArabic ? <ChevronRight /> : <ChevronLeft />}
          </button>
        </div>
      </div>
      <div className="nav-label">{t("nav")}</div>
      <nav>
        {visibleNavigation.map((item, index) => {
          const Icon = iconFor(item.href);
          const group = groupFor(item.href);
          const previousGroup = index ? groupFor(visibleNavigation[index - 1]!.href) : "";
          const groupLabel = group === "workspace"
            ? (isArabic ? "المساحة الشخصية" : "Workspace")
            : group === "browser"
              ? (isArabic ? "المتصفح والمختبر" : "Browser & lab")
              : group === "fiber"
                ? (isArabic ? "الألياف والبنية" : "Fiber & infrastructure")
                : group === "operations"
                  ? (isArabic ? "العمليات" : "Operations")
                  : (isArabic ? "الأدوات" : "Tools");
          return (
            <div key={`${item.href}-group`}>
              {group !== previousGroup && <div className="nav-section-label">{groupLabel}</div>}
            <Link
              href={item.href}
              key={item.href}
              draggable
              onDragStart={event =>
                event.dataTransfer.setData("text/zero-gram-nav", item.href)
              }
              onDragOver={event => event.preventDefault()}
              onDrop={event => {
                event.preventDefault();
                move(
                  event.dataTransfer.getData("text/zero-gram-nav"),
                  item.href
                );
              }}
              className={cn(
                "nav-item",
                location === item.href && "active",
                item.pinned && "pinned"
              )}
            >
              <GripVertical className="nav-grip" size={12} />
              <Icon />
              <span>{t(item.key)}</span>
              {item.pinned && <Pin size={11} />}
            </Link>
            </div>
          );
        })}
      </nav>
      <div className="sidebar-bottom">
        <div className="signal-line">
          <span />
          <span />
          <span />
          <span />
        </div>
        <div
          className="profile-card local-guest-card"
          aria-label={isArabic ? "وضع الضيف المحلي" : "Local guest mode"}
        >
          <span className="profile-initial">Z</span>
          <span className="profile-copy">
            <b>{isArabic ? "ضيف محلي" : "Local guest"}</b>
            <small>{isArabic ? "البيانات على هذا الخادم" : "Data on this server"}</small>
          </span>
          <ShieldCheck size={16} />
        </div>
      </div>
    </aside>
  );
  return (
    <div className={cn("app-grid", collapsed && "sidebar-collapsed")}>
      <div className="scanlines" aria-hidden="true" />
      {sidebar}
      {sidebarSetupOpen && (
        <section
          className="sidebar-customizer"
          role="dialog"
          aria-label={
            isArabic ? "تخصيص الشريط الجانبي" : "Sidebar customization"
          }
        >
          <header>
            <div>
              <Settings2 size={16} />
              <b>{isArabic ? "تنظيم المحطات" : "Arrange stations"}</b>
            </div>
            <button
              className="icon-button"
              onClick={() => setSidebarSetupOpen(false)}
              aria-label="Close"
            >
              <X size={15} />
            </button>
          </header>
          <p>
            {isArabic
              ? "اسحب لترتيب العناصر، ثبّت المحطات الحرجة، أو أخفِ ما لا تستخدمه. يُحفظ الترتيب على هذا المتصفح."
              : "Drag to reorder, pin critical stations, or hide unused ones. Layout is saved in this browser."}
          </p>
          <div>
            {navPreferences.map(item => {
              const Icon = iconFor(item.href);
              return (
                <article
                  key={item.href}
                  draggable
                  onDragStart={event =>
                    event.dataTransfer.setData("text/zero-gram-nav", item.href)
                  }
                  onDragOver={event => event.preventDefault()}
                  onDrop={event => {
                    event.preventDefault();
                    move(
                      event.dataTransfer.getData("text/zero-gram-nav"),
                      item.href
                    );
                  }}
                >
                  <GripVertical size={15} />
                  <Icon size={15} />
                  <b>{t(item.key)}</b>
                  <button
                    className="icon-button"
                    onClick={() =>
                      patchNav(item.href, { pinned: !item.pinned })
                    }
                    aria-label="Pin item"
                  >
                    {item.pinned ? <PinOff size={14} /> : <Pin size={14} />}
                  </button>
                  <button
                    className="icon-button"
                    onClick={() =>
                      patchNav(item.href, { enabled: !item.enabled })
                    }
                    aria-label="Toggle item"
                  >
                    {item.enabled ? <Eye size={14} /> : <EyeOff size={14} />}
                  </button>
                </article>
              );
            })}
          </div>
          <button
            className="action-button"
            onClick={() => setNavPreferences(defaultNavPreferences())}
          >
            <RotateCcw size={14} />
            {isArabic ? "إعادة الضبط" : "Reset"}
          </button>
        </section>
      )}
      <main className="workspace">
        <header className="workspace-header">
          <div className="header-start">
            <div>
              <p className="eyebrow">{eyebrow || "ZERO GRAM / OPS"}</p>
              <h1>{title}</h1>
            </div>
          </div>
          <div className="header-actions">
            <div className={cn("system-status", !online && "offline")}>
              <span />
              {online ? "SYSTEM READY" : "OFFLINE"}
            </div>
            <button
              className="icon-button keyboard-button has-tooltip"
              data-tooltip={
                isArabic ? "اختصارات لوحة المفاتيح" : "Keyboard shortcuts"
              }
              onClick={() => setShortcutOpen(!shortcutOpen)}
              aria-label={
                isArabic ? "اختصارات لوحة المفاتيح" : "Keyboard shortcuts"
              }
            >
              <Keyboard size={16} />
            </button>
            <button
              className={cn("dark-mode-button", prefs.darkMode && "active")}
              onClick={() => {
                prefs.setPreference("visualMode", "original");
                prefs.setPreference("systemTheme", false);
                prefs.setPreference("darkMode", !prefs.darkMode);
              }}
              aria-pressed={prefs.darkMode}
              aria-label={isArabic ? "تبديل الوضع الليلي" : "Toggle dark mode"}
              title={isArabic ? "تبديل الوضع الليلي" : "Toggle dark mode"}
            >
              {prefs.darkMode ? <Moon size={15} /> : <Sun size={15} />}
              <span>{isArabic ? "ليلي" : "Dark"}</span>
            </button>
            <ConsolePreferencesButton />
            <LanguageToggle />
          </div>
        </header>
        {shortcutOpen && (
          <section
            className="shortcuts-overlay"
            onClick={() => setShortcutOpen(false)}
          >
            <div
              className="shortcuts-card"
              onClick={event => event.stopPropagation()}
            >
              <header>
                <div>
                  <Keyboard size={17} />
                  <b>{isArabic ? "اختصارات الكونسول" : "Console shortcuts"}</b>
                </div>
                <button
                  className="icon-button"
                  onClick={() => setShortcutOpen(false)}
                >
                  <X size={16} />
                </button>
              </header>
              <div>
                <span>
                  <kbd>Alt</kbd>
                  <kbd>T</kbd>
                  {isArabic ? "بدء فحص اتصال" : "Start connection test"}
                </span>
                <span>
                  <kbd>Alt</kbd>
                  <kbd>F</kbd>
                  {isArabic ? "بحث في النتائج" : "Search saved results"}
                </span>
                <span>
                  <kbd>Alt</kbd>
                  <kbd>L</kbd>
                  {isArabic ? "فتح المختبر" : "Open lab"}
                </span>
                <span>
                  <kbd>Alt</kbd>
                  <kbd>R</kbd>
                  {isArabic ? "فتح التقارير" : "Open reports"}
                </span>
                <span>
                  <kbd>Alt</kbd>
                  <kbd>D</kbd>
                  {isArabic ? "تبديل التوهج المنخفض" : "Toggle low glare"}
                </span>
                <span>
                  <kbd>Alt</kbd>
                  <kbd>M</kbd>
                  {isArabic ? "تبديل تقليل الحركة" : "Toggle reduced motion"}
                </span>
                <span>
                  <kbd>Esc</kbd>
                  {isArabic ? "إغلاق اللوحة" : "Close panel"}
                </span>
              </div>
              <p>
                <WifiOff size={13} />
                {isArabic
                  ? "مؤشر الاتصال يعكس اتصال المتصفح فقط، وليس حالة وجهة المراقبة."
                  : "The connection indicator reflects browser connectivity only, not a monitoring target state."}
              </p>
            </div>
          </section>
        )}
        <nav
          className="mobile-bottom-nav"
          aria-label={isArabic ? "تنقل الهاتف" : "Mobile navigation"}
        >
          <div className="mobile-bottom-nav-scroll">
            {mobileNavigation.map(href => {
              const item = navigation.find(candidate => candidate[0] === href);
              if (!item) return null;
              const Icon = item[2];
              return (
                <Link
                  key={`mobile-${href}`}
                  href={href}
                  className={cn("mobile-bottom-nav-item", location === href && "active")}
                  aria-label={t(item[1])}
                >
                  <Icon size={17} />
                  <span>{t(item[1])}</span>
                </Link>
              );
            })}
          </div>
        </nav>
        {children}
      </main>
    </div>
  );
}
export function SectionHeading({
  index,
  title,
  description,
  action,
}: {
  index: string;
  title: string;
  description?: string;
  action?: React.ReactNode;
}) {
  return (
    <div className="section-heading">
      <div className="section-index">{index}</div>
      <div>
        <h2>{title}</h2>
        {description && <p>{description}</p>}
      </div>
      {action && <div className="section-action">{action}</div>}
    </div>
  );
}
export function EmptyState({
  title,
  copy,
  action,
}: {
  title: string;
  copy: string;
  action?: React.ReactNode;
}) {
  return (
    <div className="empty-state">
      <Network size={28} />
      <h3>{title}</h3>
      <p>{copy}</p>
      {action}
    </div>
  );
}
