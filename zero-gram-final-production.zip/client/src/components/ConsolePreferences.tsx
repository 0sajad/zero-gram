import { Moon, ScanLine, Settings2, SunMedium, Type, Zap } from "lucide-react";
import { createContext, useContext, useEffect, useState } from "react";
import { useI18n } from "@/lib/i18n";
import {
  resolveConsoleVisualMode,
  type VisualMode,
} from "../../../shared/visualModes";

export type { VisualMode } from "../../../shared/visualModes";
type FontScale = "small" | "normal" | "large";
type TimeMode = "local" | "utc";
type ConsolePreferences = {
  darkMode: boolean;
  systemTheme: boolean;
  visualMode: VisualMode;
  lowGlare: boolean;
  compact: boolean;
  reduceMotion: boolean;
  scanlines: boolean;
  glow: boolean;
  fontScale: FontScale;
  timeMode: TimeMode;
  showUnits: boolean;
  autoRefresh: boolean;
  focusMode: boolean;
};
type ConsolePreferencesContext = ConsolePreferences & {
  setPreference: <K extends keyof ConsolePreferences>(
    key: K,
    value: ConsolePreferences[K]
  ) => void;
  reset: () => void;
};
const defaults: ConsolePreferences = {
  darkMode: true,
  systemTheme: false,
  visualMode: "original",

  lowGlare: false,
  compact: false,
  reduceMotion: false,
  scanlines: true,
  glow: true,
  fontScale: "normal",
  timeMode: "local",
  showUnits: true,
  autoRefresh: false,
  focusMode: false,
};
const PreferencesContext = createContext<ConsolePreferencesContext | undefined>(
  undefined
);

export function ConsolePreferencesProvider({
  children,
}: {
  children: React.ReactNode;
}) {
  const [preferences, setPreferences] = useState<ConsolePreferences>(() => {
    try {
      return {
        ...defaults,
        ...JSON.parse(
          localStorage.getItem("zero-gram-console-preferences") || "{}"
        ),
      };
    } catch {
      return defaults;
    }
  });
  useEffect(() => {
    const media = window.matchMedia("(prefers-color-scheme: dark)");
    const apply = () => {
      localStorage.setItem(
        "zero-gram-console-preferences",
        JSON.stringify(preferences)
      );
      const root = document.documentElement;
      const mode = resolveConsoleVisualMode({
        visualMode: preferences.visualMode,
        darkMode: preferences.darkMode,
        systemTheme: preferences.systemTheme,
        systemPrefersDark: media.matches,
      });
      root.classList.toggle("zg-light-console", mode.classes.light);
      root.classList.toggle("zg-black-console", mode.classes.black);
      root.classList.toggle("zg-color-console", mode.classes.color);
      root.classList.toggle("zg-original-console", mode.classes.original);
      root.classList.toggle("dark", mode.dark);
      root.classList.toggle("zg-low-glare", preferences.lowGlare);
      root.classList.toggle("zg-compact", preferences.compact);
      root.classList.toggle("zg-reduce-motion", preferences.reduceMotion);
      root.classList.toggle("zg-no-scanlines", !preferences.scanlines);
      root.classList.toggle("zg-no-glow", !preferences.glow);
      root.classList.toggle("zg-focus-mode", preferences.focusMode);
      root.dataset.fontScale = preferences.fontScale;
    };
    apply();
    media.addEventListener("change", apply);
    return () => media.removeEventListener("change", apply);
  }, [preferences]);
  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (!event.altKey) return;
      if (event.shiftKey && event.key.toLowerCase() === "d") {
        event.preventDefault();
        setPreferences(current => ({
          ...current,
          darkMode: !current.darkMode,
          systemTheme: false,
        }));
      } else if (event.key.toLowerCase() === "d") {
        event.preventDefault();
        setPreferences(current => ({
          ...current,
          lowGlare: !current.lowGlare,
        }));
      }
      if (event.key.toLowerCase() === "m") {
        event.preventDefault();
        setPreferences(current => ({
          ...current,
          reduceMotion: !current.reduceMotion,
        }));
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);
  const setPreference = <K extends keyof ConsolePreferences>(
    key: K,
    value: ConsolePreferences[K]
  ) => setPreferences(current => ({ ...current, [key]: value }));
  return (
    <PreferencesContext.Provider
      value={{
        ...preferences,
        setPreference,
        reset: () => setPreferences(defaults),
      }}
    >
      {children}
    </PreferencesContext.Provider>
  );
}
export function useConsolePreferences() {
  const context = useContext(PreferencesContext);
  if (!context)
    throw new Error(
      "useConsolePreferences must be inside ConsolePreferencesProvider"
    );
  return context;
}

function Switch({
  enabled,
  onChange,
  label,
}: {
  enabled: boolean;
  onChange: () => void;
  label: string;
}) {
  return (
    <button
      className={`console-switch ${enabled ? "on" : ""}`}
      onClick={onChange}
      aria-pressed={enabled}
    >
      <span>{label}</span>
      <i />
    </button>
  );
}
export function ConsolePreferencesButton() {
  const { isArabic } = useI18n();
  const prefs = useConsolePreferences();
  const [open, setOpen] = useState(false);
  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (open && event.key === "Escape") setOpen(false);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open]);
  return (
    <div className="console-preferences">
      <button
        className="icon-button has-tooltip"
        data-tooltip={isArabic ? "تفضيلات العرض" : "Display preferences"}
        onClick={() => setOpen(!open)}
        aria-label={isArabic ? "تفضيلات العرض" : "Display preferences"}
      >
        <Settings2 size={17} />
      </button>
      {open && (
        <section className="preferences-popover">
          <div className="preferences-title">
            <div>
              <Settings2 size={16} />
              <b>{isArabic ? "راحة الكونسول" : "Console comfort"}</b>
            </div>
            <button onClick={prefs.reset}>
              {isArabic ? "إعادة" : "Reset"}
            </button>
          </div>
          <div className="preference-grid">
            <Switch
              label={isArabic ? "الوضع الداكن" : "Dark mode"}
              enabled={prefs.darkMode}
              onChange={() => {
                prefs.setPreference("visualMode", "original");
                prefs.setPreference("darkMode", !prefs.darkMode);
              }}
            />
            <Switch
              label={isArabic ? "اتباع النظام" : "Follow system"}
              enabled={prefs.systemTheme}
              onChange={() =>
                prefs.setPreference("systemTheme", !prefs.systemTheme)
              }
            />
            <Switch
              label={isArabic ? "توهج منخفض" : "Low glare"}
              enabled={prefs.lowGlare}
              onChange={() => prefs.setPreference("lowGlare", !prefs.lowGlare)}
            />
            <Switch
              label={isArabic ? "كثافة مدمجة" : "Compact density"}
              enabled={prefs.compact}
              onChange={() => prefs.setPreference("compact", !prefs.compact)}
            />
            <Switch
              label={isArabic ? "تقليل الحركة" : "Reduce motion"}
              enabled={prefs.reduceMotion}
              onChange={() =>
                prefs.setPreference("reduceMotion", !prefs.reduceMotion)
              }
            />
            <Switch
              label={isArabic ? "خطوط المسح" : "Scanlines"}
              enabled={prefs.scanlines}
              onChange={() =>
                prefs.setPreference("scanlines", !prefs.scanlines)
              }
            />
            <Switch
              label={isArabic ? "توهج الإشارة" : "Signal glow"}
              enabled={prefs.glow}
              onChange={() => prefs.setPreference("glow", !prefs.glow)}
            />
            <Switch
              label={isArabic ? "تحديث تلقائي" : "Auto refresh"}
              enabled={prefs.autoRefresh}
              onChange={() =>
                prefs.setPreference("autoRefresh", !prefs.autoRefresh)
              }
            />
            <Switch
              label={isArabic ? "وضع تركيز" : "Focus mode"}
              enabled={prefs.focusMode}
              onChange={() =>
                prefs.setPreference("focusMode", !prefs.focusMode)
              }
            />
            <Switch
              label={isArabic ? "إظهار الوحدات" : "Show units"}
              enabled={prefs.showUnits}
              onChange={() =>
                prefs.setPreference("showUnits", !prefs.showUnits)
              }
            />
          </div>
          <label className="visual-mode-select">
            <ScanLine size={14} />
            {isArabic ? "نمط الألوان" : "Color mode"}
            <select
              value={prefs.visualMode}
              onChange={event =>
                prefs.setPreference("visualMode", event.target.value as VisualMode)
              }
            >
              <option value="original">{isArabic ? "الأصلي" : "Original"}</option>
              <option value="color">{isArabic ? "ألوان حيوية" : "Vivid color"}</option>
              <option value="white">{isArabic ? "أبيض" : "White"}</option>
              <option value="black">{isArabic ? "أسود" : "Black"}</option>
            </select>
          </label>
          <div className="preference-selects">
            <label>
              <Type size={14} />
              {isArabic ? "حجم الخط" : "Font scale"}
              <select
                value={prefs.fontScale}
                onChange={event =>
                  prefs.setPreference(
                    "fontScale",
                    event.target.value as FontScale
                  )
                }
              >
                <option value="small">{isArabic ? "صغير" : "Small"}</option>
                <option value="normal">{isArabic ? "عادي" : "Normal"}</option>
                <option value="large">{isArabic ? "كبير" : "Large"}</option>
              </select>
            </label>
            <label>
              <SunMedium size={14} />
              {isArabic ? "الزمن" : "Time"}
              <select
                value={prefs.timeMode}
                onChange={event =>
                  prefs.setPreference(
                    "timeMode",
                    event.target.value as TimeMode
                  )
                }
              >
                <option value="local">{isArabic ? "محلي" : "Local"}</option>
                <option value="utc">UTC</option>
              </select>
            </label>
          </div>
          <p>
            <Moon size={13} />
            {isArabic
              ? "Alt+D للتوهج المنخفض · Alt+Shift+D للوضع الداكن · Alt+M لتقليل الحركة"
              : "Alt+D low glare · Alt+Shift+D dark mode · Alt+M reduce motion"}
          </p>
        </section>
      )}
    </div>
  );
}
