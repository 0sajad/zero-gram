const localGuest = {
  id: 0,
  openId: "local-guest",
  name: "ZERO GRAM Guest",
  email: null,
  loginMethod: "local",
  role: "user" as const,
  createdAt: new Date(0),
  updatedAt: new Date(0),
  lastSignedIn: new Date(0),
};

/** Local-only identity. ZERO GRAM no longer redirects to an external identity provider. */
export function useAuth() {
  return {
    user: localGuest,
    loading: false,
    error: null,
    isAuthenticated: true,
    refresh: async () => localGuest,
    logout: async () => undefined,
  };
}
