CREATE TABLE `capacity_snapshots` (
	`id` int AUTO_INCREMENT NOT NULL,
	`organizationId` int NOT NULL,
	`currentUsageMbps` double,
	`peakUsageMbps` double,
	`averageUsageMbps` double,
	`peakWindow` varchar(160),
	`sourceLabel` varchar(160) NOT NULL,
	`measuredAt` timestamp NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `capacity_snapshots_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `network_identities` (
	`id` int AUTO_INCREMENT NOT NULL,
	`organizationId` int NOT NULL,
	`siteId` int,
	`label` varchar(180) NOT NULL,
	`isPrimary` boolean NOT NULL DEFAULT false,
	`ispName` varchar(180),
	`asn` varchar(80),
	`asName` varchar(255),
	`organizationName` varchar(255),
	`publicIp` varchar(128),
	`ipv4Status` varchar(60),
	`ipv6Status` varchar(60),
	`ispDomain` varchar(255),
	`networkPrefix` varchar(128),
	`country` varchar(120),
	`region` varchar(160),
	`city` varchar(160),
	`hostname` varchar(255),
	`reverseDns` varchar(255),
	`connectionType` varchar(120),
	`detectedNetwork` varchar(255),
	`networkProvider` varchar(255),
	`sourceLabel` varchar(160) NOT NULL,
	`observedAt` timestamp NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `network_identities_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `network_packages` (
	`id` int AUTO_INCREMENT NOT NULL,
	`organizationId` int NOT NULL,
	`label` varchar(180) NOT NULL,
	`downloadMbps` double,
	`uploadMbps` double,
	`expectedDownloadMinMbps` double,
	`expectedDownloadMaxMbps` double,
	`expectedUploadMinMbps` double,
	`expectedUploadMaxMbps` double,
	`sourceLabel` varchar(160) NOT NULL,
	`observedAt` timestamp NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `network_packages_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `organization_profiles` (
	`id` int AUTO_INCREMENT NOT NULL,
	`organizationId` int NOT NULL,
	`companyName` varchar(180) NOT NULL,
	`logoUrl` varchar(2048),
	`description` text,
	`networkType` varchar(120),
	`declaredUserCount` int,
	`declaredBranchCount` int,
	`totalBandwidthMbps` double,
	`capacityWarningPercent` int,
	`nocInformation` text,
	`technicalSupportInformation` text,
	`contactInformation` text,
	`maintenanceInformation` text,
	`sourceLabel` varchar(160) NOT NULL,
	`sourceObservedAt` timestamp NOT NULL,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `organization_profiles_id` PRIMARY KEY(`id`),
	CONSTRAINT `organization_profiles_organizationId_unique` UNIQUE(`organizationId`)
);
--> statement-breakpoint
CREATE INDEX `capacity_snapshots_org_time_idx` ON `capacity_snapshots` (`organizationId`,`measuredAt`);--> statement-breakpoint
CREATE INDEX `network_identity_org_idx` ON `network_identities` (`organizationId`);--> statement-breakpoint
CREATE INDEX `network_identity_primary_idx` ON `network_identities` (`organizationId`,`isPrimary`);--> statement-breakpoint
CREATE INDEX `network_packages_org_idx` ON `network_packages` (`organizationId`);--> statement-breakpoint
CREATE INDEX `org_profile_org_idx` ON `organization_profiles` (`organizationId`);