CREATE TABLE `change_records` (
	`id` int AUTO_INCREMENT NOT NULL,
	`organizationId` int NOT NULL,
	`deviceId` int,
	`changeType` varchar(120) NOT NULL,
	`title` varchar(240) NOT NULL,
	`beforeJson` text,
	`afterJson` text,
	`sourceLabel` varchar(160) NOT NULL,
	`changedAt` timestamp NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `change_records_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `incidents` (
	`id` int AUTO_INCREMENT NOT NULL,
	`organizationId` int NOT NULL,
	`reference` varchar(120) NOT NULL,
	`title` varchar(240) NOT NULL,
	`severity` enum('critical','high','medium','low') NOT NULL DEFAULT 'medium',
	`state` enum('open','investigating','resolved') NOT NULL DEFAULT 'open',
	`startedAt` timestamp NOT NULL,
	`endedAt` timestamp,
	`affectedServiceCount` int,
	`affectedDeviceIdsJson` text,
	`relatedEventIdsJson` text,
	`rootCause` text,
	`rootCauseConfidence` int,
	`resolution` text,
	`engineerNotes` text,
	`sourceLabel` varchar(160) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `incidents_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE INDEX `changes_org_time_idx` ON `change_records` (`organizationId`,`changedAt`);--> statement-breakpoint
CREATE INDEX `changes_device_idx` ON `change_records` (`deviceId`);--> statement-breakpoint
CREATE INDEX `incidents_org_state_idx` ON `incidents` (`organizationId`,`state`);--> statement-breakpoint
CREATE INDEX `incidents_org_time_idx` ON `incidents` (`organizationId`,`startedAt`);