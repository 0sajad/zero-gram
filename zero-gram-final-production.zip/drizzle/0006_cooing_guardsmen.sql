CREATE TABLE `mac_table_entries` (
	`id` int AUTO_INCREMENT NOT NULL,
	`organizationId` int NOT NULL,
	`deviceId` int NOT NULL,
	`macAddress` varchar(32) NOT NULL,
	`ipAddress` varchar(128),
	`vlanId` varchar(80),
	`interfaceLabel` varchar(120),
	`hostname` varchar(255),
	`sourceLabel` varchar(160) NOT NULL,
	`observedAt` timestamp NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `mac_table_entries_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE INDEX `mac_entries_org_device_idx` ON `mac_table_entries` (`organizationId`,`deviceId`);--> statement-breakpoint
CREATE INDEX `mac_entries_mac_idx` ON `mac_table_entries` (`macAddress`);--> statement-breakpoint
CREATE INDEX `mac_entries_ip_idx` ON `mac_table_entries` (`ipAddress`);