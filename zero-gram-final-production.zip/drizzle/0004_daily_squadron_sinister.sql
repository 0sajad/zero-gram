CREATE TABLE `alerts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`organizationId` int NOT NULL,
	`deviceId` int,
	`topologyNodeId` int,
	`severity` enum('critical','high','medium','low','informational') NOT NULL,
	`status` enum('open','acknowledged','resolved') NOT NULL DEFAULT 'open',
	`title` varchar(240) NOT NULL,
	`impact` text,
	`probableCause` text,
	`evidenceJson` text,
	`recommendedCheck` text,
	`sourceLabel` varchar(160) NOT NULL,
	`openedAt` timestamp NOT NULL,
	`acknowledgedAt` timestamp,
	`resolvedAt` timestamp,
	CONSTRAINT `alerts_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `device_ip_addresses` (
	`id` int AUTO_INCREMENT NOT NULL,
	`organizationId` int NOT NULL,
	`deviceId` int NOT NULL,
	`address` varchar(128) NOT NULL,
	`family` enum('ipv4','ipv6') NOT NULL,
	`scope` enum('public','private','local','gateway','dns','management','client') NOT NULL,
	`hostname` varchar(255),
	`sourceLabel` varchar(160),
	`observedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `device_ip_addresses_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `ethernet_ports` (
	`id` int AUTO_INCREMENT NOT NULL,
	`organizationId` int NOT NULL,
	`deviceId` int NOT NULL,
	`label` varchar(120) NOT NULL,
	`linkStatus` varchar(40),
	`negotiatedSpeedMbps` int,
	`duplex` varchar(40),
	`rxPackets` double,
	`txPackets` double,
	`crcErrors` double,
	`interfaceErrors` double,
	`flappingCount` int,
	`sourceLabel` varchar(160),
	`observedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `ethernet_ports_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `health_snapshots` (
	`id` int AUTO_INCREMENT NOT NULL,
	`organizationId` int NOT NULL,
	`deviceId` int NOT NULL,
	`overallScore` int NOT NULL,
	`opticalScore` int,
	`networkScore` int,
	`deviceScore` int,
	`ethernetScore` int,
	`wifiScore` int,
	`authenticationScore` int,
	`explanationJson` text NOT NULL,
	`sourceLabel` varchar(160) NOT NULL,
	`calculatedAt` timestamp NOT NULL,
	CONSTRAINT `health_snapshots_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `import_batches` (
	`id` int AUTO_INCREMENT NOT NULL,
	`organizationId` int NOT NULL,
	`userId` int NOT NULL,
	`sourceName` varchar(255) NOT NULL,
	`sourceType` enum('csv','json','api','manual') NOT NULL,
	`recordCount` int NOT NULL,
	`validationSummaryJson` text NOT NULL,
	`importedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `import_batches_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `ont_units` (
	`id` int AUTO_INCREMENT NOT NULL,
	`organizationId` int NOT NULL,
	`deviceId` int NOT NULL,
	`ponPortId` int,
	`subscriberId` int,
	`onuId` varchar(160),
	`authenticationStatus` varchar(60),
	`ponStatus` varchar(60),
	`losState` varchar(40),
	`lofState` varchar(40),
	`dyingGaspState` varchar(40),
	`opticalDistanceKm` double,
	`pppoeUsername` varchar(180),
	`vlanId` varchar(80),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `ont_units_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `operational_events` (
	`id` int AUTO_INCREMENT NOT NULL,
	`organizationId` int NOT NULL,
	`deviceId` int,
	`topologyNodeId` int,
	`eventType` varchar(120) NOT NULL,
	`title` varchar(240) NOT NULL,
	`severity` enum('critical','high','medium','low','informational') NOT NULL DEFAULT 'informational',
	`evidenceJson` text,
	`sourceLabel` varchar(160) NOT NULL,
	`occurredAt` timestamp NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `operational_events_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `pon_ports` (
	`id` int AUTO_INCREMENT NOT NULL,
	`organizationId` int NOT NULL,
	`oltDeviceId` int NOT NULL,
	`label` varchar(120) NOT NULL,
	`ponIndex` varchar(80),
	`administrativeStatus` varchar(40),
	`operationalStatus` varchar(40),
	`maxOnts` int,
	`sourceLabel` varchar(160),
	`sourceObservedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `pon_ports_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `service_sessions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`organizationId` int NOT NULL,
	`deviceId` int,
	`subscriberId` int,
	`sessionType` enum('pppoe','dhcp','dns','vlan','route','arp') NOT NULL,
	`username` varchar(180),
	`vlanId` varchar(80),
	`mtu` int,
	`gatewayAddress` varchar(128),
	`dnsServersJson` text,
	`status` varchar(60),
	`startedAt` timestamp,
	`observedAt` timestamp NOT NULL DEFAULT (now()),
	`sourceLabel` varchar(160),
	CONSTRAINT `service_sessions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `telemetry_samples` (
	`id` int AUTO_INCREMENT NOT NULL,
	`organizationId` int NOT NULL,
	`deviceId` int,
	`ontUnitId` int,
	`ponPortId` int,
	`metric` varchar(120) NOT NULL,
	`valueDouble` double,
	`valueText` text,
	`unit` varchar(40),
	`state` varchar(60),
	`sourceLabel` varchar(160) NOT NULL,
	`measuredAt` timestamp NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `telemetry_samples_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `topology_edges` (
	`id` int AUTO_INCREMENT NOT NULL,
	`organizationId` int NOT NULL,
	`sourceNodeId` int NOT NULL,
	`targetNodeId` int NOT NULL,
	`relationType` varchar(80) NOT NULL,
	`fiberLengthKm` double,
	`baselineLossDb` double,
	`sourceLabel` varchar(160),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `topology_edges_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `topology_nodes` (
	`id` int AUTO_INCREMENT NOT NULL,
	`organizationId` int NOT NULL,
	`deviceId` int,
	`nodeKind` enum('internet','core','olt','pon','splitter','fiber','distribution_box','onu','ont','router','switch','gateway','access_point','client','service') NOT NULL,
	`label` varchar(180) NOT NULL,
	`reference` varchar(160),
	`status` varchar(60),
	`sourceLabel` varchar(160),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `topology_nodes_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `wifi_clients` (
	`id` int AUTO_INCREMENT NOT NULL,
	`organizationId` int NOT NULL,
	`wifiNetworkId` int NOT NULL,
	`macAddress` varchar(32),
	`ipAddress` varchar(128),
	`hostname` varchar(255),
	`signalDbm` double,
	`rxRateMbps` double,
	`txRateMbps` double,
	`connectedAt` timestamp,
	`sourceLabel` varchar(160),
	`observedAt` timestamp,
	CONSTRAINT `wifi_clients_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `wifi_networks` (
	`id` int AUTO_INCREMENT NOT NULL,
	`organizationId` int NOT NULL,
	`deviceId` int NOT NULL,
	`ssid` varchar(160) NOT NULL,
	`band` varchar(30),
	`channel` varchar(40),
	`channelWidthMHz` int,
	`signalDbm` double,
	`noiseDbm` double,
	`interferenceLevel` varchar(40),
	`authentication` varchar(80),
	`sourceLabel` varchar(160),
	`observedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `wifi_networks_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `network_devices` ADD `vendor` varchar(120);--> statement-breakpoint
ALTER TABLE `network_devices` ADD `model` varchar(160);--> statement-breakpoint
ALTER TABLE `network_devices` ADD `serialNumber` varchar(160);--> statement-breakpoint
ALTER TABLE `network_devices` ADD `macAddress` varchar(32);--> statement-breakpoint
ALTER TABLE `network_devices` ADD `hostname` varchar(255);--> statement-breakpoint
ALTER TABLE `network_devices` ADD `managementIpv4` varchar(64);--> statement-breakpoint
ALTER TABLE `network_devices` ADD `managementIpv6` varchar(128);--> statement-breakpoint
ALTER TABLE `network_devices` ADD `firmwareVersion` varchar(160);--> statement-breakpoint
ALTER TABLE `network_devices` ADD `uptimeSeconds` int;--> statement-breakpoint
ALTER TABLE `network_devices` ADD `linkStatus` varchar(40);--> statement-breakpoint
ALTER TABLE `network_devices` ADD `connectionStatus` varchar(40);--> statement-breakpoint
ALTER TABLE `network_devices` ADD `sourceLabel` varchar(160);--> statement-breakpoint
ALTER TABLE `network_devices` ADD `sourceObservedAt` timestamp;--> statement-breakpoint
CREATE INDEX `alerts_org_status_idx` ON `alerts` (`organizationId`,`status`);--> statement-breakpoint
CREATE INDEX `alerts_device_idx` ON `alerts` (`deviceId`);--> statement-breakpoint
CREATE INDEX `device_ips_org_device_idx` ON `device_ip_addresses` (`organizationId`,`deviceId`);--> statement-breakpoint
CREATE INDEX `device_ips_address_idx` ON `device_ip_addresses` (`address`);--> statement-breakpoint
CREATE INDEX `ethernet_ports_org_device_idx` ON `ethernet_ports` (`organizationId`,`deviceId`);--> statement-breakpoint
CREATE INDEX `health_org_device_time_idx` ON `health_snapshots` (`organizationId`,`deviceId`,`calculatedAt`);--> statement-breakpoint
CREATE INDEX `import_batches_org_time_idx` ON `import_batches` (`organizationId`,`importedAt`);--> statement-breakpoint
CREATE INDEX `ont_units_org_device_idx` ON `ont_units` (`organizationId`,`deviceId`);--> statement-breakpoint
CREATE INDEX `ont_units_pon_idx` ON `ont_units` (`ponPortId`);--> statement-breakpoint
CREATE INDEX `operational_events_org_time_idx` ON `operational_events` (`organizationId`,`occurredAt`);--> statement-breakpoint
CREATE INDEX `operational_events_device_time_idx` ON `operational_events` (`deviceId`,`occurredAt`);--> statement-breakpoint
CREATE INDEX `pon_ports_org_olt_idx` ON `pon_ports` (`organizationId`,`oltDeviceId`);--> statement-breakpoint
CREATE INDEX `service_sessions_org_device_idx` ON `service_sessions` (`organizationId`,`deviceId`);--> statement-breakpoint
CREATE INDEX `service_sessions_user_idx` ON `service_sessions` (`username`);--> statement-breakpoint
CREATE INDEX `telemetry_org_metric_time_idx` ON `telemetry_samples` (`organizationId`,`metric`,`measuredAt`);--> statement-breakpoint
CREATE INDEX `telemetry_device_metric_time_idx` ON `telemetry_samples` (`deviceId`,`metric`,`measuredAt`);--> statement-breakpoint
CREATE INDEX `topology_edges_org_idx` ON `topology_edges` (`organizationId`);--> statement-breakpoint
CREATE INDEX `topology_edges_source_idx` ON `topology_edges` (`sourceNodeId`);--> statement-breakpoint
CREATE INDEX `topology_edges_target_idx` ON `topology_edges` (`targetNodeId`);--> statement-breakpoint
CREATE INDEX `topology_nodes_org_idx` ON `topology_nodes` (`organizationId`);--> statement-breakpoint
CREATE INDEX `topology_nodes_device_idx` ON `topology_nodes` (`deviceId`);--> statement-breakpoint
CREATE INDEX `wifi_clients_org_network_idx` ON `wifi_clients` (`organizationId`,`wifiNetworkId`);--> statement-breakpoint
CREATE INDEX `wifi_clients_mac_idx` ON `wifi_clients` (`macAddress`);--> statement-breakpoint
CREATE INDEX `wifi_networks_org_device_idx` ON `wifi_networks` (`organizationId`,`deviceId`);