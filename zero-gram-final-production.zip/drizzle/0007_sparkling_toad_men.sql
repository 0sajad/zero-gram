CREATE TABLE `fiber_monitoring_policies` (
	`id` int AUTO_INCREMENT NOT NULL,
	`organizationId` int NOT NULL,
	`opticalRxWarningDbm` double,
	`opticalLossWarningDb` double,
	`latencyWarningMs` int,
	`jitterWarningMs` int,
	`retentionDays` int,
	`alertRepeatThreshold` int,
	`sourceLabel` varchar(160) NOT NULL,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `fiber_monitoring_policies_id` PRIMARY KEY(`id`),
	CONSTRAINT `fiber_monitoring_policies_organizationId_unique` UNIQUE(`organizationId`)
);
--> statement-breakpoint
CREATE INDEX `fiber_policy_org_idx` ON `fiber_monitoring_policies` (`organizationId`);