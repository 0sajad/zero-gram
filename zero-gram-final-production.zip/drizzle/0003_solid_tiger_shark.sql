CREATE TABLE `network_pops` (
	`id` int AUTO_INCREMENT NOT NULL,
	`organizationId` int NOT NULL,
	`label` varchar(160) NOT NULL,
	`code` varchar(80) NOT NULL,
	`locationReference` varchar(180),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `network_pops_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `result_share_links` (
	`id` int AUTO_INCREMENT NOT NULL,
	`organizationId` int NOT NULL,
	`resultId` int NOT NULL,
	`createdByUserId` int NOT NULL,
	`shareToken` varchar(96) NOT NULL,
	`isActive` boolean NOT NULL DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`expiresAt` timestamp,
	CONSTRAINT `result_share_links_id` PRIMARY KEY(`id`),
	CONSTRAINT `result_share_links_shareToken_unique` UNIQUE(`shareToken`)
);
--> statement-breakpoint
CREATE TABLE `result_share_views` (
	`id` int AUTO_INCREMENT NOT NULL,
	`shareLinkId` int NOT NULL,
	`viewedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `result_share_views_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE INDEX `pops_org_idx` ON `network_pops` (`organizationId`);--> statement-breakpoint
CREATE INDEX `share_links_result_idx` ON `result_share_links` (`resultId`);--> statement-breakpoint
CREATE INDEX `share_links_org_idx` ON `result_share_links` (`organizationId`);--> statement-breakpoint
CREATE INDEX `share_views_link_time_idx` ON `result_share_views` (`shareLinkId`,`viewedAt`);