import {
  boolean,
  double,
  index,
  int,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  varchar,
} from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export const organizations = mysqlTable("organizations", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 180 }).notNull(),
  slug: varchar("slug", { length: 100 }).notNull().unique(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const organizationMembers = mysqlTable(
  "organization_members",
  {
    id: int("id").autoincrement().primaryKey(),
    organizationId: int("organizationId").notNull(),
    userId: int("userId").notNull(),
    role: mysqlEnum("role", ["owner", "admin", "operator", "viewer"])
      .default("owner")
      .notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => [
    index("org_member_org_user_idx").on(table.organizationId, table.userId),
  ]
);

/** Manually maintained operating context; capacity values are declared, not measured usage. */
export const organizationProfiles = mysqlTable(
  "organization_profiles",
  {
    id: int("id").autoincrement().primaryKey(),
    organizationId: int("organizationId").notNull().unique(),
    companyName: varchar("companyName", { length: 180 }).notNull(),
    logoUrl: varchar("logoUrl", { length: 2048 }),
    description: text("description"),
    networkType: varchar("networkType", { length: 120 }),
    declaredUserCount: int("declaredUserCount"),
    declaredBranchCount: int("declaredBranchCount"),
    totalBandwidthMbps: double("totalBandwidthMbps"),
    capacityWarningPercent: int("capacityWarningPercent"),
    nocInformation: text("nocInformation"),
    technicalSupportInformation: text("technicalSupportInformation"),
    contactInformation: text("contactInformation"),
    maintenanceInformation: text("maintenanceInformation"),
    sourceLabel: varchar("sourceLabel", { length: 160 }).notNull(),
    sourceObservedAt: timestamp("sourceObservedAt").notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => [index("org_profile_org_idx").on(table.organizationId)]
);

/** Identity facts supplied by the organization or a sourced test record. Null means unavailable. */
export const networkIdentities = mysqlTable(
  "network_identities",
  {
    id: int("id").autoincrement().primaryKey(),
    organizationId: int("organizationId").notNull(),
    siteId: int("siteId"),
    label: varchar("label", { length: 180 }).notNull(),
    isPrimary: boolean("isPrimary").default(false).notNull(),
    ispName: varchar("ispName", { length: 180 }),
    asn: varchar("asn", { length: 80 }),
    asName: varchar("asName", { length: 255 }),
    organizationName: varchar("organizationName", { length: 255 }),
    publicIp: varchar("publicIp", { length: 128 }),
    ipv4Status: varchar("ipv4Status", { length: 60 }),
    ipv6Status: varchar("ipv6Status", { length: 60 }),
    ispDomain: varchar("ispDomain", { length: 255 }),
    networkPrefix: varchar("networkPrefix", { length: 128 }),
    country: varchar("country", { length: 120 }),
    region: varchar("region", { length: 160 }),
    city: varchar("city", { length: 160 }),
    hostname: varchar("hostname", { length: 255 }),
    reverseDns: varchar("reverseDns", { length: 255 }),
    connectionType: varchar("connectionType", { length: 120 }),
    detectedNetwork: varchar("detectedNetwork", { length: 255 }),
    networkProvider: varchar("networkProvider", { length: 255 }),
    sourceLabel: varchar("sourceLabel", { length: 160 }).notNull(),
    observedAt: timestamp("observedAt").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => [
    index("network_identity_org_idx").on(table.organizationId),
    index("network_identity_primary_idx").on(
      table.organizationId,
      table.isPrimary
    ),
  ]
);

/** Contract or plan reference used only for sourced performance comparison. */
export const networkPackages = mysqlTable(
  "network_packages",
  {
    id: int("id").autoincrement().primaryKey(),
    organizationId: int("organizationId").notNull(),
    label: varchar("label", { length: 180 }).notNull(),
    downloadMbps: double("downloadMbps"),
    uploadMbps: double("uploadMbps"),
    expectedDownloadMinMbps: double("expectedDownloadMinMbps"),
    expectedDownloadMaxMbps: double("expectedDownloadMaxMbps"),
    expectedUploadMinMbps: double("expectedUploadMinMbps"),
    expectedUploadMaxMbps: double("expectedUploadMaxMbps"),
    sourceLabel: varchar("sourceLabel", { length: 160 }).notNull(),
    observedAt: timestamp("observedAt").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => [index("network_packages_org_idx").on(table.organizationId)]
);

/** Actual current/peak use only when entered or imported with a source. */
export const capacitySnapshots = mysqlTable(
  "capacity_snapshots",
  {
    id: int("id").autoincrement().primaryKey(),
    organizationId: int("organizationId").notNull(),
    currentUsageMbps: double("currentUsageMbps"),
    peakUsageMbps: double("peakUsageMbps"),
    averageUsageMbps: double("averageUsageMbps"),
    peakWindow: varchar("peakWindow", { length: 160 }),
    sourceLabel: varchar("sourceLabel", { length: 160 }).notNull(),
    measuredAt: timestamp("measuredAt").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => [
    index("capacity_snapshots_org_time_idx").on(
      table.organizationId,
      table.measuredAt
    ),
  ]
);

export const organizationInvitations = mysqlTable(
  "organization_invitations",
  {
    id: int("id").autoincrement().primaryKey(),
    organizationId: int("organizationId").notNull(),
    email: varchar("email", { length: 320 }).notNull(),
    role: mysqlEnum("role", ["admin", "operator", "viewer"]).notNull(),
    inviteCode: varchar("inviteCode", { length: 96 }).notNull().unique(),
    status: mysqlEnum("status", ["pending", "accepted", "revoked", "expired"])
      .default("pending")
      .notNull(),
    invitedByUserId: int("invitedByUserId").notNull(),
    expiresAt: timestamp("expiresAt").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    acceptedAt: timestamp("acceptedAt"),
  },
  table => [
    index("org_invites_org_idx").on(table.organizationId),
    index("org_invites_code_idx").on(table.inviteCode),
  ]
);

export const testResults = mysqlTable(
  "test_results",
  {
    id: int("id").autoincrement().primaryKey(),
    organizationId: int("organizationId").notNull(),
    userId: int("userId").notNull(),
    payloadJson: text("payloadJson").notNull(),
    sourceJson: text("sourceJson").notNull(),
    limitationsJson: text("limitationsJson").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => [
    index("test_results_org_created_idx").on(
      table.organizationId,
      table.createdAt
    ),
  ]
);

export const resultShareLinks = mysqlTable(
  "result_share_links",
  {
    id: int("id").autoincrement().primaryKey(),
    organizationId: int("organizationId").notNull(),
    resultId: int("resultId").notNull(),
    createdByUserId: int("createdByUserId").notNull(),
    shareToken: varchar("shareToken", { length: 96 }).notNull().unique(),
    isActive: boolean("isActive").default(true).notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    expiresAt: timestamp("expiresAt"),
  },
  table => [
    index("share_links_result_idx").on(table.resultId),
    index("share_links_org_idx").on(table.organizationId),
  ]
);

export const resultShareViews = mysqlTable(
  "result_share_views",
  {
    id: int("id").autoincrement().primaryKey(),
    shareLinkId: int("shareLinkId").notNull(),
    viewedAt: timestamp("viewedAt").defaultNow().notNull(),
  },
  table => [
    index("share_views_link_time_idx").on(table.shareLinkId, table.viewedAt),
  ]
);

export const monitoringProfiles = mysqlTable(
  "monitoring_profiles",
  {
    id: int("id").autoincrement().primaryKey(),
    organizationId: int("organizationId").notNull(),
    userId: int("userId").notNull(),
    label: varchar("label", { length: 160 }).notNull(),
    targetUrl: varchar("targetUrl", { length: 2048 }).notNull(),
    intervalCron: varchar("intervalCron", { length: 64 }).notNull(),
    failureThreshold: int("failureThreshold").default(3).notNull(),
    slaTargetPercent: int("slaTargetPercent").default(99).notNull(),
    isActive: boolean("isActive").default(true).notNull(),
    scheduleCronTaskUid: varchar("schedule_cron_task_uid", { length: 65 }),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => [
    index("monitoring_schedule_task_idx").on(table.scheduleCronTaskUid),
    index("monitoring_org_idx").on(table.organizationId),
  ]
);

export const monitoringEvents = mysqlTable(
  "monitoring_events",
  {
    id: int("id").autoincrement().primaryKey(),
    profileId: int("profileId").notNull(),
    organizationId: int("organizationId").notNull(),
    state: mysqlEnum("state", ["success", "failure"]).notNull(),
    statusCode: int("statusCode"),
    responseTimeMs: int("responseTimeMs"),
    errorMessage: text("errorMessage"),
    checkedAt: timestamp("checkedAt").defaultNow().notNull(),
  },
  table => [
    index("monitoring_events_profile_time_idx").on(
      table.profileId,
      table.checkedAt
    ),
  ]
);

export const subscribers = mysqlTable(
  "subscribers",
  {
    id: int("id").autoincrement().primaryKey(),
    organizationId: int("organizationId").notNull(),
    reference: varchar("reference", { length: 120 }).notNull(),
    displayName: varchar("displayName", { length: 180 }).notNull(),
    status: mysqlEnum("status", ["active", "suspended", "inactive"])
      .default("active")
      .notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => [index("subscribers_org_idx").on(table.organizationId)]
);

export const networkSites = mysqlTable(
  "network_sites",
  {
    id: int("id").autoincrement().primaryKey(),
    organizationId: int("organizationId").notNull(),
    name: varchar("name", { length: 180 }).notNull(),
    siteType: varchar("siteType", { length: 80 }).notNull(),
    reference: varchar("reference", { length: 120 }),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => [index("sites_org_idx").on(table.organizationId)]
);

export const networkPops = mysqlTable(
  "network_pops",
  {
    id: int("id").autoincrement().primaryKey(),
    organizationId: int("organizationId").notNull(),
    label: varchar("label", { length: 160 }).notNull(),
    code: varchar("code", { length: 80 }).notNull(),
    locationReference: varchar("locationReference", { length: 180 }),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => [index("pops_org_idx").on(table.organizationId)]
);

export const networkDevices = mysqlTable(
  "network_devices",
  {
    id: int("id").autoincrement().primaryKey(),
    organizationId: int("organizationId").notNull(),
    siteId: int("siteId"),
    label: varchar("label", { length: 160 }).notNull(),
    deviceType: varchar("deviceType", { length: 80 }).notNull(),
    managementReference: varchar("managementReference", { length: 255 }),
    vendor: varchar("vendor", { length: 120 }),
    model: varchar("model", { length: 160 }),
    serialNumber: varchar("serialNumber", { length: 160 }),
    macAddress: varchar("macAddress", { length: 32 }),
    hostname: varchar("hostname", { length: 255 }),
    managementIpv4: varchar("managementIpv4", { length: 64 }),
    managementIpv6: varchar("managementIpv6", { length: 128 }),
    firmwareVersion: varchar("firmwareVersion", { length: 160 }),
    uptimeSeconds: int("uptimeSeconds"),
    linkStatus: varchar("linkStatus", { length: 40 }),
    connectionStatus: varchar("connectionStatus", { length: 40 }),
    sourceLabel: varchar("sourceLabel", { length: 160 }),
    sourceObservedAt: timestamp("sourceObservedAt"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => [index("devices_org_idx").on(table.organizationId)]
);

export const ponPorts = mysqlTable(
  "pon_ports",
  {
    id: int("id").autoincrement().primaryKey(),
    organizationId: int("organizationId").notNull(),
    oltDeviceId: int("oltDeviceId").notNull(),
    label: varchar("label", { length: 120 }).notNull(),
    ponIndex: varchar("ponIndex", { length: 80 }),
    administrativeStatus: varchar("administrativeStatus", { length: 40 }),
    operationalStatus: varchar("operationalStatus", { length: 40 }),
    maxOnts: int("maxOnts"),
    sourceLabel: varchar("sourceLabel", { length: 160 }),
    sourceObservedAt: timestamp("sourceObservedAt"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => [
    index("pon_ports_org_olt_idx").on(table.organizationId, table.oltDeviceId),
  ]
);

export const ontUnits = mysqlTable(
  "ont_units",
  {
    id: int("id").autoincrement().primaryKey(),
    organizationId: int("organizationId").notNull(),
    deviceId: int("deviceId").notNull(),
    ponPortId: int("ponPortId"),
    subscriberId: int("subscriberId"),
    onuId: varchar("onuId", { length: 160 }),
    authenticationStatus: varchar("authenticationStatus", { length: 60 }),
    ponStatus: varchar("ponStatus", { length: 60 }),
    losState: varchar("losState", { length: 40 }),
    lofState: varchar("lofState", { length: 40 }),
    dyingGaspState: varchar("dyingGaspState", { length: 40 }),
    opticalDistanceKm: double("opticalDistanceKm"),
    pppoeUsername: varchar("pppoeUsername", { length: 180 }),
    vlanId: varchar("vlanId", { length: 80 }),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => [
    index("ont_units_org_device_idx").on(table.organizationId, table.deviceId),
    index("ont_units_pon_idx").on(table.ponPortId),
  ]
);

export const deviceIpAddresses = mysqlTable(
  "device_ip_addresses",
  {
    id: int("id").autoincrement().primaryKey(),
    organizationId: int("organizationId").notNull(),
    deviceId: int("deviceId").notNull(),
    address: varchar("address", { length: 128 }).notNull(),
    family: mysqlEnum("family", ["ipv4", "ipv6"]).notNull(),
    scope: mysqlEnum("scope", [
      "public",
      "private",
      "local",
      "gateway",
      "dns",
      "management",
      "client",
    ]).notNull(),
    hostname: varchar("hostname", { length: 255 }),
    sourceLabel: varchar("sourceLabel", { length: 160 }),
    observedAt: timestamp("observedAt").defaultNow().notNull(),
  },
  table => [
    index("device_ips_org_device_idx").on(table.organizationId, table.deviceId),
    index("device_ips_address_idx").on(table.address),
  ]
);

export const macTableEntries = mysqlTable(
  "mac_table_entries",
  {
    id: int("id").autoincrement().primaryKey(),
    organizationId: int("organizationId").notNull(),
    deviceId: int("deviceId").notNull(),
    macAddress: varchar("macAddress", { length: 32 }).notNull(),
    ipAddress: varchar("ipAddress", { length: 128 }),
    vlanId: varchar("vlanId", { length: 80 }),
    interfaceLabel: varchar("interfaceLabel", { length: 120 }),
    hostname: varchar("hostname", { length: 255 }),
    sourceLabel: varchar("sourceLabel", { length: 160 }).notNull(),
    observedAt: timestamp("observedAt").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => [
    index("mac_entries_org_device_idx").on(
      table.organizationId,
      table.deviceId
    ),
    index("mac_entries_mac_idx").on(table.macAddress),
    index("mac_entries_ip_idx").on(table.ipAddress),
  ]
);

export const ethernetPorts = mysqlTable(
  "ethernet_ports",
  {
    id: int("id").autoincrement().primaryKey(),
    organizationId: int("organizationId").notNull(),
    deviceId: int("deviceId").notNull(),
    label: varchar("label", { length: 120 }).notNull(),
    linkStatus: varchar("linkStatus", { length: 40 }),
    negotiatedSpeedMbps: int("negotiatedSpeedMbps"),
    duplex: varchar("duplex", { length: 40 }),
    rxPackets: double("rxPackets"),
    txPackets: double("txPackets"),
    crcErrors: double("crcErrors"),
    interfaceErrors: double("interfaceErrors"),
    flappingCount: int("flappingCount"),
    sourceLabel: varchar("sourceLabel", { length: 160 }),
    observedAt: timestamp("observedAt"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => [
    index("ethernet_ports_org_device_idx").on(
      table.organizationId,
      table.deviceId
    ),
  ]
);

export const wifiNetworks = mysqlTable(
  "wifi_networks",
  {
    id: int("id").autoincrement().primaryKey(),
    organizationId: int("organizationId").notNull(),
    deviceId: int("deviceId").notNull(),
    ssid: varchar("ssid", { length: 160 }).notNull(),
    band: varchar("band", { length: 30 }),
    channel: varchar("channel", { length: 40 }),
    channelWidthMHz: int("channelWidthMHz"),
    signalDbm: double("signalDbm"),
    noiseDbm: double("noiseDbm"),
    interferenceLevel: varchar("interferenceLevel", { length: 40 }),
    authentication: varchar("authentication", { length: 80 }),
    sourceLabel: varchar("sourceLabel", { length: 160 }),
    observedAt: timestamp("observedAt"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => [
    index("wifi_networks_org_device_idx").on(
      table.organizationId,
      table.deviceId
    ),
  ]
);

export const wifiClients = mysqlTable(
  "wifi_clients",
  {
    id: int("id").autoincrement().primaryKey(),
    organizationId: int("organizationId").notNull(),
    wifiNetworkId: int("wifiNetworkId").notNull(),
    macAddress: varchar("macAddress", { length: 32 }),
    ipAddress: varchar("ipAddress", { length: 128 }),
    hostname: varchar("hostname", { length: 255 }),
    signalDbm: double("signalDbm"),
    rxRateMbps: double("rxRateMbps"),
    txRateMbps: double("txRateMbps"),
    connectedAt: timestamp("connectedAt"),
    sourceLabel: varchar("sourceLabel", { length: 160 }),
    observedAt: timestamp("observedAt"),
  },
  table => [
    index("wifi_clients_org_network_idx").on(
      table.organizationId,
      table.wifiNetworkId
    ),
    index("wifi_clients_mac_idx").on(table.macAddress),
  ]
);

export const serviceSessions = mysqlTable(
  "service_sessions",
  {
    id: int("id").autoincrement().primaryKey(),
    organizationId: int("organizationId").notNull(),
    deviceId: int("deviceId"),
    subscriberId: int("subscriberId"),
    sessionType: mysqlEnum("sessionType", [
      "pppoe",
      "dhcp",
      "dns",
      "vlan",
      "route",
      "arp",
    ]).notNull(),
    username: varchar("username", { length: 180 }),
    vlanId: varchar("vlanId", { length: 80 }),
    mtu: int("mtu"),
    gatewayAddress: varchar("gatewayAddress", { length: 128 }),
    dnsServersJson: text("dnsServersJson"),
    status: varchar("status", { length: 60 }),
    startedAt: timestamp("startedAt"),
    observedAt: timestamp("observedAt").defaultNow().notNull(),
    sourceLabel: varchar("sourceLabel", { length: 160 }),
  },
  table => [
    index("service_sessions_org_device_idx").on(
      table.organizationId,
      table.deviceId
    ),
    index("service_sessions_user_idx").on(table.username),
  ]
);

export const topologyNodes = mysqlTable(
  "topology_nodes",
  {
    id: int("id").autoincrement().primaryKey(),
    organizationId: int("organizationId").notNull(),
    deviceId: int("deviceId"),
    nodeKind: mysqlEnum("nodeKind", [
      "internet",
      "core",
      "olt",
      "pon",
      "splitter",
      "fiber",
      "distribution_box",
      "onu",
      "ont",
      "router",
      "switch",
      "gateway",
      "access_point",
      "client",
      "service",
    ]).notNull(),
    label: varchar("label", { length: 180 }).notNull(),
    reference: varchar("reference", { length: 160 }),
    status: varchar("status", { length: 60 }),
    sourceLabel: varchar("sourceLabel", { length: 160 }),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => [
    index("topology_nodes_org_idx").on(table.organizationId),
    index("topology_nodes_device_idx").on(table.deviceId),
  ]
);

export const topologyEdges = mysqlTable(
  "topology_edges",
  {
    id: int("id").autoincrement().primaryKey(),
    organizationId: int("organizationId").notNull(),
    sourceNodeId: int("sourceNodeId").notNull(),
    targetNodeId: int("targetNodeId").notNull(),
    relationType: varchar("relationType", { length: 80 }).notNull(),
    fiberLengthKm: double("fiberLengthKm"),
    baselineLossDb: double("baselineLossDb"),
    sourceLabel: varchar("sourceLabel", { length: 160 }),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => [
    index("topology_edges_org_idx").on(table.organizationId),
    index("topology_edges_source_idx").on(table.sourceNodeId),
    index("topology_edges_target_idx").on(table.targetNodeId),
  ]
);

export const telemetrySamples = mysqlTable(
  "telemetry_samples",
  {
    id: int("id").autoincrement().primaryKey(),
    organizationId: int("organizationId").notNull(),
    deviceId: int("deviceId"),
    ontUnitId: int("ontUnitId"),
    ponPortId: int("ponPortId"),
    metric: varchar("metric", { length: 120 }).notNull(),
    valueDouble: double("valueDouble"),
    valueText: text("valueText"),
    unit: varchar("unit", { length: 40 }),
    state: varchar("state", { length: 60 }),
    sourceLabel: varchar("sourceLabel", { length: 160 }).notNull(),
    measuredAt: timestamp("measuredAt").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => [
    index("telemetry_org_metric_time_idx").on(
      table.organizationId,
      table.metric,
      table.measuredAt
    ),
    index("telemetry_device_metric_time_idx").on(
      table.deviceId,
      table.metric,
      table.measuredAt
    ),
  ]
);

export const operationalEvents = mysqlTable(
  "operational_events",
  {
    id: int("id").autoincrement().primaryKey(),
    organizationId: int("organizationId").notNull(),
    deviceId: int("deviceId"),
    topologyNodeId: int("topologyNodeId"),
    eventType: varchar("eventType", { length: 120 }).notNull(),
    title: varchar("title", { length: 240 }).notNull(),
    severity: mysqlEnum("severity", [
      "critical",
      "high",
      "medium",
      "low",
      "informational",
    ])
      .default("informational")
      .notNull(),
    evidenceJson: text("evidenceJson"),
    sourceLabel: varchar("sourceLabel", { length: 160 }).notNull(),
    occurredAt: timestamp("occurredAt").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => [
    index("operational_events_org_time_idx").on(
      table.organizationId,
      table.occurredAt
    ),
    index("operational_events_device_time_idx").on(
      table.deviceId,
      table.occurredAt
    ),
  ]
);

/** Incident records are created from sourced evidence; automated suggestions are never persisted as facts. */
export const incidents = mysqlTable(
  "incidents",
  {
    id: int("id").autoincrement().primaryKey(),
    organizationId: int("organizationId").notNull(),
    reference: varchar("reference", { length: 120 }).notNull(),
    title: varchar("title", { length: 240 }).notNull(),
    severity: mysqlEnum("severity", ["critical", "high", "medium", "low"])
      .default("medium")
      .notNull(),
    state: mysqlEnum("state", ["open", "investigating", "resolved"])
      .default("open")
      .notNull(),
    startedAt: timestamp("startedAt").notNull(),
    endedAt: timestamp("endedAt"),
    affectedServiceCount: int("affectedServiceCount"),
    affectedDeviceIdsJson: text("affectedDeviceIdsJson"),
    relatedEventIdsJson: text("relatedEventIdsJson"),
    rootCause: text("rootCause"),
    rootCauseConfidence: int("rootCauseConfidence"),
    resolution: text("resolution"),
    engineerNotes: text("engineerNotes"),
    sourceLabel: varchar("sourceLabel", { length: 160 }).notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => [
    index("incidents_org_state_idx").on(table.organizationId, table.state),
    index("incidents_org_time_idx").on(table.organizationId, table.startedAt),
  ]
);

/** Sourced before/after snapshots for operational change detection. */
export const changeRecords = mysqlTable(
  "change_records",
  {
    id: int("id").autoincrement().primaryKey(),
    organizationId: int("organizationId").notNull(),
    deviceId: int("deviceId"),
    changeType: varchar("changeType", { length: 120 }).notNull(),
    title: varchar("title", { length: 240 }).notNull(),
    beforeJson: text("beforeJson"),
    afterJson: text("afterJson"),
    sourceLabel: varchar("sourceLabel", { length: 160 }).notNull(),
    changedAt: timestamp("changedAt").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => [
    index("changes_org_time_idx").on(table.organizationId, table.changedAt),
    index("changes_device_idx").on(table.deviceId),
  ]
);

export const healthSnapshots = mysqlTable(
  "health_snapshots",
  {
    id: int("id").autoincrement().primaryKey(),
    organizationId: int("organizationId").notNull(),
    deviceId: int("deviceId").notNull(),
    overallScore: int("overallScore").notNull(),
    opticalScore: int("opticalScore"),
    networkScore: int("networkScore"),
    deviceScore: int("deviceScore"),
    ethernetScore: int("ethernetScore"),
    wifiScore: int("wifiScore"),
    authenticationScore: int("authenticationScore"),
    serviceStabilityScore: int("serviceStabilityScore"),
    explanationJson: text("explanationJson").notNull(),
    sourceLabel: varchar("sourceLabel", { length: 160 }).notNull(),
    calculatedAt: timestamp("calculatedAt").notNull(),
  },
  table => [
    index("health_org_device_time_idx").on(
      table.organizationId,
      table.deviceId,
      table.calculatedAt
    ),
  ]
);

export const fiberMonitoringPolicies = mysqlTable(
  "fiber_monitoring_policies",
  {
    id: int("id").autoincrement().primaryKey(),
    organizationId: int("organizationId").notNull().unique(),
    opticalRxWarningDbm: double("opticalRxWarningDbm"),
    opticalLossWarningDb: double("opticalLossWarningDb"),
    latencyWarningMs: int("latencyWarningMs"),
    jitterWarningMs: int("jitterWarningMs"),
    retentionDays: int("retentionDays"),
    alertRepeatThreshold: int("alertRepeatThreshold"),
    sourceLabel: varchar("sourceLabel", { length: 160 }).notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => [index("fiber_policy_org_idx").on(table.organizationId)]
);

export const alerts = mysqlTable(
  "alerts",
  {
    id: int("id").autoincrement().primaryKey(),
    organizationId: int("organizationId").notNull(),
    deviceId: int("deviceId"),
    topologyNodeId: int("topologyNodeId"),
    severity: mysqlEnum("severity", [
      "critical",
      "high",
      "medium",
      "low",
      "informational",
    ]).notNull(),
    status: mysqlEnum("status", ["open", "acknowledged", "resolved"])
      .default("open")
      .notNull(),
    title: varchar("title", { length: 240 }).notNull(),
    impact: text("impact"),
    probableCause: text("probableCause"),
    evidenceJson: text("evidenceJson"),
    recommendedCheck: text("recommendedCheck"),
    sourceLabel: varchar("sourceLabel", { length: 160 }).notNull(),
    openedAt: timestamp("openedAt").notNull(),
    acknowledgedAt: timestamp("acknowledgedAt"),
    resolvedAt: timestamp("resolvedAt"),
  },
  table => [
    index("alerts_org_status_idx").on(table.organizationId, table.status),
    index("alerts_device_idx").on(table.deviceId),
  ]
);

export const importBatches = mysqlTable(
  "import_batches",
  {
    id: int("id").autoincrement().primaryKey(),
    organizationId: int("organizationId").notNull(),
    userId: int("userId").notNull(),
    sourceName: varchar("sourceName", { length: 255 }).notNull(),
    sourceType: mysqlEnum("sourceType", [
      "csv",
      "json",
      "api",
      "manual",
    ]).notNull(),
    recordCount: int("recordCount").notNull(),
    validationSummaryJson: text("validationSummaryJson").notNull(),
    importedAt: timestamp("importedAt").defaultNow().notNull(),
  },
  table => [
    index("import_batches_org_time_idx").on(
      table.organizationId,
      table.importedAt
    ),
  ]
);

export const tickets = mysqlTable(
  "tickets",
  {
    id: int("id").autoincrement().primaryKey(),
    organizationId: int("organizationId").notNull(),
    subscriberId: int("subscriberId"),
    title: varchar("title", { length: 240 }).notNull(),
    severity: mysqlEnum("severity", ["low", "medium", "high", "critical"])
      .default("medium")
      .notNull(),
    state: mysqlEnum("state", ["open", "investigating", "waiting", "resolved"])
      .default("open")
      .notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => [index("tickets_org_idx").on(table.organizationId)]
);

export const attachments = mysqlTable(
  "attachments",
  {
    id: int("id").autoincrement().primaryKey(),
    organizationId: int("organizationId").notNull(),
    ticketId: int("ticketId"),
    storageKey: varchar("storageKey", { length: 512 }).notNull(),
    filename: varchar("filename", { length: 255 }).notNull(),
    mimeType: varchar("mimeType", { length: 120 }).notNull(),
    sizeBytes: int("sizeBytes").notNull(),
    createdByUserId: int("createdByUserId").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => [index("attachments_org_idx").on(table.organizationId)]
);

export const auditLogs = mysqlTable(
  "audit_logs",
  {
    id: int("id").autoincrement().primaryKey(),
    organizationId: int("organizationId").notNull(),
    actorUserId: int("actorUserId").notNull(),
    action: varchar("action", { length: 140 }).notNull(),
    entityType: varchar("entityType", { length: 80 }).notNull(),
    entityId: varchar("entityId", { length: 100 }),
    detailJson: text("detailJson"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => [
    index("audit_org_time_idx").on(table.organizationId, table.createdAt),
  ]
);

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
