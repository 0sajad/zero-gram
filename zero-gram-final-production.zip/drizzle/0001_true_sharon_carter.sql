CREATE TABLE `attachments` (
	`id` int AUTO_INCREMENT NOT NULL,
	`organizationId` int NOT NULL,
	`ticketId` int,
	`storageKey` varchar(512) NOT NULL,
	`filename` varchar(255) NOT NULL,
	`mimeType` varchar(120) NOT NULL,
	`sizeBytes` int NOT NULL,
	`createdByUserId` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `attachments_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `audit_logs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`organizationId` int NOT NULL,
	`actorUserId` int NOT NULL,
	`action` varchar(140) NOT NULL,
	`entityType` varchar(80) NOT NULL,
	`entityId` varchar(100),
	`detailJson` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `audit_logs_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `monitoring_events` (
	`id` int AUTO_INCREMENT NOT NULL,
	`profileId` int NOT NULL,
	`organizationId` int NOT NULL,
	`state` enum('success','failure') NOT NULL,
	`statusCode` int,
	`responseTimeMs` int,
	`errorMessage` text,
	`checkedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `monitoring_events_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `monitoring_profiles` (
	`id` int AUTO_INCREMENT NOT NULL,
	`organizationId` int NOT NULL,
	`userId` int NOT NULL,
	`label` varchar(160) NOT NULL,
	`targetUrl` varchar(2048) NOT NULL,
	`intervalCron` varchar(64) NOT NULL,
	`failureThreshold` int NOT NULL DEFAULT 3,
	`slaTargetPercent` int NOT NULL DEFAULT 99,
	`isActive` boolean NOT NULL DEFAULT true,
	`schedule_cron_task_uid` varchar(65),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `monitoring_profiles_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `network_devices` (
	`id` int AUTO_INCREMENT NOT NULL,
	`organizationId` int NOT NULL,
	`siteId` int,
	`label` varchar(160) NOT NULL,
	`deviceType` varchar(80) NOT NULL,
	`managementReference` varchar(255),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `network_devices_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `network_sites` (
	`id` int AUTO_INCREMENT NOT NULL,
	`organizationId` int NOT NULL,
	`name` varchar(180) NOT NULL,
	`siteType` varchar(80) NOT NULL,
	`reference` varchar(120),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `network_sites_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `organization_members` (
	`id` int AUTO_INCREMENT NOT NULL,
	`organizationId` int NOT NULL,
	`userId` int NOT NULL,
	`role` enum('owner','admin','operator','viewer') NOT NULL DEFAULT 'owner',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `organization_members_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `organizations` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(180) NOT NULL,
	`slug` varchar(100) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `organizations_id` PRIMARY KEY(`id`),
	CONSTRAINT `organizations_slug_unique` UNIQUE(`slug`)
);
--> statement-breakpoint
CREATE TABLE `subscribers` (
	`id` int AUTO_INCREMENT NOT NULL,
	`organizationId` int NOT NULL,
	`reference` varchar(120) NOT NULL,
	`displayName` varchar(180) NOT NULL,
	`status` enum('active','suspended','inactive') NOT NULL DEFAULT 'active',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `subscribers_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `test_results` (
	`id` int AUTO_INCREMENT NOT NULL,
	`organizationId` int NOT NULL,
	`userId` int NOT NULL,
	`payloadJson` text NOT NULL,
	`sourceJson` text NOT NULL,
	`limitationsJson` text NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `test_results_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `tickets` (
	`id` int AUTO_INCREMENT NOT NULL,
	`organizationId` int NOT NULL,
	`subscriberId` int,
	`title` varchar(240) NOT NULL,
	`severity` enum('low','medium','high','critical') NOT NULL DEFAULT 'medium',
	`state` enum('open','investigating','waiting','resolved') NOT NULL DEFAULT 'open',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `tickets_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE INDEX `attachments_org_idx` ON `attachments` (`organizationId`);--> statement-breakpoint
CREATE INDEX `audit_org_time_idx` ON `audit_logs` (`organizationId`,`createdAt`);--> statement-breakpoint
CREATE INDEX `monitoring_events_profile_time_idx` ON `monitoring_events` (`profileId`,`checkedAt`);--> statement-breakpoint
CREATE INDEX `monitoring_schedule_task_idx` ON `monitoring_profiles` (`schedule_cron_task_uid`);--> statement-breakpoint
CREATE INDEX `monitoring_org_idx` ON `monitoring_profiles` (`organizationId`);--> statement-breakpoint
CREATE INDEX `devices_org_idx` ON `network_devices` (`organizationId`);--> statement-breakpoint
CREATE INDEX `sites_org_idx` ON `network_sites` (`organizationId`);--> statement-breakpoint
CREATE INDEX `org_member_org_user_idx` ON `organization_members` (`organizationId`,`userId`);--> statement-breakpoint
CREATE INDEX `subscribers_org_idx` ON `subscribers` (`organizationId`);--> statement-breakpoint
CREATE INDEX `test_results_org_created_idx` ON `test_results` (`organizationId`,`createdAt`);--> statement-breakpoint
CREATE INDEX `tickets_org_idx` ON `tickets` (`organizationId`);