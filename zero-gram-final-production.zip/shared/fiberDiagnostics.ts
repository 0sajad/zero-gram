export type FiberSignal = {
  metric: string;
  value: number | null;
  valueText?: string | null;
  unit?: string | null;
  measuredAt: Date;
  sourceLabel: string;
};
export type FiberFinding = {
  id: string;
  domain:
    | "optical"
    | "network"
    | "device"
    | "ethernet"
    | "wifi"
    | "authentication";
  level: "critical" | "high" | "medium" | "low" | "informational";
  title: string;
  evidence: string;
  confidence: "high" | "medium" | "low";
  limitation: string;
  recommendedCheck: string;
};
export type HealthBreakdown = {
  overallScore: number;
  opticalScore: number | null;
  networkScore: number | null;
  deviceScore: number | null;
  ethernetScore: number | null;
  wifiScore: number | null;
  authenticationScore: number | null;
  serviceStabilityScore: number | null;
  findings: FiberFinding[];
};

const clamp = (value: number) => Math.max(0, Math.min(100, Math.round(value)));
const latest = (samples: FiberSignal[], metric: string) =>
  samples
    .filter(sample => sample.metric === metric)
    .sort((a, b) => b.measuredAt.getTime() - a.measuredAt.getTime())[0];

export function diagnoseFiberSignals(
  samples: FiberSignal[],
  states: Record<string, string | null | undefined> = {},
  ethernet: {
    label?: string | null;
    negotiatedSpeedMbps?: number | null;
    duplex?: string | null;
    crcErrors?: number | null;
    interfaceErrors?: number | null;
    flappingCount?: number | null;
    sourceLabel?: string | null;
  }[] = [],
  wifi: {
    ssid?: string | null;
    signalDbm?: number | null;
    noiseDbm?: number | null;
    interferenceLevel?: string | null;
    sourceLabel?: string | null;
  }[] = []
): FiberFinding[] {
  const findings: FiberFinding[] = [];
  const rx = latest(samples, "optical_rx_dbm");
  const loss = latest(samples, "optical_loss_db");
  const temperature = latest(samples, "temperature_c");
  const cpu = latest(samples, "cpu_percent");
  const memory = latest(samples, "memory_percent");
  const latency = latest(samples, "latency_ms");
  const jitter = latest(samples, "jitter_ms");
  const packetLoss = latest(samples, "packet_loss_percent");
  const congestion = latest(samples, "congestion_percent");
  const rebootCount = latest(samples, "reboot_count");
  const wifiUtilization = latest(samples, "wifi_channel_utilization_percent");
  const wifiClients = latest(samples, "wifi_client_count");
  const connectorState = latest(samples, "connector_state");
  const splitterState = latest(samples, "splitter_state");
  const spliceLoss = latest(samples, "splice_loss_db");
  const attenuation = latest(samples, "fiber_attenuation_db_per_km");
  const ponFlapping =
    latest(samples, "pon_flapping_count") ||
    latest(samples, "ont_flapping_count");
  if (rx?.value !== undefined && rx.value !== null && rx.value <= -28)
    findings.push({
      id: "optical-rx-low",
      domain: "optical",
      level: "critical",
      title: "Optical RX below the observed threshold",
      evidence: `RX is ${rx.value.toFixed(2)} dBm from ${rx.sourceLabel}.`,
      confidence: "medium",
      limitation:
        "A threshold must be calibrated to the specific optics, split ratio, and vendor design budget.",
      recommendedCheck:
        "Safely inspect the documented optical path, connector condition, splice/splitter references, and compare against previous readings.",
    });
  else if (rx?.value !== undefined && rx.value !== null && rx.value <= -25)
    findings.push({
      id: "optical-rx-watch",
      domain: "optical",
      level: "medium",
      title: "Optical RX needs observation",
      evidence: `RX is ${rx.value.toFixed(2)} dBm from ${rx.sourceLabel}.`,
      confidence: "medium",
      limitation:
        "This reading alone does not identify fiber, connector, splitter, or ONU as the cause.",
      recommendedCheck:
        "Compare to prior measurements and the vendor's documented optical range before field action.",
    });
  if (loss?.value !== undefined && loss.value !== null && loss.value > 3)
    findings.push({
      id: "optical-loss-high",
      domain: "optical",
      level: "high",
      title: "Optical loss is above the configured observation level",
      evidence: `Optical loss is ${loss.value.toFixed(2)} dB from ${loss.sourceLabel}.`,
      confidence: "medium",
      limitation:
        "Loss interpretation requires the link budget, fiber length, and splitter design.",
      recommendedCheck:
        "Compare loss with the design budget and inspect approved path records for bends, connectors, splice and splitter references.",
    });
  if (
    ["sc_apc_mismatch", "connector_attention", "dirty", "damaged"].includes(
      (connectorState?.valueText || "").toLowerCase()
    )
  )
    findings.push({
      id: "connector-state-attention",
      domain: "optical",
      level: "high",
      title: "Stored connector state requires optical-path review",
      evidence: `Connector state is ${connectorState?.valueText} from ${connectorState?.sourceLabel}.`,
      confidence: "medium",
      limitation:
        "A reported connector state does not prove whether SC/APC mating, cleanliness, damage, or another path element caused the loss.",
      recommendedCheck:
        "Compare the documented connector types and approved path records; perform only authorized inspection/cleaning procedures.",
    });
  if (
    ["overloaded", "attention", "mismatch", "failed"].includes(
      (splitterState?.valueText || "").toLowerCase()
    )
  )
    findings.push({
      id: "splitter-state-attention",
      domain: "optical",
      level: "high",
      title: "Stored splitter state requires review",
      evidence: `Splitter state is ${splitterState?.valueText} from ${splitterState?.sourceLabel}.`,
      confidence: "medium",
      limitation:
        "The status does not prove split ratio, connector, splice or fiber attenuation as a unique cause.",
      recommendedCheck:
        "Compare approved splitter ratio, branch design and loss budget with the stored path records.",
    });
  if (
    spliceLoss?.value !== undefined &&
    spliceLoss.value !== null &&
    spliceLoss.value > 0.3
  )
    findings.push({
      id: "splice-loss-attention",
      domain: "optical",
      level: "medium",
      title: "Stored splice loss exceeds observation level",
      evidence: `Splice loss is ${spliceLoss.value.toFixed(2)} dB from ${spliceLoss.sourceLabel}.`,
      confidence: "medium",
      limitation:
        "The observation level is not a substitute for the project acceptance specification or measurement method.",
      recommendedCheck:
        "Compare the recorded splice location, acceptance record and method consistency before any field work.",
    });
  if (
    attenuation?.value !== undefined &&
    attenuation.value !== null &&
    attenuation.value > 0.4
  )
    findings.push({
      id: "fiber-attenuation-attention",
      domain: "optical",
      level: "medium",
      title: "Stored fiber attenuation requires budget comparison",
      evidence: `Attenuation is ${attenuation.value.toFixed(2)} dB/km from ${attenuation.sourceLabel}.`,
      confidence: "medium",
      limitation:
        "The reading depends on wavelength, fiber type, length calculation and source method.",
      recommendedCheck:
        "Compare wavelength, route length and accepted design budget before attributing the condition to a fiber segment.",
    });
  if (
    ["los", "true", "detected"].includes((states.losState || "").toLowerCase())
  )
    findings.push({
      id: "los-detected",
      domain: "optical",
      level: "critical",
      title: "Loss of signal reported",
      evidence: `LOS state reported as ${states.losState}.`,
      confidence: "high",
      limitation:
        "The system records a reported state; it does not remotely verify the physical fiber path.",
      recommendedCheck:
        "Validate the OLT/PON/ONT event sequence and safely inspect the authorized optical path.",
    });
  if (
    ["lof", "true", "detected"].includes((states.lofState || "").toLowerCase())
  )
    findings.push({
      id: "lof-detected",
      domain: "optical",
      level: "high",
      title: "Loss of frame is reported",
      evidence: `LOF state reported as ${states.lofState}.`,
      confidence: "high",
      limitation:
        "The reported frame-loss state does not isolate optical signal, PON synchronization, ONU behavior or upstream equipment as the final cause.",
      recommendedCheck:
        "Review the sourced OLT/PON/ONT event sequence and compare LOS, optical RX and PON-state records before intervention.",
    });
  if (
    ponFlapping?.value !== undefined &&
    ponFlapping.value !== null &&
    ponFlapping.value > 0
  )
    findings.push({
      id: "optical-path-flapping",
      domain: "optical",
      level: "high",
      title: "Stored ONT/PON flapping is present",
      evidence: `${ponFlapping.metric} is ${ponFlapping.value.toFixed(0)} from ${ponFlapping.sourceLabel}.`,
      confidence: "medium",
      limitation:
        "A flapping count does not prove whether optical power, fiber path, PON synchronization, ONT power, provisioning or another factor caused each transition.",
      recommendedCheck:
        "Correlate timestamped PON/ONT events with optical RX, LOS/LOF, power and approved topology records.",
    });
  if (
    ["down", "offline", "o1", "o2"].includes(
      (states.ponStatus || "").toLowerCase()
    )
  )
    findings.push({
      id: "pon-offline",
      domain: "optical",
      level: "high",
      title: "PON status is not operational",
      evidence: `PON status reported as ${states.ponStatus}.`,
      confidence: "medium",
      limitation:
        "A non-operational PON state can have optical, authentication, provisioning, or equipment causes.",
      recommendedCheck:
        "Review the event timeline, ONU authentication state, and vendor-specific PON records.",
    });
  if (
    ["failed", "rejected", "offline"].includes(
      (states.authenticationStatus || "").toLowerCase()
    )
  )
    findings.push({
      id: "auth-failed",
      domain: "authentication",
      level: "high",
      title: "ONT or service authentication is not successful",
      evidence: `Authentication state reported as ${states.authenticationStatus}.`,
      confidence: "high",
      limitation:
        "The state does not identify whether credentials, VLAN, provisioning, or the upstream service is responsible.",
      recommendedCheck:
        "Verify the approved subscriber, VLAN, and service-session records without modifying device configuration.",
    });
  if (
    latency?.value !== undefined &&
    latency.value !== null &&
    latency.value > 120
  )
    findings.push({
      id: "latency-high",
      domain: "network",
      level: "medium",
      title: "Latency is elevated in the stored sample",
      evidence: `Latency is ${latency.value.toFixed(0)} ms from ${latency.sourceLabel}.`,
      confidence: "medium",
      limitation: "One sample does not prove congestion or a routing fault.",
      recommendedCheck:
        "Compare multiple time-stamped samples and the monitored target status.",
    });
  if (
    packetLoss?.value !== undefined &&
    packetLoss.value !== null &&
    packetLoss.value > 2
  )
    findings.push({
      id: "packet-loss",
      domain: "network",
      level: "high",
      title: "Packet-loss estimate exceeds the observation level",
      evidence: `Loss is ${packetLoss.value.toFixed(2)}% from ${packetLoss.sourceLabel}.`,
      confidence: "medium",
      limitation:
        "HTTP sample loss and device counters are not equivalent to layer-3 packet loss unless the source says so.",
      recommendedCheck:
        "Cross-check the source method, interface counters, latency trend, and upstream monitoring events.",
    });
  if (jitter?.value !== undefined && jitter.value !== null && jitter.value > 30)
    findings.push({
      id: "jitter-high",
      domain: "network",
      level: "medium",
      title: "Jitter is elevated in the stored sample",
      evidence: `Jitter is ${jitter.value.toFixed(1)} ms from ${jitter.sourceLabel}.`,
      confidence: "medium",
      limitation:
        "One jitter sample does not prove congestion, path asymmetry or a local access fault.",
      recommendedCheck:
        "Compare time-series jitter, latency, loss and the documented target/source method.",
    });
  if (
    congestion?.value !== undefined &&
    congestion.value !== null &&
    congestion.value >= 85
  )
    findings.push({
      id: "congestion-high",
      domain: "network",
      level: "high",
      title: "Stored utilization suggests possible congestion",
      evidence: `Congestion/utilization is ${congestion.value.toFixed(1)}% from ${congestion.sourceLabel}.`,
      confidence: "medium",
      limitation:
        "Utilization alone does not identify the congested queue, interface or upstream segment.",
      recommendedCheck:
        "Compare directional counters, queue telemetry and adjacent topology nodes during the same time window.",
    });
  if (
    rebootCount?.value !== undefined &&
    rebootCount.value !== null &&
    rebootCount.value > 0
  )
    findings.push({
      id: "reboot-recorded",
      domain: "device",
      level: "medium",
      title: "A device reboot count is recorded",
      evidence: `Reboot count is ${rebootCount.value.toFixed(0)} from ${rebootCount.sourceLabel}.`,
      confidence: "medium",
      limitation:
        "A reboot counter does not establish whether power, firmware, management or hardware caused the restart.",
      recommendedCheck:
        "Correlate reboot timestamps with power, thermal, firmware and event logs through approved access.",
    });
  if (
    ["down", "failed", "unreachable"].includes(
      (states.dnsStatus || "").toLowerCase()
    )
  )
    findings.push({
      id: "dns-state-failed",
      domain: "network",
      level: "high",
      title: "A stored DNS state is not operational",
      evidence: `DNS status is ${states.dnsStatus}.`,
      confidence: "medium",
      limitation:
        "The status does not identify resolver, gateway, routing, DHCP option or upstream cause.",
      recommendedCheck:
        "Verify documented DNS server, gateway, DHCP option and resolver event records.",
    });
  if (
    ["down", "failed", "unreachable"].includes(
      (states.gatewayStatus || "").toLowerCase()
    )
  )
    findings.push({
      id: "gateway-state-failed",
      domain: "network",
      level: "high",
      title: "A stored gateway state is not operational",
      evidence: `Gateway status is ${states.gatewayStatus}.`,
      confidence: "medium",
      limitation:
        "The state does not isolate local interface, ARP, VLAN, routing or upstream failure.",
      recommendedCheck:
        "Review the sourced ARP, VLAN, route and interface timeline before intervention.",
    });
  if (
    ["down", "failed", "power_loss"].includes(
      (states.powerState || "").toLowerCase()
    )
  )
    findings.push({
      id: "power-state-failed",
      domain: "device",
      level: "high",
      title: "A stored power state requires attention",
      evidence: `Power state is ${states.powerState}.`,
      confidence: "medium",
      limitation:
        "The report does not prove a site-power, adapter, UPS or hardware fault.",
      recommendedCheck:
        "Review approved power/UPS records and correlate with reboot and LOS events.",
    });
  if (
    ["failed", "unsupported", "mismatch"].includes(
      (states.firmwareStatus || "").toLowerCase()
    )
  )
    findings.push({
      id: "firmware-state-attention",
      domain: "device",
      level: "medium",
      title: "A stored firmware state requires review",
      evidence: `Firmware state is ${states.firmwareStatus}.`,
      confidence: "medium",
      limitation:
        "The state does not prove firmware is responsible for the observed symptom.",
      recommendedCheck:
        "Compare the vendor-approved version, release notes and event history without changing configuration.",
    });
  if (
    temperature?.value !== undefined &&
    temperature.value !== null &&
    temperature.value >= 70
  )
    findings.push({
      id: "temperature-high",
      domain: "device",
      level: "high",
      title: "Device temperature is high",
      evidence: `Temperature is ${temperature.value.toFixed(1)} °C from ${temperature.sourceLabel}.`,
      confidence: "medium",
      limitation: "Safe range depends on device/vendor specifications.",
      recommendedCheck:
        "Check the manufacturer-approved operating range, ventilation, and the temperature trend.",
    });
  if (cpu?.value !== undefined && cpu.value !== null && cpu.value >= 90)
    findings.push({
      id: "cpu-high",
      domain: "device",
      level: "high",
      title: "CPU utilization is high",
      evidence: `CPU is ${cpu.value.toFixed(1)}% from ${cpu.sourceLabel}.`,
      confidence: "medium",
      limitation: "A high sample does not identify the responsible process.",
      recommendedCheck:
        "Compare the utilization trend and review authorized device telemetry or logs.",
    });
  if (
    memory?.value !== undefined &&
    memory.value !== null &&
    memory.value >= 90
  )
    findings.push({
      id: "memory-high",
      domain: "device",
      level: "medium",
      title: "Memory utilization is high",
      evidence: `Memory is ${memory.value.toFixed(1)}% from ${memory.sourceLabel}.`,
      confidence: "medium",
      limitation:
        "Interpretation depends on vendor memory accounting and trend history.",
      recommendedCheck:
        "Review the historical memory trend and vendor diagnostics through approved access.",
    });
  if (
    ["failed", "down", "offline", "rejected"].includes(
      (states.serviceStatus || "").toLowerCase()
    )
  )
    findings.push({
      id: "service-session-failed",
      domain: "authentication",
      level: "high",
      title: "A stored service session is not operational",
      evidence: `A PPPoE/DHCP/DNS/VLAN session reports ${states.serviceStatus}.`,
      confidence: "medium",
      limitation:
        "The session state does not prove whether access credentials, VLAN, DHCP, DNS, gateway, or upstream service is responsible.",
      recommendedCheck:
        "Review the approved service session, VLAN, DHCP/DNS and gateway records without modifying device configuration.",
    });
  ethernet.forEach(port => {
    const label = port.label || "interface";
    const source = port.sourceLabel || "the stored interface record";
    if ((port.crcErrors || 0) > 0 || (port.interfaceErrors || 0) > 0)
      findings.push({
        id: `ethernet-errors-${label}`,
        domain: "ethernet",
        level: "high",
        title: "Ethernet errors are present",
        evidence: `${label} reports CRC ${port.crcErrors ?? 0} and interface errors ${port.interfaceErrors ?? 0} from ${source}.`,
        confidence: "medium",
        limitation:
          "Counters may be cumulative and do not isolate cable, peer, duplex or hardware as the final cause.",
        recommendedCheck:
          "Compare counter deltas and negotiated settings with the approved peer-port record before any physical intervention.",
      });
    if (
      port.negotiatedSpeedMbps !== null &&
      port.negotiatedSpeedMbps !== undefined &&
      port.negotiatedSpeedMbps <= 100
    )
      findings.push({
        id: `ethernet-speed-${label}`,
        domain: "ethernet",
        level: "medium",
        title: "Ethernet link is negotiated at 100 Mbps or below",
        evidence: `${label} reports ${port.negotiatedSpeedMbps} Mbps from ${source}.`,
        confidence: "medium",
        limitation:
          "A lower negotiated speed can be intentional and does not prove a cabling or duplex fault.",
        recommendedCheck:
          "Compare the expected service profile, peer capability, auto-negotiation and cable documentation.",
      });
    if ((port.duplex || "").toLowerCase().includes("half"))
      findings.push({
        id: `ethernet-duplex-${label}`,
        domain: "ethernet",
        level: "medium",
        title: "A half-duplex interface state is stored",
        evidence: `${label} reports ${port.duplex} duplex from ${source}.`,
        confidence: "medium",
        limitation:
          "The stored duplex mode does not prove a peer mismatch or cable fault.",
        recommendedCheck:
          "Compare both ends' negotiated mode, auto-negotiation state and approved cable/peer documentation.",
      });
    if ((port.flappingCount || 0) > 0)
      findings.push({
        id: `ethernet-flapping-${label}`,
        domain: "ethernet",
        level: "high",
        title: "Ethernet link instability is recorded",
        evidence: `${label} reports ${port.flappingCount} link transition(s) from ${source}.`,
        confidence: "medium",
        limitation:
          "The count does not identify which side of the link originated the transition.",
        recommendedCheck:
          "Review time correlation with power, peer interface and event timeline data.",
      });
  });
  wifi.forEach(network => {
    const label = network.ssid || "Wi‑Fi radio";
    const source = network.sourceLabel || "the stored Wi‑Fi record";
    if (
      network.signalDbm !== null &&
      network.signalDbm !== undefined &&
      network.signalDbm <= -72
    )
      findings.push({
        id: `wifi-signal-${label}`,
        domain: "wifi",
        level: "medium",
        title: "Wi‑Fi signal is low in the stored record",
        evidence: `${label} reports ${network.signalDbm} dBm from ${source}.`,
        confidence: "medium",
        limitation:
          "A radio-level signal cannot determine a specific client's location, obstruction, or experience.",
        recommendedCheck:
          "Compare client-side measurements, channel plan, radio placement and historical samples.",
      });
    if (
      ["high", "severe"].includes(
        (network.interferenceLevel || "").toLowerCase()
      )
    )
      findings.push({
        id: `wifi-interference-${label}`,
        domain: "wifi",
        level: "medium",
        title: "Wi‑Fi interference is reported",
        evidence: `${label} reports ${network.interferenceLevel} interference from ${source}.`,
        confidence: "medium",
        limitation:
          "The recorded interference level depends on the source method and does not identify a transmitter.",
        recommendedCheck:
          "Review approved spectrum observations, channel utilization and neighboring radio records.",
      });
  });
  if (
    wifiUtilization?.value !== undefined &&
    wifiUtilization.value !== null &&
    wifiUtilization.value >= 80
  )
    findings.push({
      id: "wifi-channel-utilization",
      domain: "wifi",
      level: "medium",
      title: "Stored Wi‑Fi channel utilization is high",
      evidence: `Channel utilization is ${wifiUtilization.value.toFixed(1)}% from ${wifiUtilization.sourceLabel}.`,
      confidence: "medium",
      limitation:
        "Channel utilization does not identify the interfering transmitter, client placement or airtime cause.",
      recommendedCheck:
        "Compare the selected channel, nearby radio records, client distribution and approved spectrum observations.",
    });
  if (
    wifiClients?.value !== undefined &&
    wifiClients.value !== null &&
    wifiClients.value >= 40
  )
    findings.push({
      id: "wifi-client-density",
      domain: "wifi",
      level: "medium",
      title: "Stored Wi‑Fi client count suggests high density",
      evidence: `Client count is ${wifiClients.value.toFixed(0)} from ${wifiClients.sourceLabel}.`,
      confidence: "low",
      limitation:
        "A client count alone cannot determine contention, placement or actual client throughput.",
      recommendedCheck:
        "Review client RX/TX rates, channel utilization, placement records and time correlation.",
    });
  return findings;
}

export function calculateHealth(
  samples: FiberSignal[],
  states: Record<string, string | null | undefined> = {},
  ethernet?: {
    negotiatedSpeedMbps?: number | null;
    crcErrors?: number | null;
    interfaceErrors?: number | null;
  }[],
  wifi?: { signalDbm?: number | null; interferenceLevel?: string | null }[]
): HealthBreakdown {
  const findings = diagnoseFiberSignals(samples, states, ethernet, wifi);
  const byDomain = (domain: FiberFinding["domain"]) =>
    findings
      .filter(finding => finding.domain === domain)
      .reduce(
        (score, finding) =>
          score -
          { critical: 55, high: 35, medium: 18, low: 8, informational: 0 }[
            finding.level
          ],
        100
      );
  const opticalScore = clamp(byDomain("optical"));
  const networkScore = clamp(byDomain("network"));
  const deviceScore = clamp(byDomain("device"));
  const authenticationScore = clamp(byDomain("authentication"));
  let ethernetScore: number | null = ethernet?.length ? 100 : null;
  if (ethernet?.length)
    for (const port of ethernet) {
      if ((port.crcErrors || 0) > 0 || (port.interfaceErrors || 0) > 0)
        ethernetScore = Math.min(ethernetScore ?? 100, 70);
      if (port.negotiatedSpeedMbps && port.negotiatedSpeedMbps <= 100)
        ethernetScore = Math.min(ethernetScore ?? 100, 78);
    }
  let wifiScore: number | null = wifi?.length ? 100 : null;
  if (wifi?.length)
    for (const network of wifi) {
      if (
        network.signalDbm !== null &&
        network.signalDbm !== undefined &&
        network.signalDbm <= -72
      )
        wifiScore = Math.min(wifiScore ?? 100, 70);
      if (
        ["high", "severe"].includes(
          (network.interferenceLevel || "").toLowerCase()
        )
      )
        wifiScore = Math.min(wifiScore ?? 100, 72);
    }
  const available = [
    opticalScore,
    networkScore,
    deviceScore,
    authenticationScore,
    ethernetScore,
    wifiScore,
  ].filter((score): score is number => score !== null);
  const stabilityInputs = [
    opticalScore,
    networkScore,
    authenticationScore,
    ethernetScore,
    wifiScore,
  ].filter((score): score is number => score !== null);
  const serviceStabilityScore = stabilityInputs.length
    ? clamp(
        stabilityInputs.reduce((sum, score) => sum + score, 0) /
          stabilityInputs.length
      )
    : null;
  return {
    overallScore: clamp(
      available.reduce((sum, score) => sum + score, 0) /
        Math.max(1, available.length)
    ),
    opticalScore,
    networkScore,
    deviceScore,
    ethernetScore,
    wifiScore,
    authenticationScore,
    serviceStabilityScore,
    findings,
  };
}

export function detectOpticalTrend(samples: FiberSignal[]): FiberFinding[] {
  const ordered = samples
    .filter(
      sample => sample.metric === "optical_rx_dbm" && sample.value !== null
    )
    .sort((a, b) => a.measuredAt.getTime() - b.measuredAt.getTime());
  if (ordered.length < 3) return [];
  const first = ordered[0]!;
  const last = ordered.at(-1)!;
  const days = Math.max(
    1,
    (last.measuredAt.getTime() - first.measuredAt.getTime()) / 86_400_000
  );
  const change = (last.value ?? 0) - (first.value ?? 0);
  if (change <= -0.5 && Math.abs(change / days) >= 0.1)
    return [
      {
        id: "optical-degradation-trend",
        domain: "optical",
        level: "medium",
        title: "Early warning: optical RX is gradually declining",
        evidence: `RX changed ${change.toFixed(2)} dB across ${days.toFixed(1)} day(s), using ${ordered.length} stored samples.`,
        confidence: "medium",
        limitation:
          "The trend is only as representative as the stored samples and their consistent source method.",
        recommendedCheck:
          "Review the source continuity, compare link-budget records, and plan a safe optical-path verification before service impact occurs.",
      },
    ];
  return [];
}

export function detectServiceStabilityTrend(
  events: {
    eventType: string;
    severity: string;
    occurredAt: Date;
    sourceLabel?: string | null;
  }[]
): FiberFinding[] {
  const ordered = [...events].sort(
    (a, b) => a.occurredAt.getTime() - b.occurredAt.getTime()
  );
  if (ordered.length < 3) return [];
  const recent = ordered.filter(
    event =>
      Date.now() - event.occurredAt.getTime() <= 7 * 86_400_000 &&
      ["critical", "high", "medium"].includes(event.severity.toLowerCase())
  );
  if (recent.length < 3) return [];
  const grouped = recent.reduce<Record<string, number>>(
    (counts, event) => ({
      ...counts,
      [event.eventType]: (counts[event.eventType] || 0) + 1,
    }),
    {}
  );
  const repeated = Object.entries(grouped).find(([, count]) => count >= 3);
  if (!repeated) return [];
  const [eventType, count] = repeated;
  return [
    {
      id: `service-stability-${eventType}`,
      domain: "network",
      level: "medium",
      title:
        "Early warning: repeated operational events may affect service stability",
      evidence: `${count} ${eventType} event(s) were stored in the last 7 days.`,
      confidence: "medium",
      limitation:
        "Repeated recorded events show recurrence, not a confirmed single root cause or a customer-impact estimate.",
      recommendedCheck:
        "Review event correlation with optical, authentication, interface and upstream monitoring timelines before any intervention.",
    },
  ];
}
