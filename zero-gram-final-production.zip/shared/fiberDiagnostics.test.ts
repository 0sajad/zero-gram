import { describe, expect, it } from "vitest";
import {
  calculateHealth,
  detectOpticalTrend,
  diagnoseFiberSignals,
  type FiberSignal,
} from "./fiberDiagnostics";

const at = (daysAgo: number) => new Date(Date.now() - daysAgo * 86_400_000);

describe("fiber diagnostics", () => {
  it("connects a low RX reading to an optical finding without claiming a final physical cause", () => {
    const findings = diagnoseFiberSignals([
      {
        metric: "optical_rx_dbm",
        value: -28.6,
        measuredAt: at(0),
        sourceLabel: "ONT export",
      },
    ]);
    expect(findings).toEqual(
      expect.arrayContaining([
        expect.objectContaining({
          id: "optical-rx-low",
          domain: "optical",
          level: "critical",
          confidence: "medium",
        }),
      ])
    );
    expect(findings[0]?.limitation).toMatch(/threshold/i);
  });

  it("retains authentication and LOS as distinct evidence domains", () => {
    const findings = diagnoseFiberSignals([], {
      losState: "detected",
      authenticationStatus: "failed",
    });
    expect(findings.map(finding => finding.id)).toEqual(
      expect.arrayContaining(["los-detected", "auth-failed"])
    );
    expect(
      findings.find(finding => finding.id === "los-detected")?.domain
    ).toBe("optical");
    expect(findings.find(finding => finding.id === "auth-failed")?.domain).toBe(
      "authentication"
    );
  });

  it("calculates a transparent health score from present evidence only", () => {
    const health = calculateHealth(
      [
        {
          metric: "packet_loss_percent",
          value: 5,
          measuredAt: at(0),
          sourceLabel: "HTTP session",
        },
      ],
      {},
      [{ negotiatedSpeedMbps: 100, crcErrors: 2 }],
      []
    );
    expect(health.overallScore).toBeLessThan(100);
    expect(health.networkScore).toBeLessThan(100);
    expect(health.ethernetScore).toBeLessThan(100);
    expect(health.wifiScore).toBeNull();
  });

  it("requires at least three real optical samples before producing an early warning", () => {
    const samples: FiberSignal[] = [
      {
        metric: "optical_rx_dbm",
        value: -22.1,
        measuredAt: at(5),
        sourceLabel: "OLT export",
      },
      {
        metric: "optical_rx_dbm",
        value: -22.4,
        measuredAt: at(3),
        sourceLabel: "OLT export",
      },
      {
        metric: "optical_rx_dbm",
        value: -22.9,
        measuredAt: at(0),
        sourceLabel: "OLT export",
      },
    ];
    expect(detectOpticalTrend(samples)).toEqual(
      expect.arrayContaining([
        expect.objectContaining({
          id: "optical-degradation-trend",
          level: "medium",
        }),
      ])
    );
    expect(detectOpticalTrend(samples.slice(0, 2))).toEqual([]);
  });
});
