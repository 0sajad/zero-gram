export type SwipeDirection = "next" | "previous" | null;

export function resolveMobileSwipe(
  startX: number,
  startY: number,
  endX: number,
  endY: number,
  threshold = 56
): SwipeDirection {
  const dx = endX - startX;
  const dy = endY - startY;
  if (Math.abs(dx) < threshold || Math.abs(dx) <= Math.abs(dy) * 1.25) return null;
  return dx < 0 ? "next" : "previous";
}
