export type NumericPoint = { at: Date; value: number; label?: string };
export type MonitorEventLike = {
  state: "success" | "failure";
  checkedAt: Date;
};

const mean = (values: number[]) =>
  values.length
    ? values.reduce((sum, value) => sum + value, 0) / values.length
    : undefined;
const median = (values: number[]) => {
  const sorted = [...values].sort((a, b) => a - b);
  if (!sorted.length) return undefined;
  const middle = Math.floor(sorted.length / 2);
  return sorted.length % 2
    ? sorted[middle]
    : (sorted[middle - 1] + sorted[middle]) / 2;
};

export function analyzeCapacity(
  points: NumericPoint[],
  totalBandwidthMbps?: number | null
) {
  const sorted = [...points]
    .filter(point => Number.isFinite(point.value))
    .sort((a, b) => a.at.getTime() - b.at.getTime());
  const values = sorted.map(point => point.value);
  const current = sorted.at(-1)?.value;
  const peak = values.length ? Math.max(...values) : undefined;
  const average = mean(values);
  const first = sorted[0]?.value;
  const utilizationPercent =
    totalBandwidthMbps && current !== undefined
      ? (current / totalBandwidthMbps) * 100
      : undefined;
  const peakUtilizationPercent =
    totalBandwidthMbps && peak !== undefined
      ? (peak / totalBandwidthMbps) * 100
      : undefined;
  return {
    current,
    peak,
    average,
    utilizationPercent,
    peakUtilizationPercent,
    growthPercent:
      first && current !== undefined
        ? ((current - first) / first) * 100
        : undefined,
    sampleCount: sorted.length,
  };
}

export function analyzeReliability(events: MonitorEventLike[]) {
  const sorted = [...events].sort(
    (a, b) => a.checkedAt.getTime() - b.checkedAt.getTime()
  );
  if (!sorted.length)
    return {
      observedCheckSuccessPercent: undefined,
      outageCount: 0,
      totalDowntimeMs: undefined,
      mtbfMs: undefined,
      mttrMs: undefined,
      sampleCount: 0,
    };
  const successPercent =
    (sorted.filter(event => event.state === "success").length / sorted.length) *
    100;
  const starts: Date[] = [];
  const durations: number[] = [];
  let failureStart: Date | null = null;
  for (const event of sorted) {
    if (event.state === "failure" && !failureStart) {
      failureStart = event.checkedAt;
      starts.push(event.checkedAt);
    }
    if (event.state === "success" && failureStart) {
      durations.push(event.checkedAt.getTime() - failureStart.getTime());
      failureStart = null;
    }
  }
  const gaps = starts
    .slice(1)
    .map((start, index) => start.getTime() - starts[index].getTime());
  return {
    observedCheckSuccessPercent: successPercent,
    outageCount: starts.length,
    totalDowntimeMs: durations.length
      ? durations.reduce((sum, value) => sum + value, 0)
      : undefined,
    mtbfMs: mean(gaps),
    mttrMs: mean(durations),
    sampleCount: sorted.length,
  };
}

export function detectAnomaly(points: NumericPoint[], metric: string) {
  const sorted = [...points]
    .filter(point => Number.isFinite(point.value))
    .sort((a, b) => a.at.getTime() - b.at.getTime());
  const current = sorted.at(-1);
  const baseline = sorted.slice(0, -1);
  if (!current || baseline.length < 3) return null;
  const values = baseline.map(point => point.value);
  const typical = median(values)!;
  const average = mean(values)!;
  const deviation = Math.sqrt(
    values.reduce((sum, value) => sum + (value - average) ** 2, 0) /
      values.length
  );
  const threshold = Math.max(deviation * 3, Math.abs(typical) * 0.5, 1);
  const difference = current.value - typical;
  if (Math.abs(difference) < threshold) return null;
  return {
    metric,
    latest: current.value,
    baselineMedian: typical,
    difference,
    threshold,
    confidence: baseline.length >= 6 ? ("high" as const) : ("medium" as const),
    evidenceCount: baseline.length,
    observedAt: current.at,
  };
}
