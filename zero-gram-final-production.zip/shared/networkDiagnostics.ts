export type RiskLevel = "info" | "warning" | "critical";

export type ConnectionMeasurement = {
  downloadMbps?: number;
  uploadMbps?: number;
  webLatencyMs?: number;
  jitterMs?: number;
  ttfbMs?: number;
  dnsMs?: number;
  packetLossEstimate?: number;
  networkType?: string;
  effectiveType?: string;
  saveData?: boolean;
  ipv4?: boolean;
  ipv6?: boolean;
  webrtc?: boolean;
  downloadTrace?: SpeedTrace[];
  uploadTrace?: SpeedTrace[];
  downloadConsistencyPercent?: number;
  uploadConsistencyPercent?: number;
  testDurationMs?: number;
};

export type SpeedTrace = { elapsedMs: number; mbps: number };

export type DiagnosticFinding = {
  id: string;
  level: RiskLevel;
  title: string;
  evidence: string;
  confidence: "low" | "medium" | "high";
  limitation: string;
  safeNextStep: string;
};

export type Diagnosis = {
  netScore?: number;
  quality?: "VERY GOOD" | "GOOD" | "FAIR" | "NEEDS ATTENTION";
  findings: DiagnosticFinding[];
  missing: string[];
  methodology: string;
};

const finite = (value: unknown): value is number =>
  typeof value === "number" && Number.isFinite(value);

export function calculateSpeedConsistency(
  trace: SpeedTrace[]
): number | undefined {
  const values = trace.map(sample => sample.mbps).filter(finite);
  if (values.length < 2) return undefined;
  const mean = values.reduce((sum, value) => sum + value, 0) / values.length;
  if (mean <= 0) return 0;
  const variation =
    Math.sqrt(
      values.reduce((sum, value) => sum + (value - mean) ** 2, 0) /
        values.length
    ) / mean;
  return Math.round(Math.max(0, Math.min(100, (1 - variation) * 100)));
}

export function calculateNetScore(
  measurement: ConnectionMeasurement
): number | undefined {
  const components: Array<{ score: number; weight: number }> = [];
  if (finite(measurement.webLatencyMs))
    components.push({
      score: Math.max(
        0,
        100 - Math.max(0, measurement.webLatencyMs - 20) * 0.4
      ),
      weight: 0.28,
    });
  if (finite(measurement.jitterMs))
    components.push({
      score: Math.max(0, 100 - measurement.jitterMs * 3),
      weight: 0.24,
    });
  if (finite(measurement.packetLossEstimate))
    components.push({
      score: Math.max(0, 100 - measurement.packetLossEstimate * 16),
      weight: 0.28,
    });
  if (finite(measurement.ttfbMs))
    components.push({
      score: Math.max(0, 100 - Math.max(0, measurement.ttfbMs - 120) * 0.22),
      weight: 0.2,
    });
  if (!components.length) return undefined;
  const weight = components.reduce(
    (sum, component) => sum + component.weight,
    0
  );
  return Math.round(
    components.reduce(
      (sum, component) => sum + component.score * component.weight,
      0
    ) / weight
  );
}

export function diagnoseConnection(
  measurement: ConnectionMeasurement
): Diagnosis {
  const findings: DiagnosticFinding[] = [];
  const missing: string[] = [];
  const netScore = calculateNetScore(measurement);

  if (!finite(measurement.webLatencyMs))
    missing.push("زمن استجابة الويب لم يُقَس.");
  if (!finite(measurement.jitterMs))
    missing.push("التذبذب لم يُقَس من عينات كافية.");
  if (!finite(measurement.packetLossEstimate))
    missing.push("فقد الحزم تقديري وغير متاح في هذه الجلسة.");

  if (finite(measurement.jitterMs) && measurement.jitterMs >= 25) {
    findings.push({
      id: "high-jitter",
      level: measurement.jitterMs >= 50 ? "critical" : "warning",
      title: "تذبذب مرتفع في زمن الاستجابة",
      evidence: `فرق العينات بلغ ${measurement.jitterMs.toFixed(1)} ms.`,
      confidence: "high",
      limitation:
        "يقيس تذبذب طلبات الويب إلى نقطة الاختبار فقط، وليس تأخير ICMP أو كل المسار.",
      safeNextStep:
        "أعد الفحص عبر اتصال سلكي ثم قارن النتيجة في وقت مختلف قبل تغيير إعدادات الشبكة.",
    });
  }

  if (
    finite(measurement.packetLossEstimate) &&
    measurement.packetLossEstimate >= 3
  ) {
    findings.push({
      id: "loss-estimate",
      level: measurement.packetLossEstimate >= 8 ? "critical" : "warning",
      title: "مؤشر على فقد محتمل في عينات الويب",
      evidence: `تعذر إكمال ${measurement.packetLossEstimate.toFixed(1)}% من العينات ضمن مهلة الجلسة.`,
      confidence: "medium",
      limitation: "هذا تقدير من طلبات HTTP ولا يعادل قياس فقد حزم طبقة الشبكة.",
      safeNextStep:
        "تحقق من ثبات الوصلة المحلية وأعد الاختبار مع خادم مختلف أو شبكة بديلة.",
    });
  }

  if (finite(measurement.dnsMs) && measurement.dnsMs >= 180) {
    findings.push({
      id: "slow-dns",
      level: "warning",
      title: "زمن حل DNS مرتفع",
      evidence: `استجابة DNS المقاسة بلغت ${measurement.dnsMs.toFixed(0)} ms.`,
      confidence: "medium",
      limitation:
        "القياس مرتبط بخدمة DNS-over-HTTPS المحددة وبحالة التخزين المؤقت في المتصفح أو المسار.",
      safeNextStep:
        "أعد طلب DNS لخادم موثق آخر وقارن النتائج قبل تعديل إعدادات جهاز التوجيه.",
    });
  }

  if (finite(measurement.webLatencyMs) && measurement.webLatencyMs >= 400) {
    findings.push({
      id: "web-latency",
      level: measurement.webLatencyMs >= 750 ? "critical" : "warning",
      title: "زمن استجابة الويب مرتفع",
      evidence: `متوسط رحلة HTTP/HTTPS بلغ ${measurement.webLatencyMs.toFixed(0)} ms.`,
      confidence: "high",
      limitation:
        "لا يمثل هذا القياس ICMP ping؛ يشمل وقت العميل وHTTPS وخادم الوجهة.",
      safeNextStep:
        "قارن القياس مع وجهة موثقة أخرى، وتحقق من وجود تنزيلات أو مكالمات فيديو نشطة محليًا.",
    });
  }

  if (finite(measurement.downloadMbps) && measurement.downloadMbps < 5) {
    findings.push({
      id: "low-download",
      level: "warning",
      title: "معدل تنزيل محدود في نقطة الاختبار",
      evidence: `معدل تنزيل HTTP متعدد العينات بلغ ${measurement.downloadMbps.toFixed(2)} Mbps.`,
      confidence: "medium",
      limitation:
        "النتيجة مقيدة بسعة نقطة الاختبار والمتصفح والخدمة الخلفية، وليست سرعة الخط التعاقدية.",
      safeNextStep:
        "أوقف الاستخدام الكثيف مؤقتًا وأعد الفحص سلكيًا ثم احتفظ بالنتيجتين للمقارنة.",
    });
  }

  if (
    finite(measurement.downloadConsistencyPercent) &&
    measurement.downloadConsistencyPercent < 65
  ) {
    findings.push({
      id: "download-instability",
      level:
        measurement.downloadConsistencyPercent < 40 ? "critical" : "warning",
      title: "تذبذب ملحوظ في معدل تنزيل HTTP",
      evidence: `اتساق التنزيل بين العينات الفعلية بلغ ${measurement.downloadConsistencyPercent.toFixed(0)}%.`,
      confidence: "medium",
      limitation:
        "الاتساق يقارن عينات HTTP من نقطة ZERO GRAM فقط ولا يعزل سببًا في Wi‑Fi أو Ethernet أو المزود.",
      safeNextStep:
        "قارن الجلسة باتصال سلكي وبوقت آخر، ثم راجع فرق العينات المحفوظة قبل نسب السبب إلى المسار.",
    });
  }

  if (
    finite(measurement.uploadConsistencyPercent) &&
    measurement.uploadConsistencyPercent < 65
  ) {
    findings.push({
      id: "upload-instability",
      level: measurement.uploadConsistencyPercent < 40 ? "critical" : "warning",
      title: "تذبذب ملحوظ في معدل رفع HTTP",
      evidence: `اتساق الرفع بين العينات الفعلية بلغ ${measurement.uploadConsistencyPercent.toFixed(0)}%.`,
      confidence: "medium",
      limitation:
        "الاتساق يقارن عمليات رفع HTTP قصيرة ولا يمثل سعة الرفع التعاقدية أو فقد حزم طبقة الشبكة.",
      safeNextStep:
        "أعد القياس دون نقل ملفات موازٍ وقارن الجلسة مع سجل واجهة مصدره موثق إن كان متاحًا.",
    });
  }

  if (!findings.length && netScore !== undefined) {
    findings.push({
      id: "within-sample",
      level: "info",
      title: "لا يظهر مؤشر عتبة في عينات هذه الجلسة",
      evidence: "القيم المتاحة بقيت ضمن العتبات الاسترشادية لمحرك القواعد.",
      confidence: "medium",
      limitation:
        "غياب مؤشر في هذه الجلسة لا يثبت سلامة الشبكة خارج وقت القياس أو خارج مسار الاختبار.",
      safeNextStep: "احفظ النتيجة كأساس مقارنة وأعد الفحص عند ظهور المشكلة.",
    });
  }

  return {
    netScore,
    quality:
      netScore === undefined
        ? undefined
        : netScore >= 85
          ? "VERY GOOD"
          : netScore >= 70
            ? "GOOD"
            : netScore >= 50
              ? "FAIR"
              : "NEEDS ATTENTION",
    findings,
    missing,
    methodology:
      "NetScore موزون من زمن استجابة الويب والتذبذب وفقد العينات وTTFB عند توفرها؛ لا يُحسب عند نقص كل العناصر.",
  };
}

export type LabInput = {
  ontModel?: string;
  opticalRxDbm?: number;
  opticalTxDbm?: number;
  oltRxDbm?: number;
  ponState?: string;
  snrDb?: number;
  rsrpDbm?: number;
  rsrqDb?: number;
  rawLog?: string;
};

export type LabFinding = DiagnosticFinding & { source: string };

export function analyzeTechnicianInput(input: LabInput): LabFinding[] {
  const findings: LabFinding[] = [];
  const log = (input.rawLog || "").toLowerCase();
  if (finite(input.opticalRxDbm) && input.opticalRxDbm < -27) {
    findings.push({
      id: "low-optical-rx",
      level: input.opticalRxDbm < -30 ? "critical" : "warning",
      title: "قدرة استقبال ضوئية منخفضة",
      evidence: `قراءة ONT RX المدخلة: ${input.opticalRxDbm.toFixed(1)} dBm.`,
      confidence: "high",
      limitation:
        "العتبة استرشادية وقد تختلف حسب فئة GPON ونموذج العتاد وقياس OLT المقابل.",
      safeNextStep:
        "تحقق بصريًا من نظافة ووضع الموصلات، ثم قارن القراءة بسجل OLT أو قراءة جهاز موثق دون إجراء تعديل على العتاد.",
      source: "حقل ONT RX",
    });
  }
  if (
    input.ponState &&
    !/^(up|o5|online|active)$/i.test(input.ponState.trim())
  ) {
    findings.push({
      id: "pon-state",
      level: "warning",
      title: "حالة PON تحتاج مراجعة",
      evidence: `حالة PON المدخلة: ${input.ponState}.`,
      confidence: "medium",
      limitation: "القيمة تفسر كما أدخلت فقط؛ تختلف رموز الحالة بين المصنعين.",
      safeNextStep:
        "طابق رمز الحالة مع دليل الجهاز ثم راجع سجل OLT والزمن الذي تغيرت فيه الحالة.",
      source: "حقل PON",
    });
  }
  if (finite(input.snrDb) && input.snrDb < 10) {
    findings.push({
      id: "low-snr",
      level: "warning",
      title: "نسبة إشارة إلى ضوضاء منخفضة",
      evidence: `SNR المدخل: ${input.snrDb.toFixed(1)} dB.`,
      confidence: "medium",
      limitation:
        "قد تكون القراءة مرتبطة بواجهة لاسلكية أو خلوية؛ لا تحدد السبب الجذري وحدها.",
      safeNextStep:
        "قارن القراءة بموقع بديل وبوقت آخر، وتحقق من مسار الهوائي أو المصدر اللاسلكي قبل أي تعديل.",
      source: "حقل SNR",
    });
  }
  if (
    /pppoe.*(auth|authentication).*fail|authentication.*fail|failed.*auth/.test(
      log
    )
  ) {
    findings.push({
      id: "pppoe-auth",
      level: "warning",
      title: "فشل مصادقة PPPoE ظاهر في السجل",
      evidence: "تم العثور على نمط فشل مصادقة في النص الملصق.",
      confidence: "high",
      limitation: "لا يكشف النص وحده عن اسم الحساب أو سبب الرفض النهائي.",
      safeNextStep:
        "تحقق من تطابق بيانات الاعتماد المصرح بها وحالة الحساب من النظام المختص، ثم راجع توقيت المحاولة في السجل.",
      source: "سجل PPPoE / RouterOS",
    });
  }
  if (/pppoe.*(terminate|disconnect)|session.*(terminated|dropped)/.test(log)) {
    findings.push({
      id: "pppoe-disconnect",
      level: "warning",
      title: "انقطاع جلسة PPPoE ظاهر في السجل",
      evidence: "تم العثور على نمط إنهاء أو انقطاع جلسة في النص الملصق.",
      confidence: "medium",
      limitation:
        "لا يحدد السجل الملصق وحده إن كان السبب من CPE أو BRAS أو المسار.",
      safeNextStep:
        "رتب الأحداث زمنيًا، وقارن وقت الانقطاع بحالة الضوء والإنذارات المحفوظة قبل التصعيد.",
      source: "سجل PPPoE / RouterOS",
    });
  }
  if (/duplicate.*(mac|address)|mac.*conflict|ip.*conflict/.test(log)) {
    findings.push({
      id: "address-conflict",
      level: "warning",
      title: "مؤشر تعارض MAC أو IP ظاهر",
      evidence: "تم العثور على نمط تعارض عناوين في النص الملصق.",
      confidence: "medium",
      limitation:
        "يتطلب تأكيدًا من جدول عناوين المصدر المصرح به ولا يثبت أن الجهاز الحالي هو المسبب.",
      safeNextStep:
        "راجع جدول العناوين والسياق الزمني من النظام المصرح به، وحدد السجلين المتعارضين دون تنفيذ تغيير تلقائي.",
      source: "سجل RouterOS",
    });
  }
  return findings;
}
