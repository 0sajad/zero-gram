export const COOKIE_NAME = "app_session_id";
export const AXIOS_TIMEOUT_MS = 30_000;
export const NOT_ADMIN_ERR_MSG = "You do not have required permission (10002)";
