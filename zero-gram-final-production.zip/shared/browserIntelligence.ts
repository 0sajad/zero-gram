export type EvidenceState =
  | "Measured"
  | "Detected"
  | "Calculated"
  | "Estimated"
  | "Unavailable";

export type BrowserValue<T> = {
  value: T | null;
  state: EvidenceState;
  source: string;
  limitation?: string;
};

export function browserValue<T>(
  value: T | null,
  state: EvidenceState,
  source: string,
  limitation?: string
): BrowserValue<T> {
  return { value, state, source, limitation };
}

export function scoreQuality(input: {
  downloadMbps?: number | null;
  uploadMbps?: number | null;
  latencyMs?: number | null;
  jitterMs?: number | null;
  packetLossPercent?: number | null;
  downloadConsistency?: number | null;
  uploadConsistency?: number | null;
}) {
  const parts: number[] = [];
  if (input.downloadMbps !== null && input.downloadMbps !== undefined)
    parts.push(Math.min(100, input.downloadMbps));
  if (input.uploadMbps !== null && input.uploadMbps !== undefined)
    parts.push(Math.min(100, input.uploadMbps * 2));
  if (input.latencyMs !== null && input.latencyMs !== undefined)
    parts.push(Math.max(0, 100 - input.latencyMs));
  if (input.jitterMs !== null && input.jitterMs !== undefined)
    parts.push(Math.max(0, 100 - input.jitterMs * 2));
  if (input.packetLossPercent !== null && input.packetLossPercent !== undefined)
    parts.push(Math.max(0, 100 - input.packetLossPercent * 10));
  if (
    input.downloadConsistency !== null &&
    input.downloadConsistency !== undefined
  )
    parts.push(input.downloadConsistency);
  if (input.uploadConsistency !== null && input.uploadConsistency !== undefined)
    parts.push(input.uploadConsistency);
  return parts.length
    ? Math.round(parts.reduce((sum, value) => sum + value, 0) / parts.length)
    : null;
}

export function qualityLabel(score: number | null) {
  if (score === null) return "Unavailable";
  if (score >= 90) return "Excellent";
  if (score >= 75) return "Good";
  if (score >= 55) return "Fair";
  return "Needs review";
}

export function compareMetric(current: number | null, baseline: number | null) {
  if (current === null || baseline === null || baseline === 0) return null;
  return ((current - baseline) / Math.abs(baseline)) * 100;
}

export type CapabilityStatus =
  | "Supported"
  | "Not Supported"
  | "Permission Required"
  | "Unavailable";

export function capabilityStatus(
  value: boolean | null,
  permission = false
): CapabilityStatus {
  if (permission) return "Permission Required";
  if (value === null) return "Unavailable";
  return value ? "Supported" : "Not Supported";
}

export function browserError(message: string, source = "Browser runtime") {
  const lower = message.toLowerCase();
  if (lower.includes("permission") || lower.includes("notallowed"))
    return browserValue(null, "Unavailable", source, "Permission is required.");
  if (
    lower.includes("cors") ||
    lower.includes("security") ||
    lower.includes("failed to fetch")
  )
    return browserValue(
      null,
      "Unavailable",
      source,
      "Browser security restrictions prevented this diagnostic."
    );
  return browserValue(null, "Unavailable", source, message);
}
