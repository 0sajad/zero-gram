export const visualModes = ["original", "color", "white", "black"] as const;
export type VisualMode = (typeof visualModes)[number];

export function resolveConsoleVisualMode({
  visualMode,
  darkMode,
  systemTheme,
  systemPrefersDark,
}: {
  visualMode: VisualMode;
  darkMode: boolean;
  systemTheme: boolean;
  systemPrefersDark: boolean;
}) {
  const dark =
    visualMode === "white"
      ? false
      : visualMode === "black" || visualMode === "color"
        ? true
        : systemTheme
          ? systemPrefersDark
          : darkMode;

  return {
    dark,
    classes: {
      light: visualMode === "white",
      black: visualMode === "black",
      color: visualMode === "color",
      original: visualMode === "original",
    },
  };
}
