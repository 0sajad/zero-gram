export type FunState =
  | "Measured"
  | "Detected"
  | "Calculated"
  | "Unavailable"
  | "Simulation";
export type Symptom =
  | "slow"
  | "offline"
  | "high_latency"
  | "disconnects"
  | "wifi_weak"
  | "dns"
  | "below_package"
  | "stuck_100";
export type Metrics = {
  downloadMbps?: number | null;
  uploadMbps?: number | null;
  latencyMs?: number | null;
  jitterMs?: number | null;
  packetLossPercent?: number | null;
  dnsMs?: number | null;
  stabilityScore?: number | null;
  packageMbps?: number | null;
  online?: boolean | null;
  ipv4?: boolean | null;
  ipv6?: boolean | null;
  isp?: string | null;
  asn?: string | null;
  publicIp?: string | null;
  connectionType?: string | null;
};
export type Evidence = {
  metric: string;
  value: string;
  state: FunState;
  note: string;
};
export type Suspect = {
  name: "DNS" | "Wi-Fi" | "Ethernet" | "ISP" | "User Configuration";
  probability: number;
  reason: string;
};

const available = (value: unknown) => value !== null && value !== undefined;
const percent = (value: number) =>
  Math.max(0, Math.min(100, Math.round(value)));
export const evidenceFrom = (metrics: Metrics): Evidence[] => [
  available(metrics.downloadMbps)
    ? {
        metric: "Download",
        value: `${metrics.downloadMbps} Mbps`,
        state: "Measured",
        note: "HTTP browser session",
      }
    : {
        metric: "Download",
        value: "Not Available",
        state: "Unavailable",
        note: "No completed speed record",
      },
  available(metrics.latencyMs)
    ? {
        metric: "Latency",
        value: `${metrics.latencyMs} ms`,
        state: "Measured",
        note: "Browser fetch timing; not ICMP",
      }
    : {
        metric: "Latency",
        value: "Not Available",
        state: "Unavailable",
        note: "No latency record",
      },
  available(metrics.jitterMs)
    ? {
        metric: "Jitter",
        value: `${metrics.jitterMs} ms`,
        state: "Calculated",
        note: "Derived from timing samples",
      }
    : {
        metric: "Jitter",
        value: "Not Available",
        state: "Unavailable",
        note: "Insufficient samples",
      },
  available(metrics.packetLossPercent)
    ? {
        metric: "Packet loss",
        value: `${metrics.packetLossPercent}%`,
        state: "Calculated",
        note: "Fetch sample failure ratio; not ICMP",
      }
    : {
        metric: "Packet loss",
        value: "Not Available",
        state: "Unavailable",
        note: "No stability sample",
      },
  available(metrics.dnsMs)
    ? {
        metric: "DNS",
        value: `${metrics.dnsMs} ms`,
        state: "Measured",
        note: "Allowed public DNS request",
      }
    : {
        metric: "DNS",
        value: "Not Available",
        state: "Unavailable",
        note: "No DNS sample",
      },
];

export function suspects(symptoms: Symptom[], metrics: Metrics): Suspect[] {
  const weights = {
    DNS: 0,
    "Wi-Fi": 0,
    Ethernet: 0,
    ISP: 0,
    "User Configuration": 0,
  };
  symptoms.forEach(symptom => {
    if (symptom === "dns") weights.DNS += 7;
    if (symptom === "wifi_weak") weights["Wi-Fi"] += 9;
    if (symptom === "stuck_100") weights.Ethernet += 10;
    if (symptom === "slow" || symptom === "below_package") weights.ISP += 4;
    if (symptom === "offline" || symptom === "disconnects")
      weights["User Configuration"] += 2;
    if (symptom === "high_latency") weights.ISP += 5;
  });
  if (available(metrics.dnsMs) && (metrics.dnsMs as number) > 180)
    weights.DNS += 8;
  if (
    available(metrics.packetLossPercent) &&
    (metrics.packetLossPercent as number) > 2
  )
    weights.ISP += 7;
  if (available(metrics.latencyMs) && (metrics.latencyMs as number) > 120)
    weights.ISP += 7;
  if (metrics.online === false) weights["User Configuration"] += 5;
  const entries = Object.entries(weights) as Array<[Suspect["name"], number]>;
  const total = entries.reduce((sum, [, weight]) => sum + weight, 0);
  return entries
    .map(([name, weight]) => ({
      name,
      probability: total ? percent((weight / total) * 100) : 0,
      reason:
        name === "Ethernet"
          ? "Check cable condition, negotiation speed and interface errors."
          : name === "Wi-Fi"
            ? "Check signal, channel congestion, distance, and client density."
            : name === "DNS"
              ? "Check resolver availability and resolution timing."
              : name === "ISP"
                ? "Check latency, loss, service status, and package performance."
                : "Check local connection state and device configuration.",
    }))
    .sort((a, b) => b.probability - a.probability);
}

export function diagnosis(symptoms: Symptom[], metrics: Metrics) {
  const evidence = evidenceFrom(metrics).filter(
    item => item.state !== "Unavailable"
  );
  const ranked = suspects(symptoms, metrics);
  const prime = ranked[0];
  const hasSignal = evidence.length > 0 || symptoms.length > 0;
  const confidence = hasSignal
    ? percent(
        Math.min(
          82,
          evidence.length * 12 +
            symptoms.length * 9 +
            (prime?.probability || 0) * 0.45
        )
      )
    : 0;
  const checks = [
    "Check connection status.",
    "Check gateway reachability.",
    "Check DNS resolution.",
    "Check interface state.",
  ];
  return {
    evidence,
    suspects: ranked,
    confidence,
    likelyCause:
      !hasSignal || !prime || prime.probability === 0
        ? "Insufficient Evidence"
        : `${prime.name} is currently the prime suspect.`,
    checks,
    finalVerdict:
      confidence < 30
        ? "Insufficient Evidence"
        : `${prime.name} is currently the prime suspect.`,
  };
}

export function health(metrics: Metrics) {
  const components: number[] = [];
  if (available(metrics.latencyMs))
    components.push(
      percent(100 - Math.max(0, ((metrics.latencyMs as number) - 20) * 0.45))
    );
  if (available(metrics.jitterMs))
    components.push(percent(100 - (metrics.jitterMs as number) * 2));
  if (available(metrics.packetLossPercent))
    components.push(percent(100 - (metrics.packetLossPercent as number) * 20));
  if (available(metrics.stabilityScore))
    components.push(percent(metrics.stabilityScore as number));
  if (metrics.online === false) components.push(0);
  const score = components.length
    ? Math.round(
        components.reduce((sum, value) => sum + value, 0) / components.length
      )
    : null;
  const disaster =
    score === null
      ? null
      : score >= 90
        ? 0
        : score >= 75
          ? 1
          : score >= 55
            ? 2
            : score >= 35
              ? 3
              : score >= 15
                ? 4
                : 5;
  return {
    score,
    disaster,
    label:
      disaster === null
        ? "Not Available"
        : [
            "Normal",
            "Minor Issue",
            "Suspicious",
            "Service Degradation",
            "Major Incident",
            "NOC Has Noticed",
          ][disaster],
    survival:
      score === null
        ? null
        : percent(score * 0.92 + (metrics.downloadMbps ? 8 : 0)),
  };
}

export function personality(metrics: Metrics) {
  if (metrics.online === false) return "The Internet has left the building.";
  if (
    available(metrics.packetLossPercent) &&
    (metrics.packetLossPercent as number) > 2
  )
    return "Some packets appear to have chosen a different career.";
  if (available(metrics.dnsMs) && (metrics.dnsMs as number) > 180)
    return "Internet exists. Names do not.";
  if (available(metrics.latencyMs) && (metrics.latencyMs as number) > 120)
    return "Speed is fine. Latency has other plans.";
  if (
    available(metrics.packageMbps) &&
    available(metrics.downloadMbps) &&
    (metrics.downloadMbps as number) < (metrics.packageMbps as number) * 0.7
  )
    return "Bandwidth is currently taking the scenic route.";
  return "Network is behaving unusually well.";
}

export function roast(metrics: Metrics) {
  if (!available(metrics.downloadMbps) && !available(metrics.latencyMs))
    return "No measured connection result yet — even the roast needs evidence.";
  if (
    available(metrics.packetLossPercent) &&
    (metrics.packetLossPercent as number) > 2
  )
    return "Your packets are exploring alternative career paths.";
  if (available(metrics.latencyMs) && (metrics.latencyMs as number) > 120)
    return "Ping is high enough to make real-time applications question their life choices.";
  if (
    available(metrics.packageMbps) &&
    available(metrics.downloadMbps) &&
    (metrics.downloadMbps as number) < (metrics.packageMbps as number) * 0.7
  )
    return "Your download speed has entered a period of deep personal reflection.";
  return "Your connection is doing surprisingly well today.";
}

export function ticketFrom(text: string, language: "ar" | "iq" | "en") {
  const lower = text.toLowerCase();
  const intermittent = /يقطع|disconnect|intermittent/.test(lower);
  const dns = /dns|اسم|names/.test(lower);
  const slow = /بطي|slow|speed/.test(lower);
  const title = intermittent
    ? "Intermittent Internet Connectivity"
    : dns
      ? "DNS Resolution Issue"
      : slow
        ? "Reduced Internet Performance"
        : "Network Connectivity Investigation";
  return language === "ar"
    ? {
        title,
        description: intermittent
          ? "لوحظ انقطاع متكرر في الاتصال أثناء الاستخدام المعتاد."
          : dns
            ? "لوحظت صعوبة في حل أسماء النطاقات."
            : "ورد وصف لحالة اتصال تتطلب التحقق.",
        checks: ["Latency", "Packet Loss", "Gateway Reachability", "DNS", "Connection Stability"],
      }
    : language === "iq"
      ? {
          title,
          description: intermittent
            ? "واضح النت يقطع كل شوي أثناء الاستخدام."
            : dns
              ? "أكو مشكلة بحل أسماء المواقع."
              : "وصلنا وصف لحالة اتصال وتحتاج تدقيق.",
          checks: ["زمن الاستجابة", "فقدان الحزم", "وصول البوابة", "DNS", "استقرار الاتصال"],
        }
      : {
        title,
        description: intermittent
          ? "Intermittent connectivity observed during normal usage."
          : dns
            ? "Difficulty resolving domain names was observed."
            : "A connectivity condition requiring verification was reported.",
        checks: [
          "Latency",
          "Packet Loss",
          "Gateway Reachability",
          "DNS",
          "Connection Stability",
        ],
      };
}

export const panicFrames = [
  "CORE NETWORK · CRITICAL",
  "OLT STATUS · PANIC",
  "INTERNET · QUESTIONABLE",
  "ROOT CAUSE FOUND",
  "Ethernet Cable: Disconnected",
  "After extensive investigation, the cable was unplugged.",
] as const;
