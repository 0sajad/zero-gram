export type DashboardScoreFilter = "all" | "strong" | "watch" | "critical";
export type DashboardSourceFilter = "all" | "scored" | "raw";
export type DashboardTimeFilter = "all" | "7" | "30" | "90";

export type DashboardFilterInput = {
  id: number;
  payloadJson: string;
  createdAt: Date | number | string;
};

export type DashboardFilters = {
  query: string;
  scoreFilter: DashboardScoreFilter;
  sourceFilter: DashboardSourceFilter;
  timeFilter: DashboardTimeFilter;
  now?: number;
};

function getScore(payloadJson: string): number | undefined {
  try {
    const parsed = JSON.parse(payloadJson) as {
      diagnosis?: { netScore?: unknown };
    };
    return typeof parsed.diagnosis?.netScore === "number"
      ? parsed.diagnosis.netScore
      : undefined;
  } catch {
    return undefined;
  }
}

export function filterDashboardRows(
  rows: DashboardFilterInput[],
  filters: DashboardFilters
): DashboardFilterInput[] {
  const now = filters.now ?? Date.now();
  const query = filters.query.trim().toLowerCase();
  return rows.filter(row => {
    const score = getScore(row.payloadJson);
    const matchesQuery =
      !query || `${row.id} ${row.payloadJson}`.toLowerCase().includes(query);
    const matchesSource =
      filters.sourceFilter === "all" ||
      (filters.sourceFilter === "scored" && typeof score === "number") ||
      (filters.sourceFilter === "raw" && typeof score !== "number");
    const matchesScore =
      filters.scoreFilter === "all" ||
      (typeof score === "number" &&
        ((filters.scoreFilter === "strong" && score >= 80) ||
          (filters.scoreFilter === "watch" && score >= 50 && score < 80) ||
          (filters.scoreFilter === "critical" && score < 50)));
    const matchesTime =
      filters.timeFilter === "all" ||
      now - new Date(row.createdAt).getTime() <=
        Number(filters.timeFilter) * 86400000;
    return matchesQuery && matchesSource && matchesScore && matchesTime;
  });
}
