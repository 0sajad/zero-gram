export type ManualMonitoringState =
  | "idle"
  | "running"
  | "success"
  | "failure";

export function canRunManualMonitoring(
  profileId: number,
  state: ManualMonitoringState,
  mutationPending = false
) {
  return (
    !mutationPending &&
    state !== "running" &&
    Number.isInteger(profileId) &&
    profileId > 0
  );
}

export function manualMonitoringLabel(
  state: ManualMonitoringState,
  isArabic: boolean
) {
  if (state === "running") return isArabic ? "جارٍ الفحص" : "Checking";
  if (state === "success") return isArabic ? "اكتمل" : "Completed";
  if (state === "failure") return isArabic ? "فشل" : "Failed";
  return isArabic ? "شغّل الآن" : "Run now";
}

export function manualMonitoringStatusLabel(
  state: ManualMonitoringState,
  isArabic: boolean
) {
  if (state === "running") return isArabic ? "قيد التشغيل" : "Running";
  if (state === "success") return isArabic ? "مكتملة" : "Completed";
  if (state === "failure") return isArabic ? "فشل آخر فحص" : "Last check failed";
  return isArabic ? "جاهزة للتشغيل" : "Ready to run";
}
