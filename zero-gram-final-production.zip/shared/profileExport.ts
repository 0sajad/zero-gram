export type ProfileExportData = {
  exportedAt: string;
  userName: string;
  userEmail: string | null;
  status: "online" | "away" | "offline";
  avatarStoredLocally: boolean;
  storageScope: string;
  source: string;
};

export function buildProfileExport(
  data: ProfileExportData,
  format: "csv" | "json"
): string {
  if (format === "json") return JSON.stringify(data, null, 2);
  return [
    "field,value",
    ...Object.entries(data).map(([key, value]) =>
      `${key},${JSON.stringify(String(value ?? ""))}`
    ),
  ].join("\n");
}
